function signInUser() {
    if (window.__chatBackendUrl) {
        let unsubscribe = firebase.auth().onAuthStateChanged(function(user) {
            unsubscribe();
            if (!user) {
                let xhr = new XMLHttpRequest();
                xhr.open('GET', `${window.__chatBackendUrl}/createGuest`);
                xhr.setRequestHeader('Content-Type', 'text/plain');
                xhr.onload = function() {
                    if (xhr.responseText) {
                        let response = JSON.parse(xhr.responseText);
                        let token = response.data.success;
                        firebase.auth().signInWithCustomToken(token);
                    }
                };
                xhr.send();
            }
        });
    }
}

function isSyncFlutter() {
    return !window.location.href.includes("asyncFlutter=true");
}

function isAnalyticsDisabled() {
    return window.location.href.includes("analyticsDisabled=true");
}

function loadFlutter() {
    var script = document.createElement("script");
    script.src = "main.dart.js";
    script.fetchpriority = "high";
    document.documentElement.firstChild.appendChild(script);
}

function gtag() {
    window.dataLayer.push(arguments);
}

function initializeAnalytics(tag) {
    window.dataLayer = window.dataLayer || [];
    if (!isAnalyticsDisabled()) {
        gtag('js', new Date());
        gtag('config', tag);
        (function(w, d, s, i) {
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s);
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtag/js?id=' + i;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', tag);
    }
}

function initializeApp(options) {
    firebase.initializeApp(options);
    firebase.performance();
    firebase.analytics = function() {
        return {};
    };
    window.addEventListener("message", function(event) {
        if (event.data && event.data.action) {
            if (event.data.action === "@gr/chat/ready") {
                window.__chatBackendUrl = event.data.data.backendUrl;
                window.__chatSettings = JSON.stringify(event.data.data.settings);
                window.chatWindowInfo = {
                    width: event.data.data.windowWidth,
                    height: event.data.data.windowHeight,
                    alignment: event.data.data.alignment
                };
                if (isSyncFlutter()) signInUser();
            } else if (event.data.action === "@gr/chat/windowResize") {
                window.chatWindowInfo = {
                    width: event.data.data.windowWidth,
                    height: event.data.data.windowHeight
                };
            } else if (event.data.action === "@gr/chat/loadFlutter") {
                loadFlutter();
                signInUser();
            }
        }
    }, false);
    if (isSyncFlutter()) loadFlutter();
}