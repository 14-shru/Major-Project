(() => {
    "use strict";
    var t, e = {
        d: (t, i) => {
            for (var n in i) e.o(i, n) && !e.o(t, n) && Object.defineProperty(t, n, {
                enumerable: !0,
                get: i[n]
            })
        },
        o: (t, e) => Object.prototype.hasOwnProperty.call(t, e)
    };
    e.d({}, {
            j: () => u
        }),
        function(t) {
            t.Ready = "@gr/chat/ready", t.LoadFlutter = "@gr/chat/loadFlutter", t.WindowResize = "@gr/chat/windowResize", t.ChangeContentSize = "@gr/chat/changeContentSize", t.ChangeFullScreen = "@gr/chat/changeFullScreen", t.FormFilled = "@gr/chat/contactFormFilled", t.ApiReady = "@gr/chat/apiReady", t.RequestResult = "@gr/chat/requestResult"
        }(t || (t = {}));
    var i, n, s, o, a, l, r, d, h = function(t, e, i, n) {
        return new(i || (i = Promise))((function(s, o) {
            function a(t) {
                try {
                    r(n.next(t))
                } catch (t) {
                    o(t)
                }
            }

            function l(t) {
                try {
                    r(n.throw(t))
                } catch (t) {
                    o(t)
                }
            }

            function r(t) {
                var e;
                t.done ? s(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                    t(e)
                }))).then(a, l)
            }
            r((n = n.apply(t, e || [])).next())
        }))
    };
    class c {
        constructor(t) {
            this.apiReady = !1, this._chat = t, this.initialize()
        }
        static ready(e, i, n, s) {
            e ? window.setTimeout((() => {
                var o, a, l, r;
                c.sendMessage(e.contentWindow, {
                    action: t.Ready,
                    data: {
                        windowHeight: null !== (a = null === (o = window.visualViewport) || void 0 === o ? void 0 : o.height) && void 0 !== a ? a : window.innerHeight,
                        windowWidth: null !== (r = null === (l = window.visualViewport) || void 0 === l ? void 0 : l.width) && void 0 !== r ? r : window.innerWidth,
                        alignment: n,
                        backendUrl: i,
                        settings: s
                    }
                })
            })) : console.warn("Cannot sent event. Missing iframe")
        }
        static loadFlutter(e) {
            e ? c.sendMessage(e.contentWindow, {
                action: t.LoadFlutter,
                data: {}
            }) : console.warn("Cannot sent event. Missing iframe")
        }
        static sendMessage(t, e, i) {
            null == t || t.postMessage(e, i || "*")
        }
        _handleMessage(e) {
            const i = e.data;
            switch ((null == i ? void 0 : i.action) ? i.action : null) {
                case t.ChangeFullScreen:
                    this._chat.handleFullscreen(!0);
                    break;
                case t.ChangeContentSize:
                    const {
                        height: i,
                        width: n,
                        alignment: s
                    } = e.data.data;
                    this._chat.handleChangeSize(i, n, s);
                    break;
                case t.ApiReady:
                    this.apiReady = !0
            }
        }
        _handleResize() {
            window.clearTimeout(this.timeOutId), this.timeOutId = window.setTimeout((() => {
                var e, i, n, s;
                const o = this._chat.getIframe();
                o ? c.sendMessage(o.contentWindow, {
                    action: t.WindowResize,
                    data: {
                        windowHeight: null !== (i = null === (e = window.visualViewport) || void 0 === e ? void 0 : e.height) && void 0 !== i ? i : window.innerHeight,
                        windowWidth: null !== (s = null === (n = window.visualViewport) || void 0 === n ? void 0 : n.width) && void 0 !== s ? s : window.innerWidth
                    }
                }) : console.warn("Cannot sent event. Missing iframe")
            }), this.timeout)
        }
        initialize() {
            var t;
            window.addEventListener("message", this._handleMessage.bind(this), !1), window.addEventListener("resize", this._handleResize.bind(this), !1), null === (t = window.visualViewport) || void 0 === t || t.addEventListener("resize", this._handleResize.bind(this), !1)
        }
        sendForm(e, i, n, s) {
            return h(this, void 0, void 0, (function*() {
                if (!(yield this._chat.initializePromise)) throw Error("Chat API not available. Check integration parameters.");
                const o = this._chat.getModel(),
                    a = this._chat.getIframe();
                return this._chat.isFlutterLoaded() || this._chat.loadIFrameAndHideButton(), yield this.waitForApiReady(), c.sendMessage(a.contentWindow, {
                    action: t.FormFilled,
                    data: {
                        name: n,
                        email: e,
                        message: i,
                        phoneNumber: s,
                        isHidden: o.isHidden()
                    }
                }), this.waitForResponse(t.RequestResult, t.FormFilled)
            }))
        }
        waitForResponse(t, e) {
            return new Promise(((i, n) => {
                window.addEventListener("message", (s => {
                    const o = s.data;
                    if (((null == o ? void 0 : o.action) ? o.action : null) === t) {
                        const {
                            data: t
                        } = s.data;
                        e && t.request !== e || (t.success || t.errorCode !== u.internalError || n({
                            success: t.success,
                            errorCode: t.errorCode
                        }), i({
                            success: t.success,
                            errorCode: t.errorCode
                        }))
                    }
                }), !1)
            }))
        }
        waitForApiReady() {
            return h(this, void 0, void 0, (function*() {
                this.apiReady || (yield this.waitForResponse(t.ApiReady))
            }))
        }
    }! function(t) {
        t.Button = "ChatStartButtonShape.button", t.Sidebar = "ChatStartButtonShape.sidebar"
    }(i || (i = {})),
    function(t) {
        t.ProdSMB = "https://guest.getresponse.chat/", t.ProdMAX = "https://guest.getresponse.chat/", t.ReleaseSMB = "https://guestgrchatrelease.web.app/", t.ReleaseMAX = "https://guestgrchatrelease.web.app/", t.BetaSMB = "https://guestgrchatbeta.web.app/", t.BetaMAX = "https://guestgrchatbeta.web.app/", t.local = "http://localhost:58566/", t.androidEmulator = "http://10.0.2.2:58566/"
    }(n || (n = {})),
    function(t) {
        t.V1 = "v1", t.V2 = "v2", t.V3 = "v3", t.V4 = "v4", t.V5 = "v5", t.V6 = "v6", t.V7 = "v7", t.V8 = "v8"
    }(s || (s = {})),
    function(t) {
        t.Prod = "https://us-central1-grchat-d3548.cloudfunctions.net", t.Release = "https://us-central1-grchatrelease.cloudfunctions.net", t.Beta = "https://us-central1-grchatbeta.cloudfunctions.net", t.local = "http://localhost:5001/grchatbeta/us-central1", t.androidEmulator = "http://10.0.2.2:58566/grchatbeta/us-central1"
    }(o || (o = {})),
    function(t) {
        t.Prod = "G-PR6SN12QDF", t.Release = "G-SZ48WTL9FG", t.Beta = "G-3J1JNWWS1R"
    }(a || (a = {}));
    class m {
        constructor(t) {
            var e, i, l, r, d, h;
            if (this._uuid = m.uuidv4(), this._height = null == t ? void 0 : t.height, this._width = null == t ? void 0 : t.width, this._horizontalPadding = null !== (e = null == t ? void 0 : t.horizontalPadding) && void 0 !== e ? e : 0, this._alignment = null == t ? void 0 : t.alignment, this._isAlignmentEditable = void 0 === (null == t ? void 0 : t.alignment), this._bottom = null !== (i = null == t ? void 0 : t.bottom) && void 0 !== i ? i : 0, this._hidden = null !== (l = null == t ? void 0 : t.hidden) && void 0 !== l && l, this._analyticsDisabled = null !== (r = null == t ? void 0 : t.analyticsDisabled) && void 0 !== r && r, this._iframeUrlVariant = null !== (d = null == t ? void 0 : t.iuv) && void 0 !== d ? d : s.V1, this._urlParams = null !== (h = null == t ? void 0 : t.urlParams) && void 0 !== h ? h : null, t) {
                const e = ["urlParams", "height", "width", "horizontalPadding", "alignment", "bottom", "hidden", "analyticsDisabled", "iuv"];
                Object.keys(t).forEach((t => {
                    e.includes(t) || console.warn(`GR Chat - Unknown parameter: ${t}`)
                }))
            }
            this._iframeUrlSpecialPostfix = "#/embedded", this._iframeUrls = {
                [s.V1]: n.ProdSMB,
                [s.V2]: n.ProdMAX,
                [s.V3]: n.ReleaseSMB,
                [s.V4]: n.ReleaseMAX,
                [s.V5]: n.BetaSMB,
                [s.V6]: n.BetaMAX,
                [s.V7]: n.local,
                [s.V8]: n.androidEmulator
            }, this._backendUrls = {
                [s.V1]: o.Prod,
                [s.V2]: o.Prod,
                [s.V3]: o.Release,
                [s.V4]: o.Release,
                [s.V5]: o.Beta,
                [s.V6]: o.Beta,
                [s.V7]: o.local,
                [s.V8]: o.androidEmulator
            }, this._analyticsIds = {
                [s.V1]: a.Prod,
                [s.V2]: a.Prod,
                [s.V3]: a.Release,
                [s.V4]: a.Release,
                [s.V5]: a.Beta,
                [s.V6]: a.Beta,
                [s.V7]: a.Beta,
                [s.V8]: a.Beta
            }
        }
        static uuidv4() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(t) {
                const e = 16 * Math.random() | 0;
                return ("x" == t ? e : 3 & e | 8).toString(16)
            }))
        }
        getUuid() {
            return this._uuid
        }
        isHidden() {
            return this._hidden
        }
        isAnalyticsDisabled() {
            return this._analyticsDisabled
        }
        getSize() {
            return {
                fullscreen: this._fullscreen,
                height: this._height,
                width: this._width
            }
        }
        setSize(t, e) {
            this._height = t, this._width = e
        }
        getChatPosition() {
            return {
                isAlignmentEditable: this._isAlignmentEditable,
                alignment: this._alignment,
                horizontalPadding: this._horizontalPadding,
                bottom: this._bottom
            }
        }
        setChatPosition(t, e, i) {
            this._alignment = t, this._horizontalPadding = e, this._bottom = i
        }
        setFullscreen(t) {
            this._fullscreen = t
        }
        getUrlParams() {
            if (!this._urlParams) throw Error("Missing Url Params");
            return this._urlParams
        }
        getIframeUrlVariant() {
            if (!this._iframeUrlVariant) throw Error("No iframe url variant");
            return this._iframeUrlVariant
        }
        getIframeUrl() {
            const t = this.getIframeUrlVariant();
            return this._iframeUrls[t]
        }
        getBackendUrl() {
            const t = this.getIframeUrlVariant();
            return this._backendUrls[t]
        }
        getAnalyticsId() {
            const t = this.getIframeUrlVariant();
            return this._analyticsIds[t]
        }
        getIframeUrlSpecialPostfix() {
            if (!this._iframeUrlSpecialPostfix) throw Error("No iframe postfix");
            return this._iframeUrlSpecialPostfix
        }
        getData() {
            return {
                uuid: this.getUuid(),
                height: this.getSize().height,
                width: this.getSize().width,
                fullscreen: this.getSize().fullscreen,
                alignment: this.getChatPosition().alignment,
                horizontalPadding: this.getChatPosition().horizontalPadding,
                bottom: this.getChatPosition().bottom,
                iframeUrl: this.getIframeUrl(),
                iframeUrlParams: this.getUrlParams(),
                iframeUrlPostFix: this.getIframeUrlSpecialPostfix(),
                pageHref: window.location.href,
                pageTitle: document.title
            }
        }
    }! function(t) {
        t.BottomLeft = "bottomLeft", t.BottomRight = "bottomRight"
    }(l || (l = {})),
    function(t) {
        t.Chat = "ChatStartButtonType.chat", t.Message = "ChatStartButtonType.message", t.MessageFilled = "ChatStartButtonType.messageFilled"
    }(r || (r = {})),
    function(t) {
        t.BottomRight = "ChatStartButtonPosition.bottomRight", t.BottomLeft = "ChatStartButtonPosition.bottomLeft"
    }(d || (d = {}));
    var u;
    class g {
        constructor() {
            this.iframeElement = null, this.buildDiv(), this.buildIframe(), this.buildViewport()
        }
        static isValidUrl(t) {
            return new RegExp(/^(https?|ftp|torrent|image|irc):\/\/(-\.)?([^\s\/?\.#]+\.?)+(\/[^\s]*)?$/i).test(t)
        }
        buildDiv() {
            const t = document.createElement("div");
            t.id = "grchat-button", t.style.display = "block", t.style.margin = "0", t.style.padding = "0", t.ontouchstart = () => {}, document.body.appendChild(t), this.divElement = t
        }
        buildIframe() {
            const t = document.createElement("iframe");
            t.name = "gr-chat-iframe", t.style.all = "initial", t.style.width = "100%", t.style.height = "100%", t.style.border = "none", t.style.display = "none", this.iframeElement = t
        }
        buildViewport() {
            const t = document.createElement("meta");
            t.name = "viewport", t.content = "width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0", this.viewportElement = t
        }
        initializeAnalytics(t) {
            this._initializeAnalytics = this.loadAnalytics(t, "grChatDataLayer")
        }
        applyChanges(t, e) {
            var n, s;
            const o = t.getData();
            this.applySizeChange(o.width, o.height, o.fullscreen), this.applyUUIDChange(o.uuid);
            const a = e.chatStartButtonPosition.replace("ChatStartButtonPosition.", ""),
                l = null !== (n = e.chatStartButtonShape) && void 0 !== n ? n : i.Button;
            this.applyPositionChange(o.horizontalPadding, l, null !== (s = o.alignment) && void 0 !== s ? s : a, o.bottom), t.isHidden() || this.applySourceChange(t, e, !0, !0), this.buttonElement && (this.buttonElement.onclick = () => {
                this.openChat(), this.sendEvent("chat_window_opened", {
                    type: "clicked"
                })
            })
        }
        openChat() {
            return !this.isButtonHidden() && (this.hideButton(), this.showIframe(), this.flutterLoaded || (this.flutterLoaded = !0, c.loadFlutter(this.iframeElement)), !0)
        }
        applyPositionChange(t, e, n, s) {
            if (this.isInFullscreenMode()) return;
            const o = e === i.Button ? t : 0;
            if (Object.assign(this.divElement.style, {
                    bottom: `${s}px`,
                    left: n === l.BottomLeft ? `${o}px` : null,
                    right: n === l.BottomRight ? `${o}px` : null,
                    position: "fixed",
                    zIndex: 2e9
                }), this.buttonElement) {
                const t = e === i.Button ? "23px" : 0;
                Object.assign(this.buttonElement.style, {
                    marginLeft: n === l.BottomLeft ? t : null,
                    marginRight: n === l.BottomRight ? t : null,
                    flexDirection: e === i.Sidebar ? n === l.BottomLeft ? "row-reverse" : "row" : n === l.BottomLeft ? "row" : "row-reverse"
                })
            }
        }
        applySizeChange(t, e, i) {
            var n, s;
            i ? (this.isInFullscreenMode() || (this.originalBodyStyle = window.document.body.getAttribute("style"), window.document.body.setAttribute("style", "min-width: 400px; overflow: hidden; position: fixed; top: 0px; left: 0px; bottom: 0px; right: 0px;"), this.originalDocumentStyle = window.document.documentElement.getAttribute("style"), window.document.documentElement.setAttribute("style", "overflow: hidden; margin: 0px;"), this.fixViewport()), this.divElement.style.width = "100%", this.divElement.style.height = "100%", this.divElement.style.minHeight = "-webkit-fill-available", this.divElement.style.maxWidth = "100%", this.divElement.style.maxHeight = "100%", this.divElement.style.top = "0px", this.divElement.style.left = "0px", this.divElement.style.right = "0px", this.divElement.style.bottom = "0px", this.iframeElement.contentWindow.focus()) : (this.isInFullscreenMode() && (window.document.body.setAttribute("style", null !== (n = this.originalBodyStyle) && void 0 !== n ? n : ""), window.document.documentElement.setAttribute("style", null !== (s = this.originalDocumentStyle) && void 0 !== s ? s : ""), this.restoreViewport()), this.divElement.style.width = t ? `${t}px` : void 0, this.divElement.style.height = e ? `${e}px` : void 0, this.divElement.style.removeProperty("min-height"), this.divElement.style.maxWidth = t ? `${t}px` : void 0, this.divElement.style.maxHeight = e ? `${e}px` : void 0, this.divElement.style.top = "")
        }
        isInFullscreenMode() {
            return "100%" === this.divElement.style.width
        }
        applySourceChange(t, e, i, n) {
            const s = e.settings;
            e.settings = void 0;
            const o = `${t.getIframeUrl()}?data=${encodeURIComponent(JSON.stringify(e))}&isHidden=${t.isHidden()}&analyticsDisabled=${t.isAnalyticsDisabled()}&open=${i}&asyncFlutter=${n}${t.getIframeUrlSpecialPostfix()}`;
            g.isValidUrl(o) ? (t.isHidden() && (this.divElement.style.display = "none"), this.divElement.appendChild(this.iframeElement), this.iframeElement.onload = c.ready.bind(this, this.iframeElement, t.getBackendUrl(), t.getChatPosition().alignment, s), this.iframeElement.src = o, n || (this.flutterLoaded = !0)) : console.error("Invalid URL :: ", o)
        }
        applyUUIDChange(t) {
            this.iframeElement.id = t
        }
        initializeView(t, e) {
            e.showButton && !t.isHidden() && (e.errorTitle && e.errorMessage ? this.showErrorMessage(e.errorTitle, e.errorMessage) : this.buildButton(e, t.getChatPosition().alignment)), this.applyChanges(t, e)
        }
        isButtonHidden() {
            return !this.buttonElement || "none" === this.buttonElement.style.display
        }
        hideButton() {
            this.buttonElement && (this.buttonElement.style.display = "none")
        }
        showIframe() {
            this.iframeElement.style.display = "block", this.iframeElement.contentWindow.focus()
        }
        static getSafeColor(t) {
            return t.includes("#") ? t : `#${t}`
        }
        buildButton(t, e) {
            const n = document.createElement("button");
            this.divElement.appendChild(n), n.insertAdjacentHTML("beforeend", function(t) {
                switch (t) {
                    case r.Chat:
                        return '<svg width="24" height="24" viewBox=\'0 0 24 24\' xmlns="http://www.w3.org/2000/svg"><g fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path d="m4.3 12h-1.1a2.19 2.19 0 0 1 -2.2-2.2v-6.6a2.19 2.19 0 0 1 2.2-2.2h11a2.19 2.19 0 0 1 2.2 2.2v6.6a2.19 2.19 0 0 1 -2.2 2.2h-5"/><path d="m4.3 12v3.78"/><path d="m4.3 15.78 4.88-3.78"/><path d="m7.6 13.22v3.78a2.19 2.19 0 0 0 2.2 2.2h5"/><path d="m19.7 19.22h1.1a2.19 2.19 0 0 0 2.2-2.22v-6.6a2.2 2.2 0 0 0 -2.2-2.2h-4.4"/><path d="m19.7 19.22v3.78"/><path d="m19.7 23-4.88-3.78"/></g></svg>';
                    case r.Message:
                        return '<svg width="21" height="21" viewBox=\'0 0 21 21\' xmlns="http://www.w3.org/2000/svg"><g fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path d="m5 14.4h-1.32a2.68 2.68 0 0 1 -2.68-2.68v-8a2.68 2.68 0 0 1 2.68-2.72h13.4a2.68 2.68 0 0 1 2.68 2.68v8a2.68 2.68 0 0 1 -2.68 2.68h-6.08"/><path d="m5.02 14.4v4.6"/><path d="m5.02 19 5.94-4.6"/></g></svg>';
                    case r.MessageFilled:
                        return '<svg width="21" height="20" viewBox=\'0 0 21 20\' xmlns="http://www.w3.org/2000/svg"><path d="m17.08 0h-13.4a3.68 3.68 0 0 0 -3.68 3.68v8a3.68 3.68 0 0 0 3.68 3.72h.32v3.6s0 .08 0 .12a.73.73 0 0 0 0 .2 1 1 0 0 0 .08.18s0 .08.06.11 0 0 0 0a.79.79 0 0 0 .25.19.71.71 0 0 0 .09.07 1.12 1.12 0 0 0 .52.13 1.15 1.15 0 0 0 .36-.07l.11-.06a.64.64 0 0 0 .14-.08l5.69-4.39h5.78a3.68 3.68 0 0 0 3.68-3.68v-8a3.68 3.68 0 0 0 -3.68-3.72z" fill="#000000"/></svg>'
                }
            }(t.chatStartButton).replace(/#000000/g, g.getSafeColor(t.textColorHex)));
            const s = n.getElementsByTagName("svg")[0];
            if (s.style.all = "initial", s.style.width = "22px", s.style.height = "auto", s.style.cursor = "pointer", t.showPreChatMessage) {
                const e = document.createElement("div");
                e.style.width = "9px", n.appendChild(e);
                const i = document.createElement("span");
                i.textContent = t.headlineText, n.appendChild(i)
            }
            n.style.all = "initial", n.style.display = "flex", n.style.cursor = "pointer", n.style.alignItems = "center", n.style.backgroundColor = g.getSafeColor(t.mainChatColorHex), n.style.color = g.getSafeColor(t.textColorHex), n.style.fontSize = "16px", n.style.fontFamily = '".AppleSystemUIFont", -apple-system, BlinkMacSystemFont, sans-serif', n.style.padding = "15px", n.style.borderWidth = "0px", n.style.marginBottom = "20px";
            const o = e ? this.alignmentToChatPosition(e) : t.chatStartButtonPosition;
            t.chatStartButtonShape === i.Sidebar ? (n.style.transform = o == d.BottomRight ? "rotate(-90deg) translateX(100%)" : "rotate(90deg) translateX(-100%)", n.style.transformOrigin = o == d.BottomRight ? "bottom right" : "bottom left", s.style.transform = o == d.BottomRight ? "rotate(90deg)" : "rotate(-90deg)", n.style.borderRadius = "10px 10px 0 0") : (n.style.borderRadius = "25px", n.style.boxShadow = "0 4px 8px 0 rgba(0,0,0,0.2)"), this.buttonElement = n
        }
        isFlutterLoaded() {
            return this.flutterLoaded
        }
        getIframe() {
            return this.iframeElement
        }
        fixViewport() {
            this.originalViewportElement = document.querySelector("meta[name=viewport]"), this.originalViewportElement && this.originalViewportElement.remove(), document.getElementsByTagName("head")[0].appendChild(this.viewportElement)
        }
        alignmentToChatPosition(t) {
            switch (t) {
                case l.BottomLeft:
                    return d.BottomLeft;
                case l.BottomRight:
                    return d.BottomRight
            }
        }
        restoreViewport() {
            this.viewportElement.remove(), this.originalViewportElement && document.getElementsByTagName("head")[0].appendChild(this.originalViewportElement)
        }
        showErrorMessage(t, e) {
            const n = document.createElement("div");
            this.divElement.appendChild(n), n.insertAdjacentHTML("beforeend", '<svg width="61" height="54" xmlns="http://www.w3.org/2000/svg"><path d="m27.6 2.68-26.15 45.32a3.36 3.36 0 0 0 2.91 5h52.3a3.35 3.35 0 0 0 2.9-5l-26.15-45.32a3.35 3.35 0 0 0 -5.81 0z" fill="none" stroke="#f62f37" stroke-miterlimit="10" stroke-width="2"/><path d="m30.51 16.48v16" fill="none" stroke="#f62f37" stroke-linecap="round" stroke-miterlimit="10" stroke-width="4"/><circle cx="30.42" cy="41.09" fill="#f62f37" r="3"/></svg>'), n.style.all = "initial", n.style.display = "flex", n.style.alignItems = "center", n.style.flexDirection = "row", n.style.height = "100%", n.style.padding = "0 30px 0 30px", this.divElement.style.backgroundColor = "white", this.divElement.style.borderRadius = "8px", this.divElement.style.borderStyle = "solid", this.divElement.style.borderWidth = "2px", this.divElement.style.borderColor = "#f62f37";
            const s = document.createElement("div");
            n.appendChild(s), s.style.all = "initial", s.style.display = "flex", s.style.flexDirection = "column", s.style.flex = "1", s.style.marginLeft = "30px";
            const o = document.createElement("span");
            o.style.all = "initial", o.textContent = t, o.style.fontWeight = "bold", o.style.fontSize = "14px", o.style.lineHeight = "1.7", o.style.fontFamily = '".AppleSystemUIFont", -apple-system, BlinkMacSystemFont, sans-serif';
            const a = document.createElement("span");
            a.style.all = "initial", a.textContent = e, a.style.fontSize = "14px", a.style.lineHeight = "1.7", a.style.fontFamily = '".AppleSystemUIFont", -apple-system, BlinkMacSystemFont, sans-serif', s.appendChild(o), s.appendChild(a), this.applySizeChange(420, 120, !1), this.applyPositionChange(20, i.Button, l.BottomRight, 20)
        }
        sendEvent(t, e) {
            return i = this, n = void 0, o = function*() {
                (yield this._initializeAnalytics)("event", t, e)
            }, new((s = void 0) || (s = Promise))((function(t, e) {
                function a(t) {
                    try {
                        r(o.next(t))
                    } catch (t) {
                        e(t)
                    }
                }

                function l(t) {
                    try {
                        r(o.throw(t))
                    } catch (t) {
                        e(t)
                    }
                }

                function r(e) {
                    var i;
                    e.done ? t(e.value) : (i = e.value, i instanceof s ? i : new s((function(t) {
                        t(i)
                    }))).then(a, l)
                }
                r((o = o.apply(i, n || [])).next())
            }));
            var i, n, s, o
        }
        loadAnalytics(t, e) {
            return new Promise(((i, n) => {
                window[e] = window[e] || [];
                const s = t.getAnalyticsId(),
                    o = function() {
                        window[e].push(arguments)
                    };
                if (o("js", new Date), o("config", s), t.isAnalyticsDisabled()) i(o);
                else {
                    const t = document.createElement("script");
                    t.type = "text/javascript", t.setAttribute("async", "true"), t.setAttribute("src", `https://www.googletagmanager.com/gtag/js?id=${s}&l=${e}`), t.onload = () => i(o), document.documentElement.firstChild.appendChild(t)
                }
            }))
        }
    }! function(t) {
        t[t.internalError = 1] = "internalError", t[t.emailValidation = 1e3] = "emailValidation", t[t.emptyMessage = 1001] = "emptyMessage", t[t.phoneNumberValidation = 1002] = "phoneNumberValidation", t[t.messageValidation = 1003] = "messageValidation", t[t.guestLimitExceeded = 1004] = "guestLimitExceeded"
    }(u || (u = {}));
    const p = new c(new class {
        constructor(t, e) {
            this._service = t, this._view = e, e.initializeAnalytics(this._service.getModel()), this._service.bindGrChatSizeAndPositionChanged(this.onChatSizeChanged.bind(this)), this.initializePromise = this.initialize(this._service.getModel())
        }
        initialize(t) {
            return new Promise(((e, i) => {
                const n = new XMLHttpRequest;
                n.open("POST", `${t.getBackendUrl()}/buildButton`), n.setRequestHeader("Content-Type", "text/plain"), n.onload = () => {
                    var i, s, o, a, l, r, d, h;
                    if (n.responseText) {
                        const c = JSON.parse(n.responseText);
                        if (null === (s = null === (i = c.data) || void 0 === i ? void 0 : i.error) || void 0 === s ? void 0 : s.status) {
                            e(!1);
                            const i = null === (l = null === (a = null === (o = c.data) || void 0 === o ? void 0 : o.error) || void 0 === a ? void 0 : a.data) || void 0 === l ? void 0 : l.title,
                                n = null === (h = null === (d = null === (r = c.data) || void 0 === r ? void 0 : r.error) || void 0 === d ? void 0 : d.data) || void 0 === h ? void 0 : h.message;
                            i && n && !t.isHidden() && this._view.showErrorMessage(i, n), console.error(`GR Chat - Wrong integration parameters: ${t.getUrlParams()}`), this._view.sendEvent("chat_button_hidden", {
                                hidden_reason: "wrong_parameters"
                            })
                        } else this._linkParams = c.data.success, window.innerWidth < 1024 && (this._linkParams = Object.assign(Object.assign({}, this._linkParams), this._linkParams.mobile)), this._view.initializeView(t, this._linkParams), !t.isHidden() && this._linkParams.openChatTriggerEnabled && (this._linkParams.openChatTriggerSeconds && this.openChatAfterSeconds(this._linkParams.openChatTriggerSeconds), this._linkParams.openChatTriggerScrollToBottom && this.openChatWhenScrollToBottom()), this._linkParams.showButton ? this._view.sendEvent("chat_button_shown", {}) : this._view.sendEvent("chat_button_hidden", {
                            hidden_reason: this._linkParams.analyticsReason
                        }), e(!0)
                    } else e(!1)
                }, n.onerror = () => {
                    e(!1)
                };
                const s = JSON.parse('{"' + t.getUrlParams().replace(/&/g, '","').replace(/=/g, '":"') + '"}', (function(t, e) {
                    return "" === t ? e : decodeURIComponent(e)
                }));
                s.pageHref = t.getData().pageHref, s.pageTitle = t.getData().pageTitle, s.includeButtonInformation = !0, n.send(JSON.stringify({
                    data: s
                }))
            }))
        }
        onChatSizeChanged(t, e, n, s) {
            var o, a;
            this._view.applySizeChange(t, e, n);
            const l = this._linkParams.chatStartButtonPosition.replace("ChatStartButtonPosition.", ""),
                r = null !== (o = this._linkParams.chatStartButtonShape) && void 0 !== o ? o : i.Button;
            this._view.applyPositionChange(s.horizontalPadding, r, null !== (a = s.alignment) && void 0 !== a ? a : l, s.bottom)
        }
        handleFullscreen(t) {
            this._service.updateFullscreen(t)
        }
        handleChangeSize(t, e, i) {
            this._service.updateSizeAndPosition(t, e, i)
        }
        getModel() {
            return this._service.getModel()
        }
        isFlutterLoaded() {
            return this._view.isFlutterLoaded()
        }
        getIframe() {
            return this._view.getIframe()
        }
        loadIFrameAndHideButton() {
            const t = this._service.getModel();
            this._view.hideButton(), t.isHidden() || this._view.showIframe(), this._view.applySourceChange(t, this._linkParams, !1, !1)
        }
        openChatAfterSeconds(t) {
            setTimeout((() => {
                this.autoOpenChat()
            }), 1e3 * t)
        }
        openChatWhenScrollToBottom() {
            window.document.addEventListener("scroll", (() => {
                window.innerHeight + window.scrollY >= document.body.scrollHeight - 50 && this.autoOpenChat()
            }))
        }
        autoOpenChat() {
            if (!sessionStorage.getItem("_grChatAutoOpen")) {
                const t = this._view.openChat();
                sessionStorage.setItem("_grChatAutoOpen", "true"), t && this._view.sendEvent("chat_window_opened", {
                    type: "automatically"
                })
            }
        }
    }(new class {
        constructor(t) {
            let e = {
                urlParams: null
            };
            Array.isArray(t) && t.length > 0 && (e = t[0]), this._model = new m(e)
        }
        bindGrChatSizeAndPositionChanged(t) {
            this.onGrChatSizeAndPositionChanged = t
        }
        _commitSizeAndPositionChange() {
            const t = this.getModel(),
                e = t.getSize();
            this.onGrChatSizeAndPositionChanged(e.width, e.height, e.fullscreen, t.getChatPosition())
        }
        getModel() {
            return this._model
        }
        updateFullscreen(t) {
            const e = this.getModel(),
                i = e.getSize();
            e.isHidden() ? console.log("Size not changed. Chat hidden") : i.fullscreen !== t ? (e.setFullscreen(t), this._commitSizeAndPositionChange()) : console.log("Size not changed. Values are the same")
        }
        updateSizeAndPosition(t, e, i) {
            const n = this.getModel(),
                s = n.getSize(),
                o = n.getChatPosition();
            n.isHidden() ? console.log("Size not changed. Chat hidden") : s.height !== t || s.width !== e || s.fullscreen || o.alignment !== i ? (n.setFullscreen(!1), n.setSize(t, e), o.isAlignmentEditable && void 0 !== i && o.alignment !== i && n.setChatPosition(i, o.horizontalPadding, o.bottom), this._commitSizeAndPositionChange()) : console.log("Size not changed. Values are the same")
        }
    }(window.__GrChatData__), new g));
    window.__GrChat = {
        sendForm: (t, e, i, n) => p.sendForm(t, e, i, n)
    }
})();