let VSBoxCounter = function() {
    let e = 0,
        i = [];
    return {
        set: function(t) {
            i.push({
                offset: ++e,
                ptr: t
            });
            return i[i.length - 1].offset
        },
        remove: function(e) {
            let t = i.filter(function(t) {
                return t.offset != e
            });
            i = t.splice(0)
        },
        closeAllButMe: function(e) {
            i.forEach(function(t) {
                t.offset != e && t.ptr.closeOrder()
            })
        }
    }
}();

function vanillaSelectBox(t, e) {
    let u = this;
    this.instanceOffset = VSBoxCounter.set(u);
    this.domSelector = t;
    this.root = document.querySelector(t);
    this.rootToken = null;
    this.main;
    this.button;
    this.title;
    this.isMultiple = this.root.hasAttribute("multiple");
    this.multipleSize = this.isMultiple && this.root.hasAttribute("size") ? parseInt(this.root.getAttribute("size")) : -1;
    this.isOptgroups = !1;
    this.currentOptgroup = 0;
    this.drop;
    this.top;
    this.left;
    this.options;
    this.listElements;
    this.isDisabled = !1;
    this.search = !1;
    this.searchZone = null;
    this.inputBox = null;
    this.disabledItems = [];
    this.ulminWidth = 140;
    this.ulmaxWidth = 280;
    this.ulminHeight = 25;
    this.maxOptionWidth = 1 / 0;
    this.maxSelect = 1 / 0;
    this.isInitRemote = !1;
    this.isSearchRemote = !1;
    this.onInit = null;
    this.onSearch = null;
    this.onInitSize = null;
    this.forbidenAttributes = ["class", "selected", "disabled", "data-text", "data-value", "style"];
    this.forbidenClasses = ["active", "disabled"];
    this.userOptions = {
        maxWidth: 500,
        minWidth: -1,
        maxHeight: 400,
        translations: {
            all: "All",
            items: "items",
            selectAll: "Select All",
            clearAll: "Clear All"
        },
        search: !1,
        placeHolder: "",
        stayOpen: !1,
        disableSelectAll: !1
    };
    if (e) {
        null != e.maxWidth && (this.userOptions.maxWidth = e.maxWidth);
        null != e.minWidth && (this.userOptions.minWidth = e.minWidth);
        null != e.maxHeight && (this.userOptions.maxHeight = e.maxHeight);
        if (null != e.translations)
            for (var i in e.translations) e.translations.hasOwnProperty(i) && this.userOptions.translations[i] && (this.userOptions.translations[i] = e.translations[i]);
        null != e.placeHolder && (this.userOptions.placeHolder = e.placeHolder);
        null != e.search && (this.search = e.search);
        if (null != e.remote && e.remote) {
            if (null != e.remote.onInit && "function" == typeof e.remote.onInit) {
                this.onInit = e.remote.onInit;
                this.isInitRemote = !0
            }
            if (null != e.remote.onInitSize) {
                this.onInitSize = e.remote.onInitSize;
                this.onInitSize < 3 && (this.onInitSize = 3)
            }
            if (null != e.remote.onSearch && "function" == typeof e.remote.onSearch) {
                this.onSearch = e.remote.onSearch;
                this.isSearchRemote = !0
            }
        }
        null != e.stayOpen && (this.userOptions.stayOpen = e.stayOpen);
        null != e.disableSelectAll && (this.userOptions.disableSelectAll = e.disableSelectAll);
        if (null != e.maxSelect && !isNaN(e.maxSelect) && 1 <= e.maxSelect) {
            this.maxSelect = e.maxSelect;
            this.userOptions.disableSelectAll = !0
        }
        if (null != e.maxOptionWidth && !isNaN(e.maxOptionWidth) && 20 <= e.maxOptionWidth) {
            this.maxOptionWidth = e.maxOptionWidth;
            this.ulminWidth = e.maxOptionWidth + 60;
            this.ulmaxWidth = e.maxOptionWidth + 60
        }
    }
    this.closeOrder = function() {
        var t = this;
        if (!t.userOptions.stayOpen) {
            t.drop.style.visibility = "hidden";
            if (t.search) {
                t.inputBox.value = "";
                Array.prototype.slice.call(t.listElements).forEach(function(t) {
                    t.classList.remove("hide")
                })
            }
        }
    };
    this.getCssArray = function(t) {
        let i = [];
        ".vsb-main button" === t && (i = [{
            key: "min-width",
            value: "120px"
        }, {
            key: "border-radius",
            value: "6px"
        }, {
            key: "width",
            value: "100%"
        }, {
            key: "text-align",
            value: "left"
        }, {
            key: "z-index",
            value: "1"
        }, {
            key: "color",
            value: "#333"
        }, {
            key: "background",
            value: "white !important"
        }, {
            key: "border",
            value: "1px solid #d3d3d3 !important"
        }, {
            key: "line-height",
            value: "20px"
        }, {
            key: "font-size",
            value: "14px"
        }, {
            key: "padding",
            value: "6px 12px"
        }]); {
            t = i;
            let e = "";
            t.forEach(function(t) {
                e += t.key + ":" + t.value + ";"
            });
            return e
        }
    };
    this.init = function() {
        let e = this;
        e.isInitRemote ? e.onInit("", e.onInitSize).then(function(t) {
            e.buildSelect(t);
            e.createTree()
        }) : e.createTree()
    };
    this.createTree = function() {
        this.rootToken = u.domSelector.replace(/[^A-Za-z0-9]+/, "");
        this.root.style.display = "none";
        let t = document.getElementById("btn-group-" + this.rootToken);
        t && t.remove();
        this.main = document.createElement("div");
        this.root.parentNode.insertBefore(this.main, this.root.nextSibling);
        this.main.classList.add("vsb-main");
        this.main.classList.add("bot-google-font");
        this.main.setAttribute("id", "btn-group-" + this.rootToken);
        this.main.style.marginLeft = this.main.style.marginLeft;
        u.userOptions.stayOpen && (this.main.style.minHeight = this.userOptions.maxHeight + 10 + "px");
        if (u.userOptions.stayOpen) this.button = document.createElement("div");
        else {
            this.button = document.createElement("button");
            var e = u.getCssArray(".vsb-main button");
            this.button.setAttribute("style", e);
            this.button.classList.add("bot-google-font")
        }
        this.button.style.maxWidth = this.userOptions.maxWidth + "px"; - 1 !== this.userOptions.minWidth && (this.button.style.minWidth = this.userOptions.minWidth + "px");
        this.main.appendChild(this.button);
        this.title = document.createElement("span");
        this.button.appendChild(this.title);
        this.title.classList.add("title");
        let i = document.createElement("span");
        this.button.appendChild(i);
        i.classList.add("caret");
        i.style.position = "absolute";
        i.style.right = "8px";
        i.style.marginTop = "8px";
        if (u.userOptions.stayOpen) {
            i.style.display = "none";
            this.title.style.paddingLeft = "20px";
            this.title.style.fontStyle = "italic";
            this.title.style.verticalAlign = "20%"
        }
        this.drop = document.createElement("div");
        this.main.appendChild(this.drop);
        this.drop.classList.add("vsb-menu");
        this.drop.classList.add("bot-google-font");
        this.drop.style.zIndex = 2e3 - this.instanceOffset;
        this.ul = document.createElement("ul");
        this.drop.appendChild(this.ul);
        this.ul.style.maxHeight = this.userOptions.maxHeight + "px";
        this.ul.style.minWidth = this.ulminWidth + "px";
        this.ul.style.maxWidth = this.ulmaxWidth + "px";
        this.ul.style.minHeight = this.ulminHeight + "px";
        if (this.isMultiple) {
            this.ul.classList.add("multi");
            if (!u.userOptions.disableSelectAll) {
                let t = document.createElement("option");
                t.setAttribute("value", "all");
                t.innerText = u.userOptions.translations.selectAll;
                this.root.insertBefore(t, this.root.hasChildNodes() ? this.root.childNodes[0] : null)
            }
        }
        let r = "",
            c = "",
            d = 0;
        if (this.search) {
            this.searchZone = document.createElement("div");
            this.ul.appendChild(this.searchZone);
            this.searchZone.classList.add("vsb-js-search-zone");
            this.searchZone.style.zIndex = 2001 - this.instanceOffset;
            this.inputBox = document.createElement("input");
            this.inputBox.placeholder = "Search ...";
            this.inputBox.classList.add("bot-google-font");
            this.searchZone.appendChild(this.inputBox);
            this.inputBox.setAttribute("type", "text");
            this.inputBox.setAttribute("id", "search_" + this.rootToken);
            if (this.maxOptionWidth < 1 / 0) {
                this.searchZone.style.maxWidth = u.maxOptionWidth + 30 + "px";
                this.inputBox.style.maxWidth = u.maxOptionWidth + 30 + "px"
            }
            e = document.createElement("p");
            this.ul.appendChild(e);
            e.style.fontSize = "12px";
            e.innerHTML = "&nbsp;";
            this.ul.addEventListener("scroll", function(t) {
                var e = this.scrollTop;
                u.searchZone.parentNode.style.top = e + "px"
            })
        }
        this.options = document.querySelectorAll(this.domSelector + " > option");
        Array.prototype.slice.call(this.options).forEach(function(t) {
            var e = t.textContent,
                i = t.value;
            let l, s = (t.hasAttributes() && (l = Array.prototype.slice.call(t.attributes).filter(function(t) {
                    return -1 === u.forbidenAttributes.indexOf(t.name)
                })), t.getAttribute("class")),
                a = (s = s ? s.split(" ").filter(function(t) {
                    return -1 === u.forbidenClasses.indexOf(t)
                }) : [], document.createElement("li"));
            var n = t.hasAttribute("selected"),
                t = t.hasAttribute("disabled");
            u.ul.appendChild(a);
            a.setAttribute("data-value", i);
            a.setAttribute("data-text", e);
            void 0 !== l && l.forEach(function(t) {
                a.setAttribute(t.name, t.value)
            });
            s.forEach(function(t) {
                a.classList.add(t)
            });
            if (u.maxOptionWidth < 1 / 0) {
                a.classList.add("short");
                a.style.maxWidth = u.maxOptionWidth + "px"
            }
            if (n) {
                d++;
                r += c + e;
                c = ",";
                a.classList.add("active");
                if (!u.isMultiple) {
                    u.title.textContent = e;
                    0 != s.length && s.forEach(function(t) {
                        u.title.classList.add(t)
                    })
                }
            }
            t && a.classList.add("disabled");
            a.appendChild(document.createTextNode(" " + e))
        });
        if (null !== document.querySelector(this.domSelector + " optgroup")) {
            this.isOptgroups = !0;
            this.options = document.querySelectorAll(this.domSelector + " option");
            e = document.querySelectorAll(this.domSelector + " optgroup");
            Array.prototype.slice.call(e).forEach(function(t) {
                var e = t.querySelectorAll("option");
                let i = document.createElement("li");
                var l = document.createElement("span"),
                    s = document.createElement("i");
                let a = document.createElement("b"),
                    n = t.getAttribute("data-way");
                (n = n || "closed") && ("closed" === n || "open" === n) || (n = "closed");
                i.appendChild(l);
                i.appendChild(s);
                u.ul.appendChild(i);
                i.classList.add("grouped-option");
                i.classList.add(n);
                u.currentOptgroup++;
                let o = u.rootToken + "-opt-" + u.currentOptgroup;
                i.id = o;
                i.appendChild(a);
                a.appendChild(document.createTextNode(t.label));
                i.setAttribute("data-text", t.label);
                u.ul.appendChild(i);
                Array.prototype.slice.call(e).forEach(function(t) {
                    var e = t.textContent,
                        i = t.value;
                    let l = t.getAttribute("class"),
                        s = ((l = l ? l.split(" ") : []).push(n), document.createElement("li"));
                    t = t.hasAttribute("selected");
                    u.ul.appendChild(s);
                    s.setAttribute("data-value", i);
                    s.setAttribute("data-text", e);
                    s.setAttribute("data-parent", o);
                    0 != l.length && l.forEach(function(t) {
                        s.classList.add(t)
                    });
                    if (t) {
                        d++;
                        r += c + e;
                        c = ",";
                        s.classList.add("active");
                        if (!u.isMultiple) {
                            u.title.textContent = e;
                            0 != l.length && l.forEach(function(t) {
                                u.title.classList.add(t)
                            })
                        }
                    }
                    s.appendChild(document.createTextNode(e))
                })
            })
        }
        if (-1 != u.multipleSize && d > u.multipleSize) {
            e = u.userOptions.translations.items || "items";
            r = d + " " + e
        }
        u.isMultiple && (u.title.innerHTML = r);
        "" != u.userOptions.placeHolder && "" == u.title.textContent && (u.title.textContent = u.userOptions.placeHolder);
        this.listElements = this.drop.querySelectorAll("li:not(.grouped-option)");
        u.search && u.inputBox.addEventListener("keyup", function(t) {
            let i = t.target.value.toUpperCase();
            t = i.length;
            let l = 0,
                s = 0,
                a = null;
            if (u.isSearchRemote) 0 == t ? u.remoteSearchIntegrate(null) : 3 <= t && u.onSearch(i).then(function(t) {
                u.remoteSearchIntegrate(t)
            });
            else {
                t < 3 ? Array.prototype.slice.call(u.listElements).forEach(function(t) {
                    if ("all" === t.getAttribute("data-value")) a = t;
                    else {
                        t.classList.remove("hidden-search");
                        l++;
                        s += t.classList.contains("active")
                    }
                }) : Array.prototype.slice.call(u.listElements).forEach(function(e) {
                    if ("all" !== e.getAttribute("data-value")) {
                        let t = e.getAttribute("data-text").toUpperCase();
                        if (-1 === t.indexOf(i) && "all" !== e.getAttribute("data-value")) e.classList.add("hidden-search");
                        else {
                            l++;
                            e.classList.remove("hidden-search");
                            s += e.classList.contains("active")
                        }
                    } else a = e
                });
                if (a) {
                    0 === l ? a.classList.add("disabled") : a.classList.remove("disabled");
                    if (s !== l) {
                        a.classList.remove("active");
                        a.innerText = u.userOptions.translations.selectAll;
                        a.setAttribute("data-selected", "false")
                    } else {
                        a.classList.add("active");
                        a.innerText = u.userOptions.translations.clearAll;
                        a.setAttribute("data-selected", "true")
                    }
                }
            }
        });
        if (u.userOptions.stayOpen) {
            u.drop.style.visibility = "visible";
            u.drop.style.boxShadow = "none";
            u.drop.style.minHeight = this.userOptions.maxHeight + 10 + "px";
            u.drop.style.position = "relative";
            u.drop.style.left = "0px";
            u.drop.style.top = "0px";
            u.button.style.border = "none"
        } else this.main.addEventListener("click", function(t) {
            if (!u.isDisabled) {
                u.drop.style.left = u.left + "px";
                u.drop.style.top = u.top + "px";
                u.drop.style.visibility = "visible";
                document.addEventListener("click", a);
                t.preventDefault();
                t.stopPropagation();
                u.userOptions.stayOpen || VSBoxCounter.closeAllButMe(u.instanceOffset)
            }
        });
        this.drop.addEventListener("click", function(n) {
            if (!u.isDisabled && "INPUT" !== n.target.tagName) {
                var s = "SPAN" === n.target.tagName,
                    o = "I" === n.target.tagName;
                let l = n.target.parentElement;
                if (!l.hasAttribute("data-value") && l.classList.contains("grouped-option")) {
                    if (!s && !o) return;
                    let e, i;
                    if (o) u.checkUncheckFromParent(l);
                    else {
                        if (l.classList.contains("open")) {
                            e = "open";
                            i = "closed"
                        } else {
                            e = "closed";
                            i = "open"
                        }
                        l.classList.remove(e);
                        l.classList.add(i);
                        let t = u.drop.querySelectorAll("[data-parent='" + l.id + "']");
                        t.forEach(function(t) {
                            t.classList.remove(e);
                            t.classList.add(i)
                        })
                    }
                } else {
                    var r = n.target.getAttribute("data-value"),
                        s = n.target.getAttribute("data-text");
                    let t = n.target.getAttribute("class");
                    if (!(t && -1 != t.indexOf("disabled") || t && -1 != t.indexOf("overflow"))) {
                        if ("all" === r) return n.target.hasAttribute("data-selected") && "true" === n.target.getAttribute("data-selected") ? u.setValue("none") : u.setValue("all"), void 0;
                        if (u.isMultiple) {
                            let e = !1;
                            (e = t ? -1 != t.indexOf("active") : e) ? n.target.classList.remove("active"): n.target.classList.add("active");
                            n.target.hasAttribute("data-parent") && u.checkUncheckFromChild(n.target);
                            let i = "",
                                l = "",
                                s = 0,
                                a = 0;
                            for (let t = 0; t < u.options.length; t++) {
                                a++;
                                u.options[t].value == r && (u.options[t].selected = !e);
                                if (u.options[t].selected) {
                                    s++;
                                    i += l + u.options[t].textContent;
                                    l = ","
                                }
                            }
                            if (a == s) {
                                o = u.userOptions.translations.all || "all";
                                i = o
                            } else if (-1 != u.multipleSize && s > u.multipleSize) {
                                o = u.userOptions.translations.items || "items";
                                i = s + " " + o
                            }
                            u.title.textContent = i;
                            u.checkSelectMax(s);
                            u.checkUncheckAll();
                            u.privateSendChange()
                        } else {
                            u.root.value = r;
                            u.title.textContent = s;
                            t ? u.title.setAttribute("class", t + " title") : u.title.setAttribute("class", "title");
                            Array.prototype.slice.call(u.listElements).forEach(function(t) {
                                t.classList.remove("active")
                            });
                            "" != s && n.target.classList.add("active");
                            u.privateSendChange();
                            u.userOptions.stayOpen || a()
                        }
                        n.preventDefault();
                        n.stopPropagation();
                        "" != u.userOptions.placeHolder && "" == u.title.textContent && (u.title.textContent = u.userOptions.placeHolder)
                    }
                }
            }
        });

        function a() {
            document.removeEventListener("click", a);
            u.drop.style.visibility = "hidden";
            if (u.search) {
                u.inputBox.value = "";
                Array.prototype.slice.call(u.listElements).forEach(function(t) {
                    t.classList.remove("hidden-search")
                })
            }
        }
    };
    this.init();
    this.checkUncheckAll()
}
vanillaSelectBox.prototype.buildSelect = function(t) {
    let l = this;
    if (!(null == t || t.length < 1)) {
        l.isOptgroups || (l.isOptgroups = null != t[0].parent && "" != t[0].parent);
        if (l.isOptgroups) {
            let i = {};
            (t = t.filter(function(t) {
                return null != t.parent && "" != t.parent
            })).forEach(function(t) {
                i[t.parent] || (i[t.parent] = !0)
            });
            for (let e in i) {
                let i = document.createElement("optgroup");
                i.setAttribute("label", e);
                (options = t.filter(function(t) {
                    return t.parent == e
                })).forEach(function(t) {
                    let e = document.createElement("option");
                    e.value = t.value;
                    e.text = t.text;
                    t.selected && e.setAttribute("selected", !0);
                    i.appendChild(e)
                });
                l.root.appendChild(i)
            }
        } else t.forEach(function(t) {
            let e = document.createElement("option");
            e.value = t.value;
            e.text = t.text;
            t.selected && e.setAttribute("selected", !0);
            l.root.appendChild(e)
        })
    }
};
vanillaSelectBox.prototype.remoteSearchIntegrate = function(e) {
    if (null == e || 0 == e.length) {
        let t = this.optionsCheckedToData();
        t && (e = t.slice(0));
        this.remoteSearchIntegrateIt(e)
    } else {
        let t = this.optionsCheckedToData();
        if (0 < t.length)
            for (var i = e.length - 1; 0 <= i; i--) - 1 != t.indexOf(e[i].id) && e.slice(i, 1);
        e = e.concat(t);
        this.remoteSearchIntegrateIt(e)
    }
};
vanillaSelectBox.prototype.optionsCheckedToData = function() {
    let s = this,
        t = [];
    var e = s.ul.querySelectorAll("li.active:not(.grouped-option)");
    let a = {};
    e && Array.prototype.slice.call(e).forEach(function(e) {
        let i = {
            value: e.getAttribute("data-value"),
            text: e.getAttribute("data-text"),
            selected: !0
        };
        if ("all" !== i.value) {
            if (s.isOptgroups) {
                e = e.getAttribute("data-parent");
                if (null != a[e]) i.parent = a[e];
                else {
                    let t = s.ul.querySelector("#" + e);
                    var l = t.getAttribute("data-text");
                    a[e] = l;
                    i.parent = l
                }
            }
            t.push(i)
        }
    });
    return t
};
vanillaSelectBox.prototype.removeOptionsNotChecked = function(e) {
    var i = this,
        l = i.onInitSize,
        e = null == e ? 0 : e.length,
        s = i.root.length;
    if (l < s + e) {
        var a = s + e - l - 1;
        let t = 0;
        for (var n = i.root.length - 1; 0 <= n; n--)
            if (0 == i.root.options[n].selected && t <= a) {
                t++;
                i.root.remove(n)
            }
    }
};
vanillaSelectBox.prototype.remoteSearchIntegrateIt = function(t) {
    var e = this;
    if (null != t && 0 != t.length) {
        for (; e.root.firstChild;) e.root.removeChild(e.root.firstChild);
        e.buildSelect(t);
        e.reloadTree()
    }
};
vanillaSelectBox.prototype.reloadTree = function() {
    let r = this,
        t = r.ul.querySelectorAll("li");
    if (null != t)
        for (var e = t.length - 1; 0 <= e; e--) "all" !== t[e].getAttribute("data-value") && r.ul.removeChild(t[e]);
    let c = "",
        d = "",
        u = 0;
    if (r.isOptgroups) {
        if (null !== document.querySelector(r.domSelector + " optgroup")) {
            r.options = document.querySelectorAll(this.domSelector + " option");
            var i = document.querySelectorAll(this.domSelector + " optgroup");
            Array.prototype.slice.call(i).forEach(function(t) {
                var e = t.querySelectorAll("option");
                let i = document.createElement("li");
                var l = document.createElement("span"),
                    s = document.createElement("i");
                let a = document.createElement("b"),
                    n = t.getAttribute("data-way");
                (n = n || "closed") && ("closed" === n || "open" === n) || (n = "closed");
                i.appendChild(l);
                i.appendChild(s);
                r.ul.appendChild(i);
                i.classList.add("grouped-option");
                i.classList.add(n);
                r.currentOptgroup++;
                let o = r.rootToken + "-opt-" + r.currentOptgroup;
                i.id = o;
                i.appendChild(a);
                a.appendChild(document.createTextNode(t.label));
                i.setAttribute("data-text", t.label);
                r.ul.appendChild(i);
                Array.prototype.slice.call(e).forEach(function(t) {
                    var e = t.textContent,
                        i = t.value;
                    let l = t.getAttribute("class"),
                        s = ((l = l ? l.split(" ") : []).push(n), document.createElement("li"));
                    t = t.hasAttribute("selected");
                    r.ul.appendChild(s);
                    s.setAttribute("data-value", i);
                    s.setAttribute("data-text", e);
                    s.setAttribute("data-parent", o);
                    0 != l.length && l.forEach(function(t) {
                        s.classList.add(t)
                    });
                    if (t) {
                        u++;
                        c += d + e;
                        d = ",";
                        s.classList.add("active");
                        if (!r.isMultiple) {
                            r.title.textContent = e;
                            0 != l.length && l.forEach(function(t) {
                                r.title.classList.add(t)
                            })
                        }
                    }
                    s.appendChild(document.createTextNode(e))
                })
            })
        }
        r.listElements = this.drop.querySelectorAll("li:not(.grouped-option)")
    } else {
        r.options = r.root.querySelectorAll("option");
        Array.prototype.slice.call(r.options).forEach(function(l) {
            var s = l.textContent,
                a = l.value;
            if ("all" != a) {
                let t, e = (l.hasAttributes() && (t = Array.prototype.slice.call(l.attributes).filter(function(t) {
                        return -1 === r.forbidenAttributes.indexOf(t.name)
                    })), l.getAttribute("class")),
                    i = (e = e ? e.split(" ").filter(function(t) {
                        return -1 === r.forbidenClasses.indexOf(t)
                    }) : [], document.createElement("li"));
                var n = l.hasAttribute("selected"),
                    l = l.disabled;
                r.ul.appendChild(i);
                i.setAttribute("data-value", a);
                i.setAttribute("data-text", s);
                void 0 !== t && t.forEach(function(t) {
                    i.setAttribute(t.name, t.value)
                });
                e.forEach(function(t) {
                    i.classList.add(t)
                });
                if (r.maxOptionWidth < 1 / 0) {
                    i.classList.add("short");
                    i.style.maxWidth = r.maxOptionWidth + "px"
                }
                if (n) {
                    u++;
                    c += d + s;
                    d = ",";
                    i.classList.add("active");
                    if (!r.isMultiple) {
                        r.title.textContent = s;
                        0 != e.length && e.forEach(function(t) {
                            r.title.classList.add(t)
                        })
                    }
                }
                l && i.classList.add("disabled");
                i.appendChild(document.createTextNode(" " + s))
            }
        })
    }
};
vanillaSelectBox.prototype.disableItems = function(e) {
    let i = [];
    "string" == vanillaSelectBox_type(e) && (e = e.split(","));
    "array" == vanillaSelectBox_type(e) && Array.prototype.slice.call(this.options).forEach(function(t) {
        if (-1 != e.indexOf(t.value)) {
            i.push(t.value);
            t.setAttribute("disabled", "")
        }
    });
    Array.prototype.slice.call(this.listElements).forEach(function(t) {
        var e = t.getAttribute("data-value"); - 1 != i.indexOf(e) && t.classList.add("disabled")
    })
};
vanillaSelectBox.prototype.enableItems = function(e) {
    let i = [];
    "string" == vanillaSelectBox_type(e) && (e = e.split(","));
    "array" == vanillaSelectBox_type(e) && Array.prototype.slice.call(this.options).forEach(function(t) {
        if (-1 != e.indexOf(t.value)) {
            i.push(t.value);
            t.removeAttribute("disabled")
        }
    });
    Array.prototype.slice.call(this.listElements).forEach(function(t) {
        -1 != i.indexOf(t.getAttribute("data-value")) && t.classList.remove("disabled")
    })
};
vanillaSelectBox.prototype.checkSelectMax = function(t) {
    var e = this;
    e.maxSelect != 1 / 0 && e.isMultiple && (e.maxSelect <= t ? Array.prototype.slice.call(e.listElements).forEach(function(t) {
        !t.hasAttribute("data-value") || t.classList.contains("disabled") || t.classList.contains("active") || t.classList.add("overflow")
    }) : Array.prototype.slice.call(e.listElements).forEach(function(t) {
        t.classList.contains("overflow") && t.classList.remove("overflow")
    }))
};
vanillaSelectBox.prototype.checkUncheckFromChild = function(i) {
    let l = i.getAttribute("data-parent"),
        s = document.getElementById(l);
    if (this.isMultiple) {
        i = this.drop.querySelectorAll("li");
        let t = Array.prototype.slice.call(i).filter(function(t) {
                return t.hasAttribute("data-parent") && t.getAttribute("data-parent") == l && !t.classList.contains("hidden-search")
            }),
            e = 0;
        i = t.length;
        if (0 != i) {
            t.forEach(function(t) {
                t.classList.contains("active") && e++
            });
            e !== i && 0 !== e || 0 === e ? s.classList.remove("checked") : s.classList.add("checked")
        }
    }
};
vanillaSelectBox.prototype.checkUncheckFromParent = function(i) {
    let l = i.id;
    if (this.isMultiple) {
        var s = this.drop.querySelectorAll("li");
        let t = Array.prototype.slice.call(s).filter(function(t) {
                return t.hasAttribute("data-parent") && t.getAttribute("data-parent") == l && !t.classList.contains("hidden-search")
            }),
            e = 0;
        s = t.length;
        if (0 != s) {
            t.forEach(function(t) {
                t.classList.contains("active") && e++
            });
            if (e === s || 0 === e) {
                t.forEach(function(t) {
                    var e = document.createEvent("HTMLEvents");
                    e.initEvent("click", !0, !1);
                    t.dispatchEvent(e)
                });
                0 === e ? i.classList.add("checked") : i.classList.remove("checked")
            } else {
                i.classList.remove("checked");
                t.forEach(function(t) {
                    if (!t.classList.contains("active")) {
                        var e = document.createEvent("HTMLEvents");
                        e.initEvent("click", !0, !1);
                        t.dispatchEvent(e)
                    }
                })
            }
        }
    }
};
vanillaSelectBox.prototype.checkUncheckAll = function() {
    var t = this;
    if (t.isMultiple) {
        let e = 0,
            i = 0,
            l = null;
        if (null != t.listElements) {
            Array.prototype.slice.call(t.listElements).forEach(function(t) {
                if (t.hasAttribute("data-value")) {
                    "all" === t.getAttribute("data-value") && (l = t);
                    if ("all" !== t.getAttribute("data-value") && !t.classList.contains("hidden-search") && !t.classList.contains("disabled")) {
                        i++;
                        e += t.classList.contains("active")
                    }
                }
            });
            if (l)
                if (e === i) {
                    l.classList.add("active");
                    l.innerText = t.userOptions.translations.clearAll;
                    l.setAttribute("data-selected", "true")
                } else if (0 === e) {
                t.title.textContent = t.userOptions.placeHolder;
                l.classList.remove("active");
                l.innerText = t.userOptions.translations.selectAll;
                l.setAttribute("data-selected", "false")
            }
        }
    }
};
vanillaSelectBox.prototype.setValue = function(n) {
    var t = this,
        o = t.drop.querySelectorAll("li");
    if (null == n || "" == n) t.empty();
    else if (t.isMultiple) {
        if ("string" == vanillaSelectBox_type(n))
            if ("all" === n) {
                n = [];
                Array.prototype.slice.call(o).forEach(function(t) {
                    if (t.hasAttribute("data-value")) {
                        var e = t.getAttribute("data-value");
                        if ("all" !== e) {
                            t.classList.contains("hidden-search") || t.classList.contains("disabled") || n.push(t.getAttribute("data-value"));
                            t.classList.contains("active") && (t.classList.contains("hidden-search") || t.classList.contains("disabled")) && n.push(e)
                        }
                    } else t.classList.contains("grouped-option") && t.classList.add("checked")
                })
            } else if ("none" === n) {
            n = [];
            Array.prototype.slice.call(o).forEach(function(t) {
                if (t.hasAttribute("data-value")) {
                    var e = t.getAttribute("data-value");
                    "all" !== e && t.classList.contains("active") && (t.classList.contains("hidden-search") || t.classList.contains("disabled")) && n.push(e)
                } else t.classList.contains("grouped-option") && t.classList.remove("checked")
            })
        } else n = n.split(",");
        let a = [];
        if ("array" == vanillaSelectBox_type(n)) {
            Array.prototype.slice.call(t.options).forEach(function(t) {
                if (-1 !== n.indexOf(t.value)) {
                    t.selected = !0;
                    a.push(t.value)
                } else t.selected = !1
            });
            let e = "",
                i = "",
                l = 0,
                s = 0;
            Array.prototype.slice.call(o).forEach(function(t) {
                s++;
                if (-1 != a.indexOf(t.getAttribute("data-value"))) {
                    t.classList.add("active");
                    l++;
                    e += i + t.getAttribute("data-text");
                    i = ","
                } else t.classList.remove("active")
            });
            if (s == l) {
                var r = t.userOptions.translations.all || "all";
                e = r
            } else if (-1 != t.multipleSize && l > t.multipleSize) {
                r = t.userOptions.translations.items || "items";
                e = l + " " + r
            }
            t.title.textContent = e;
            t.privateSendChange()
        }
        t.checkUncheckAll()
    } else {
        let e = !1,
            i = "";
        Array.prototype.slice.call(o).forEach(function(t) {
            if (t.getAttribute("data-value") == n) {
                t.classList.add("active");
                e = !0;
                i = t.getAttribute("data-text")
            } else t.classList.remove("active")
        });
        Array.prototype.slice.call(t.options).forEach(function(t) {
            if (t.value == n) {
                t.selected = !0;
                className = (className = t.getAttribute("class")) || ""
            } else t.selected = !1
        });
        if (e) {
            t.title.textContent = i;
            "" != t.userOptions.placeHolder && "" == t.title.textContent && (t.title.textContent = t.userOptions.placeHolder);
            "" != className ? t.title.setAttribute("class", className + " title") : t.title.setAttribute("class", "title")
        }
    }
};
vanillaSelectBox.prototype.privateSendChange = function() {
    let t = document.createEvent("HTMLEvents");
    t.initEvent("change", !0, !1);
    this.root.dispatchEvent(t)
};
vanillaSelectBox.prototype.empty = function() {
    Array.prototype.slice.call(this.listElements).forEach(function(t) {
        t.classList.remove("active")
    });
    Array.prototype.slice.call(this.options).forEach(function(t) {
        t.selected = !1
    });
    (this.title.textContent = "") != this.userOptions.placeHolder && "" == this.title.textContent && (this.title.textContent = this.userOptions.placeHolder);
    this.checkUncheckAll();
    this.privateSendChange()
};
vanillaSelectBox.prototype.destroy = function() {
    let t = document.getElementById("btn-group-" + this.rootToken);
    if (t) {
        VSBoxCounter.remove(this.instanceOffset);
        t.remove();
        this.root.style.display = "inline-block"
    }
};
vanillaSelectBox.prototype.disable = function() {
    let t = document.getElementById("btn-group-" + this.rootToken);
    if (t) {
        (button = t.querySelector("button")) && button.classList.add("disabled");
        this.isDisabled = !0
    }
};
vanillaSelectBox.prototype.enable = function() {
    let t = document.getElementById("btn-group-" + this.rootToken);
    if (t) {
        (button = t.querySelector("button")) && button.classList.remove("disabled");
        this.isDisabled = !1
    }
};
vanillaSelectBox.prototype.showOptions = function() {
    console.log(this.userOptions)
};
"remove" in Element.prototype || (Element.prototype.remove = function() {
    this.parentNode && this.parentNode.removeChild(this)
});

function vanillaSelectBox_type(t) {
    const e = Object.prototype.toString.call(t),
        i = e.replace("[object ", "").replace("]", "");
    return i.toLowerCase()
}