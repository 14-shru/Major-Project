var M0 = Object.defineProperty;
var O0 = (e, t, o) => t in e ? M0(e, t, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: o
}) : e[t] = o;
var Et = (e, t, o) => (O0(e, typeof t != "symbol" ? t + "" : t, o), o),
    Eu = (e, t, o) => {
        if (!t.has(e)) throw TypeError("Cannot " + o)
    };
var gr = (e, t, o) => (Eu(e, t, "read from private field"), o ? o.call(e) : t.get(e)),
    qi = (e, t, o) => {
        if (t.has(e)) throw TypeError("Cannot add the same private member more than once");
        t instanceof WeakSet ? t.add(e) : t.set(e, o)
    },
    Gl = (e, t, o, r) => (Eu(e, t, "write to private field"), r ? r.call(e, o) : t.set(e, o), o);
import {
    F as Jn,
    T as At,
    B as Me,
    E as A0,
    j as d,
    g as Mt,
    I as Ye,
    e as Lu,
    a as W0,
    b as se,
    p as Eo,
    c as Re,
    d as wr,
    v as Oe,
    L as th,
    A as W,
    C as Jo,
    R as Kr,
    f as D0,
    h as N0,
    i as U0,
    M as V0,
    k as aa,
    l as ba,
    m as H0,
    U as Mu,
    n as y,
    o as a,
    q as x,
    r as f,
    Z as oh,
    s as j0,
    t as P,
    u as v,
    w as z0,
    x as rh,
    y as _0,
    z as G0,
    D as Z0,
    G as q0,
    H as ir,
    J as nh,
    K as J0,
    N as Y0,
    O as X0,
    P as Ji,
    Q as ih,
    W as K0,
    S as je,
    V as so,
    X as Q0,
    Y as ef,
    _ as Ms,
    $ as tf,
    a0 as of ,
    a1 as rf,
    a2 as nf,
    a3 as ah,
    a4 as af,
    a5 as lf,
    a6 as sf,
    a7 as df,
    a8 as uf,
    a9 as cf,
    aa as hf,
    ab as mf,
    ac as bf
} from "./vendor.377da65b.js";
(function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
    new MutationObserver(i => {
        for (const n of i)
            if (n.type === "childList")
                for (const l of n.addedNodes) l.tagName === "LINK" && l.rel === "modulepreload" && r(l)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function o(i) {
        const n = {};
        return i.integrity && (n.integrity = i.integrity), i.referrerpolicy && (n.referrerPolicy = i.referrerpolicy), i.crossorigin === "use-credentials" ? n.credentials = "include" : i.crossorigin === "anonymous" ? n.credentials = "omit" : n.credentials = "same-origin", n
    }

    function r(i) {
        if (i.ep) return;
        i.ep = !0;
        const n = o(i);
        fetch(i.href, n)
    }
})();
var Yt;
(function(e) {
    e[e.Small = 0] = "Small", e[e.Medium = 1] = "Medium", e[e.Large = 2] = "Large", e[e.Custom = 3] = "Custom"
})(Yt || (Yt = {}));
var I;
(function(e) {
    e.Body = "body", e.Section = "section", e.Column = "column", e.Navbar = "wb-navbar", e.Gallery = "wb-gallery", e.Button = "wb-button", e.ColumnGroup = "wb-column-group", e.CustomHtml = "wb-custom-html", e.SocialMedia = "wb-social-media", e.Image = "wb-image", e.EnterPasswordForm = "wb-enter-password-form", e.LoginForm = "wb-login-form", e.Text = "wb-text", e.Video = "wb-video", e.Divider = "wb-divider", e.Spacer = "wb-spacer", e.Timer = "wb-timer", e.Form = "wb-form", e.Lightbox = "wb-lightbox", e.ContactForm = "wb-contact-form", e.MemberProfile = "wb-member-profile", e.RegisterForm = "wb-register-form", e.BuyButton = "wb-buy-button", e.PromoCode = "wb-promo-code", e.Webinar = "wb-webinar", e.ProductBox = "wb-product-box", e.OrderForm = "wb-order-form", e.ConfirmationPage = "wb-confirmation-page"
})(I || (I = {}));
const Oa = [{
        displayName: "Arial",
        fontStack: ["Arial", "sans-serif"]
    }, {
        displayName: "Arial Black",
        fontStack: ["Arial Black", "sans-serif"]
    }, {
        displayName: "Comic Sans MS",
        fontStack: ["Comic Sans MS", "sans-serif"]
    }, {
        displayName: "Courier New",
        fontStack: ["Courier New", "serif"]
    }, {
        displayName: "Georgia",
        fontStack: ["Georgia", "serif"]
    }, {
        displayName: "Impact",
        fontStack: ["Impact", "sans-serif"]
    }, {
        displayName: "Luicida Console",
        fontStack: ["Luicida Console", "monospace"]
    }, {
        displayName: "Luicida Sans Unicode",
        fontStack: ["Luicida Sans Unicode", "sans-serif"]
    }, {
        displayName: "Tahoma",
        fontStack: ["Tahoma", "sans-serif"]
    }, {
        displayName: "Times New Roman",
        fontStack: ["Times New Roman", "serif"]
    }, {
        displayName: "Trebuchet MS",
        fontStack: ["Trebuchet MS", "sans-serif"]
    }, {
        displayName: "Verdana",
        fontStack: ["Verdana", "sans-serif"]
    }],
    ff = [{
        displayName: "Roboto",
        fontStack: ["Roboto", "Arial", "sans-serif"]
    }, {
        displayName: "Open sans",
        fontStack: ["Open sans", "sans-serif"]
    }, {
        displayName: "Lato",
        fontStack: ["Lato", "sans-serif"]
    }, {
        displayName: "Montserrat",
        fontStack: ["Montserrat", "sans-serif"]
    }, {
        displayName: "Oswald",
        fontStack: ["Oswald", "sans-serif"]
    }, {
        displayName: "Raleway",
        fontStack: ["Raleway", "sans-serif"]
    }, {
        displayName: "Noto Sans",
        fontStack: ["Noto Sans", "sans-serif"]
    }, {
        displayName: "Ubuntu",
        fontStack: ["Ubuntu", "sans-serif"]
    }, {
        displayName: "Varela Round",
        fontStack: ["Varela Round", "sans-serif"]
    }, {
        displayName: "Montserrat Alternates",
        fontStack: ["Montserrat Alternates", "sans-serif"]
    }, {
        displayName: "Roboto Slab",
        fontStack: ["Roboto Slab", "serif"]
    }, {
        displayName: "Merriweather",
        fontStack: ["Merriweather", "serif"]
    }, {
        displayName: "Playfair Display",
        fontStack: ["Playfair Display", "serif"]
    }, {
        displayName: "Noto Serif",
        fontStack: ["Noto Serif", "serif"]
    }, {
        displayName: "Arvo",
        fontStack: ["Arvo", "serif"]
    }, {
        displayName: "Cormorant Garamond",
        fontStack: ["Cormorant Garamond", "serif"]
    }, {
        displayName: "Josefin Slab",
        fontStack: ["Josefin Slab", "serif"]
    }, {
        displayName: "Quattrocento",
        fontStack: ["Quattrocento", "serif"]
    }, {
        displayName: "Sanchez",
        fontStack: ["Sanchez", "serif"]
    }, {
        displayName: "Libre Baskerville",
        fontStack: ["Libre Baskerville", "serif"]
    }, {
        displayName: "Roboto Mono",
        fontStack: ["Roboto Mono", "monospace"]
    }, {
        displayName: "Inconsolata",
        fontStack: ["Inconsolata", "monospace"]
    }, {
        displayName: "Nova Mono",
        fontStack: ["Nova Mono", "monospace"]
    }, {
        displayName: "DM Mono",
        fontStack: ["DM Mono", "monospace"]
    }, {
        displayName: "Dancing Script",
        fontStack: ["Dancing Script", "cursive"]
    }, {
        displayName: "Pacifico",
        fontStack: ["Pacifico", "cursive"]
    }, {
        displayName: "Courgette",
        fontStack: ["Courgette", "cursive"]
    }, {
        displayName: "Sacramento",
        fontStack: ["Sacramento", "cursive"]
    }, {
        displayName: "Great Vibes",
        fontStack: ["Great Vibes", "cursive"]
    }, {
        displayName: "Cinzel Decorative",
        fontStack: ["Cinzel Decorative", "fantasy"]
    }],
    gf = Oa[0];
gf.fontStack.join(", ");
const Ur = ff[0].fontStack.join(", ");
var xr;
(function(e) {
    e.Serif = "serif", e.SansSerif = "sans-serif", e.Monospace = "monospace", e.Cursive = "cursive", e.Fantasy = "fantasy", e.SystemUi = "system-ui", e.UiSerif = "ui-serif", e.UiSansSerif = "ui-sans-serif", e.UiMonospace = "ui-monospace", e.UiRounded = "ui-rounded", e.Math = "math", e.Emoji = "emoji", e.Fangsong = "fangsong"
})(xr || (xr = {}));
Jn.Display + "", xr.Fantasy, Jn.Handwriting + "", xr.Cursive, Jn.Monospace + "", xr.Monospace, Jn.SansSerif + "", xr.SansSerif, Jn.Serif + "", xr.Serif;
var Xt;
(function(e) {
    e.Header = "section-shared-header", e.Footer = "section-shared-footer"
})(Xt || (Xt = {}));
var Ou;
(function(e) {
    e.Standard = "standard", e.ModuleSource = "module-source", e.GlobalTemplate = "global-template", e.UserTemplate = "user-template"
})(Ou || (Ou = {}));
var fa;
(function(e) {
    e[e.Background = 999988] = "Background", e[e.Default = 999989] = "Default", e[e.Top = 999990] = "Top"
})(fa || (fa = {}));
var Hr;
(function(e) {
    e[e.TopHeader = 36] = "TopHeader", e[e.Header = 30] = "Header", e[e.Subheader = 24] = "Subheader", e[e.Paragraph = 16] = "Paragraph"
})(Hr || (Hr = {}));
const Si = 1.714;
var cs;
(function(e) {
    e.Labels = "Labels", e.Fields = "Fields", e.Button = "Button", e.None = "None"
})(cs || (cs = {}));
var Ot;
(function(e) {
    e.Left = "left", e.Right = "right", e.Top = "top", e.Bottom = "bottom"
})(Ot || (Ot = {}));
var hs;
(function(e) {
    e.EN = "en", e.PL = "pl", e.FR = "fr", e.DE = "de", e.ES = "es", e.PT = "pt", e.RU = "ru", e.IT = "it", e.ZH = "zh", e.MS = "ms", e.VI = "vi", e.ID = "id", e.NL = "nl"
})(hs || (hs = {}));
I.OrderForm, I.ConfirmationPage, I.LoginForm, I.EnterPasswordForm, I.RegisterForm;
Xt.Header, Xt.Footer;
const pf = {
        $refType: "settings",
        path: "subscription.autoresponderDay"
    },
    yf = {
        $refType: "settings",
        path: "subscription.doubleOptIn"
    },
    xf = {
        $refType: "settings",
        path: "subscription.id"
    },
    vf = {
        $refType: "settings",
        path: "ecommerce.storeId"
    };
var D;
(function(e) {
    e.One = "ColorOne", e.Two = "ColorTwo", e.Three = "ColorThree", e.Four = "ColorFour", e.Five = "ColorFive"
})(D || (D = {}));
var O;
(function(e) {
    e.Palette = "palette", e.Custom = "custom"
})(O || (O = {}));
const Cf = {
        origin: O.Custom,
        value: At
    },
    wf = {
        boxShadowColor: {
            origin: O.Custom,
            value: "#000000"
        },
        boxShadowOffsetX: 0,
        boxShadowOffsetY: 4,
        boxShadowSpreadRadius: -10,
        boxShadowBlurRadius: 20,
        boxShadowOpacity: 95,
        isBoxShadowEnabled: !1
    },
    Os = {
        boxPaddingTop: 15,
        boxPaddingLeft: 25,
        boxPaddingRight: 25,
        boxPaddingBottom: 15,
        isBoxPaddingLocked: !0,
        isBoxPaddingEnabled: !1
    },
    Bf = {
        boxBorderWidthTop: 1,
        boxBorderWidthLeft: 1,
        boxBorderWidthRight: 1,
        boxBorderWidthBottom: 1,
        boxBorderStyleTop: Me.Solid,
        boxBorderStyleLeft: Me.Solid,
        boxBorderStyleRight: Me.Solid,
        boxBorderStyleBottom: Me.Solid,
        boxBorderColorTop: {
            origin: O.Palette,
            name: D.Three
        },
        boxBorderColorLeft: {
            origin: O.Palette,
            name: D.Three
        },
        boxBorderColorRight: {
            origin: O.Palette,
            name: D.Three
        },
        boxBorderColorBottom: {
            origin: O.Palette,
            name: D.Three
        },
        isBoxBorderEnabled: !1
    },
    Sf = {
        boxBorderRadiusTopLeft: 10,
        boxBorderRadiusBottomLeft: 10,
        boxBorderRadiusTopRight: 10,
        boxBorderRadiusBottomRight: 10,
        isBoxRadiusLocked: !0,
        isBoxRadiusEnabled: !1
    },
    $f = {
        boxBackgroundColor: {
            value: At,
            origin: O.Custom
        }
    },
    rt = { ...Bf,
        ...Sf,
        ...Os,
        ...wf,
        ...$f
    },
    Rf = { ...Os,
        boxPaddingTop: 10,
        boxPaddingLeft: 10,
        boxPaddingRight: 10,
        boxPaddingBottom: 10,
        isBoxPaddingEnabled: !0
    };
class wo {
    static getGoogleFontsUrl(t, o = {}) {
        const r = {
                swap: !1,
                ...o
            },
            i = this.getFontsFromWebfonts(t);
        return i.length === 0 ? null : this.url + i.map(this.getUrlFontItem).join("|") + (r.swap ? "&display=swap" : "")
    }
    static getWebfontFromFont(t) {
        const o = t.split(/,\s*/);
        return o.some(i => wo.isWebfont(i)) ? {
            displayName: o[0],
            fontStack: o
        } : null
    }
    static getUniqueWebfonts(t) {
        const o = t.map(r => r.fontStack.join(","));
        return t.filter((r, i) => o.indexOf(o[i]) === i)
    }
    static getFontsFromWebfonts(t) {
        return t.map(o => o.fontStack).reduce((o, r) => o.concat(r), []).filter((o, r, i) => i.indexOf(o) === r).filter(o => this.isWebfont(o))
    }
    static isWebfont(t) {
        return !this.excludedFamilies.includes(t) && !this.normalizedStandardFonts.includes(t.toLowerCase())
    }
    static getUrlFontItem(t) {
        return `${encodeURIComponent(t)}:400,400i,700,700i`
    }
}
Object.defineProperty(wo, "host", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: "https://fonts.bunny.net"
});
Object.defineProperty(wo, "url", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: "https://fonts.bunny.net/css?subset=cyrillic,greek,latin-ext,vietnamese&family="
});
Object.defineProperty(wo, "excludedFamilies", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: ["serif", "sans-serif", "monospace", "cursive", "fantasy", "system-ui", "ui-serif", "ui-sans-serif", "ui-monospace", "ui-rounded", "math", "emoji", "fangsong", "inherit"]
});
Object.defineProperty(wo, "normalizedStandardFonts", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Oa.map(e => e.fontStack.map(t => t.toLowerCase())).reduce((e, t) => e.concat(t), []).filter((e, t, o) => o.indexOf(e) === t)
});
class Ne extends A0 {
    static fromJson(t) {
        return super.fromJson(t, {})
    }
    constructor(t, o, r = null) {
        super(t, o, r)
    }
    stripUserInformation() {
        return this
    }
    getPlaceholders() {
        return []
    }
    getPlaceholderHandlers() {
        return {}
    }
    withPlaceholders(t) {
        const o = this.getPlaceholderHandlers();
        return t.reduce((r, i) => {
            const n = o[i.type];
            if (r.id !== i.elementId || i.value === void 0) return r;
            if (n) return r.withProperties(n.call(r, i, t));
            throw new Error(`Website element ${r.type} doesn't have handler for placeholder ${i.type}`)
        }, this)
    }
    getAssets() {
        return this.assetsService.getAllAssets()
    }
    applyPatches(t) {
        const o = this.patcherService.applyPatches(t);
        return o !== this.properties ? this.withProperties(o) : this
    }
    getFontFamilyProperties() {
        return []
    }
    getWebfonts() {
        return this.getFontFamilyProperties().reduce((t, o) => {
            const r = this.properties[o];
            if (typeof r == "string") {
                const i = wo.getWebfontFromFont(r);
                i && t.push(i)
            } else if (r !== null) throw new Error(`Font family property needs to be string ${typeof r} given`);
            return t
        }, [])
    }
}
class He {
    static fromJson(t) {
        throw new Error(`fromJson has been not implemented by ${this}. JSON: ${t};`)
    }
    constructor(t, o, r, i, n) {
        Object.defineProperty(this, "uuid", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "elementId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        }), Object.defineProperty(this, "type", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }), Object.defineProperty(this, "value", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: i
        }), Object.defineProperty(this, "properties", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: n
        })
    }
    toJSON() {
        return {
            uuid: this.uuid,
            elementId: this.elementId,
            type: this.type,
            properties: this.properties,
            value: this.value
        }
    }
}
var E;
(function(e) {
    e.SectionBackgroundImage = "sectionBackgroundImage", e.SectionForceBackgroundImage = "sectionForceBackgroundImage", e.SectionExternalBackgroundImage = "sectionExternalBackgroundImage", e.SectionForceExternalBackgroundImage = "sectionForceExternalBackgroundImage", e.SectionBackgroundVideo = "sectionBackgroundVideo", e.SectionBackgroundColor = "sectionBackgroundColor", e.ButtonHref = "buttonHref", e.ButtonText = "buttonText", e.Text = "text", e.TextColor = "textColor", e.TextList = "textList", e.TextBackgroundImage = "textBackgroundImage", e.TextForceBackgroundImage = "textForceBackgroundImage", e.TextExternalBackgroundImage = "textExternalBackgroundImage", e.TextForceExternalBackgroundImage = "textForceExternalBackgroundImage", e.TextFontSize = "textFontSize", e.TextFontFamily = "textFontFamily", e.TextBlockType = "textBlockType", e.Video = "video", e.ImageHref = "imageHref", e.ImageSource = "imageSource", e.ImageExternalSource = "imageExternalSource", e.SocialMedia = "socialMedia", e.Gallery = "gallery", e.FormSubscriptionList = "formList", e.FormRedirect = "formRedirect"
})(E || (E = {}));
var Au;
(function(e) {
    e.Default = "default", e.Header = "header", e.Footer = "footer", e.NotFoundPage = "page404", e.PasswordPage = "password", e.LoginPage = "login", e.Raw = "raw"
})(Au || (Au = {}));
class Aa extends He {
    static fromJson(t) {
        return new Aa(t.uuid, t.elementId, t.properties, t.value)
    }
    constructor(t, o, r, i) {
        super(t, o, E.ButtonHref, i, r)
    }
}
class Wa extends He {
    static fromJson(t) {
        return new Wa(t.uuid, t.elementId, t.properties, t.value)
    }
    constructor(t, o, r, i) {
        super(t, o, E.ButtonText, i, r)
    }
}
class Da extends He {
    static fromJson(t) {
        return new Da(t.uuid, t.elementId, t.properties, t.value)
    }
    constructor(t, o, r, i) {
        super(t, o, E.ImageHref, i, r)
    }
}
class Na extends He {
    static fromJson(t) {
        return new Na(t.uuid, t.elementId, t.properties, t.value)
    }
    constructor(t, o, r, i) {
        super(t, o, E.ImageSource, i, r)
    }
}
class Ua extends He {
    static fromJson(t) {
        return new Ua(t.uuid, t.elementId, t.properties, t.value)
    }
    constructor(t, o, r, i) {
        super(t, o, E.Gallery, i, r)
    }
}
class Va extends He {
    static fromJson(t) {
        return new Va(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.SectionBackgroundImage, r)
    }
}
class Ha extends He {
    static fromJson(t) {
        return new Ha(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.SectionBackgroundVideo, r)
    }
}
class ja extends He {
    static fromJson(t) {
        return new ja(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.SocialMedia, r)
    }
}
class za extends He {
    static fromJson(t) {
        return new za(t.uuid, t.elementId, t.properties, t.value)
    }
    constructor(t, o, r, i) {
        super(t, o, E.Text, i, r)
    }
}
class _a extends He {
    static fromJson(t) {
        return new _a(t.uuid, t.elementId, t.properties, t.value)
    }
    constructor(t, o, r, i) {
        super(t, o, E.Video, i, r)
    }
}
class Ga extends He {
    static fromJson(t) {
        return new Ga(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.FormSubscriptionList, r)
    }
}
class Za extends He {
    static fromJson(t) {
        return new Za(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.FormRedirect, r)
    }
}
class qa extends He {
    static fromJson(t) {
        return new qa(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextList, r)
    }
}
class Ja extends He {
    static fromJson(t) {
        return new Ja(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.SectionExternalBackgroundImage, r)
    }
}
class Ya extends He {
    static fromJson(t) {
        return new Ya(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.SectionBackgroundColor, r)
    }
}
class Xa extends He {
    static fromJson(t) {
        return new Xa(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextColor, r)
    }
}
class Ka extends He {
    static fromJson(t) {
        return new Ka(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.SectionForceBackgroundImage, r)
    }
}
class Qa extends He {
    static fromJson(t) {
        return new Qa(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.SectionForceExternalBackgroundImage, r)
    }
}
class el extends He {
    static fromJson(t) {
        return new el(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextBackgroundImage, r)
    }
}
class tl extends He {
    static fromJson(t) {
        return new tl(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextForceBackgroundImage, r)
    }
}
class ol extends He {
    static fromJson(t) {
        return new ol(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextExternalBackgroundImage, r)
    }
}
class rl extends He {
    static fromJson(t) {
        return new rl(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextForceExternalBackgroundImage, r)
    }
}
class nl extends He {
    static fromJson(t) {
        return new nl(t.uuid, t.elementId, t.properties, t.value)
    }
    constructor(t, o, r, i) {
        super(t, o, E.ImageExternalSource, i, r)
    }
}
class il extends He {
    static fromJson(t) {
        return new il(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextBlockType, r)
    }
}
class al extends He {
    static fromJson(t) {
        return new al(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextFontSize, r)
    }
}
class ll extends He {
    static fromJson(t) {
        return new ll(t.uuid, t.elementId, t.value)
    }
    constructor(t, o, r) {
        super(t, o, E.TextFontFamily, r)
    }
}
E.SectionBackgroundColor + "", E.SectionExternalBackgroundImage + "", E.ButtonHref + "", E.ButtonText + "", E.ImageHref + "", E.ImageSource + "", E.Gallery + "", E.SectionBackgroundImage + "", E.SectionBackgroundVideo + "", E.SocialMedia + "", E.Text + "", E.TextColor + "", E.Video + "", E.FormSubscriptionList + "", E.FormRedirect + "", E.TextList + "", E.SectionForceBackgroundImage + "", E.SectionForceExternalBackgroundImage + "", E.TextBackgroundImage + "", E.TextForceBackgroundImage + "", E.TextExternalBackgroundImage + "", E.TextForceExternalBackgroundImage + "", E.ImageExternalSource + "", E.TextBlockType + "", E.TextFontSize + "", E.TextFontFamily + "";

function lh(e) {
    var t;
    return (t = e ? .reduce((o, r) => {
        var i;
        const {
            text: n,
            content: l
        } = r;
        return o + ((i = n ? .length) !== null && i !== void 0 ? i : 0) + lh(l)
    }, 0)) !== null && t !== void 0 ? t : 0
}
const N = d.object({
        origin: d.valid(...Object.values(O)),
        name: d.alternatives().conditional("origin", {
            is: O.Palette,
            then: d.valid(...Object.values(D)),
            otherwise: d.forbidden()
        }),
        value: d.alternatives().conditional("origin", {
            is: O.Custom,
            then: d.string(),
            otherwise: d.forbidden()
        })
    }),
    ot = d.valid(...Object.values(Me)),
    nt = {
        boxBorderColorTop: N,
        boxBorderColorLeft: N,
        boxBorderColorRight: N,
        boxBorderColorBottom: N,
        boxBorderStyleTop: ot,
        boxBorderStyleLeft: ot,
        boxBorderStyleBottom: ot,
        boxBorderStyleRight: ot,
        boxBorderWidthTop: d.number(),
        boxBorderWidthBottom: d.number(),
        boxBorderWidthLeft: d.number(),
        boxBorderWidthRight: d.number(),
        isBoxBorderEnabled: d.boolean().allow(null),
        boxBorderRadiusTopLeft: d.number(),
        boxBorderRadiusBottomLeft: d.number(),
        boxBorderRadiusBottomRight: d.number(),
        boxBorderRadiusTopRight: d.number(),
        isBoxRadiusLocked: d.boolean(),
        isBoxRadiusEnabled: d.boolean(),
        boxBackgroundColor: N,
        boxPaddingLeft: d.number(),
        boxPaddingBottom: d.number(),
        boxPaddingRight: d.number(),
        boxPaddingTop: d.number(),
        isBoxPaddingEnabled: d.boolean(),
        isBoxPaddingLocked: d.boolean(),
        boxShadowOffsetX: d.number(),
        boxShadowOffsetY: d.number(),
        boxShadowBlurRadius: d.number(),
        boxShadowSpreadRadius: d.number(),
        boxShadowColor: N,
        boxShadowOpacity: d.number(),
        isBoxShadowEnabled: d.boolean()
    };
var Vo;
(function(e) {
    e.Absolute = "absolute", e.Relative = "relative", e.Fixed = "fixed", e.Initial = "initial", e.Static = "static", e.Sticky = "sticky"
})(Vo || (Vo = {}));
var ga;
(function(e) {
    e.Left = "left", e.Right = "right"
})(ga || (ga = {}));
var pa;
(function(e) {
    e.Top = "top", e.Bottom = "bottom"
})(pa || (pa = {}));
const As = {
    type: Vo.Relative,
    isContainer: !0,
    horizontalRelative: null,
    verticalRelative: null,
    top: null,
    left: null,
    right: null,
    bottom: null,
    width: null,
    zIndex: null
};
Vo.Absolute, ga.Left, pa.Top;
const ct = {
    elementPosition: d.object({
        type: d.string().valid(...Object.values(Vo)),
        isContainer: d.boolean(),
        horizontalRelative: d.string().valid(...Object.values(ga)).allow(null),
        verticalRelative: d.string().valid(...Object.values(pa)).allow(null),
        top: d.number().allow(null),
        left: d.number().allow(null),
        right: d.number().allow(null),
        bottom: d.number().allow(null),
        width: d.number().allow(null),
        zIndex: d.number().allow(null)
    }).allow(null)
};
var V;
(function(e) {
    e.CustomFields = "customs", e.Lps = "lps", e.Autoresponders = "autoresponders", e.GdprFields = "gdpr_fields", e.ContactLists = "contact_lists", e.Hyperlinks = "hyperlinks", e.Websites = "websites", e.StorageFiles = "storage_files", e.Pages = "pages", e.WebPush = "web_push", e.Webinars = "webinars"
})(V || (V = {}));
class bt {
    static get base() {
        return {
            [V.Lps]: [],
            [V.Autoresponders]: [],
            [V.ContactLists]: [],
            [V.CustomFields]: [],
            [V.GdprFields]: [],
            [V.Hyperlinks]: [],
            [V.Websites]: [],
            [V.StorageFiles]: [],
            [V.Pages]: [],
            [V.WebPush]: [],
            [V.Webinars]: []
        }
    }
    static getBaseAsset(t) {
        return {
            id: t
        }
    }
    static getWebsiteAsset(t) {
        return {
            websiteUuid: t.websiteUuid,
            pageUuid: t.pageUuid
        }
    }
    static getStorageAsset(t) {
        return {
            id: t.id,
            src: t.src,
            externalId: t.externalId,
            provider: t.provider,
            showPixel: t.showPixel
        }
    }
    static getStorageFileAssetFromHyperlink(t) {
        return {
            id: t.fileId,
            src: t.href
        }
    }
    static getCustomsAssets(t) {
        return t.map(o => ({
            id: o
        }))
    }
    static getUniqueAssetsByKey(t, ...o) {
        return Array.from(new Map(t.map(r => [o.map(i => r[i]).join("|"), r])).values())
    }
    static getUniqueAssetsById(t) {
        return bt.getUniqueAssetsByKey(t, "id")
    }
    static getPageAsset(t) {
        return bt.getBaseAsset(t.pageUuid)
    }
    static mergeMetaAssets(...t) {
        return t.reduce((o, r) => ({
            [V.Lps]: bt.getUniqueAssetsById([...o[V.Lps], ...r[V.Lps]]),
            [V.Autoresponders]: bt.getUniqueAssetsById([...o[V.Autoresponders], ...r[V.Autoresponders]]),
            [V.ContactLists]: bt.getUniqueAssetsById([...o[V.ContactLists], ...r[V.ContactLists]]),
            [V.CustomFields]: bt.getUniqueAssetsById([...o[V.CustomFields], ...r[V.CustomFields]]),
            [V.GdprFields]: bt.getUniqueAssetsById([...o[V.GdprFields], ...r[V.GdprFields]]),
            [V.Hyperlinks]: bt.getUniqueAssetsById([...o[V.Hyperlinks], ...r[V.Hyperlinks]]),
            [V.Websites]: bt.getUniqueAssetsByKey([...o[V.Websites], ...r[V.Websites]], "websiteUuid", "pageUuid"),
            [V.StorageFiles]: bt.getUniqueAssetsById([...o[V.StorageFiles], ...r[V.StorageFiles]]),
            [V.Pages]: bt.getUniqueAssetsById([...o[V.Pages], ...r[V.Pages]]),
            [V.WebPush]: bt.getUniqueAssetsById([...o[V.WebPush], ...r[V.WebPush]]),
            [V.Webinars]: bt.getUniqueAssetsById([...o[V.Webinars], ...r[V.Webinars]])
        }), bt.base)
    }
}
class st {
    constructor(t) {
        Object.defineProperty(this, "props", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "getAllAssetsCallbackMap", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: {
                [V.CustomFields]: this.getCustomFields.bind(this),
                [V.Lps]: this.getLandingPages.bind(this),
                [V.Autoresponders]: this.getAutoresponders.bind(this),
                [V.GdprFields]: this.getGDPRFields.bind(this),
                [V.ContactLists]: this.getContactLists.bind(this),
                [V.Hyperlinks]: this.getHyperlinks.bind(this),
                [V.Websites]: this.getWebsites.bind(this),
                [V.StorageFiles]: this.getStorageFiles.bind(this),
                [V.Pages]: this.getPages.bind(this),
                [V.WebPush]: this.getWebPush.bind(this),
                [V.Webinars]: this.getWebinar.bind(this)
            }
        })
    }
    getAllAssets() {
        return Object.keys(this.getAllAssetsCallbackMap).reduce((t, o) => ({ ...t,
            [o]: this.getAllAssetsCallbackMap[o]()
        }), st.operation.base)
    }
}
Object.defineProperty(st, "operation", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: bt
});
var k;
(function(e) {
    e[e.Web = 0] = "Web", e[e.LandingPage = 1] = "LandingPage", e[e.Email = 2] = "Email", e[e.Phone = 3] = "Phone", e[e.Protocol = 4] = "Protocol", e[e.Anchor = 5] = "Anchor", e[e.Document = 6] = "Document", e[e.Website = 7] = "Website", e[e.Internal = 8] = "Internal", e[e.SocialShare = 9] = "SocialShare", e[e.Action = 10] = "Action", e[e.SpecialPage = 11] = "SpecialPage"
})(k || (k = {}));
var Ce;
(function(e) {
    e.Self = "_self", e.Blank = "_blank"
})(Ce || (Ce = {}));
var we;
(function(e) {
    e[e.External = 0] = "External", e[e.Internal = 1] = "Internal", e[e.Login = 2] = "Login", e[e.EnterPassword = 3] = "EnterPassword", e[e.NotFound = 4] = "NotFound", e[e.Register = 5] = "Register", e[e.PopupSubmit = 6] = "PopupSubmit", e[e.Order = 7] = "Order", e[e.Confirmation = 8] = "Confirmation", e[e.ThankYou = 9] = "ThankYou"
})(we || (we = {}));
const Pf = [we.Internal, we.External],
    Ff = Object.values(we).filter(e => typeof e != "string" && !Pf.includes(e));
we.PopupSubmit;
we.Confirmation + "", we.Login + "", we.EnterPassword + "", we.NotFound + "", we.Order + "", we.PopupSubmit + "", we.Register + "", we.ThankYou + "";
class j {
    constructor() {
        Object.defineProperty(this, "registeredHyperlinks", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: new Map
        })
    }
    register(t, o) {
        this.registeredHyperlinks.set(t, o)
    }
    unregister(t) {
        this.registeredHyperlinks.delete(t)
    }
    getRegisteredData(t) {
        return this.registeredHyperlinks.get(t)
    }
    static isLandingPage(t) {
        return !!t && t.type === k.LandingPage && t.landingPageID !== null
    }
    static isWebsiteHyperlink(t) {
        return !!t && t.type === k.Website && t.websiteUuid !== null && t.pageUuid !== null
    }
    static isDocumentHyperlink(t) {
        return !!t && t.type === k.Document && t.fileId !== null
    }
    static isInternalHyperlink(t) {
        return !!t && t.type === k.Internal && t.pageUuid !== void 0
    }
    static isSpecialPageHyperlink(t) {
        return Boolean(t) && t.type === k.SpecialPage
    }
    static isAnchorHyperlink(t) {
        return !!t && t.type === k.Anchor && t.pageUuid !== void 0 && t.sectionId !== void 0
    }
    static isExternalPageHyperlink(t) {
        return Boolean(t) && "href" in t && t.href === void 0
    }
    static isActionHyperlink(t) {
        return t ? .type === k.Action
    }
    static createDefaultHyperlink(t = k.Web) {
        return j.createHyperlinkFactory[t](t)
    }
    static createCommonHyperlink(t) {
        return {
            id: Mt(),
            type: t,
            target: Ce.Blank,
            href: ""
        }
    }
    static createLandingPageHyperlink() {
        return { ...j.createCommonHyperlink(k.LandingPage),
            landingPageID: null
        }
    }
    static createWebsiteHyperlink() {
        return { ...j.createCommonHyperlink(k.Website),
            websiteUuid: null,
            pageUuid: null
        }
    }
    static createDocumentHyperlink() {
        return { ...j.createCommonHyperlink(k.Document),
            fileId: null,
            fileName: null
        }
    }
    static createInternalHyperlink() {
        return { ...j.createCommonHyperlink(k.Internal),
            href: "/",
            pageUuid: null,
            target: Ce.Self
        }
    }
    static createAnchorHyperlink() {
        return { ...j.createCommonHyperlink(k.Anchor),
            pageUuid: null,
            sectionId: Xt.Header,
            href: "/",
            target: Ce.Self
        }
    }
    static createActionHyperlink() {
        return { ...j.createCommonHyperlink(k.Action),
            action: null,
            href: "#",
            target: Ce.Self
        }
    }
    static createSpecialPageHyperlink() {
        return { ...j.createCommonHyperlink(k.SpecialPage),
            pageType: we.NotFound,
            href: "",
            target: Ce.Self
        }
    }
    static createExternalPageHyperlink(t) {
        const {
            href: o,
            ...r
        } = t;
        return r
    }
    static createTextHyperlink(t) {
        var o, r, i;
        if (!t) return j.createDefaultHyperlink();
        const n = j.createDefaultHyperlink((o = t.type) !== null && o !== void 0 ? o : k.Web);
        return { ...n,
            id: (r = t.uniqueId) !== null && r !== void 0 ? r : n.id,
            target: t.isNewTab ? Ce.Blank : Ce.Self,
            href: (i = t.url) !== null && i !== void 0 ? i : n.href,
            ...t.data
        }
    }
    static createProtocolHyperlink() {
        return { ...j.createCommonHyperlink(k.Protocol),
            target: Ce.Self
        }
    }
}
Object.defineProperty(j, "createHyperlinkFactory", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: {
        [k.Web]: j.createCommonHyperlink,
        [k.Email]: j.createCommonHyperlink,
        [k.Phone]: j.createCommonHyperlink,
        [k.Protocol]: j.createProtocolHyperlink,
        [k.SocialShare]: j.createCommonHyperlink,
        [k.LandingPage]: j.createLandingPageHyperlink,
        [k.Website]: j.createWebsiteHyperlink,
        [k.Document]: j.createDocumentHyperlink,
        [k.Internal]: j.createInternalHyperlink,
        [k.Anchor]: j.createAnchorHyperlink,
        [k.Action]: j.createActionHyperlink,
        [k.SpecialPage]: j.createSpecialPageHyperlink
    }
});
class _e extends st {
    constructor(t, o = []) {
        super(t), Object.defineProperty(this, "props", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "imageProps", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    getCustomFields() {
        return []
    }
    getLandingPages() {
        return []
    }
    getAutoresponders() {
        return []
    }
    getGDPRFields() {
        return []
    }
    getContactLists() {
        return []
    }
    getHyperlinks() {
        return []
    }
    getWebsites() {
        return []
    }
    getWebPush() {
        return []
    }
    getWebinar() {
        return []
    }
    getStorageFiles() {
        const {
            props: t,
            imageProps: o
        } = this, r = [];
        for (const i of o) {
            const n = t[i];
            n ? .type === Ye.Storage && r.push(bt.getStorageAsset(n.data))
        }
        return r
    }
    getPages() {
        return []
    }
}
class he {
    static getHyperlinkAssets(t) {
        return t ? [{ ...t
        }] : []
    }
    static getDocumentAssets(t) {
        return j.isDocumentHyperlink(t) ? [st.operation.getStorageFileAssetFromHyperlink(t)] : []
    }
    static updateDocument(t, o) {
        var r, i;
        return j.isDocumentHyperlink(t) && t.fileId === o.getId() ? { ...t,
            href: (i = (r = o.getData()) === null || r === void 0 ? void 0 : r.src) !== null && i !== void 0 ? i : t.href
        } : t
    }
    static deleteDocument(t, o) {
        return j.isDocumentHyperlink(t) && t.fileId === o.getId() ? null : t
    }
    static getLandingPageAssets(t) {
        return j.isLandingPage(t) ? [st.operation.getBaseAsset(t.landingPageID)] : []
    }
    static updateLandingPage(t, o) {
        var r, i;
        return j.isLandingPage(t) && t.landingPageID === o.getId() ? { ...t,
            href: (i = (r = o.getData()) === null || r === void 0 ? void 0 : r.url) !== null && i !== void 0 ? i : t.href
        } : t
    }
    static deleteLandingPage(t, o) {
        return j.isLandingPage(t) && t.landingPageID === o.getId() ? null : t
    }
    static getWebsitesAssets(t) {
        return j.isWebsiteHyperlink(t) ? [st.operation.getWebsiteAsset(t)] : []
    }
    static updateWebsites(t, o) {
        var r, i;
        const {
            websiteUuid: n,
            pageUuid: l
        } = o.getId();
        return j.isWebsiteHyperlink(t) && t.websiteUuid === n && t.pageUuid === l ? { ...t,
            href: (i = (r = o.getData()) === null || r === void 0 ? void 0 : r.href) !== null && i !== void 0 ? i : t.href
        } : t
    }
    static deleteWebsites(t, o) {
        const {
            websiteUuid: r,
            pageUuid: i
        } = o.getId();
        return j.isWebsiteHyperlink(t) && t.websiteUuid === r && t.pageUuid === i ? null : t
    }
    static deletePages(t, o) {
        return (j.isInternalHyperlink(t) || j.isAnchorHyperlink(t)) && t.pageUuid === o.getId() ? null : t
    }
    static deleteSection(t, o) {
        const {
            pageId: r,
            sectionId: i
        } = o.getId();
        return j.isAnchorHyperlink(t) && (r === void 0 || t.pageUuid === r) && t.sectionId === i ? null : t
    }
    static updatePages(t, o) {
        if ((j.isInternalHyperlink(t) || j.isAnchorHyperlink(t)) && t.pageUuid === o.getId()) {
            const {
                id: r
            } = o.getData();
            return { ...t,
                pageUuid: r,
                href: j.isExternalPageHyperlink(t) ? void 0 : r
            }
        }
        return t
    }
    static getPagesAssets(t) {
        return j.isInternalHyperlink(t) || j.isAnchorHyperlink(t) ? [st.operation.getPageAsset(t)] : []
    }
}
class If extends _e {
    getAsset(t) {
        return Lu(this.props.content).reduce((o, r) => [...o, ...t(j.createTextHyperlink(r.attrs))], [])
    }
    getLandingPages() {
        return Lu(this.props.content).reduce((t, o) => {
            var r, i;
            const n = (i = (r = o.attrs) === null || r === void 0 ? void 0 : r.data) === null || i === void 0 ? void 0 : i.landingPageID;
            return n ? [...t, st.operation.getBaseAsset(n)] : t
        }, [])
    }
    getHyperlinks() {
        return this.getAsset(he.getHyperlinkAssets)
    }
    getWebsites() {
        return this.getAsset(he.getWebsitesAssets)
    }
    getStorageFiles() {
        return this.getAsset(he.getDocumentAssets)
    }
    getPages() {
        return this.getAsset(he.getPagesAssets)
    }
    getWebfontsFromContent() {
        return W0(this.props.content).filter(t => t.type === se.FontFamily).reduce((t, o) => {
            const {
                fontFamily: r
            } = o.attrs, i = wo.getWebfontFromFont(r);
            return i && t.push(i), t
        }, [])
    }
}
class sh {}
class $i extends sh {
    static build(t, o) {
        return new this(t, o)
    }
    constructor(t, o) {
        super(), Object.defineProperty(this, "id", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "data", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    getId() {
        return this.id
    }
    getData() {
        return this.data
    }
}
class Kt extends $i {}
var Ee;
(function(e) {
    e.UpdateAutoresponderSchemaPatch = "UpdateAutoresponder", e.UpdateContactListSchemaPatch = "UpdateContactList", e.UpdateCustomFieldSchemaPatch = "UpdateCustomField", e.UpdateGdprFieldSchemaPatch = "UpdateGdprField", e.UpdateHyperlinkSchemaPatch = "UpdateHyperlink", e.UpdateLpsSchemaPatch = "UpdateLps", e.UpdatePageSchemaPatch = "UpdatePage", e.UpdateStorageFileSchemaPatch = "UpdateStorageFile", e.UpdateWebsiteSchemaPatch = "UpdateWebsite", e.UpdateFormNameSchemaPatch = "UpdateFormName", e.UpdateContactFormNameSchemaPatch = "UpdateContactFormName", e.UpdateLightboxNameSchemaPatch = "UpdateLightboxName", e.UpdateWebinarSchemaPatch = "UpdateWebinar", e.UpdateChatIdSchemaPatch = "UpdateChatId", e.UpdateEcommerceSchemaPatch = "UpdateEcommerceSchemaPatch", e.UpdateSubscriptionSettingsSchemaPatch = "UpdateSubscriptionSettingsSchemaPatch", e.DeleteAutoresponderSchemaPatch = "DeleteAutoresponder", e.DeleteContactListSchemaPatch = "DeleteContactList", e.DeleteCustomFieldSchemaPatch = "DeleteCustomField", e.DeleteGdprFieldSchemaPatch = "DeleteGdprField", e.DeleteHyperlinkSchemaPatch = "DeleteHyperlink", e.DeleteLpsSchemaPatch = "DeleteLps", e.DeletePageSchemaPatch = "DeletePage", e.DeleteStorageFileSchemaPatch = "DeleteStorageFile", e.DeleteWebsiteSchemaPatch = "DeleteWebsite", e.DeleteSectionSchemaPatch = "DeleteSection", e.DeleteWebPushSchemaPatch = "DeleteWebPush", e.DeleteWebinarSchemaPatch = "DeleteWebinar"
})(Ee || (Ee = {}));
class Ws extends Kt {}
Object.defineProperty(Ws, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateLpsSchemaPatch
});
class kf extends sh {
    static build(t) {
        return new this(t)
    }
    constructor(t) {
        super(), Object.defineProperty(this, "id", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        })
    }
    getId() {
        return this.id
    }
}
class Qt extends kf {}
class Ds extends Qt {}
Object.defineProperty(Ds, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteLpsSchemaPatch
});
class Ns extends Kt {}
Object.defineProperty(Ns, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateContactListSchemaPatch
});
class Us extends Qt {}
Object.defineProperty(Us, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteContactListSchemaPatch
});
class Vs extends Kt {}
Object.defineProperty(Vs, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateCustomFieldSchemaPatch
});
class Hs extends Qt {}
Object.defineProperty(Hs, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteCustomFieldSchemaPatch
});
class js extends Kt {}
Object.defineProperty(js, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateStorageFileSchemaPatch
});
class zs extends Qt {}
Object.defineProperty(zs, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteStorageFileSchemaPatch
});
class _s extends Kt {}
Object.defineProperty(_s, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateAutoresponderSchemaPatch
});
class Gs extends Qt {}
Object.defineProperty(Gs, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteAutoresponderSchemaPatch
});
class Zs extends Kt {}
Object.defineProperty(Zs, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateWebsiteSchemaPatch
});
class qs extends Qt {}
Object.defineProperty(qs, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteWebsiteSchemaPatch
});
class Js extends Kt {}
Object.defineProperty(Js, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateGdprFieldSchemaPatch
});
class Ys extends Qt {}
Object.defineProperty(Ys, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteGdprFieldSchemaPatch
});
class Xs extends Kt {}
Object.defineProperty(Xs, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateHyperlinkSchemaPatch
});
class Ks extends Qt {}
Object.defineProperty(Ks, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteHyperlinkSchemaPatch
});
class Qs extends Kt {}
Object.defineProperty(Qs, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdatePageSchemaPatch
});
class ed extends Qt {}
Object.defineProperty(ed, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeletePageSchemaPatch
});
class td extends Qt {}
Object.defineProperty(td, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteSectionSchemaPatch
});
class od extends Qt {}
Object.defineProperty(od, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteWebPushSchemaPatch
});
class rd extends Kt {}
Object.defineProperty(rd, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateChatIdSchemaPatch
});
class nd extends Kt {}
Object.defineProperty(nd, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateWebinarSchemaPatch
});
class id extends Qt {}
Object.defineProperty(id, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.DeleteWebinarSchemaPatch
});
class ad extends $i {}
Object.defineProperty(ad, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateEcommerceSchemaPatch
});
class ld extends Kt {}
Object.defineProperty(ld, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateSubscriptionSettingsSchemaPatch
});
class Tf {
    constructor(t) {
        Object.defineProperty(this, "props", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        })
    }
    updateLps(t, o) {
        return t
    }
    deleteLps(t, o) {
        return t
    }
    updateContactList(t, o) {
        return t
    }
    deleteContactList(t, o) {
        return t
    }
    updateCustomField(t, o) {
        return t
    }
    deleteCustomField(t, o) {
        return t
    }
    updateStorageFile(t, o) {
        return t
    }
    deleteStorageFile(t, o) {
        return t
    }
    updateAutoresponder(t, o) {
        return t
    }
    deleteAutoresponder(t, o) {
        return t
    }
    updateWebsite(t, o) {
        return t
    }
    deleteWebsite(t, o) {
        return t
    }
    updateGdprField(t, o) {
        return t
    }
    deleteGdprField(t, o) {
        return t
    }
    updateHyperlink(t, o) {
        return t
    }
    updateWebinar(t, o) {
        return t
    }
    deleteHyperlink(t, o) {
        return t
    }
    updatePage(t, o) {
        return t
    }
    deletePage(t, o) {
        return t
    }
    deleteSection(t, o) {
        return t
    }
    deleteWebPush(t, o) {
        return t
    }
    deleteWebinar(t, o) {
        return t
    }
    updateAnalyticsChatId(t, o) {
        return t
    }
    updateEcommerce(t, o) {
        return t
    }
    updateSubscriptionSettings(t, o) {
        return t
    }
    applyPatch(t, o) {
        return o instanceof Ws ? this.updateLps(t, o) : o instanceof Ds ? this.deleteLps(t, o) : o instanceof Ns ? this.updateContactList(t, o) : o instanceof Us ? this.deleteContactList(t, o) : o instanceof Vs ? this.updateCustomField(t, o) : o instanceof Hs ? this.deleteCustomField(t, o) : o instanceof js ? this.updateStorageFile(t, o) : o instanceof zs ? this.deleteStorageFile(t, o) : o instanceof _s ? this.updateAutoresponder(t, o) : o instanceof Gs ? this.deleteAutoresponder(t, o) : o instanceof Zs ? this.updateWebsite(t, o) : o instanceof qs ? this.deleteWebsite(t, o) : o instanceof Js ? this.updateGdprField(t, o) : o instanceof Ys ? this.deleteGdprField(t, o) : o instanceof Xs ? this.updateHyperlink(t, o) : o instanceof Ks ? this.deleteHyperlink(t, o) : o instanceof Qs ? this.updatePage(t, o) : o instanceof ed ? this.deletePage(t, o) : o instanceof td ? this.deleteSection(t, o) : o instanceof od ? this.deleteWebPush(t, o) : o instanceof nd ? this.updateWebinar(t, o) : o instanceof id ? this.deleteWebinar(t, o) : o instanceof rd ? this.updateAnalyticsChatId(t, o) : o instanceof ad ? this.updateEcommerce(t, o) : o instanceof ld ? this.updateSubscriptionSettings(t, o) : t
    }
    applyPatches(t) {
        return t.reduce((o, r) => this.applyPatch(o, r), this.props)
    }
}
class Ze extends Tf {
    constructor(t, o = []) {
        super(t), Object.defineProperty(this, "imageProps", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    updateStorageFile(t, o) {
        const r = super.updateStorageFile(t, o),
            {
                imageProps: i
            } = this;
        let n = r;
        for (const l of i) {
            const s = n[l];
            s ? .type !== Ye.Storage || s.data.id !== o.getId() || (n = { ...n,
                [l]: { ...s,
                    data: { ...s.data,
                        ...o.getData()
                    }
                }
            })
        }
        return n
    }
    deleteStorageFile(t, o) {
        const r = super.deleteStorageFile(t, o),
            {
                imageProps: i
            } = this;
        let n = r;
        for (const l of i) {
            const s = n[l];
            !s || s.type !== Ye.Storage || s.data.id !== o.getId() || (n = { ...n,
                [l]: null
            })
        }
        return n
    }
}
var jr;
(function(e) {
    e.Web = "http", e.Phone = "tel:", e.Email = "mailto:"
})(jr || (jr = {}));
var ms;
(function(e) {
    e[e.ClosePopup = 1] = "ClosePopup"
})(ms || (ms = {}));
class Ef extends Ze {
    patchTextContent(t, o) {
        var r, i;
        let n = [];
        return o && (n = Array.isArray(o) ? [...o] : [{ ...o
        }]), { ...t,
            content: { ...t.content,
                content: n,
                version: ((i = (r = t.content) === null || r === void 0 ? void 0 : r.version) !== null && i !== void 0 ? i : 1) + 1
            }
        }
    }
    updateLps(t, o) {
        const r = super.updateLps(t, o);
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(i) {
                var n, l, s;
                const u = (l = (n = i.attrs) === null || n === void 0 ? void 0 : n.data) === null || l === void 0 ? void 0 : l.landingPageID,
                    c = (s = i.attrs) === null || s === void 0 ? void 0 : s.type;
                return u === o.getId() && c === k.LandingPage ? { ...i,
                    attrs: { ...i.attrs,
                        url: o.getData().url
                    }
                } : i
            }
        }))
    }
    deleteLps(t, o) {
        const r = super.deleteLps(t, o);
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(i) {
                var n, l, s;
                const u = (l = (n = i.attrs) === null || n === void 0 ? void 0 : n.data) === null || l === void 0 ? void 0 : l.landingPageID,
                    c = (s = i.attrs) === null || s === void 0 ? void 0 : s.type;
                return u === o.getId() && c === k.LandingPage ? null : i
            }
        }))
    }
    updateWebsite(t, o) {
        const r = super.updateWebsite(t, o);
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(i) {
                var n, l, s, u, c;
                if (((n = i.attrs) === null || n === void 0 ? void 0 : n.type) === k.Website) {
                    const m = (s = (l = i.attrs) === null || l === void 0 ? void 0 : l.data) === null || s === void 0 ? void 0 : s.websiteUuid,
                        g = (c = (u = i.attrs) === null || u === void 0 ? void 0 : u.data) === null || c === void 0 ? void 0 : c.pageUuid,
                        {
                            websiteUuid: p,
                            pageUuid: b
                        } = o.getId();
                    if (p === m && b === g) return { ...i,
                        attrs: { ...i.attrs,
                            url: o.getData().href
                        }
                    }
                }
                return i
            }
        }))
    }
    deleteWebsite(t, o) {
        const r = super.deleteWebsite(t, o);
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(i) {
                var n, l, s, u, c;
                if (((n = i.attrs) === null || n === void 0 ? void 0 : n.type) === k.Website) {
                    const m = (s = (l = i.attrs) === null || l === void 0 ? void 0 : l.data) === null || s === void 0 ? void 0 : s.websiteUuid,
                        g = (c = (u = i.attrs) === null || u === void 0 ? void 0 : u.data) === null || c === void 0 ? void 0 : c.pageUuid,
                        {
                            websiteUuid: p,
                            pageUuid: b
                        } = o.getId();
                    if (p === m && b === g) return null
                }
                return i
            }
        }))
    }
    updateStorageFile(t, o) {
        const r = super.updateStorageFile(t, o);
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(i) {
                var n, l, s;
                return ((n = i.attrs) === null || n === void 0 ? void 0 : n.type) === k.Document && ((s = (l = i.attrs) === null || l === void 0 ? void 0 : l.data) === null || s === void 0 ? void 0 : s.fileId) === o.getId() ? { ...i,
                    attrs: { ...i.attrs,
                        url: o.getData().src
                    }
                } : i
            }
        }))
    }
    deleteStorageFile(t, o) {
        const r = super.deleteStorageFile(t, o);
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(i) {
                var n, l, s;
                return ((n = i.attrs) === null || n === void 0 ? void 0 : n.type) === k.Document && ((s = (l = i.attrs) === null || l === void 0 ? void 0 : l.data) === null || s === void 0 ? void 0 : s.fileId) === o.getId() ? null : i
            }
        }))
    }
    updatePage(t, o) {
        const r = super.updatePage(t, o);
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(i) {
                var n, l, s;
                const u = (n = i.attrs) === null || n === void 0 ? void 0 : n.type;
                return (u === k.Internal || u === k.Anchor) && ((s = (l = i.attrs) === null || l === void 0 ? void 0 : l.data) === null || s === void 0 ? void 0 : s.pageUuid) === o.getId() ? { ...i,
                    attrs: { ...i.attrs,
                        data: { ...i.attrs.data,
                            pageUuid: o.getData().id
                        }
                    }
                } : i
            }
        }))
    }
    deletePage(t, o) {
        const r = super.deletePage(t, o);
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(i) {
                var n, l, s;
                const u = (n = i.attrs) === null || n === void 0 ? void 0 : n.type;
                return (u === k.Internal || u === k.Anchor) && ((s = (l = i.attrs) === null || l === void 0 ? void 0 : l.data) === null || s === void 0 ? void 0 : s.pageUuid) === o.getId() ? null : i
            }
        }))
    }
    deleteSection(t, o) {
        const r = super.deleteSection(t, o),
            {
                pageId: i,
                sectionId: n
            } = o.getId();
        return this.patchTextContent(r, Eo({
            editorContentNode: r.content.content,
            patchMark(l) {
                var s, u, c, h, m;
                if (((s = l.attrs) === null || s === void 0 ? void 0 : s.type) === k.Anchor) {
                    const p = (c = (u = l.attrs) === null || u === void 0 ? void 0 : u.data) === null || c === void 0 ? void 0 : c.pageUuid,
                        b = (m = (h = l.attrs) === null || h === void 0 ? void 0 : h.data) === null || m === void 0 ? void 0 : m.sectionId;
                    if ((i === void 0 || p === i) && b === n) return null
                }
                return l
            }
        }))
    }
}
const Wu = Symbol("missing value");

function Ue(e, t, o) {
    const r = o.get;
    let i = Wu;
    o.get = function() {
        return i === Wu && (i = r.call(this)), i
    }
}

function Fr(e) {
    return e ? .type === Ye.Storage
}

function dh(e) {
    return e ? .type === Ye.External
}
const Lf = 85;

function Mf(e) {
    const t = new URL(e);
    return t.searchParams.set("fm", "webp"), t.searchParams.set("q", Lf.toString()), t.toString()
}
var bs;
(function(e) {
    e.WebP = "webp"
})(bs || (bs = {}));
var di;
(function(e) {
    e.Gif = "image/gif", e.Jpeg = "image/jpeg", e.Png = "image/png", e.Svg = "image/svg+xml", e.WebP = "image/webp"
})(di || (di = {}));

function Of(e) {
    return {
        src: e,
        id: bs.WebP,
        type: di.WebP
    }
}
var ya;
(function(e) {
    e.Unsplash = "unsplash"
})(ya || (ya = {}));

function Qr(e) {
    return e.provider === ya.Unsplash && (e.fallback = [Of(Mf(e.src))]), e
}
const Af = d.object({
        id: d.string(),
        type: d.valid(...Object.values(di)).allow(null),
        src: d.string()
    }),
    Wf = d.object({
        fallback: d.array().items(Af).allow(null).optional()
    }).unknown(),
    Df = d.object(),
    sl = d.object({
        type: d.valid(...Object.values(Ye)),
        data: d.alternatives().conditional("type", {
            switch: [{
                is: Ye.Storage,
                then: Wf
            }, {
                is: Ye.External,
                then: Df
            }],
            otherwise: d.object()
        })
    }).allow(null);
var be;
(function(e) {
    e.TopLeft = "top-left", e.TopCenter = "top-center", e.TopRight = "top-right", e.CenterLeft = "center-left", e.CenterCenter = "center-center", e.CenterRight = "center-right", e.BottomLeft = "bottom-left", e.BottomCenter = "bottom-center", e.BottomRight = "bottom-right"
})(be || (be = {}));
var Ir;
(function(e) {
    e.Cover = "cover", e.NoRepeat = "no-repeat", e.Repeat = "repeat", e.RepeatX = "repeat-x", e.RepeatY = "repeat-y"
})(Ir || (Ir = {}));
const uh = 100,
    ch = {
        backgroundOpacity: uh,
        isBackgroundMediaEnabled: !1
    },
    Nf = { ...ch,
        backgroundVideo: null
    },
    hh = { ...ch,
        backgroundImage: null,
        backgroundSize: 100,
        backgroundPosition: be.CenterCenter,
        backgroundRepeat: Ir.NoRepeat
    },
    Uf = { ...Nf,
        ...hh
    },
    Vf = { ...Uf,
        backgroundRepeat: Ir.Cover
    },
    mh = {
        isBackgroundMediaEnabled: d.boolean().required(),
        backgroundOpacity: d.number().min(0).max(uh)
    },
    Hf = { ...mh,
        backgroundVideo: sl
    },
    bh = { ...mh,
        backgroundImage: sl,
        backgroundRepeat: d.valid(...Object.values(Ir)).allow(null),
        backgroundPosition: d.valid(...Object.values(be)).allow(null),
        backgroundSize: d.number().allow(null)
    },
    jf = { ...Hf,
        ...bh
    };
var vr;
(function(e) {
    e.TopHeader = "h1", e.Header = "h2", e.Subheader = "h3", e.Paragraph = "p", e.Meta = "s"
})(vr || (vr = {}));
var q;
(function(e) {
    e[e.Paragraph = 0] = "Paragraph", e[e.Header = 1] = "Header", e[e.Subheader = 2] = "Subheader", e[e.Disclaimer = 3] = "Disclaimer", e[e.TopHeader = 4] = "TopHeader"
})(q || (q = {}));
const Du = {
    [vr.Paragraph]: {
        type: "paragraph"
    },
    [vr.TopHeader]: {
        type: `block-type-${q.TopHeader}`,
        attrs: {
            blockTypeId: q.TopHeader
        }
    },
    [vr.Header]: {
        type: `block-type-${q.Header}`,
        attrs: {
            blockTypeId: q.Header
        }
    },
    [vr.Subheader]: {
        type: `block-type-${q.Subheader}`,
        attrs: {
            blockTypeId: q.Subheader
        }
    },
    [vr.Meta]: {
        type: `block-type-${q.Disclaimer}`,
        attrs: {
            blockTypeId: q.Disclaimer
        }
    }
};
var zf = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};

function zr(e, t, o = () => !0) {
    if (Array.isArray(e)) return e.map(i => zr(i, t, o));
    const r = { ...e
    };
    return o(r) ? (Array.isArray(r.content) && (r.content = zr(r.content, t, o)), t(r)) : r
}
class en extends Ne {
    get validationMap() {
        return { ...nt,
            ...ct,
            ...bh,
            content: d.object({
                version: d.number().optional(),
                type: d.valid(Re.Doc),
                content: d.array().items(d.object({
                    type: d.string(),
                    text: d.string().optional().allow(""),
                    marks: d.array().items(d.object({
                        type: d.string(),
                        attrs: d.object().unknown(!0).optional()
                    })).optional(),
                    attrs: d.object().unknown(!0).optional(),
                    content: d.array().items(d.link("#textNodeValidator")).optional()
                }).id("textNodeValidator")).optional()
            }),
            isHiddenOnMobile: d.boolean()
        }
    }
    static fromJson(t) {
        return new en(t.id, t.properties)
    }
    constructor(t = wr(I.Text), o = {
        content: {
            version: 1,
            type: Re.Doc,
            content: [{
                type: Re.Paragraph,
                content: []
            }]
        },
        elementPosition: null,
        ...rt,
        ...Rf,
        ...hh,
        isHiddenOnMobile: !1
    }) {
        super(t, en.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new If(this.properties, this.getImageProperties()), this.patcherService = new Ef(this.properties, this.getImageProperties())
    }
    getPlaceholders() {
        const t = [new Xa(Oe(), this.id), new al(Oe(), this.id), new ll(Oe(), this.id), new il(Oe(), this.id)];
        return this.properties.isBackgroundMediaEnabled && this.properties.backgroundImage ? t.push(new el(Oe(), this.id), new ol(Oe(), this.id)) : t.push(new tl(Oe(), this.id), new rl(Oe(), this.id)), this.isBeginningWithList() ? t.push(new qa(Oe(), this.id)) : t.push(new za(Oe(), this.id, {
            minWith: 0,
            maxWidth: lh(this.properties.content.content)
        })), t
    }
    getPlaceholderHandlers() {
        return {
            [E.Text]: this.getTextPropertiesFromPlaceholder,
            [E.TextList]: this.getTextListPropertiesFromPlaceholder,
            [E.TextColor]: this.getTextPropertiesFromColorPlaceholder,
            [E.TextFontSize]: this.getPropertiesFromFontSizePlaceholder,
            [E.TextFontFamily]: this.getPropertiesFromFontFamilyPlaceholder,
            [E.TextBlockType]: this.getPropertiesFromBlockTypePlaceholder,
            [E.TextBackgroundImage]: this.getPropertiesFromTextBackgroundImagePlaceholder,
            [E.TextExternalBackgroundImage]: this.getPropertiesFromTextExternalBackgroundImagePlaceholder,
            [E.TextForceBackgroundImage]: this.getPropertiesFromTextForceBackgroundImagePlaceholder,
            [E.TextForceExternalBackgroundImage]: this.getPropertiesFromTextForceExternalBackgroundImagePlaceholder
        }
    }
    getPropertiesFromTextBackgroundImagePlaceholder(t) {
        return {
            backgroundImage: {
                type: Ye.Storage,
                data: Qr(t.value)
            }
        }
    }
    getPropertiesFromTextExternalBackgroundImagePlaceholder(t) {
        return {
            backgroundImage: {
                type: Ye.External,
                data: {
                    src: t.value.src
                }
            }
        }
    }
    getPropertiesFromTextForceBackgroundImagePlaceholder(t) {
        const {
            backgroundImage: o,
            ...r
        } = t.value;
        return { ...r,
            isBackgroundMediaEnabled: !0,
            backgroundImage: {
                type: Ye.Storage,
                data: Qr(o)
            }
        }
    }
    getPropertiesFromTextForceExternalBackgroundImagePlaceholder(t) {
        const {
            backgroundImage: o,
            ...r
        } = t.value;
        return { ...r,
            isBackgroundMediaEnabled: !0,
            backgroundImage: {
                type: Ye.External,
                data: {
                    src: o.src
                }
            }
        }
    }
    getTextPropertiesFromColorPlaceholder(t) {
        var o;
        const r = (o = this.properties.content) === null || o === void 0 ? void 0 : o.content;
        if (!r) return {};
        const i = t.value,
            n = i.origin === O.Palette ? `var(--${i.name})` : i.value;
        return {
            content: { ...this.properties.content,
                content: zr(r, l => {
                    var s, u;
                    return l.type === Re.ListItem ? l.attrs = { ...(s = l.attrs) !== null && s !== void 0 ? s : {},
                        color: n
                    } : l.type === Re.Text && (l.marks = [...((u = l.marks) !== null && u !== void 0 ? u : []).filter(c => c.type !== se.TextColor), {
                        type: se.TextColor,
                        attrs: {
                            color: n
                        }
                    }]), l
                })
            }
        }
    }
    getPropertiesFromFontSizePlaceholder(t) {
        var o, r;
        const i = (o = this.properties.content) === null || o === void 0 ? void 0 : o.content;
        if (!i) return {};
        const n = (r = t.value) !== null && r !== void 0 ? r : null,
            l = n === null;
        return {
            content: { ...this.properties.content,
                content: zr(i, s => {
                    var u, c;
                    if (s.type === Re.ListItem) s.attrs = { ...(u = s.attrs) !== null && u !== void 0 ? u : {},
                        fontSize: n
                    };
                    else if (s.type === Re.Text) {
                        const h = ((c = s.marks) !== null && c !== void 0 ? c : []).filter(m => m.type !== se.FontSize);
                        l ? s.marks = h : s.marks = [...h, {
                            type: se.FontSize,
                            attrs: {
                                size: n
                            }
                        }]
                    }
                    return s
                })
            }
        }
    }
    getPropertiesFromFontFamilyPlaceholder(t) {
        var o, r;
        const i = (o = this.properties.content) === null || o === void 0 ? void 0 : o.content;
        if (!i) return {};
        const n = (r = t.value) !== null && r !== void 0 ? r : null,
            l = n === null;
        return {
            content: { ...this.properties.content,
                content: zr(i, s => {
                    var u, c;
                    if (s.type === Re.ListItem) s.attrs = { ...(u = s.attrs) !== null && u !== void 0 ? u : {},
                        fontFamily: n
                    };
                    else if (s.type === Re.Text) {
                        const h = ((c = s.marks) !== null && c !== void 0 ? c : []).filter(m => m.type !== se.FontFamily);
                        l ? s.marks = h : s.marks = [...h, {
                            type: se.FontFamily,
                            attrs: {
                                fontFamily: n
                            }
                        }]
                    }
                    return s
                })
            }
        }
    }
    getPropertiesFromBlockTypePlaceholder(t) {
        var o;
        const r = (o = this.properties.content) === null || o === void 0 ? void 0 : o.content;
        if (!r) return {};
        const i = t.value,
            n = Object.values(Du).map(({
                type: s
            }) => s),
            l = [se.FontFamily, se.FontSize, se.Strong, se.Italic, se.Underline];
        return {
            content: { ...this.properties.content,
                content: zr(r, s => n.includes(s.type) ? { ...s,
                    ...Du[i],
                    marks: s.marks.filter(({
                        type: u
                    }) => l.includes(u))
                } : s.type === Re.Text ? { ...s,
                    marks: s.marks.filter(({
                        type: u
                    }) => l.includes(u))
                } : s, s => s.type !== Re.ListItem)
            }
        }
    }
    getTextPropertiesFromPlaceholder(t) {
        var o, r, i;
        const n = (r = (o = this.properties.content) === null || o === void 0 ? void 0 : o.content) === null || r === void 0 ? void 0 : r[0],
            l = (i = n ? .content) === null || i === void 0 ? void 0 : i[0],
            s = l ? .type === Re.Text ? l : {};
        return t.value === null ? {
            content: {
                version: 1,
                type: Re.Doc,
                content: [{
                    type: Re.Paragraph,
                    content: []
                }]
            }
        } : {
            content: { ...this.properties.content,
                content: t.value.map(u => ({
                    type: Re.Paragraph,
                    ...n,
                    content: [{ ...s,
                        type: Re.Text,
                        text: u
                    }]
                }))
            }
        }
    }
    getTextListPropertiesFromPlaceholder(t) {
        var o, r, i, n, l, s;
        const u = (n = (i = (r = (o = this.properties.content) === null || o === void 0 ? void 0 : o.content) === null || r === void 0 ? void 0 : r[0]) === null || i === void 0 ? void 0 : i.content) !== null && n !== void 0 ? n : [{
            type: Re.ListItem,
            attrs: {
                isBold: !1,
                isItalic: !1,
                fontFamily: null,
                fontSize: null,
                color: null
            },
            content: [{
                type: Re.Paragraph,
                content: [{
                    type: Re.Text,
                    text: ""
                }]
            }]
        }];
        return {
            content: { ...this.properties.content,
                content: [{
                    type: Re.BulletList,
                    ...(s = (l = this.properties.content) === null || l === void 0 ? void 0 : l.content) === null || s === void 0 ? void 0 : s[0],
                    content: t.value.map((c, h) => {
                        var m, g;
                        const p = u[h % u.length],
                            b = (m = p ? .content) === null || m === void 0 ? void 0 : m[0],
                            C = (g = b ? .content) === null || g === void 0 ? void 0 : g[0],
                            w = C ? .type === Re.Text ? C : {};
                        return { ...p,
                            content: [{
                                type: Re.Paragraph,
                                ...b,
                                content: [{ ...w,
                                    type: Re.Text,
                                    text: c
                                }]
                            }]
                        }
                    })
                }]
            }
        }
    }
    isBeginningWithList() {
        var t, o;
        return [Re.BulletList, Re.OrderedList].includes((o = (t = this.properties.content) === null || t === void 0 ? void 0 : t.content) === null || o === void 0 ? void 0 : o[0].type)
    }
    getWebfonts() {
        return super.getWebfonts().concat(this.assetsService.getWebfontsFromContent())
    }
    getImageProperties() {
        return ["backgroundImage"]
    }
}
Object.defineProperty(en, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Text
});
zf([Ue], en.prototype, "validationMap", null);
const _f = "disclaimer",
    Gf = th,
    sd = "fontSizeMark";
var Ve;
(function(e) {
    e.Header = "header", e.Subheader = "subheader", e.Paragraph = "paragraph", e.Meta = "meta", e.Link = "link", e.HoverLink = "hover-link", e.TopHeader = "top-header"
})(Ve || (Ve = {}));
const fs = [{
        id: q.Paragraph,
        tagName: "p"
    }, {
        id: q.TopHeader,
        tagName: "h1"
    }, {
        id: q.Header,
        tagName: "h2"
    }, {
        id: q.Subheader,
        tagName: "h3"
    }, {
        id: q.Disclaimer,
        tagName: "p",
        className: _f
    }],
    dd = {
        [q.TopHeader]: Ve.TopHeader,
        [q.Header]: Ve.Header,
        [q.Subheader]: Ve.Subheader,
        [q.Disclaimer]: Ve.Meta,
        [q.Paragraph]: Ve.Paragraph
    },
    fh = {
        shadowColor: {
            origin: O.Custom,
            value: "#000000"
        },
        shadowOffsetX: 0,
        shadowOffsetY: 4,
        shadowSpreadRadius: -10,
        shadowBlurRadius: 20,
        shadowOpacity: 95,
        isShadowEnabled: !1
    },
    Zf = {
        shadowColor: null,
        shadowOffsetX: null,
        shadowOffsetY: null,
        shadowSpreadRadius: null,
        shadowBlurRadius: null,
        shadowOpacity: null,
        isShadowEnabled: null
    },
    qf = {
        paddingTop: 0,
        paddingLeft: 0,
        paddingRight: 0,
        paddingBottom: 0
    },
    Jf = {
        paddingTop: null,
        paddingLeft: null,
        paddingRight: null,
        paddingBottom: null
    },
    ud = {
        borderWidthTop: 1,
        borderWidthLeft: 1,
        borderWidthRight: 1,
        borderWidthBottom: 1,
        borderStyleTop: Me.Solid,
        borderStyleLeft: Me.Solid,
        borderStyleRight: Me.Solid,
        borderStyleBottom: Me.Solid,
        borderColorTop: {
            origin: O.Palette,
            name: D.Two
        },
        borderColorLeft: {
            origin: O.Palette,
            name: D.Two
        },
        borderColorRight: {
            origin: O.Palette,
            name: D.Two
        },
        borderColorBottom: {
            origin: O.Palette,
            name: D.Two
        },
        isBorderEnabled: !0
    },
    Yf = {
        borderWidthTop: null,
        borderWidthLeft: null,
        borderWidthRight: null,
        borderWidthBottom: null,
        borderStyleTop: null,
        borderStyleLeft: null,
        borderStyleRight: null,
        borderStyleBottom: null,
        borderColorTop: null,
        borderColorLeft: null,
        borderColorRight: null,
        borderColorBottom: null,
        isBorderEnabled: null
    },
    gh = {
        borderRadiusTopLeft: 10,
        borderRadiusTopRight: 10,
        borderRadiusBottomLeft: 10,
        borderRadiusBottomRight: 10,
        isRadiusLocked: !0,
        isRadiusEnabled: !1
    },
    Xf = {
        borderRadiusTopLeft: null,
        borderRadiusTopRight: null,
        borderRadiusBottomLeft: null,
        borderRadiusBottomRight: null,
        isRadiusLocked: null,
        isRadiusEnabled: null
    },
    Ri = { ...ud,
        ...gh,
        ...qf,
        ...fh
    },
    Kf = { ...Yf,
        ...Xf,
        ...Jf,
        ...Zf
    },
    ph = {
        ratio: 0,
        width: 0,
        height: 0,
        originalWidth: 0,
        originalHeight: 0,
        isAdjustToWidth: !0,
        isSizeLocked: !0
    },
    Zl = 560,
    ql = 340,
    Qf = {
        ratio: Zl / ql,
        width: Zl,
        height: ql,
        originalWidth: Zl,
        originalHeight: ql,
        isAdjustToWidth: !1,
        isSizeLocked: !0
    },
    dl = {
        fontFamily: Oa[0].fontStack.join(", "),
        fontSize: 12,
        isBold: !1,
        isItalic: !1,
        isUnderline: !1,
        textColor: {
            origin: O.Palette,
            name: D.Two
        }
    },
    eg = {
        fontFamily: null,
        fontSize: null,
        isBold: null,
        isItalic: null,
        isUnderline: null,
        textColor: {
            origin: O.Palette,
            name: D.Two
        }
    },
    tg = {
        dateFontFamily: null,
        dateFontSize: null,
        isDateBold: null,
        isDateItalic: null,
        isDateUnderline: null,
        dateAlign: W.Center,
        dateLineHeight: Si,
        dateType: q.Paragraph,
        dateTextColor: {
            origin: O.Palette,
            name: D.Two
        },
        dateBackgroundColor: {
            value: At,
            origin: O.Custom
        }
    },
    og = {
        hoverTextColor: null,
        isHoverBold: null,
        isHoverItalic: null,
        isHoverUnderline: null
    },
    rg = {
        clockFontFamily: null,
        clockFontSize: null,
        isClockBold: !1,
        isClockItalic: !1,
        isClockUnderline: !1,
        clockTextColor: {
            origin: O.Palette,
            name: D.Two
        }
    },
    yh = {
        fontFamily: d.string().allow(null),
        fontSize: d.number().allow(null),
        isBold: d.boolean(),
        isUnderline: d.boolean(),
        isItalic: d.boolean()
    },
    No = { ...yh,
        textColor: N
    },
    ng = { ...No,
        isBold: d.boolean().allow(null),
        isUnderline: d.boolean().allow(null),
        isItalic: d.boolean().allow(null)
    },
    xh = {
        borderColorBottom: N,
        borderColorLeft: N,
        borderColorRight: N,
        borderColorTop: N,
        borderStyleBottom: ot,
        borderStyleLeft: ot,
        borderStyleRight: ot,
        borderStyleTop: ot,
        borderWidthBottom: d.number(),
        borderWidthLeft: d.number(),
        borderWidthRight: d.number(),
        borderWidthTop: d.number(),
        isBorderEnabled: d.boolean().allow(null)
    },
    ig = {
        borderRadiusBottomLeft: d.number(),
        borderRadiusBottomRight: d.number(),
        borderRadiusTopLeft: d.number(),
        borderRadiusTopRight: d.number(),
        isRadiusLocked: d.boolean(),
        isRadiusEnabled: d.boolean()
    },
    ag = {
        shadowOffsetX: d.number(),
        shadowOffsetY: d.number(),
        shadowBlurRadius: d.number(),
        shadowSpreadRadius: d.number(),
        shadowColor: N,
        shadowOpacity: d.number(),
        isShadowEnabled: d.boolean().allow(null)
    },
    Mr = { ...xh,
        ...ig,
        ...ag,
        paddingBottom: d.number(),
        paddingLeft: d.number(),
        paddingRight: d.number(),
        paddingTop: d.number()
    },
    cd = {
        width: d.number(),
        height: d.number(),
        originalHeight: d.number(),
        originalWidth: d.number(),
        ratio: d.number(),
        isAdjustToWidth: d.boolean(),
        isSizeLocked: d.boolean()
    },
    ft = d.valid(...Object.values(W));
var pt;
(function(e) {
    e[e.Row = 0] = "Row", e[e.Column = 1] = "Column"
})(pt || (pt = {}));
const hd = d.valid(...Object.values(pt));
var De;
(function(e) {
    e.Palette = "palette", e.Typography = "typography", e.Body = "body", e.Section = "section", e.Social = "socialMedia", e.Button = "button", e.Mobile = "mobile", e.Popup = "popup", e.CustomCode = "customCode"
})(De || (De = {}));
var kr;
(function(e) {
    e.Active = "active", e.Inactive = "inactive"
})(kr || (kr = {}));
var Bo;
(function(e) {
    e[e.Public = 0] = "Public", e[e.Password = 1] = "Password", e[e.Members = 2] = "Members"
})(Bo || (Bo = {}));
var Qe;
(function(e) {
    e.Variant1 = "Variant1", e.Variant2 = "Variant2", e.Variant3 = "Variant3", e.Variant4 = "Variant4", e.Variant5 = "Variant5", e.Variant6 = "Variant6", e.Variant7 = "Variant7", e.Variant8 = "Variant8", e.Variant9 = "Variant9"
})(Qe || (Qe = {}));
var Br;
(function(e) {
    e[e.Small = 20] = "Small", e[e.Medium = 30] = "Medium", e[e.Large = 40] = "Large", e[e.MinCustom = 10] = "MinCustom", e[e.MaxCustom = 100] = "MaxCustom"
})(Br || (Br = {}));
const lg = {
    iconsColor: null,
    iconsSize: Yt.Medium,
    customIconsSize: Br.MaxCustom,
    iconsVariant: Qe.Variant2,
    iconsSpacing: 10
};
var ro;
(function(e) {
    e.Internal = "internal", e.External = "external", e.Unknown = "unknown"
})(ro || (ro = {}));
var Pe;
(function(e) {
    e.Date = "date", e.String = "string", e.Gender = "gender", e.Url = "url", e.Phone = "phone", e.Country = "country", e.Currency = "currency", e.Datetime = "datetime", e.Ip = "ip", e.Number = "number"
})(Pe || (Pe = {}));
var Je;
(function(e) {
    e.Text = "text", e.Textarea = "textarea", e.Single_select = "single_select", e.Multi_select = "multi_select", e.Checkbox = "checkbox", e.Radio = "radio"
})(Je || (Je = {}));
var _r;
(function(e) {
    e.DateTimeMax = "2100-01-01T23:59", e.DateTimeMin = "1900-01-01T00:00", e.DateMax = "2100-01-01", e.DateMin = "1900-01-01"
})(_r || (_r = {}));
const Nu = {
    [Pe.Date]: {
        min: _r.DateMin,
        max: _r.DateMax
    },
    [Pe.Datetime]: {
        min: _r.DateTimeMin,
        max: _r.DateTimeMax
    }
};

function sg(e) {
    return e in Nu ? Nu[e] : {
        min: null,
        max: null
    }
}

function xa(e, t = {}) {
    var o, r, i, n, l;
    const s = (o = t.valueType) !== null && o !== void 0 ? o : e.valueType;
    return { ...e,
        ...sg(s),
        id: (r = t.id) !== null && r !== void 0 ? r : e.id,
        name: (i = t.name) !== null && i !== void 0 ? i : e.name,
        valueType: s,
        format: (n = t.format) !== null && n !== void 0 ? n : e.format,
        defaultValues: (l = t.defaultValues) !== null && l !== void 0 ? l : e.defaultValues
    }
}
const tr = e => e.id,
    Uu = {
        fontFamily: "fieldFontFamily",
        fontSize: "fieldFontSize",
        isBold: "fieldIsBold",
        isItalic: "fieldIsItalic",
        isUnderline: "fieldIsUnderline"
    },
    dg = e => Object.entries(e).reduce((t, [o, r]) => (Uu.hasOwnProperty(o) && (t[Uu[o]] = r), t), {}),
    Vu = {
        fontFamily: "labelFontFamily",
        fontSize: "labelFontSize",
        isBold: "labelIsBold",
        isItalic: "labelIsItalic",
        isUnderline: "labelIsUnderline"
    },
    ug = e => Object.entries(e).reduce((t, [o, r]) => (Vu.hasOwnProperty(o) && (t[Vu[o]] = r), t), {}),
    Hu = {
        isRadiusLocked: "isButtonButtonRadiusLocked",
        isRadiusEnabled: "isButtonRadiusEnabled",
        backgroundColor: "buttonBackgroundColor",
        backgroundColorHover: "buttonBackgroundHoverColor",
        textColor: "buttonFontColor",
        textColorHover: "buttonFontColorHover",
        borderColorTop: "buttonBorderColorTop",
        borderColorLeft: "buttonBorderColorLeft",
        borderColorRight: "buttonBorderColorRight",
        borderColorBottom: "buttonBorderColorBottom",
        shadowColor: "buttonShadowColor",
        paddingLeft: "buttonInternalPaddingLeft",
        paddingRight: "buttonInternalPaddingRight",
        paddingTop: "buttonInternalPaddingTop",
        paddingBottom: "buttonInternalPaddingBottom",
        fontFamily: "buttonFontFamily",
        borderRadiusTopLeft: "buttonBorderRadiusTopLeft",
        borderRadiusTopRight: "buttonBorderRadiusTopRight",
        borderRadiusBottomLeft: "buttonBorderRadiusBottomLeft",
        borderRadiusBottomRight: "buttonBorderRadiusBottomRight",
        shadowBlurRadius: "buttonShadowBlurRadius",
        shadowOffsetX: "buttonShadowOffsetX",
        shadowOffsetY: "buttonShadowOffsetY",
        shadowOpacity: "buttonShadowOpacity",
        shadowSpreadRadius: "buttonShadowSpreadRadius",
        borderStyleBottom: "buttonBorderStyleTop",
        borderStyleLeft: "buttonBorderStyleLeft",
        borderStyleRight: "buttonBorderStyleRight",
        borderStyleTop: "buttonBorderStyleBottom",
        borderWidthTop: "buttonBorderWidthTop",
        borderWidthLeft: "buttonBorderWidthLeft",
        borderWidthRight: "buttonBorderWidthRight",
        borderWidthBottom: "buttonBorderWidthBottom",
        isBorderEnabled: "buttonBorderEnabled",
        fontSize: "buttonFontSize",
        isBold: "isButtonFontBold",
        isItalic: "isButtonFontItalic",
        isUnderline: "isButtonFontUnderLine",
        isShadowEnabled: "isButtonShadowEnabled"
    };

function cg(e) {
    return Object.entries(e).reduce((t, [o, r]) => (Hu.hasOwnProperty(o) && (t[Hu[o]] = r), t), {})
}
const ju = {
        isBold: "consentLinkIsBold",
        isItalic: "consentLinkIsItalic",
        isUnderline: "consentLinkIsUnderline"
    },
    zu = {
        isBold: "consentLinkHoverIsBold",
        isItalic: "consentLinkHoverIsItalic",
        isUnderline: "consentLinkHoverIsUnderline"
    },
    _u = {
        fontFamily: "consentFontFamily",
        fontSize: "consentFontSize"
    };

function hg(e) {
    return Object.entries(e).reduce((t, [o, r]) => (ju.hasOwnProperty(o) && (t[ju[o]] = r), t), {})
}

function mg(e) {
    return Object.entries(e).reduce((t, [o, r]) => (zu.hasOwnProperty(o) && (t[zu[o]] = r), t), {})
}

function bg(e) {
    return Object.entries(e).reduce((t, [o, r]) => (_u.hasOwnProperty(o) && (t[_u[o]] = r), t), {})
}
var tn;
(function(e) {
    e.px = "px", e.percent = "%"
})(tn || (tn = {}));

function va(e, t = tn.px) {
    return typeof e == "string" ? e : `${e}${t}`
}
const fg = e => {
    var t;
    return {
        id: e.id,
        latestVersionContent: e.latestVersionContent,
        name: e.name,
        required: (t = e.isRequired) !== null && t !== void 0 ? t : !0
    }
};
var on;
(function(e) {
    e.Seconds = "Seconds", e.Minutes = "Minutes", e.Hours = "Hours"
})(on || (on = {}));
const gg = {
        Hours: 36e5,
        Minutes: 6e4,
        Seconds: 1e3
    },
    vh = ([e, t]) => e * gg[t],
    pg = (e, t) => ({ ...e,
        [t.id]: t
    }),
    Ca = (e, t) => {
        const {
            [t]: o, ...r
        } = e;
        return r
    };
var gs;
(function(e) {
    e[e.Website = 1] = "Website", e[e.Form = 2] = "Form", e[e.Email = 3] = "Email", e[e.WebsiteLite = 4] = "WebsiteLite"
})(gs || (gs = {}));
var ps;
(function(e) {
    e[e.None = 0] = "None", e[e.Close = 1] = "Close"
})(ps || (ps = {}));
var ui;
(function(e) {
    e[e.Popup = 1] = "Popup", e[e.SlideIn = 2] = "SlideIn", e[e.FullScreen = 3] = "FullScreen", e[e.Bar = 4] = "Bar"
})(ui || (ui = {}));
var ci;
(function(e) {
    e.Popup = "popup", e.Inline = "inline"
})(ci || (ci = {}));
var fo;
(function(e) {
    e[e.Simple = 0] = "Simple", e[e.SimpleLight = 1] = "SimpleLight", e[e.Rounded = 2] = "Rounded", e[e.Square = 3] = "Square", e[e.Comic = 4] = "Comic", e[e.ComicRounded = 5] = "ComicRounded", e[e.ComicSquare = 6] = "ComicSquare"
})(fo || (fo = {}));
class ri {
    constructor(t) {
        Object.defineProperty(this, "properties", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.properties = t ? ? ri.DefaultProperties
    }
    static fromJson(t) {
        return new ri(t)
    }
    withProperties(t) {
        return new ri({ ...this.properties,
            ...t
        })
    }
    withModeDefaults(t) {
        if (t === ci.Inline) return this.withProperties({
            initialMode: ci.Inline
        });
        const o = r => Object.entries(r).reduce((i, [n, l]) => {
            var s;
            return { ...i,
                [n]: (s = this.properties[n]) !== null && s !== void 0 ? s : l
            }
        }, {});
        return this.withProperties({ ...o({
                displayType: ui.Popup,
                position: be.CenterCenter,
                width: 50
            }),
            initialMode: t
        })
    }
    toJSON() {
        return this.properties
    }
}
Object.defineProperty(ri, "DefaultProperties", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: {
        displayType: ui.Popup,
        initialMode: ci.Popup,
        position: be.CenterCenter,
        width: 50,
        isOverlayEnabled: !0,
        overlayClickBehavior: ps.Close,
        overlayColor: {
            origin: O.Custom,
            value: "#00000080"
        },
        ...fh,
        ...ud,
        ...gh,
        isBorderEnabled: !1,
        backgroundColor: {
            origin: O.Custom,
            value: "#FFFFFFFF"
        },
        closeButtonStyle: fo.Simple,
        closeButtonColor: {
            origin: O.Custom,
            value: "#000000FF"
        },
        closeButtonBackgroundColor: Cf,
        closeButtonSize: 20
    }
});
var Wo;
(function(e) {
    e[e.Normal = 0] = "Normal", e[e.Fixed = 1] = "Fixed", e[e.Disappear = 2] = "Disappear", e[e.Fade = 3] = "Fade"
})(Wo || (Wo = {}));
const yg = {
        scrollingBehavior: Wo.Normal
    },
    xg = {
        scrollingBehavior: null
    },
    On = d.object({
        id: d.string().allow(null),
        action: d.alternatives().conditional("type", {
            is: k.Action,
            then: d.valid(...Object.values(ms)).allow(null),
            otherwise: d.forbidden()
        }),
        href: d.string().allow("", null),
        type: d.valid(...Object.values(k)),
        target: d.valid(...Object.values(Ce)),
        landingPageID: d.alternatives().conditional("type", {
            is: k.LandingPage,
            then: d.string().allow(null),
            otherwise: d.forbidden()
        }),
        websiteUuid: d.alternatives().conditional("type", {
            is: k.Website,
            then: d.string().allow(null),
            otherwise: d.forbidden()
        }),
        pageUuid: d.alternatives().conditional("type", {
            is: d.valid(k.Website, k.Internal, k.Anchor),
            then: d.string().allow(null),
            otherwise: d.forbidden()
        }),
        fileName: d.alternatives().conditional("type", {
            is: k.Document,
            then: d.string().allow(null),
            otherwise: d.forbidden()
        }),
        fileId: d.alternatives().conditional("type", {
            is: k.Document,
            then: d.string().allow(null),
            otherwise: d.forbidden()
        }),
        sectionId: d.alternatives().conditional("type", {
            is: d.valid(k.Anchor),
            then: d.string().allow(null),
            otherwise: d.forbidden()
        }),
        pageType: d.alternatives().conditional("type", {
            is: d.valid(k.SpecialPage),
            then: d.valid(...Ff).allow(null),
            otherwise: d.forbidden()
        })
    }).allow(null),
    Ch = {
        fieldFontFamily: d.string().allow(null),
        fieldFontSize: d.number().allow(null),
        fieldIsBold: d.boolean().allow(null),
        fieldIsItalic: d.boolean().allow(null),
        fieldIsUnderline: d.boolean().allow(null),
        fieldTextColor: N,
        fieldPaddingBottom: d.number(),
        fieldPaddingLeft: d.number(),
        fieldPaddingRight: d.number(),
        fieldPaddingTop: d.number(),
        isFieldPaddingLocked: d.boolean(),
        fieldWidth: d.number(),
        fieldBorderRadiusBottomLeft: d.number(),
        fieldBorderRadiusBottomRight: d.number(),
        fieldBorderRadiusTopLeft: d.number(),
        fieldBorderRadiusTopRight: d.number(),
        isFieldBorderRadiusEnabled: d.boolean(),
        isFieldBorderRadiusLocked: d.boolean(),
        fieldBorderStyleTop: ot,
        fieldBorderStyleBottom: ot,
        fieldBorderStyleLeft: ot,
        fieldBorderStyleRight: ot,
        fieldBorderWidthBottom: d.number(),
        fieldBorderWidthLeft: d.number(),
        fieldBorderWidthRight: d.number(),
        fieldBorderWidthTop: d.number(),
        isFieldBorderEnabled: d.boolean(),
        fieldBorderColorBottom: N,
        fieldBorderColorLeft: N,
        fieldBorderColorRight: N,
        fieldBorderColorTop: N,
        fieldBackgroundColor: N,
        fieldShadowBlurRadius: d.number(),
        fieldShadowOffsetX: d.number(),
        fieldShadowOffsetY: d.number(),
        fieldShadowOpacity: d.number(),
        fieldShadowSpreadRadius: d.number(),
        isFieldShadowEnabled: d.boolean(),
        fieldShadowColor: N,
        fieldErrorColor: N
    },
    wh = {
        buttonFontSize: d.number().allow(null),
        isButtonFontBold: d.boolean().allow(null),
        isButtonFontUnderLine: d.boolean().allow(null),
        isButtonFontItalic: d.boolean().allow(null),
        buttonFontColor: N.allow(null),
        buttonFontColorHover: N.allow(null),
        buttonFontFamily: d.string().allow(null),
        buttonBorderColorTop: N.allow(null),
        buttonBorderColorLeft: N.allow(null),
        buttonBorderColorBottom: N.allow(null),
        buttonBorderColorRight: N.allow(null),
        buttonBorderStyleTop: ot.allow(null),
        buttonBorderStyleBottom: ot.allow(null),
        buttonBorderStyleLeft: ot.allow(null),
        buttonBorderStyleRight: ot.allow(null),
        buttonBorderWidthBottom: d.number().allow(null),
        buttonBorderWidthLeft: d.number().allow(null),
        buttonBorderWidthRight: d.number().allow(null),
        buttonBorderWidthTop: d.number().allow(null),
        buttonBorderEnabled: d.boolean().allow(null),
        buttonBorderRadiusBottomLeft: d.number().allow(null),
        buttonBorderRadiusBottomRight: d.number().allow(null),
        buttonBorderRadiusTopLeft: d.number().allow(null),
        buttonBorderRadiusTopRight: d.number().allow(null),
        isButtonButtonRadiusLocked: d.boolean().allow(null),
        isButtonRadiusEnabled: d.boolean().allow(null),
        buttonBackgroundColor: N.allow(null),
        buttonBackgroundHoverColor: N.allow(null),
        buttonInternalPaddingTop: d.number().allow(null),
        buttonInternalPaddingBottom: d.number().allow(null),
        buttonInternalPaddingLeft: d.number().allow(null),
        buttonInternalPaddingRight: d.number().allow(null),
        isButtonInternalPaddingLocked: d.boolean().allow(null),
        buttonShadowOffsetX: d.number().allow(null),
        buttonShadowOffsetY: d.number().allow(null),
        buttonShadowBlurRadius: d.number().allow(null),
        buttonShadowSpreadRadius: d.number().allow(null),
        buttonShadowColor: N.allow(null),
        buttonShadowOpacity: d.number().allow(null),
        isButtonShadowEnabled: d.boolean().allow(null),
        buttonAlign: ft,
        buttonText: d.string().allow("")
    },
    Bh = {
        labelFontFamily: d.string().allow(null),
        labelFontSize: d.number().allow(null),
        labelIsBold: d.boolean().allow(null),
        labelIsItalic: d.boolean().allow(null),
        labelIsUnderline: d.boolean().allow(null),
        labelTextColor: N
    },
    Sh = {
        consentFontFamily: d.string().allow(null),
        consentFontSize: d.number().allow(null),
        consentLinkIsBold: d.boolean().allow(null),
        consentLinkIsItalic: d.boolean().allow(null),
        consentLinkIsUnderline: d.boolean().allow(null),
        consentLinkHoverIsBold: d.boolean().allow(null),
        consentLinkHoverIsItalic: d.boolean().allow(null),
        consentLinkHoverIsUnderline: d.boolean().allow(null)
    };
var So;
(function(e) {
    e.ShowMessage = "showMessage", e.Redirect = "redirect", e.NavigateToSubmitPage = "typNavigation", e.ClosePopup = "closePopup"
})(So || (So = {}));
var Yo;
(function(e) {
    e.AboveInput = "AboveInput", e.InInput = "inInput"
})(Yo || (Yo = {}));
var rn;
(function(e) {
    e.Asterix = "asterix", e.Text = "text"
})(rn || (rn = {}));
const ys = d.object({
        id: d.string(),
        label: d.string().allow(""),
        required: d.boolean(),
        defaultValues: d.array().items(d.string().allow("")),
        format: d.valid(...Object.values(Je)),
        name: d.string(),
        valueType: d.valid(...Object.values(Pe)),
        min: d.alternatives().conditional("valueType", {
            switch: [{
                is: Pe.Date,
                then: d.string()
            }, {
                is: Pe.Datetime,
                then: d.string()
            }, {
                is: Pe.Number,
                then: d.number().allow(null)
            }],
            otherwise: d.valid(null)
        }),
        max: d.alternatives().conditional("valueType", {
            switch: [{
                is: Pe.Date,
                then: d.string()
            }, {
                is: Pe.Datetime,
                then: d.string()
            }, {
                is: Pe.Number,
                then: d.number().allow(null)
            }],
            otherwise: d.valid(null)
        })
    }),
    hi = d.object({
        $refType: d.string().required(),
        path: d.string().required()
    }),
    $h = {
        fieldsById: d.object().unknown(!0).pattern(/^/, ys),
        fieldsIds: d.array().items(d.string()),
        gdprFieldsById: d.object().unknown(!0).pattern(/^/, d.object({
            id: d.string(),
            latestVersionContent: d.string(),
            name: d.string(),
            required: d.boolean()
        })),
        gdprFieldsIds: d.array().items(d.string()),
        areGDPRSEnabled: d.boolean(),
        isRecaptchaEnabled: d.boolean(),
        isContactUpdateEnabled: d.boolean(),
        autoresponderDay: d.alternatives(d.number(), hi).allow(null),
        doubleOptIn: d.alternatives(d.boolean(), hi),
        labelPlacement: d.valid(...Object.values(Yo)),
        requiredInputMarkerType: d.valid(...Object.values(rn)),
        requiredInputMarkerText: d.string().allow("").optional(),
        successViewMethod: d.valid(...Object.values(So)),
        message: d.string().allow(""),
        hyperlink: On
    },
    vg = {
        dateFontFamily: d.string().allow(null),
        dateFontSize: d.number().allow(null),
        isDateBold: d.boolean().allow(null),
        isDateUnderline: d.boolean().allow(null),
        isDateItalic: d.boolean().allow(null),
        dateAlign: ft.allow(null),
        dateLineHeight: d.number().allow(null),
        dateType: d.number().allow(null),
        dateBackgroundColor: N,
        dateTextColor: N
    },
    Cg = { ...vg,
        dateTextColor: N
    };
var wg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class nn extends Ne {
    get validationMap() {
        return { ...nt,
            ...No,
            ...ct,
            align: ft,
            direction: hd,
            hoverTextColor: N.allow(null),
            isHoverBold: d.boolean().allow(null),
            isHoverItalic: d.boolean().allow(null),
            isHoverUnderline: d.boolean().allow(null),
            isHiddenOnMobile: d.boolean()
        }
    }
    static fromJson(t) {
        return new nn(t.id, t.properties)
    }
    constructor(t, o = { ...dl,
        ...og,
        ...rt,
        align: W.Center,
        isHiddenOnMobile: !1,
        elementPosition: null,
        direction: pt.Row
    }) {
        super(t, nn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    getFontFamilyProperties() {
        return ["fontFamily"]
    }
}
Object.defineProperty(nn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Navbar
});
wg([Ue], nn.prototype, "validationMap", null);
var Bg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class An extends Ne {
    get validationMap() {
        return {
            width: d.number().allow(null)
        }
    }
    static fromJson(t) {
        return new An(t.id, t.properties)
    }
    constructor(t = Kr, o = {
        width: null
    }) {
        super(t, I.Body, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(An, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Jo.Body
});
Bg([Ue], An.prototype, "validationMap", null);
class ul extends _e {
    getLandingPages() {
        return [...super.getLandingPages(), ...he.getLandingPageAssets(this.props.hyperlink)]
    }
    getHyperlinks() {
        return [...super.getHyperlinks(), ...he.getHyperlinkAssets(this.props.hyperlink)]
    }
    getWebsites() {
        return [...super.getWebsites(), ...he.getWebsitesAssets(this.props.hyperlink)]
    }
    getPages() {
        return [...super.getPages(), ...he.getPagesAssets(this.props.hyperlink)]
    }
    getStorageFiles() {
        return [...super.getStorageFiles(), ...he.getDocumentAssets(this.props.hyperlink)]
    }
}
class Pi extends Ze {
    replaceifNotSame(t, o) {
        return o !== t.hyperlink ? { ...t,
            hyperlink: o
        } : t
    }
    updateLps(t, o) {
        const r = super.updateLps(t, o);
        return this.replaceifNotSame(r, he.updateLandingPage(r.hyperlink, o))
    }
    deleteLps(t, o) {
        const r = super.deleteLps(t, o);
        return this.replaceifNotSame(r, he.deleteLandingPage(r.hyperlink, o))
    }
    updateWebsite(t, o) {
        const r = super.updateWebsite(t, o);
        return this.replaceifNotSame(r, he.updateWebsites(r.hyperlink, o))
    }
    deleteWebsite(t, o) {
        const r = super.deleteWebsite(t, o);
        return this.replaceifNotSame(r, he.deleteWebsites(r.hyperlink, o))
    }
    updatePage(t, o) {
        const r = super.updatePage(t, o);
        return this.replaceifNotSame(r, he.updatePages(r.hyperlink, o))
    }
    deletePage(t, o) {
        const r = super.deletePage(t, o);
        return this.replaceifNotSame(r, he.deletePages(r.hyperlink, o))
    }
    deleteSection(t, o) {
        const r = super.deleteSection(t, o);
        return this.replaceifNotSame(r, he.deleteSection(r.hyperlink, o))
    }
    updateStorageFile(t, o) {
        const r = super.updateStorageFile(t, o);
        return this.replaceifNotSame(r, he.updateDocument(r.hyperlink, o))
    }
    deleteStorageFile(t, o) {
        const r = super.deleteStorageFile(t, o);
        return this.replaceifNotSame(r, he.deleteDocument(r.hyperlink, o))
    }
}
var Sg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};

function Jl(e) {
    return Object.entries(e).reduce((t, [o, r]) => ({ ...t,
        [o]: r.allow(null)
    }), {})
}
class an extends Ne {
    get validationMap() {
        return { ...Jl(nt),
            ...Jl(Mr),
            ...Jl(No),
            ...ct,
            backgroundColor: N.allow(null),
            textColorHover: N.allow(null),
            backgroundColorHover: N.allow(null),
            hyperlink: On,
            isRadiusLocked: d.boolean().allow(null),
            align: ft.allow(null),
            isHiddenOnMobile: d.boolean(),
            buttonText: d.string().allow("")
        }
    }
    static fromJson(t) {
        return new an(t.id, t.properties)
    }
    constructor(t, o = {
        hyperlink: null,
        align: W.Center,
        backgroundColor: null,
        textColor: null,
        isRadiusLocked: !0,
        isHiddenOnMobile: !1,
        buttonText: "Call to action",
        fontFamily: null,
        fontSize: null,
        isBold: null,
        isItalic: null,
        isUnderline: null,
        backgroundColorHover: null,
        textColorHover: null,
        elementPosition: null,
        ...Kf,
        ...rt
    }) {
        super(t, an.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new ul(o, this.getImageProperties()), this.patcherService = new Pi(this.properties, this.getImageProperties())
    }
    regenerateContentIds() {
        return this.properties.hyperlink === null ? this : this.withProperties({
            hyperlink: { ...this.properties.hyperlink,
                id: Mt()
            }
        })
    }
    getPlaceholders() {
        var t, o;
        return [new Aa(Oe(), this.id, {
            href: (o = (t = this.properties.hyperlink) === null || t === void 0 ? void 0 : t.href) !== null && o !== void 0 ? o : null
        }), new Wa(Oe(), this.id, {
            minWith: 1,
            maxWidth: this.properties.buttonText.length
        })]
    }
    getPlaceholderHandlers() {
        return {
            [E.ButtonHref]: this.getHyperlinkPropertiesFromPlaceholder,
            [E.ButtonText]: this.getTextPropertiesFromPlaceholder
        }
    }
    getHyperlinkPropertiesFromPlaceholder(t) {
        const {
            isInternal: o
        } = t.value;
        if (o) {
            const {
                pageId: r
            } = t.value;
            return {
                hyperlink: {
                    id: Mt(),
                    type: k.Internal,
                    target: Ce.Blank,
                    pageUuid: r,
                    href: r
                }
            }
        }
        return {
            hyperlink: {
                id: Mt(),
                type: k.Web,
                target: Ce.Blank,
                href: t.value.href
            }
        }
    }
    getTextPropertiesFromPlaceholder(t) {
        return {
            buttonText: t.value
        }
    }
    getFontFamilyProperties() {
        return ["fontFamily"]
    }
}
Object.defineProperty(an, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Button
});
Sg([Ue], an.prototype, "validationMap", null);
var $g = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class ln extends Ne {
    get validationMap() {
        return {
            width: d.number(),
            ...ct
        }
    }
    static fromJson(t) {
        return new ln(t.id, t.properties)
    }
    constructor(t, o = {
        width: 100,
        elementPosition: As
    }) {
        super(t, ln.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(ln, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Jo.Column
});
$g([Ue], ln.prototype, "validationMap", null);
class mi extends Ne {
    static fromJson(t) {
        return new mi(t.id, t.properties)
    }
    constructor(t, o = {}) {
        super(t, mi.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "validationMap", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: {}
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(mi, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.ColumnGroup
});
var Rg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class sn extends Ne {
    get validationMap() {
        return {
            isHiddenOnMobile: d.boolean(),
            content: d.string().allow(""),
            ...ct
        }
    }
    static fromJson(t) {
        return new sn(t.id, t.properties)
    }
    constructor(t, o = {
        isHiddenOnMobile: !1,
        content: "",
        elementPosition: null
    }) {
        super(t, sn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(sn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.CustomHtml
});
Rg([Ue], sn.prototype, "validationMap", null);
var Pg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class dn extends Ne {
    get validationMap() {
        return { ...Mr,
            ...cd,
            ...nt,
            ...ct,
            alt: d.string().allow(""),
            src: sl,
            hyperlink: On,
            align: ft,
            isHiddenOnMobile: d.boolean(),
            sizeHasBeenModified: d.boolean(),
            opacity: d.number()
        }
    }
    static fromJson(t) {
        return new dn(t.id, t.properties)
    }
    constructor(t, o = {
        src: null,
        alt: "",
        hyperlink: null,
        align: W.Center,
        isHiddenOnMobile: !1,
        ...ph,
        ...Ri,
        ...rt,
        isBoxPaddingEnabled: !0,
        boxPaddingBottom: 20,
        boxPaddingLeft: 20,
        boxPaddingRight: 20,
        boxPaddingTop: 20,
        isBorderEnabled: !1,
        elementPosition: null,
        sizeHasBeenModified: !1,
        opacity: 100
    }) {
        super(t, dn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new ul(this.properties, this.getImageProperties()), this.patcherService = new Pi(this.properties, this.getImageProperties())
    }
    regenerateContentIds() {
        return this.properties.hyperlink === null ? this : this.withProperties({
            hyperlink: { ...this.properties.hyperlink,
                id: Mt()
            }
        })
    }
    getImageProperties() {
        return ["src"]
    }
    getPlaceholders() {
        var t, o, r, i, n, l, s, u, c, h;
        return [new Na(Oe(), this.id, {
            minWidth: (o = (t = this.properties.width) !== null && t !== void 0 ? t : this.properties.originalWidth) !== null && o !== void 0 ? o : 0,
            minHeight: (i = (r = this.properties.height) !== null && r !== void 0 ? r : this.properties.originalHeight) !== null && i !== void 0 ? i : 0
        }), new nl(Oe(), this.id, {
            minWidth: (l = (n = this.properties.width) !== null && n !== void 0 ? n : this.properties.originalWidth) !== null && l !== void 0 ? l : 0,
            minHeight: (u = (s = this.properties.height) !== null && s !== void 0 ? s : this.properties.originalHeight) !== null && u !== void 0 ? u : 0
        }), new Da(Oe(), this.id, {
            href: (h = (c = this.properties.hyperlink) === null || c === void 0 ? void 0 : c.href) !== null && h !== void 0 ? h : null
        })]
    }
    getPlaceholderHandlers() {
        return {
            [E.ImageHref]: this.getHyperlinkPropertiesFromPlaceholder,
            [E.ImageSource]: this.getSourcePropertiesFromPlaceholder,
            [E.ImageExternalSource]: this.getExternalSourcePropertiesFromPlaceholder
        }
    }
    getHyperlinkPropertiesFromPlaceholder(t) {
        return {
            hyperlink: {
                id: Mt(),
                type: k.Web,
                target: Ce.Blank,
                href: t.value
            }
        }
    }
    getSourcePropertiesFromPlaceholder(t) {
        const {
            value: o
        } = t, {
            originalWidth: r,
            originalHeight: i,
            isSizeLocked: n,
            width: l,
            height: s
        } = this.properties, {
            resolution: u = {
                width: r,
                height: i
            }
        } = o, c = u.width / u.height || 0;
        return {
            src: {
                type: Ye.Storage,
                data: Qr(o)
            },
            originalWidth: u.width,
            originalHeight: u.height,
            ratio: c,
            height: n ? l / c : s
        }
    }
    getExternalSourcePropertiesFromPlaceholder(t) {
        const {
            value: o
        } = t, {
            originalWidth: r,
            originalHeight: i,
            isSizeLocked: n,
            width: l,
            height: s
        } = this.properties, {
            resolution: u = {
                width: r,
                height: i
            }
        } = o, c = u.width / u.height || 0;
        return {
            src: {
                type: Ye.External,
                data: o
            },
            originalWidth: u.width,
            originalHeight: u.height,
            ratio: c,
            height: n ? l / c : s
        }
    }
}
Object.defineProperty(dn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Image
});
Pg([Ue], dn.prototype, "validationMap", null);
const Fg = {
        isShadowEnabled: !1,
        shadowColor: {
            origin: O.Custom,
            value: "#000000"
        },
        shadowOffsetX: 0,
        shadowOffsetY: 0,
        shadowSpreadRadius: 10,
        shadowBlurRadius: 10,
        shadowOpacity: 100
    },
    Ig = {
        isBorderEnabled: !1,
        borderRadiusTopLeft: 10,
        borderRadiusTopRight: 10,
        borderRadiusBottomLeft: 10,
        borderRadiusBottomRight: 10,
        isRadiusLocked: !0,
        isRadiusEnabled: !1,
        borderWidthTop: 1,
        borderWidthLeft: 1,
        borderWidthRight: 1,
        borderWidthBottom: 1,
        borderStyleTop: Me.Solid,
        borderStyleLeft: Me.Solid,
        borderStyleRight: Me.Solid,
        borderStyleBottom: Me.Solid,
        borderColorTop: {
            origin: O.Palette,
            name: D.Three
        },
        borderColorLeft: {
            origin: O.Palette,
            name: D.Three
        },
        borderColorRight: {
            origin: O.Palette,
            name: D.Three
        },
        borderColorBottom: {
            origin: O.Palette,
            name: D.Three
        }
    };
var kg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class Uo extends Ne {
    get validationMap() {
        return { ...Mr,
            ...ct,
            ...jf,
            isHidden: d.boolean(),
            isHiddenOnMobile: d.boolean(),
            isBorderEnabled: d.boolean(),
            backgroundColor: N,
            bottomSpace: d.number(),
            isFullWidth: d.boolean(),
            templateModule: d.object({
                uuid: d.string(),
                assignedFeatures: d.array().items(d.string())
            }).optional().allow(null),
            scrollingBehavior: d.valid(...Object.values(Wo)).allow(null)
        }
    }
    static fromJson(t) {
        return new Uo(t.id, t.properties)
    }
    constructor(t, o = {
        isHidden: !1,
        isHiddenOnMobile: !1,
        backgroundColor: {
            origin: O.Palette,
            name: D.One
        },
        paddingLeft: 0,
        paddingRight: 0,
        paddingBottom: 50,
        paddingTop: 50,
        ...Ig,
        ...Fg,
        ...Vf,
        bottomSpace: 0,
        isFullWidth: !0,
        elementPosition: As,
        ...t === Xt.Header ? yg : xg
    }) {
        super(t, Uo.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    regenerateContentIds() {
        return this.withProperties({
            templateModule: null
        })
    }
    getImageProperties() {
        return ["backgroundImage", "backgroundVideo"]
    }
    getPlaceholders() {
        const t = [];
        return this.properties.backgroundImage ? (t.push(new Va(Oe(), this.id)), t.push(new Ja(Oe(), this.id))) : (t.push(new Ka(Oe(), this.id)), t.push(new Qa(Oe(), this.id))), this.properties.backgroundVideo && t.push(new Ha(Oe(), this.id)), t.push(new Ya(Oe(), this.id)), t
    }
    getPlaceholderHandlers() {
        return {
            [E.SectionBackgroundImage]: this.getBackgroundImagePropertiesFromPlaceholder,
            [E.SectionExternalBackgroundImage]: this.getExternalBackgroundImagePropertiesFromPlaceholder,
            [E.SectionBackgroundVideo]: this.getBackgroundVideoPropertiesFromPlaceholder,
            [E.SectionBackgroundColor]: this.getBackgroundColorPropertiesFromPlaceholder,
            [E.SectionForceBackgroundImage]: this.getForceBackgroundImagePropertiesFromPlaceholder,
            [E.SectionForceExternalBackgroundImage]: this.getForceExternalBackgroundImagePropertiesFromPlaceholder
        }
    }
    getBackgroundColorPropertiesFromPlaceholder(t) {
        return {
            backgroundColor: t.value
        }
    }
    getBackgroundImagePropertiesFromPlaceholder(t) {
        return {
            backgroundImage: {
                type: Ye.Storage,
                data: Qr(t.value)
            }
        }
    }
    getForceBackgroundImagePropertiesFromPlaceholder(t) {
        const {
            backgroundImage: o,
            ...r
        } = t.value;
        return { ...r,
            isBackgroundMediaEnabled: !0,
            backgroundImage: {
                type: Ye.Storage,
                data: Qr(o)
            }
        }
    }
    getExternalBackgroundImagePropertiesFromPlaceholder(t) {
        return {
            backgroundImage: {
                type: Ye.External,
                data: {
                    src: t.value.src
                }
            }
        }
    }
    getForceExternalBackgroundImagePropertiesFromPlaceholder(t) {
        const {
            backgroundImage: o,
            ...r
        } = t.value;
        return { ...r,
            isBackgroundMediaEnabled: !0,
            backgroundImage: {
                type: Ye.External,
                data: {
                    src: o.src
                }
            }
        }
    }
    getBackgroundVideoPropertiesFromPlaceholder(t) {
        return {
            backgroundImage: {
                type: Ye.Storage,
                data: t.value
            }
        }
    }
    stripUserInformation() {
        const t = super.stripUserInformation();
        return t.properties.templateModule ? t.withProperties({
            templateModule: null
        }) : t
    }
}
Object.defineProperty(Uo, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Jo.Section
});
kg([Ue], Uo.prototype, "validationMap", null);
var R;
(function(e) {
    e[e.Facebook = 0] = "Facebook", e[e.Twitter = 1] = "Twitter", e[e.Instagram = 2] = "Instagram", e[e.YouTube = 3] = "YouTube", e[e.LinkedIn = 4] = "LinkedIn", e[e.Pinterest = 5] = "Pinterest", e[e.VKontakte = 6] = "VKontakte", e[e.TikTok = 7] = "TikTok"
})(R || (R = {}));
const Gu = [{
        type: R.Facebook,
        isEnabled: !0,
        data: {
            hyperlink: null,
            label: null,
            alt: null
        }
    }, {
        type: R.Twitter,
        isEnabled: !0,
        data: {
            hyperlink: null,
            label: null,
            alt: null
        }
    }, {
        type: R.Instagram,
        isEnabled: !0,
        data: {
            hyperlink: null,
            label: null,
            alt: null
        }
    }, {
        type: R.LinkedIn,
        isEnabled: !0,
        data: {
            hyperlink: null,
            label: null,
            alt: null
        }
    }, {
        type: R.Pinterest,
        isEnabled: !1,
        data: {
            hyperlink: null,
            label: null,
            alt: null
        }
    }, {
        type: R.VKontakte,
        isEnabled: !1,
        data: {
            hyperlink: null,
            label: null,
            alt: null
        }
    }, {
        type: R.YouTube,
        isEnabled: !1,
        data: {
            hyperlink: null,
            label: null,
            alt: null
        }
    }, {
        type: R.TikTok,
        isEnabled: !1,
        data: {
            hyperlink: null,
            label: null,
            alt: null
        }
    }],
    Tg = [{
        type: R.Facebook,
        isEnabled: !0,
        data: {
            hyperlink: {
                id: Mt(),
                href: "https://www.facebook.com/sharer/sharer.php?u={{PAGE_URL}}",
                type: k.SocialShare,
                target: Ce.Blank
            },
            label: "Share",
            alt: null
        }
    }, {
        type: R.Twitter,
        isEnabled: !0,
        data: {
            hyperlink: {
                id: Mt(),
                href: "https://twitter.com/intent/tweet?url={{PAGE_URL}}",
                type: k.SocialShare,
                target: Ce.Blank
            },
            label: "Tweet",
            alt: null
        }
    }, {
        type: R.LinkedIn,
        isEnabled: !0,
        data: {
            hyperlink: {
                id: Mt(),
                href: "https://www.linkedin.com/shareArticle?mini=true&url={{PAGE_URL}}",
                type: k.SocialShare,
                target: Ce.Blank
            },
            label: "Share",
            alt: null
        }
    }, {
        type: R.Pinterest,
        isEnabled: !1,
        data: {
            hyperlink: {
                id: Mt(),
                href: "https://pinterest.com/pin/create/button/?url={{PAGE_URL}}&media=&description=",
                type: k.SocialShare,
                target: Ce.Blank
            },
            label: "Pin it",
            alt: null
        }
    }, {
        type: R.VKontakte,
        isEnabled: !1,
        data: {
            hyperlink: {
                id: Mt(),
                href: "https://vk.com/share.php?url={{PAGE_URL}}",
                type: k.SocialShare,
                target: Ce.Blank
            },
            label: "Share",
            alt: null
        }
    }];
var Xo;
(function(e) {
    e.Share = "share", e.Follow = "follow"
})(Xo || (Xo = {}));
class Eg extends _e {
    getHyperlinks() {
        const t = { ...this.props
            },
            {
                action: o
            } = t;
        return o === Xo.Follow ? t.follow.medias.reduce((r, i) => i.isEnabled ? [...r, ...he.getHyperlinkAssets(i.data.hyperlink)] : r, []) : o === Xo.Share ? t.share.medias.reduce((r, i) => i.isEnabled ? [...r, { ...i.data.hyperlink
        }] : r, []) : []
    }
}
var Lg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
const {
    textColor: eR,
    ...Mg
} = dl;
class un extends Ne {
    get validationMap() {
        const t = d.object({
            medias: d.array().items(d.object({
                type: d.valid(...Object.values(R)),
                isEnabled: d.boolean(),
                data: d.object({
                    hyperlink: On,
                    label: d.string().allow("", null),
                    alt: d.string().allow("", null)
                })
            }))
        });
        return { ...nt,
            ...yh,
            ...ct,
            iconsVariant: d.valid(...Object.values(Qe)),
            iconsColor: N.allow(null),
            iconsSpacing: d.number(),
            iconsSize: d.valid(...Object.values(Yt)),
            customIconsSize: d.number(),
            follow: t,
            share: t,
            action: d.valid(...Object.values(Xo)),
            align: ft,
            isHiddenOnMobile: d.boolean(),
            labelColor: N,
            alt: d.string().allow("", null),
            direction: hd
        }
    }
    static fromJson(t) {
        return new un(t.id, t.properties)
    }
    constructor(t, o = {
        follow: {
            medias: Gu
        },
        share: {
            medias: Tg
        },
        action: Xo.Follow,
        align: W.Center,
        isHiddenOnMobile: !1,
        alt: null,
        direction: pt.Row,
        labelColor: {
            origin: O.Palette,
            name: D.Two
        },
        elementPosition: null,
        ...Mg,
        ...lg,
        ...rt
    }) {
        super(t, un.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new Eg(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    getPlaceholders() {
        return [new ja(Oe(), this.id)]
    }
    getPlaceholderHandlers() {
        return {
            [E.SocialMedia]: this.getSocialMediaPropertiesFromPlaceholder
        }
    }
    getSocialMediaPropertiesFromPlaceholder(t) {
        const {
            value: o
        } = t;
        return {
            follow: {
                medias: Gu.map(r => {
                    const i = o[r.type];
                    return i ? { ...r,
                        data: { ...r.data,
                            url: i
                        }
                    } : r
                })
            },
            action: Xo.Follow
        }
    }
    getFontFamilyProperties() {
        return ["fontFamily"]
    }
}
Object.defineProperty(un, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.SocialMedia
});
Lg([Ue], un.prototype, "validationMap", null);
var Ko;
(function(e) {
    e.Masonry = "masonry", e.Grid = "grid", e.Slideshow = "slideshow"
})(Ko || (Ko = {}));
const Yi = 350,
    Og = 600,
    Ag = 10,
    Wg = 10,
    Dg = {
        width: Yi,
        height: Yi,
        slideshowWidth: null,
        slideshowHeight: Og,
        originalWidth: Yi,
        originalHeight: Yi,
        imagesVerticalSpacing: Ag,
        imagesHorizontalSpacing: Wg
    };
class Ng extends _e {
    getLandingPages() {
        return this.props.sources.reduce((t, o) => {
            const {
                hyperlink: r
            } = o;
            return [...t, ...he.getLandingPageAssets(r)]
        }, [])
    }
    getHyperlinks() {
        return this.props.sources.reduce((t, o) => [...t, ...he.getHyperlinkAssets(o.hyperlink)], [])
    }
    getWebsites() {
        return this.props.sources.reduce((t, o) => {
            const {
                hyperlink: r
            } = o;
            return [...t, ...he.getWebsitesAssets(r)]
        }, [])
    }
    getPages() {
        return this.props.sources.reduce((t, o) => [...t, ...he.getPagesAssets(o.hyperlink)], [])
    }
    getStorageFiles() {
        return this.props.sources.reduce((t, o) => [...t, ...he.getDocumentAssets(o.hyperlink)], super.getStorageFiles())
    }
}
class Ug extends Ze {
    updateLps(t, o) {
        const r = super.updateLps(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                hyperlink: he.updateLandingPage(i.hyperlink, o)
            }))
        }
    }
    deleteLps(t, o) {
        const r = super.deleteLps(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                hyperlink: he.deleteLandingPage(i.hyperlink, o)
            }))
        }
    }
    updateWebsite(t, o) {
        const r = super.updateWebsite(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                hyperlink: he.updateWebsites(i.hyperlink, o)
            }))
        }
    }
    deleteWebsite(t, o) {
        const r = super.deleteWebsite(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                hyperlink: he.deleteWebsites(i.hyperlink, o)
            }))
        }
    }
    updatePage(t, o) {
        const r = super.updatePage(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                hyperlink: he.updatePages(i.hyperlink, o)
            }))
        }
    }
    deletePage(t, o) {
        const r = super.deletePage(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                hyperlink: he.deletePages(i.hyperlink, o)
            }))
        }
    }
    deleteSection(t, o) {
        const r = super.deleteSection(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                hyperlink: he.deleteSection(i.hyperlink, o)
            }))
        }
    }
    updateStorageFile(t, o) {
        const r = super.updateStorageFile(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                source: Fr(i.source) && i.source.data.id === o.getId() ? { ...i.source,
                    data: { ...i.source.data,
                        ...o.getData()
                    }
                } : i.source,
                hyperlink: he.updateDocument(i.hyperlink, o)
            }))
        }
    }
    deleteStorageFile(t, o) {
        const r = super.deleteStorageFile(t, o);
        return { ...r,
            sources: r.sources.map(i => ({ ...i,
                source: Fr(i.source) && i.source.data.id === o.getId() ? null : i.source,
                hyperlink: he.deleteDocument(i.hyperlink, o)
            }))
        }
    }
}
var Vg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class cn extends Ne {
    get validationMap() {
        return { ...nt,
            ...Mr,
            ...cd,
            ...ct,
            slideshowWidth: d.number().allow(null),
            slideshowHeight: d.number(),
            imagesHorizontalSpacing: d.number(),
            imagesVerticalSpacing: d.number(),
            sources: d.array().items(d.object({
                id: d.string(),
                source: sl,
                alt: d.string().allow(""),
                hyperlink: On
            })),
            align: ft,
            isHiddenOnMobile: d.boolean(),
            isExternalLinkModalOpen: d.boolean(),
            galleryType: d.valid(...Object.values(Ko)),
            sizeHasBeenModified: d.boolean()
        }
    }
    static fromJson(t) {
        return new cn(t.id, t.properties)
    }
    constructor(t, o = {
        sources: [{
            id: wr().toString(),
            source: null,
            alt: "",
            hyperlink: null
        }, {
            id: wr().toString(),
            source: null,
            alt: "",
            hyperlink: null
        }, {
            id: wr().toString(),
            source: null,
            alt: "",
            hyperlink: null
        }],
        align: W.Center,
        isHiddenOnMobile: !1,
        ...ph,
        ...Ri,
        ...rt,
        ...Dg,
        isBorderEnabled: !1,
        isExternalLinkModalOpen: !1,
        isSizeLocked: !1,
        galleryType: Ko.Grid,
        ratio: 1,
        isAdjustToWidth: !1,
        sizeHasBeenModified: !1,
        elementPosition: null
    }) {
        super(t, cn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new Ng(this.properties, this.getImageProperties()), this.patcherService = new Ug(this.properties, this.getImageProperties())
    }
    regenerateContentIds() {
        return this.withProperties({
            sources: this.properties.sources.map(t => t.hyperlink === null ? t : { ...t,
                hyperlink: { ...t.hyperlink,
                    id: Mt()
                }
            })
        })
    }
    getUsedStorageImages() {
        return this.properties.sources.filter(t => {
            var o;
            return ((o = t.source) === null || o === void 0 ? void 0 : o.type) === Ye.Storage
        }).map(t => t.source)
    }
    updateImageSource(t) {
        return this.withProperties({
            sources: this.properties.sources.map(o => {
                if (Fr(o.source)) {
                    const {
                        id: r
                    } = o.source.data, i = t.find(n => n.id === r);
                    if (i) return { ...o,
                        source: { ...o.source,
                            data: { ...o.source.data,
                                id: i.newId,
                                src: i.src
                            }
                        }
                    }
                }
                return o
            })
        })
    }
    getPlaceholders() {
        return [new Ua(Oe(), this.id, {
            minWidth: this.properties.width,
            minHeight: this.properties.height
        })]
    }
    getPlaceholderHandlers() {
        return {
            [E.Gallery]: this.getPropertiesFromPlaceholder
        }
    }
    getPropertiesFromPlaceholder(t) {
        const {
            value: o
        } = t;
        return {
            sources: o.map(r => ({
                id: wr().toString(),
                source: { ...r,
                    data: Qr(r.data)
                },
                alt: "",
                hyperlink: null
            }))
        }
    }
}
Object.defineProperty(cn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Gallery
});
Vg([Ue], cn.prototype, "validationMap", null);
var Hg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class hn extends Ne {
    get validationMap() {
        return {
            labelContent: d.string().allow(""),
            buttonContent: d.string().allow("")
        }
    }
    static fromJson(t) {
        return new hn(t.id, t.properties)
    }
    constructor(t, o = {
        labelContent: "Enter password",
        buttonContent: "Submit"
    }) {
        super(t, hn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(hn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.EnterPasswordForm
});
Hg([Ue], hn.prototype, "validationMap", null);
var jg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class mn extends Ne {
    get validationMap() {
        return { ...nt,
            emailLabelContent: d.string().allow(""),
            passwordLabelContent: d.string().allow(""),
            rememberMeLabelContent: d.string().allow(""),
            submitButtonContent: d.string().allow(""),
            isRememberMeVisible: d.boolean(),
            fontFamily: d.string().allow(null),
            fontSize: d.number().allow(null),
            isBold: d.boolean().allow(null),
            isItalic: d.boolean().allow(null),
            isUnderline: d.boolean().allow(null),
            color: N.allow(null)
        }
    }
    static fromJson(t) {
        return new mn(t.id, t.properties)
    }
    constructor(t, o = { ...rt,
        emailLabelContent: "E-mail",
        passwordLabelContent: "Password",
        rememberMeLabelContent: "Remember me",
        submitButtonContent: "Sign in",
        isRememberMeVisible: !0,
        fontFamily: null,
        fontSize: null,
        isBold: null,
        isItalic: null,
        isUnderline: null,
        color: null
    }) {
        super(t, mn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    getFontFamilyProperties() {
        return ["fontFamily"]
    }
}
Object.defineProperty(mn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.LoginForm
});
jg([Ue], mn.prototype, "validationMap", null);
var io;
(function(e) {
    e.YouTube = "youtube", e.Vimeo = "vimeo", e.Twitch = "twitch", e.Dailymotion = "dailymotion", e.CanalPlus = "canalplus", e.Youku = "youku", e.Coub = "coub", e.Wistia = "wistia", e.SoundCloud = "soundcloud", e.TeacherTube = "teachertube", e.Ted = "ted", e.Tiktok = "tiktok", e.Unknown = "Unknown"
})(io || (io = {}));
var ye;
(function(e) {
    e.AutoPlay = "autoPlay", e.AutoPlayAndMute = "autoPlayAndMute", e.Loop = "loop", e.ShowTitleBar = "showTitleBar", e.ShowByLine = "showByLine", e.ShowRelatedVideos = "showRelatedVideos", e.Mute = "mute", e.Controls = "controls"
})(ye || (ye = {}));
class cl {
    constructor(t, o) {
        if (Object.defineProperty(this, "info", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: t
            }), Object.defineProperty(this, "enabledPropertyValue", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: "1"
            }), Object.defineProperty(this, "disabledPropertyValue", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: "0"
            }), Object.defineProperty(this, "providerType", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: io.Unknown
            }), Object.defineProperty(this, "config", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: void 0
            }), Object.defineProperty(this, "baseUrl", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: void 0
            }), Object.defineProperty(this, "embeddedVideoUrl", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: void 0
            }), Object.defineProperty(this, "propertyNameMap", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: void 0
            }), Object.defineProperty(this, "defaultConfig", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: void 0
            }), this.setPropertyNameMap(), this.setDefaultConfig(), this.config = o ? ? this.getDefaultConfig(), this.initialize(), t && this.providerType !== t.provider) throw Error(`Invalid provider - ${t.provider}`)
    }
    getProviderType() {
        return this.providerType
    }
    getId() {
        var t, o;
        return (o = (t = this.info) === null || t === void 0 ? void 0 : t.id) !== null && o !== void 0 ? o : null
    }
    getEmbeddedVideoUrl() {
        return this.embeddedVideoUrl
    }
    setEmbeddedVideoUrl(t) {
        this.embeddedVideoUrl = t
    }
    getBaseUrl() {
        return this.baseUrl
    }
    setBaseUrl(t) {
        this.baseUrl = t
    }
    getEnabledPropertyValue() {
        return this.enabledPropertyValue
    }
    getDisabledPropertyValue() {
        return this.disabledPropertyValue
    }
    getSupportedProperties() {
        return Object.keys(this.getPropertyNameMap()).map(t => {
            const o = t,
                r = this.getPropertyNameMap()[o];
            return {
                enabled: this.isPropertyEnabled(o),
                name: r,
                type: o,
                active: this.isPropertyActive(o)
            }
        })
    }
    toVideoSource() {
        const t = {};
        return this.getSupportedProperties().forEach(r => {
            t[r.name] = r.enabled
        }), {
            type: ro.External,
            src: this.getEmbeddedVideoUrl(),
            videoUrl: this.getVideoUrl(),
            id: this.getId(),
            config: t
        }
    }
    getQueryParamsWithoutAutoPlay() {
        const t = this.getSupportedProperties().filter(({
            type: o
        }) => o !== ye.AutoPlayAndMute);
        return this.getQueryParams(t)
    }
    getDefaultConfig() {
        return this.defaultConfig
    }
    setDefaultConfig() {
        this.defaultConfig = {}
    }
    getPropertyNameMap() {
        return this.propertyNameMap
    }
    setPropertyNameMap() {
        this.propertyNameMap = {}
    }
    getConfig() {
        return this.config
    }
    isPropertyEnabled(t) {
        const o = this.getConfig(),
            r = this.getPropertyNameMap(),
            i = o[r[t]],
            n = o[r[ye.AutoPlayAndMute]];
        return t === ye.Mute && n ? n : i
    }
    isPropertyActive(t) {
        const o = this.getConfig(),
            r = this.getPropertyNameMap(),
            i = o[r[ye.AutoPlayAndMute]];
        return !(t === ye.Mute && i)
    }
}
const Rh = D0;
class zg extends cl {
    initialize() {
        this.providerType = io.YouTube, this.setBaseUrl("https://www.youtube.com/"), this.setEmbeddedVideoUrl("https://www.youtube.com/embed/")
    }
    getVideoUrl() {
        return `${this.getBaseUrl()}watch?v=${this.getId()}`
    }
    getSimpleEmbeddedVideoUrl() {
        return `${this.getEmbeddedVideoUrl()}${this.getId()}`
    }
    getFullEmbeddedVideoUrl() {
        return `${this.getSimpleEmbeddedVideoUrl()}?${this.getQueryParams()}`
    }
    getFullEmbeddedVideoUrlWithoutAutoPlay() {
        return `${this.getSimpleEmbeddedVideoUrl()}?${this.getQueryParamsWithoutAutoPlay()}`
    }
    getQueryParams(t = this.getSupportedProperties()) {
        return `modestbranding=1&rel=0&${t.map(({type:r,enabled:i,name:n})=>r===ye.Loop&&i?`
        playlist = $ {
            this.getId()
        } & $ {
            n
        } = $ {
            this.getEnabledPropertyValue()
        }
        `:`
        $ {
            n
        } = $ {
            i ? this.getEnabledPropertyValue() : this.getDisabledPropertyValue()
        }
        `).join("&")}`
    }
    setPropertyNameMap() {
        this.propertyNameMap = {
            [ye.AutoPlayAndMute]: "autoplay",
            [ye.Mute]: "mute",
            [ye.Loop]: "loop",
            [ye.Controls]: "controls"
        }
    }
    setDefaultConfig() {
        const t = this.getPropertyNameMap();
        this.defaultConfig = {
            [t[ye.AutoPlayAndMute]]: !1,
            [t[ye.Mute]]: !1,
            [t[ye.Loop]]: !1,
            [t[ye.Controls]]: !0
        }
    }
}
class _g extends cl {
    initialize() {
        this.providerType = io.Vimeo, this.setBaseUrl("https://vimeo.com/"), this.setEmbeddedVideoUrl("https://player.vimeo.com/video/")
    }
    getVideoUrl() {
        return `${this.getBaseUrl()}${this.getId()}`
    }
    getSimpleEmbeddedVideoUrl() {
        return `${this.getEmbeddedVideoUrl()}${this.getId()}`
    }
    getFullEmbeddedVideoUrl() {
        return `${this.getSimpleEmbeddedVideoUrl()}?${this.getQueryParams()}`
    }
    getFullEmbeddedVideoUrlWithoutAutoPlay() {
        return `${this.getSimpleEmbeddedVideoUrl()}?${this.getQueryParamsWithoutAutoPlay()}`
    }
    getQueryParams(t = this.getSupportedProperties()) {
        return t.map(({
            name: o,
            enabled: r
        }) => `${o}=${r?this.getEnabledPropertyValue():this.getDisabledPropertyValue()}`).join("&")
    }
    setPropertyNameMap() {
        this.propertyNameMap = {
            [ye.AutoPlayAndMute]: "autoplay",
            [ye.Mute]: "muted",
            [ye.Loop]: "loop",
            [ye.ShowTitleBar]: "title",
            [ye.ShowByLine]: "byline"
        }
    }
    setDefaultConfig() {
        const t = this.getPropertyNameMap();
        this.defaultConfig = {
            [t[ye.AutoPlayAndMute]]: !1,
            [t[ye.Mute]]: !1,
            [t[ye.Loop]]: !1,
            [t[ye.ShowTitleBar]]: !1,
            [t[ye.ShowByLine]]: !1
        }
    }
}
class Gg extends cl {
    initialize() {}
    getSupportedParams() {
        return ""
    }
    getSupportedProperties() {
        return []
    }
    getVideoUrl() {
        return ""
    }
    toVideoSource() {
        return {
            src: null,
            type: ro.Unknown,
            id: null,
            config: null
        }
    }
    getFullEmbeddedVideoUrl() {
        return ""
    }
    getSimpleEmbeddedVideoUrl() {
        return ""
    }
    getQueryParams() {
        return ""
    }
    getFullEmbeddedVideoUrlWithoutAutoPlay() {
        return ""
    }
}
class Zg extends cl {
    initialize() {
        this.providerType = io.Wistia, this.enabledPropertyValue = "true", this.disabledPropertyValue = "false", this.setBaseUrl("https://wistia.com/"), this.setEmbeddedVideoUrl("https://fast.wistia.com/embed/iframe/")
    }
    getVideoUrl() {
        var t;
        return !((t = this.info) === null || t === void 0) && t.channel ? Rh.create({
            videoInfo: { ...this.info,
                mediaType: "video"
            }
        }) : this.getSimpleEmbeddedVideoUrl()
    }
    getSimpleEmbeddedVideoUrl() {
        return `${this.getEmbeddedVideoUrl()}${this.getId()}`
    }
    getFullEmbeddedVideoUrl() {
        return `${this.getSimpleEmbeddedVideoUrl()}?${this.getQueryParams()}`
    }
    getFullEmbeddedVideoUrlWithoutAutoPlay() {
        return `${this.getSimpleEmbeddedVideoUrl()}?${this.getQueryParamsWithoutAutoPlay()}`
    }
    getQueryParams(t = this.getSupportedProperties()) {
        return t.map(({
            name: o,
            type: r,
            enabled: i
        }) => r === ye.Loop ? `${o}=${i?"loop":"default"}` : `${o}=${i?this.getEnabledPropertyValue():this.getDisabledPropertyValue()}`).join("&")
    }
    setPropertyNameMap() {
        this.propertyNameMap = {
            [ye.AutoPlayAndMute]: "autoPlay",
            [ye.Mute]: "muted",
            [ye.Loop]: "endVideoBehavior",
            [ye.Controls]: "controlsVisibleOnLoad"
        }
    }
    setDefaultConfig() {
        const t = this.getPropertyNameMap();
        this.defaultConfig = {
            [t[ye.AutoPlayAndMute]]: !1,
            [t[ye.Mute]]: !1,
            [t[ye.Loop]]: !1,
            [t[ye.Controls]]: !1
        }
    }
}
class $r {
    static getUrl(t) {
        var o, r;
        return t.type === ro.External ? (o = t.videoUrl) !== null && o !== void 0 ? o : `${t.src}${t.id}` : (r = t.src) !== null && r !== void 0 ? r : ""
    }
    static getProvider(t) {
        if (!t) throw new Error("Missing source");
        const o = Rh.parse($r.getUrl(t));
        switch (o ? .provider) {
            case io.YouTube:
                return new zg(o, t.config);
            case io.Vimeo:
                return new _g(o, t.config);
            case io.Wistia:
                return new Zg(o, t.config);
            default:
                return new Gg
        }
    }
    static getProviderByUrl(t) {
        return $r.getProvider({
            config: null,
            src: t,
            id: null,
            type: null
        })
    }
    static isPlatformSupported(t) {
        return $r.getProviderByUrl(t).getProviderType() !== io.Unknown
    }
}
var qg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class bn extends Ne {
    get validationMap() {
        return { ...nt,
            ...Mr,
            ...cd,
            ...ct,
            isHiddenOnMobile: d.boolean(),
            align: ft,
            source: d.object({
                type: d.valid(...Object.values(ro)),
                src: d.string().allow(null),
                videoUrl: d.alternatives().conditional("type", {
                    is: ro.External,
                    then: d.string().allow(null),
                    otherwise: d.optional()
                }),
                id: d.alternatives().conditional("type", {
                    is: ro.Unknown,
                    then: d.valid(null),
                    otherwise: d.string()
                }),
                config: d.alternatives().conditional("type", {
                    is: ro.Unknown,
                    then: d.valid(null),
                    otherwise: d.object().unknown(!0)
                })
            }),
            sizeHasBeenModified: d.boolean()
        }
    }
    static fromJson(t) {
        return new bn(t.id, t.properties)
    }
    constructor(t, o = {
        source: {
            type: ro.Unknown,
            src: null,
            config: null,
            id: null
        },
        align: W.Center,
        ...rt,
        ...Ri,
        ...Qf,
        isBoxPaddingEnabled: !0,
        boxPaddingBottom: 20,
        boxPaddingLeft: 20,
        boxPaddingRight: 20,
        boxPaddingTop: 20,
        isBorderEnabled: !1,
        elementPosition: null,
        sizeHasBeenModified: !1,
        isHiddenOnMobile: !1
    }) {
        super(t, bn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    getPlaceholders() {
        var t, o, r, i;
        return [new _a(Oe(), this.id, {
            minWidth: (o = (t = this.properties.width) !== null && t !== void 0 ? t : this.properties.originalWidth) !== null && o !== void 0 ? o : 0,
            minHeight: (i = (r = this.properties.height) !== null && r !== void 0 ? r : this.properties.originalHeight) !== null && i !== void 0 ? i : 0
        })]
    }
    getPlaceholderHandlers() {
        return {
            [E.Video]: this.getVideoSourcePropertiesFromPlaceholder
        }
    }
    getVideoSourcePropertiesFromPlaceholder(t) {
        return {
            source: $r.getProvider({
                type: ro.Internal,
                config: null,
                id: null,
                src: t.value
            }).toVideoSource()
        }
    }
}
Object.defineProperty(bn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Video
});
qg([Ue], bn.prototype, "validationMap", null);
var Jg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class fn extends Ne {
    get validationMap() {
        return { ...nt,
            ...xh,
            ...ct,
            isHiddenOnMobile: d.boolean(),
            align: ft,
            direction: hd,
            width: d.number(),
            height: d.number()
        }
    }
    static fromJson(t) {
        return new fn(t.id, t.properties)
    }
    constructor(t, o = {
        align: W.Center,
        direction: pt.Row,
        width: 50,
        height: 50,
        ...ud,
        ...rt,
        boxPaddingTop: 20,
        boxPaddingBottom: 20,
        isBoxPaddingEnabled: !0,
        elementPosition: null,
        isHiddenOnMobile: !1
    }) {
        super(t, fn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    withProperties(t) {
        return typeof t.direction < "u" && t.direction !== this.properties.direction ? super.withProperties({ ...t,
            isHiddenOnMobile: t.direction === pt.Column
        }) : super.withProperties(t)
    }
}
Object.defineProperty(fn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Divider
});
Jg([Ue], fn.prototype, "validationMap", null);
var Yg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class gn extends Ne {
    get validationMap() {
        return { ...nt,
            isHiddenOnMobile: d.boolean(),
            space: d.number()
        }
    }
    static fromJson(t) {
        return new gn(t.id, t.properties)
    }
    constructor(t, o = {
        isHiddenOnMobile: !1,
        space: 100,
        ...rt
    }) {
        super(t, gn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(gn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Spacer
});
Yg([Ue], gn.prototype, "validationMap", null);
var qr;
(function(e) {
    e[e.FixedDate = 0] = "FixedDate", e[e.Evergreen = 1] = "Evergreen"
})(qr || (qr = {}));
var Rt;
(function(e) {
    e[e.Days = 0] = "Days", e[e.Hours = 1] = "Hours", e[e.Minutes = 2] = "Minutes", e[e.Seconds = 3] = "Seconds"
})(Rt || (Rt = {}));
var Xg = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class pn extends Ne {
    get validationMap() {
        return { ...nt,
            ...No,
            ...Mr,
            ...ct,
            fontFamily: No.fontFamily.allow(null),
            fontSize: No.fontSize.allow(null),
            isPaddingEnabled: d.boolean(),
            isPaddingLocked: d.boolean(),
            clockFontFamily: d.string().allow(null),
            clockFontSize: d.number().allow(null),
            isClockBold: d.boolean(),
            isClockItalic: d.boolean(),
            isClockUnderline: d.boolean(),
            clockTextColor: N,
            isHiddenOnMobile: d.boolean(),
            backgroundColor: N,
            type: d.valid(...Object.values(qr)),
            evergreen: d.object({
                seconds: d.number()
            }),
            fixedDate: d.alternatives().conditional("type", {
                is: qr.FixedDate,
                then: d.object({
                    id: d.string().allow(null),
                    offset: d.string(),
                    date: d.string()
                }),
                otherwise: d.allow(null)
            }),
            fields: d.array().items(d.valid(...Object.values(Rt))),
            isLabelsVisible: d.boolean()
        }
    }
    static fromJson(t) {
        return new pn(t.id, t.properties)
    }
    constructor(t, o = { ...dl,
        ...rt,
        ...Ri,
        ...rg,
        fields: [Rt.Days, Rt.Hours, Rt.Minutes, Rt.Seconds],
        fixedDate: null,
        evergreen: {
            seconds: 120
        },
        type: qr.Evergreen,
        paddingTop: 5,
        paddingLeft: 5,
        paddingRight: 5,
        paddingBottom: 5,
        isPaddingEnabled: !0,
        isPaddingLocked: !0,
        fontFamily: null,
        fontSize: null,
        isBorderEnabled: !1,
        backgroundColor: {
            value: At,
            origin: O.Custom
        },
        isHiddenOnMobile: !1,
        elementPosition: null,
        isLabelsVisible: !0
    }) {
        super(t, pn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    getFontFamilyProperties() {
        return ["fontFamily", "clockFontFamily"]
    }
}
Object.defineProperty(pn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Timer
});
Xg([Ue], pn.prototype, "validationMap", null);
var or;
(function(e) {
    e.Name = "name", e.Email = "email"
})(or || (or = {}));
const go = {
        isHidden: !1,
        defaultValues: [""],
        format: Je.Text,
        id: "80ebb95a-01b7-4456-9ce0-6a7ab9d03862",
        name: or.Name,
        valueType: Pe.String
    },
    po = {
        isHidden: !1,
        defaultValues: [""],
        format: Je.Text,
        id: "c21d27a1-69ab-4064-bbf5-2e40d14a2884",
        name: or.Email,
        valueType: Pe.String
    },
    rr = [{
        defaultValues: go.defaultValues,
        format: go.format,
        id: go.id,
        name: go.name,
        label: "name",
        valueType: go.valueType,
        required: !0,
        min: null,
        max: null
    }, {
        defaultValues: po.defaultValues,
        format: po.format,
        id: po.id,
        name: po.name,
        label: "email",
        valueType: po.valueType,
        required: !0,
        min: null,
        max: null
    }];

function Kg(e, t) {
    return String.prototype.split.call(t, ".").filter(Boolean).reduce((o, r) => o ? .[r], e)
}
class Wn {
    constructor(t) {
        Object.defineProperty(this, "settings", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        })
    }
    getValue(t) {
        if (Wn.isReference(t)) {
            if (t.$refType === "settings") return Kg(this.settings, t.path);
            throw new Error("Missing context for value reference")
        }
        return t
    }
    static isReference(t) {
        return typeof t == "object" && t !== null && "$refType" in t
    }
}
class Qg extends ul {
    getContactLists() {
        const {
            subscriptionListId: t
        } = this.props;
        return t && !Wn.isReference(t) ? [st.operation.getBaseAsset(t), ...super.getContactLists()] : super.getContactLists()
    }
    getGDPRFields() {
        return this.props.gdprFieldsIds.map(t => ({
            id: t
        })).concat(super.getGDPRFields())
    }
    getCustomFields() {
        const t = rr.map(tr),
            o = this.props.fieldsIds.filter(r => !t.includes(r));
        return st.operation.getCustomsAssets(o).concat(super.getCustomFields())
    }
}
var e1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class bi extends Ne {
    static get CommonValidationMap() {
        return { ...nt,
            ...ct,
            ...Ch,
            ...wh,
            ...Bh,
            ...Sh,
            ...$h,
            name: d.string().allow(null),
            subscriptionListId: d.alternatives(d.string(), hi).allow(null),
            isHiddenOnMobile: d.boolean()
        }
    }
    constructor(t, o, r = null) {
        super(t, o, r)
    }
    regenerateContentIds() {
        return this.properties.hyperlink === null ? this : this.withProperties({
            hyperlink: { ...this.properties.hyperlink,
                id: Mt()
            }
        })
    }
    stripUserInformation() {
        return super.stripUserInformation().withProperties({
            name: null
        })
    }
    getPlaceholders() {
        return [new Za(Oe(), this.id)]
    }
    getPlaceholderHandlers() {
        return {
            [E.FormRedirect]: this.getPropertiesFromFromRedirectPlaceholder
        }
    }
    getFontFamilyProperties() {
        return ["labelFontFamily", "consentFontFamily", "fieldFontFamily", "buttonFontFamily"]
    }
    getPropertiesFromFromRedirectPlaceholder(t) {
        return {
            successViewMethod: So.Redirect,
            hyperlink: {
                id: Mt(),
                type: k.Web,
                target: Ce.Blank,
                href: t.value
            }
        }
    }
}
e1([Ue], bi, "CommonValidationMap", null);
class md extends $i {}
Object.defineProperty(md, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateFormNameSchemaPatch
});
class bd extends $i {}
Object.defineProperty(bd, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateContactFormNameSchemaPatch
});
class fd extends $i {}
Object.defineProperty(fd, "patchType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Ee.UpdateLightboxNameSchemaPatch
});
class Be {
    static registerBuilder(t) {
        Be.builders.set(t.patchType, t)
    }
    buildPatch({
        action: t,
        id: o,
        data: r
    }) {
        const i = Be.builders.get(t);
        if (i) return i.build(o, r);
        throw new Error(`There is no builder for patch type ${t}`)
    }
    buildPatches(t) {
        return t.map(o => this.buildPatch(o))
    }
}
Object.defineProperty(Be, "builders", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: new Map
});
Be.registerBuilder(Gs);
Be.registerBuilder(Us);
Be.registerBuilder(Hs);
Be.registerBuilder(Ys);
Be.registerBuilder(Ks);
Be.registerBuilder(Ds);
Be.registerBuilder(ed);
Be.registerBuilder(td);
Be.registerBuilder(zs);
Be.registerBuilder(qs);
Be.registerBuilder(od);
Be.registerBuilder(id);
Be.registerBuilder(_s);
Be.registerBuilder(Ns);
Be.registerBuilder(Vs);
Be.registerBuilder(Js);
Be.registerBuilder(Xs);
Be.registerBuilder(Ws);
Be.registerBuilder(Qs);
Be.registerBuilder(js);
Be.registerBuilder(md);
Be.registerBuilder(bd);
Be.registerBuilder(fd);
Be.registerBuilder(Zs);
Be.registerBuilder(nd);
Be.registerBuilder(rd);
Be.registerBuilder(ad);
Be.registerBuilder(ld);
class t1 extends Pi {
    applyPatch(t, o) {
        const r = super.applyPatch(t, o);
        return o instanceof md ? this.updateFormName(r, o) : r
    }
    deleteContactList(t, o) {
        const r = super.deleteContactList(t, o);
        return r.subscriptionListId === o.getId() ? { ...r,
            subscriptionListId: null
        } : r
    }
    updateContactList(t, o) {
        const r = super.updateContactList(t, o);
        return r.subscriptionListId === o.getId() ? { ...r,
            subscriptionListId: o.getData().id
        } : r
    }
    updateGdprField(t, o) {
        const r = super.updateGdprField(t, o),
            i = o.getId();
        return r.gdprFieldsById[o.getId()] ? { ...r,
            gdprFieldsIds: r.gdprFieldsIds.map(n => {
                var l;
                return n === i && (l = o.getData().id) !== null && l !== void 0 ? l : n
            }),
            gdprFieldsById: Object.fromEntries(Object.entries(r.gdprFieldsById).map(([n, l]) => {
                if (n === i) {
                    const {
                        name: s,
                        latestVersionContent: u,
                        id: c
                    } = o.getData();
                    return [c ? ? n, { ...l,
                        name: s ? ? l.name,
                        latestVersionContent: u ? ? l.latestVersionContent
                    }]
                }
                return [n, l]
            }))
        } : r
    }
    deleteGdprField(t, o) {
        const r = super.deleteGdprField(t, o),
            i = o.getId();
        if (r.gdprFieldsById[i]) {
            const l = Ca(r.gdprFieldsById, i);
            return { ...r,
                gdprFieldsById: l,
                gdprFieldsIds: r.gdprFieldsIds.filter(s => s !== i),
                areGDPRSEnabled: Object.values(l).length ? r.areGDPRSEnabled : !1
            }
        }
        return r
    }
    updateCustomField(t, o) {
        const r = super.updateCustomField(t, o),
            i = o.getId();
        return r.fieldsById[i] ? { ...r,
            fieldsIds: r.fieldsIds.map(n => {
                var l;
                return i === n && (l = o.getData().id) !== null && l !== void 0 ? l : n
            }),
            fieldsById: Object.fromEntries(Object.entries(r.fieldsById).map(([n, l]) => {
                if (n === i) {
                    const {
                        id: s
                    } = o.getData();
                    return [s ? ? i, xa(l, o.getData())]
                }
                return [n, l]
            }))
        } : r
    }
    deleteCustomField(t, o) {
        const r = super.deleteCustomField(t, o),
            i = o.getId();
        return r.fieldsById[i] ? { ...r,
            fieldsById: Ca(r.fieldsById, i),
            fieldsIds: r.fieldsIds.filter(l => l !== i)
        } : r
    }
    updateFormName(t, o) {
        return t.name === o.getId() ? { ...t,
            name: o.getData().name
        } : t
    }
    updateSubscriptionSettings(t, o) {
        const r = super.updateSubscriptionSettings(t, o);
        return Wn.isReference(r) ? r : { ...r,
            subscriptionListId: xf,
            autoresponderDay: pf,
            doubleOptIn: yf
        }
    }
}
const Ph = {
        origin: O.Palette,
        name: D.Two
    },
    Xi = {
        origin: O.Palette,
        name: D.Two
    },
    o1 = {
        origin: O.Palette,
        name: D.One
    },
    r1 = {
        origin: O.Palette,
        name: D.Four
    },
    n1 = {
        origin: O.Custom,
        value: "#FF0000"
    },
    Fh = {
        fieldBorderRadiusTopLeft: 5,
        fieldBorderRadiusTopRight: 5,
        fieldBorderRadiusBottomLeft: 5,
        fieldBorderRadiusBottomRight: 5,
        isFieldBorderRadiusEnabled: !0,
        isFieldBorderRadiusLocked: !0,
        fieldBorderWidthTop: 1,
        fieldBorderWidthLeft: 1,
        fieldBorderWidthRight: 1,
        fieldBorderWidthBottom: 1,
        fieldBorderStyleTop: Me.Solid,
        fieldBorderStyleLeft: Me.Solid,
        fieldBorderStyleRight: Me.Solid,
        fieldBorderStyleBottom: Me.Solid,
        isFieldBorderEnabled: !0,
        fieldBorderColorTop: Xi,
        fieldBorderColorLeft: Xi,
        fieldBorderColorRight: Xi,
        fieldBorderColorBottom: Xi,
        fieldBackgroundColor: o1,
        fieldErrorColor: n1,
        fieldPaddingTop: 12,
        fieldPaddingLeft: 5,
        fieldPaddingRight: 5,
        fieldPaddingBottom: 12,
        fieldWidth: 75,
        isFieldPaddingLocked: !1,
        fieldTextColor: Ph,
        fieldFontFamily: null,
        fieldFontSize: null,
        fieldIsBold: null,
        fieldIsItalic: null,
        fieldIsUnderline: null,
        fieldShadowColor: r1,
        fieldShadowBlurRadius: 5,
        fieldShadowOffsetX: 1,
        fieldShadowOffsetY: 1,
        fieldShadowOpacity: 0,
        fieldShadowSpreadRadius: -2,
        isFieldShadowEnabled: !1
    },
    Ih = {
        consentFontFamily: null,
        consentFontSize: null,
        consentLinkIsBold: null,
        consentLinkIsItalic: null,
        consentLinkIsUnderline: null,
        consentLinkHoverIsBold: null,
        consentLinkHoverIsItalic: null,
        consentLinkHoverIsUnderline: null
    },
    kh = {
        labelFontFamily: null,
        labelFontSize: null,
        labelIsBold: null,
        labelIsItalic: null,
        labelIsUnderline: null,
        labelTextColor: Ph
    },
    Th = {
        buttonBackgroundColor: null,
        buttonBackgroundHoverColor: null,
        buttonFontColor: null,
        buttonFontColorHover: null,
        buttonBorderColorTop: null,
        buttonBorderColorLeft: null,
        buttonBorderColorRight: null,
        buttonBorderColorBottom: null,
        buttonShadowColor: null,
        buttonInternalPaddingLeft: null,
        buttonInternalPaddingRight: null,
        buttonInternalPaddingTop: null,
        buttonInternalPaddingBottom: null,
        buttonFontFamily: null,
        buttonBorderRadiusTopLeft: null,
        buttonBorderRadiusTopRight: null,
        buttonBorderRadiusBottomLeft: null,
        buttonBorderRadiusBottomRight: null,
        isButtonRadiusEnabled: null,
        buttonShadowBlurRadius: null,
        buttonShadowOffsetX: null,
        buttonShadowOffsetY: null,
        buttonShadowOpacity: null,
        buttonShadowSpreadRadius: null,
        buttonBorderStyleTop: null,
        buttonBorderStyleLeft: null,
        buttonBorderStyleRight: null,
        buttonBorderStyleBottom: null,
        buttonBorderWidthTop: null,
        buttonBorderWidthLeft: null,
        buttonBorderWidthRight: null,
        buttonBorderWidthBottom: null,
        buttonBorderEnabled: null,
        buttonFontSize: null,
        isButtonFontBold: null,
        isButtonFontItalic: null,
        isButtonFontUnderLine: null,
        isButtonShadowEnabled: null,
        isButtonButtonRadiusLocked: null,
        isButtonInternalPaddingLocked: null,
        buttonText: "submit",
        buttonAlign: W.Center
    },
    Eh = {
        isHiddenOnMobile: !1,
        successViewMethod: So.ShowMessage,
        message: "",
        hyperlink: null,
        labelPlacement: Yo.AboveInput,
        requiredInputMarkerType: rn.Asterix,
        fieldsById: rr.reduce((e, t) => ({ ...e,
            [t.id]: t
        }), {}),
        fieldsIds: rr.map(tr),
        subscriptionListId: null,
        gdprFieldsById: {},
        gdprFieldsIds: [],
        areGDPRSEnabled: !1,
        isRecaptchaEnabled: !1,
        isContactUpdateEnabled: !1,
        autoresponderDay: null,
        doubleOptIn: !1,
        elementPosition: null,
        name: null,
        ...Fh,
        ...rt,
        ...kh,
        ...Th,
        ...Ih,
        isBoxPaddingEnabled: !0
    };
class fi extends bi {
    get validationMap() {
        return bi.CommonValidationMap
    }
    static fromJson(t) {
        return new fi(t.id, t.properties)
    }
    constructor(t, o = Eh) {
        super(t, fi.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new Qg(this.properties, this.getImageProperties()), this.patcherService = new t1(this.properties, this.getImageProperties())
    }
    stripUserInformation() {
        return super.stripUserInformation().withProperties({
            subscriptionListId: null,
            gdprFieldsIds: [],
            gdprFieldsById: {},
            areGDPRSEnabled: !1
        })
    }
    getPlaceholders() {
        return [...super.getPlaceholders(), new Ga(Oe(), this.id)]
    }
    getPlaceholderHandlers() {
        return { ...super.getPlaceholderHandlers(),
            [E.FormSubscriptionList]: this.getPropertiesFromFromSubscriptionListPlaceholder
        }
    }
    getPropertiesFromFromSubscriptionListPlaceholder(t) {
        return {
            subscriptionListId: t.value
        }
    }
}
Object.defineProperty(fi, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Form
});
class i1 extends Pi {
    applyPatch(t, o) {
        const r = super.applyPatch(t, o);
        return o instanceof bd ? this.updateFormName(r, o) : r
    }
    updateFormName(t, o) {
        return t.name === o.getId() ? { ...t,
            name: o.getData().name
        } : t
    }
}
var a1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
        var i = arguments.length,
            n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
            l;
        if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
        else
            for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
        return i > 3 && n && Object.defineProperty(t, o, n), n
    },
    xo;
(function(e) {
    e.Name = "name", e.Email = "email", e.Phone = "phone", e.Message = "message"
})(xo || (xo = {}));
const Zu = [{
        defaultValues: [""],
        format: Je.Text,
        id: "80ebb95a-01b7-4456-9ce0-6a7ab9d03862",
        name: xo.Name,
        label: "name",
        valueType: Pe.String,
        required: !0,
        min: null,
        max: null
    }, {
        defaultValues: [""],
        format: Je.Text,
        id: "c21d27a1-69ab-4064-bbf5-2e40d14a2884",
        name: xo.Email,
        label: "email",
        valueType: Pe.String,
        required: !0,
        min: null,
        max: null
    }, {
        defaultValues: [""],
        format: Je.Text,
        id: "64ef7c11-6186-4f66-b757-cdfc0f960abc",
        name: xo.Phone,
        label: "phone",
        valueType: Pe.Phone,
        required: !0,
        min: null,
        max: null
    }, {
        defaultValues: [""],
        format: Je.Textarea,
        id: "443fe2dd-1e93-4d8d-be2b-175f4cca1b29",
        name: xo.Message,
        label: "message",
        valueType: Pe.String,
        required: !0,
        min: null,
        max: null
    }],
    l1 = { ...Eh,
        fieldsById: Zu.reduce((e, t) => ({ ...e,
            [t.id]: t
        }), {}),
        fieldsIds: Zu.map(tr)
    };
class yn extends bi {
    get validationMap() {
        return { ...bi.CommonValidationMap,
            subscriptionListId: d.allow(null).only()
        }
    }
    static fromJson(t) {
        return new yn(t.id, t.properties)
    }
    constructor(t, o = l1) {
        super(t, yn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new ul(this.properties, this.getImageProperties()), this.patcherService = new i1(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(yn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.ContactForm
});
a1([Ue], yn.prototype, "validationMap", null);
const s1 = {
    overlayColor: {
        origin: O.Custom,
        value: "#00000080"
    }
};
var wa;
(function(e) {
    e.OnLanding = "OnLanding", e.OnExit = "OnExit", e.OnScroll = "OnScroll"
})(wa || (wa = {}));
var yo;
(function(e) {
    e.Small = "Small", e.Medium = "Medium", e.Large = "Large", e.FullScreen = "FullScreen", e.FullHeight = "FullHeight", e.Custom = "Custom"
})(yo || (yo = {}));
var Zo;
(function(e) {
    e.EveryTime = "EveryTime", e.EveryPageLoad = "EveryPageLoad", e.EverySession = "EverySession", e.Custom = "Custom"
})(Zo || (Zo = {}));
class d1 extends Ze {
    applyPatch(t, o) {
        const r = super.applyPatch(t, o);
        return o instanceof fd ? this.updateName(r, o) : r
    }
    updateName(t, o) {
        return t.name === o.getId() ? { ...t,
            name: o.getData().name
        } : t
    }
}
var u1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
const c1 = {
    isHiddenOnMobile: !1,
    position: be.CenterCenter,
    name: null,
    trigger: wa.OnLanding,
    minScrollPercentageWhenTriggers: 25,
    showAfterValue: 0,
    showAfterUnit: on.Seconds,
    size: yo.Small,
    customHeightPercentage: 50,
    customWidthPercentage: 50,
    isOverlayEnabled: !0,
    frequency: Zo.EveryTime,
    customFrequencyUnit: on.Hours,
    customFrequencyValue: 1,
    ...s1,
    ...rt,
    elementPosition: { ...As,
        type: Vo.Fixed
    },
    boxBackgroundColor: {
        origin: O.Palette,
        name: D.One
    }
};
class xn extends Ne {
    get validationMap() {
        return { ...nt,
            ...ct,
            isHiddenOnMobile: d.boolean(),
            position: d.valid(...Object.values(be)),
            name: d.string().allow(null),
            isOverlayEnabled: d.boolean(),
            overlayColor: N,
            trigger: d.valid(...Object.values(wa)),
            minScrollPercentageWhenTriggers: d.number(),
            size: d.valid(...Object.values(yo)),
            customHeightPercentage: d.number(),
            customWidthPercentage: d.number(),
            showAfterValue: d.number(),
            showAfterUnit: d.valid(...Object.values(on)),
            frequency: d.valid(...Object.values(Zo)),
            customFrequencyValue: d.number(),
            customFrequencyUnit: d.valid(...Object.values(on))
        }
    }
    static fromJson(t) {
        return new xn(t.id, t.properties)
    }
    constructor(t, o = c1) {
        super(t, xn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new d1(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(xn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Lightbox
});
u1([Ue], xn.prototype, "validationMap", null);
var vo;
(function(e) {
    e[e.AvatarAndName = 1] = "AvatarAndName", e[e.Avatar = 2] = "Avatar", e[e.Name = 3] = "Name"
})(vo || (vo = {}));
const h1 = { ...Os,
    boxPaddingTop: 30,
    boxPaddingLeft: 20,
    boxPaddingRight: 20,
    boxPaddingBottom: 10,
    isBoxPaddingEnabled: !0
};
var m1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class vn extends Ne {
    get validationMap() {
        return { ...nt,
            isHiddenOnMobile: d.boolean(),
            loginText: d.string().allow(""),
            registerText: d.string().allow(""),
            fontFamily: d.string().allow(null),
            fontSize: d.number().allow(null),
            isBold: d.boolean().allow(null),
            isItalic: d.boolean().allow(null),
            isUnderline: d.boolean().allow(null),
            color: N.allow(null),
            hoverColor: N.allow(null),
            mode: d.allow(...Object.values(vo)),
            align: ft
        }
    }
    static fromJson(t) {
        return new vn(t.id, t.properties)
    }
    constructor(t, o = {
        isHiddenOnMobile: !1,
        ...rt,
        ...h1,
        mode: vo.Name,
        loginText: "Log in",
        registerText: "Sign up",
        fontFamily: null,
        fontSize: null,
        isBold: null,
        isItalic: null,
        isUnderline: null,
        color: null,
        hoverColor: null,
        align: W.Center
    }) {
        super(t, vn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    getFontFamilyProperties() {
        return ["fontFamily"]
    }
}
Object.defineProperty(vn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.MemberProfile
});
m1([Ue], vn.prototype, "validationMap", null);
var _t;
(function(e) {
    e[e.Email = 0] = "Email", e[e.Password = 1] = "Password", e[e.Global = 2] = "Global"
})(_t || (_t = {}));
var b1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class Cn extends Ne {
    get validationMap() {
        return { ...nt,
            emailLabelContent: d.string().allow(""),
            passwordLabelContent: d.string().allow(""),
            submitButtonContent: d.string().allow(""),
            fontFamily: d.string().allow(null),
            fontSize: d.number().allow(null),
            isBold: d.boolean().allow(null),
            isItalic: d.boolean().allow(null),
            isUnderline: d.boolean().allow(null),
            color: N.allow(null)
        }
    }
    static fromJson(t) {
        return new Cn(t.id, t.properties)
    }
    constructor(t, o = { ...rt,
        emailLabelContent: "E-mail",
        passwordLabelContent: "Password",
        submitButtonContent: "Create account",
        fontFamily: null,
        fontSize: null,
        isBold: null,
        isItalic: null,
        isUnderline: null,
        color: null
    }) {
        super(t, Cn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    getFontFamilyProperties() {
        return ["fontFamily"]
    }
}
Object.defineProperty(Cn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.RegisterForm
});
b1([Ue], Cn.prototype, "validationMap", null);
var xs;
(function(e) {
    e[e.Shopify = 0] = "Shopify"
})(xs || (xs = {}));
var f1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class wn extends Ne {
    get validationMap() {
        return {
            isHiddenOnMobile: d.boolean(),
            content: d.string().allow(""),
            type: d.valid(...Object.values(xs)).allow(null),
            ...ct,
            ...nt
        }
    }
    static fromJson(t) {
        return new wn(t.id, t.properties)
    }
    constructor(t, o = {
        isHiddenOnMobile: !1,
        content: "",
        type: null,
        elementPosition: null,
        ...rt,
        boxPaddingTop: 10,
        boxPaddingLeft: 10,
        boxPaddingRight: 10,
        boxPaddingBottom: 10,
        isBoxPaddingEnabled: !0
    }) {
        super(t, wn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(wn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.BuyButton
});
f1([Ue], wn.prototype, "validationMap", null);
var g1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class Bn extends Ne {
    get validationMap() {
        return { ...nt,
            ...No,
            ...Mr,
            ...ct,
            fontFamily: No.fontFamily.allow(null),
            fontSize: No.fontSize.allow(null),
            isHiddenOnMobile: d.boolean(),
            backgroundColor: N,
            codeId: d.string().allow(null),
            align: ft
        }
    }
    static fromJson(t) {
        return new Bn(t.id, t.properties)
    }
    constructor(t, o = { ...dl,
        ...rt,
        ...Ri,
        paddingTop: 15,
        paddingLeft: 35,
        paddingRight: 35,
        paddingBottom: 15,
        boxPaddingBottom: 5,
        boxPaddingLeft: 5,
        boxPaddingRight: 5,
        boxPaddingTop: 5,
        isBoxPaddingEnabled: !0,
        fontFamily: null,
        fontSize: null,
        isBorderEnabled: !0,
        borderStyleRight: Me.Dashed,
        borderStyleLeft: Me.Dashed,
        borderStyleTop: Me.Dashed,
        borderStyleBottom: Me.Dashed,
        backgroundColor: {
            value: At,
            origin: O.Custom
        },
        isHiddenOnMobile: !1,
        elementPosition: null,
        codeId: null,
        isBold: !0,
        align: W.Center
    }) {
        super(t, Bn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
    getFontFamilyProperties() {
        return ["fontFamily"]
    }
    stripUserInformation() {
        return super.stripUserInformation().withProperties({
            codeId: null
        })
    }
}
Object.defineProperty(Bn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.PromoCode
});
g1([Ue], Bn.prototype, "validationMap", null);
const p1 = {
    fieldsById: rr.reduce((e, t) => ({ ...e,
        [t.id]: t
    }), {}),
    fieldsIds: rr.map(tr),
    gdprFieldsById: {},
    gdprFieldsIds: [],
    areGDPRSEnabled: !1,
    successViewMethod: So.ShowMessage,
    message: "",
    hyperlink: null,
    autoresponderDay: null,
    doubleOptIn: !1,
    labelPlacement: Yo.AboveInput,
    requiredInputMarkerType: rn.Asterix,
    designPage: null,
    isRecaptchaEnabled: !1,
    isContactUpdateEnabled: !1,
    ...Fh,
    ...kh,
    ...Th,
    ...Ih
};
class y1 extends _e {
    getWebinar() {
        const {
            webinarId: t
        } = this.props;
        return t ? [st.operation.getBaseAsset(t), ...super.getWebinar()] : super.getWebinar()
    }
    getGDPRFields() {
        return this.props.gdprFieldsIds.map(t => ({
            id: t
        })).concat(super.getGDPRFields())
    }
    getCustomFields() {
        const t = rr.map(tr),
            o = this.props.fieldsIds.filter(r => !t.includes(r));
        return st.operation.getCustomsAssets(o).concat(super.getCustomFields())
    }
}
class x1 extends Pi {
    updateGdprField(t, o) {
        const r = super.updateGdprField(t, o),
            i = o.getId();
        if (r.gdprFieldsById[o.getId()]) return { ...r,
            gdprFieldsIds: r.gdprFieldsIds.map(l => {
                var s;
                return l === i && (s = o.getData().id) !== null && s !== void 0 ? s : l
            }),
            gdprFieldsById: Object.fromEntries(Object.entries(r.gdprFieldsById).map(([l, s]) => {
                if (l === i) {
                    const {
                        name: u,
                        latestVersionContent: c,
                        id: h
                    } = o.getData();
                    return [h ? ? l, { ...s,
                        name: u ? ? s.name,
                        latestVersionContent: c ? ? s.latestVersionContent
                    }]
                }
                return [l, s]
            })),
            gdprFields: r.gdprFields.map(l => l.id === i ? { ...l,
                ...o.getData()
            } : l)
        };
        const n = r.gdprFieldsById[o.getId()];
        if (n) {
            const {
                name: l,
                latestVersionContent: s
            } = o.getData();
            return { ...r,
                gdprFieldsById: { ...r.gdprFieldsById,
                    [o.getId()]: { ...n,
                        name: l ? ? n.name,
                        latestVersionContent: s ? ? n.latestVersionContent
                    }
                },
                gdprFields: r.gdprFields.map(u => u.id === n.id ? { ...u,
                    ...o.getData()
                } : u)
            }
        }
        return r
    }
    deleteGdprField(t, o) {
        const r = super.deleteGdprField(t, o),
            i = o.getId();
        if (r.gdprFieldsById[i]) {
            const l = Ca(r.gdprFieldsById, i);
            return { ...r,
                gdprFields: r.gdprFields.filter(({
                    id: s
                }) => s !== i),
                gdprFieldsById: l,
                gdprFieldsIds: r.gdprFieldsIds.filter(s => s !== i),
                areGDPRSEnabled: Object.values(l).length !== 0
            }
        }
        return r
    }
    updateCustomField(t, o) {
        const r = super.updateCustomField(t, o),
            i = o.getId();
        return r.fieldsById[i] ? { ...r,
            fieldsIds: r.fieldsIds.map(n => {
                var l;
                return i === n && (l = o.getData().id) !== null && l !== void 0 ? l : n
            }),
            fieldsById: Object.fromEntries(Object.entries(r.fieldsById).map(([n, l]) => {
                if (n === i) {
                    const {
                        id: s
                    } = o.getData();
                    return [s ? ? i, xa(l, o.getData())]
                }
                return [n, l]
            }))
        } : r
    }
    deleteCustomField(t, o) {
        const r = super.deleteCustomField(t, o),
            i = o.getId();
        return r.fieldsById[i] ? { ...r,
            fieldsById: Ca(r.fieldsById, i),
            fieldsIds: r.fieldsIds.filter(l => l !== i)
        } : r
    }
    updateWebinar(t, o) {
        const r = super.updateWebinar(t, o);
        if (o.getId() === r.webinarId) {
            const {
                gdprFields: n,
                name: l,
                roomPin: s,
                roomLink: u,
                startsAtDate: c
            } = o.getData();
            return { ...r,
                gdprFields: n,
                webinarName: l,
                gdprFieldsIds: n.map(h => h.id),
                gdprFieldsById: n.reduce((h, m) => pg(h, fg(m)), {}),
                areGDPRSEnabled: n.length !== 0,
                roomPin: s,
                roomLink: u,
                startsAtDate: c
            }
        }
        return r
    }
    deleteWebinar(t, o) {
        const r = super.deleteWebinar(t, o);
        return o.getId() === r.webinarId ? { ...r,
            webinarId: null,
            webinarName: null,
            gdprFields: null,
            gdprFieldsById: {},
            gdprFieldsIds: [],
            areGDPRSEnabled: !1,
            roomPin: null,
            roomLink: null,
            startsAtDate: null
        } : r
    }
}
var v1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class Sn extends Ne {
    get validationMap() {
        return { ...nt,
            ...ng,
            ...Cg,
            ...Ch,
            ...wh,
            ...Bh,
            ...Sh,
            ...$h,
            ...ct,
            webinarId: d.string().allow(null),
            webinarName: d.string().allow(null),
            roomPin: d.string().allow(null),
            roomLink: d.string().allow(null),
            startsAtDate: d.string().allow(null),
            gdprFields: d.array().allow(null),
            emailLabelContent: d.string().allow(""),
            passwordLabelContent: d.string().allow(""),
            submitButtonContent: d.string().allow(""),
            backgroundColor: N,
            isHiddenOnMobile: d.boolean().allow(null),
            align: ft.allow(null),
            lineHeight: d.number().allow(null),
            type: d.number().allow(null),
            designPage: d.valid(...Object.values(cs)).allow(null)
        }
    }
    static fromJson(t) {
        return new Sn(t.id, t.properties)
    }
    constructor(t, o = { ...rt,
        ...eg,
        ...tg,
        ...p1,
        isBoxPaddingEnabled: !0,
        webinarId: null,
        webinarName: null,
        roomPin: null,
        roomLink: null,
        startsAtDate: null,
        gdprFields: null,
        emailLabelContent: "E-mail",
        passwordLabelContent: "Password",
        submitButtonContent: "Create account",
        backgroundColor: {
            value: At,
            origin: O.Custom
        },
        isHiddenOnMobile: null,
        align: W.Center,
        lineHeight: Si,
        type: q.Subheader,
        elementPosition: null
    }) {
        super(t, Sn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new y1(this.properties, this.getImageProperties()), this.patcherService = new x1(this.properties, this.getImageProperties())
    }
    getFontFamilyProperties() {
        return ["fontFamily"]
    }
}
Object.defineProperty(Sn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.Webinar
});
v1([Ue], Sn.prototype, "validationMap", null);
class C1 extends Ze {
    updateEcommerce(t, o) {
        const r = super.updateEcommerce(t, o);
        return Wn.isReference(r.storeId) ? { ...r,
            products: []
        } : r.storeId === o.getId() ? { ...r,
            ...o.getData(),
            products: r.storeId === o.getData().storeId ? r.products : []
        } : r
    }
}

function gd() {
    return Oe()
}
const w1 = {
        imageSize: Yt.Medium,
        imageStretchOnMobile: !1,
        imageAlign: W.Center,
        imageIsBorderEnabled: !1,
        imageBorderWidthTop: 0,
        imageBorderWidthBottom: 0,
        imageBorderWidthLeft: 0,
        imageBorderWidthRight: 0,
        imageBorderStyleTop: Me.Solid,
        imageBorderStyleLeft: Me.Solid,
        imageBorderStyleRight: Me.Solid,
        imageBorderStyleBottom: Me.Solid,
        imageBorderColorTop: {
            origin: O.Palette,
            name: D.Three
        },
        imageBorderColorLeft: {
            origin: O.Palette,
            name: D.Three
        },
        imageBorderColorRight: {
            origin: O.Palette,
            name: D.Three
        },
        imageBorderColorBottom: {
            origin: O.Palette,
            name: D.Three
        },
        imageIsRadiusEnabled: !1,
        imageBorderRadiusTopLeft: 0,
        imageBorderRadiusTopRight: 0,
        imageBorderRadiusBottomLeft: 0,
        imageBorderRadiusBottomRight: 0,
        imageIsRadiusLocked: !0,
        imageIsShadowEnabled: !1,
        imageShadowOffsetX: 0,
        imageShadowOffsetY: 0,
        imageShadowSpreadRadius: 0,
        imageShadowBlurRadius: 0,
        imageShadowColor: {
            origin: O.Palette,
            name: D.Three
        }
    },
    B1 = {
        buttonBorderColorTop: null,
        buttonBorderColorLeft: null,
        buttonBorderColorRight: null,
        buttonBorderColorBottom: null,
        buttonBorderStyleTop: null,
        buttonBorderStyleLeft: null,
        buttonBorderStyleRight: null,
        buttonBorderStyleBottom: null,
        buttonBorderWidthTop: null,
        buttonBorderWidthLeft: null,
        buttonBorderWidthRight: null,
        buttonBorderWidthBottom: null,
        buttonIsBorderEnabled: null,
        buttonBorderRadiusTopLeft: null,
        buttonBorderRadiusTopRight: null,
        buttonBorderRadiusBottomLeft: null,
        buttonBorderRadiusBottomRight: null,
        buttonIsRadiusLocked: null,
        buttonIsRadiusEnabled: null,
        buttonPaddingTop: null,
        buttonPaddingLeft: null,
        buttonPaddingRight: null,
        buttonPaddingBottom: null,
        buttonShadowColor: null,
        buttonShadowOffsetX: null,
        buttonShadowOffsetY: null,
        buttonShadowSpreadRadius: null,
        buttonShadowBlurRadius: null,
        buttonShadowOpacity: null,
        buttonIsShadowEnabled: null,
        buttonBackgroundColor: null,
        buttonTextColor: null,
        buttonFontFamily: null,
        buttonFontSize: null,
        buttonIsBold: null,
        buttonIsItalic: null,
        buttonIsUnderline: null,
        buttonIsSubscript: null,
        buttonIsSuperscript: null,
        buttonIsStrikethrough: null,
        buttonBackgroundColorHover: null,
        buttonTextColorHover: null,
        buttonAlign: W.Left
    },
    S1 = {
        productNameType: q.Subheader,
        productNameFontFamily: null,
        productNameFontSize: null,
        productNameFontStyleIsBold: null,
        productNameFontStyleIsItalic: null,
        productNameFontStyleIsUnderline: null,
        productNameFontColor: {
            origin: O.Palette,
            name: D.Two
        },
        productNameBackgroundColor: {
            origin: O.Custom,
            value: At
        },
        productNameAlignment: W.Left,
        productNameLineHeight: Si
    },
    $1 = {
        descriptionType: q.Paragraph,
        descriptionFontFamily: null,
        descriptionFontSize: null,
        descriptionFontStyleIsBold: null,
        descriptionFontStyleIsItalic: null,
        descriptionFontStyleIsUnderline: null,
        descriptionFontColor: {
            origin: O.Palette,
            name: D.Two
        },
        descriptionBackgroundColor: {
            origin: O.Custom,
            value: At
        },
        descriptionAlignment: W.Left,
        descriptionLineHeight: Si
    },
    R1 = {
        priceType: q.Subheader,
        priceFontSize: null,
        priceFontFamily: null,
        priceFontStyleIsBold: null,
        priceFontStyleIsItalic: null,
        priceFontStyleIsUnderline: null,
        priceFontStyleIsStrikethrough: !1,
        priceTextColor: {
            origin: O.Palette,
            name: D.Two
        },
        priceBackgroundColor: {
            origin: O.Custom,
            value: At
        },
        priceAlignment: W.Left
    },
    P1 = {
        buttonHyperlink: {
            id: gd(),
            href: "",
            type: k.Web,
            target: Ce.Blank
        },
        buttonButtonText: "BUY NOW",
        ...w1,
        ...B1,
        ...S1,
        ...$1,
        ...R1
    };

function Lh(e, t, o = new WeakMap) {
    if (Object.is(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
    if (o.get(e) === t) return !0;
    o.set(e, t);
    const r = Object.keys(e);
    if (Object.keys(t).length !== r.length) return !1;
    for (const i of r)
        if (!Object.hasOwn(t, i) || !Lh(e[i], t[i], o)) return !1;
    return !0
}

function F1(e, t) {
    return Lh(e, t)
}
class pd {
    constructor({
        root: t,
        entries: o
    }, r) {
        Object.defineProperty(this, "keys", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }), Object.defineProperty(this, "root", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "entries", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.root = t, this.entries = new Map(o)
    }
    setProperties(t, o) {
        o ? this.entries.set(o, { ...this.entries.get(o),
            ...t
        }) : (this.root = { ...this.root,
            ...t
        }, this.entries.forEach((r, i) => {
            this.entries.set(i, { ...r,
                ...t
            })
        }))
    }
    getProperties(t) {
        return t ? { ...this.root,
            ...this.entries.get(t)
        } : this.getPropertyNamesOfDifference(this.getEntries()).reduce((o, r) => ({ ...o,
            [r]: null
        }), this.root)
    }
    getRootProperties() {
        return this.root
    }
    getRawEntries() {
        return this.entries
    }
    toJSON() {
        return this.processStyles(), {
            root: this.root,
            entries: Array.from(this.entries)
        }
    }
    getEntries() {
        return Array.from(this.entries).reduce((t, [o, r]) => {
            if (this.keys.includes(o)) {
                const i = Object.keys(r).reduce((n, l) => F1(r[l], this.root[l]) ? n : { ...n,
                    [l]: r[l]
                }, {});
                Object.keys(i).length && t.push([o, i])
            }
            return t
        }, [])
    }
    getPropertyNamesOfDifference(t) {
        return t.flatMap(([, o]) => Object.keys(o)).filter((o, r, i) => i.indexOf(o) === r)
    }
    processStyles() {
        const t = this.getEntries();
        this.root = this.getPropertyNamesOfDifference(t).reduce((o, r) => t.length === this.keys.length && t.every(([, i]) => r in i) ? { ...o,
            [r]: t[0][1][r]
        } : o, this.root), this.entries = new Map(this.getEntries())
    }
}

function Mh(e) {
    const t = new pd(e.propertyStyles, e.products.map(({
        id: o
    }) => o));
    return [Ot.Top, Ot.Bottom].includes(e.layout) ? t.setProperties({
        imageAlign: W.Center,
        productNameAlignment: W.Center,
        descriptionAlignment: W.Center,
        priceAlignment: W.Center,
        buttonAlign: W.Center
    }) : t.setProperties({
        imageAlign: W.Left,
        productNameAlignment: W.Left,
        descriptionAlignment: W.Left,
        priceAlignment: W.Left,
        buttonAlign: W.Left
    }), { ...e,
        propertyStyles: t.toJSON()
    }
}
const I1 = Mh({ ...rt,
        products: [],
        propertyStyles: {
            root: P1,
            entries: []
        },
        storeId: null,
        provider: null,
        layout: Ot.Left,
        columns: 1,
        contentGap: 0,
        productGap: 0,
        elementPosition: null,
        isHiddenOnMobile: !1,
        storeCurrency: null,
        keepLayoutOnMobile: !1,
        isImageVisible: !0,
        isProductNameVisible: !0,
        isDescriptionVisible: !0,
        isPriceVisible: !0,
        isButtonVisible: !0
    }),
    Lo = N.allow(null),
    Ki = ot.allow(null),
    k1 = {
        buttonAlign: ft,
        buttonFontFamily: d.string().allow("", null),
        buttonFontSize: d.number().allow(null),
        buttonIsBold: d.boolean().allow(null),
        buttonIsItalic: d.boolean().allow(null),
        buttonIsUnderline: d.boolean().allow(null),
        buttonIsSubscript: d.boolean().allow(null),
        buttonIsSuperscript: d.boolean().allow(null),
        buttonIsStrikethrough: d.boolean().allow(null),
        buttonShadowOffsetX: d.number().allow(null),
        buttonShadowOffsetY: d.number().allow(null),
        buttonShadowBlurRadius: d.number().allow(null),
        buttonShadowSpreadRadius: d.number().allow(null),
        buttonShadowColor: Lo,
        buttonShadowOpacity: d.number().allow(null),
        buttonIsShadowEnabled: d.boolean().allow(null),
        buttonBorderRadiusTopLeft: d.number().allow(null),
        buttonBorderRadiusTopRight: d.number().allow(null),
        buttonBorderRadiusBottomLeft: d.number().allow(null),
        buttonBorderRadiusBottomRight: d.number().allow(null),
        buttonIsRadiusLocked: d.boolean().allow(null),
        buttonIsRadiusEnabled: d.boolean().allow(null),
        buttonBorderColorTop: Lo,
        buttonBorderColorLeft: Lo,
        buttonBorderColorRight: Lo,
        buttonBorderColorBottom: Lo,
        buttonBorderStyleTop: Ki,
        buttonBorderStyleLeft: Ki,
        buttonBorderStyleRight: Ki,
        buttonBorderStyleBottom: Ki,
        buttonBorderWidthTop: d.number().allow(null),
        buttonBorderWidthLeft: d.number().allow(null),
        buttonBorderWidthRight: d.number().allow(null),
        buttonBorderWidthBottom: d.number().allow(null),
        buttonIsBorderEnabled: d.boolean().allow(null),
        buttonPaddingLeft: d.number().allow(null),
        buttonPaddingRight: d.number().allow(null),
        buttonPaddingTop: d.number().allow(null),
        buttonPaddingBottom: d.number().allow(null),
        buttonTextColor: Lo,
        buttonTextColorHover: Lo,
        buttonBackgroundColor: Lo,
        buttonBackgroundColorHover: Lo
    },
    Oh = {
        imageSize: d.allow(null),
        imageStretchOnMobile: d.boolean().allow(!1),
        imageAlign: ft,
        imageIsBorderEnabled: d.boolean().allow(!1),
        imageBorderWidthTop: d.number().allow(null),
        imageBorderWidthBottom: d.number().allow(null),
        imageBorderWidthLeft: d.number().allow(null),
        imageBorderWidthRight: d.number().allow(null),
        imageBorderStyleTop: ot,
        imageBorderStyleLeft: ot,
        imageBorderStyleRight: ot,
        imageBorderStyleBottom: ot,
        imageBorderColorTop: N,
        imageBorderColorLeft: N,
        imageBorderColorRight: N,
        imageBorderColorBottom: N,
        imageIsRadiusEnabled: d.boolean().allow(!1),
        imageBorderRadiusTopLeft: d.number().allow(null),
        imageBorderRadiusTopRight: d.number().allow(null),
        imageBorderRadiusBottomLeft: d.number().allow(null),
        imageBorderRadiusBottomRight: d.number().allow(null),
        imageIsRadiusLocked: d.boolean().allow(!1),
        imageIsShadowEnabled: d.boolean().allow(!1),
        imageShadowOffsetX: d.number().allow(null),
        imageShadowOffsetY: d.number().allow(null),
        imageShadowSpreadRadius: d.number().allow(null),
        imageShadowBlurRadius: d.number().allow(null),
        imageShadowColor: N,
        productNameType: d.valid(...Object.values(q)).allow(null),
        productNameFontFamily: d.string().allow(null),
        productNameFontSize: d.number().allow(null),
        productNameFontStyleIsBold: d.boolean().allow(null),
        productNameFontStyleIsItalic: d.boolean().allow(null),
        productNameFontStyleIsUnderline: d.boolean().allow(null),
        productNameFontColor: N,
        productNameBackgroundColor: N,
        productNameAlignment: ft,
        productNameLineHeight: d.number().allow(null),
        descriptionType: d.valid(...Object.values(q)).allow(null),
        descriptionFontFamily: d.string().allow(null),
        descriptionFontSize: d.number().allow(null),
        descriptionFontStyleIsBold: d.boolean().allow(null),
        descriptionFontStyleIsItalic: d.boolean().allow(null),
        descriptionFontStyleIsUnderline: d.boolean().allow(null),
        descriptionFontColor: N,
        descriptionBackgroundColor: N,
        descriptionAlignment: ft,
        descriptionLineHeight: d.number().allow(null),
        priceType: d.valid(...Object.values(q)).allow(null),
        priceTextColor: N,
        priceBackgroundColor: N,
        priceAlignment: ft,
        priceFontSize: d.number().allow(null),
        priceFontFamily: d.string().allow(null).allow(""),
        priceFontStyleIsBold: d.boolean().allow(null),
        priceFontStyleIsItalic: d.boolean().allow(null),
        priceFontStyleIsUnderline: d.boolean().allow(null),
        priceFontStyleIsStrikethrough: d.boolean().allow(null),
        buttonButtonText: d.string().allow("", null),
        buttonHyperlink: On,
        ...k1
    },
    qu = d.object(Oh),
    T1 = d.object({
        root: qu,
        entries: d.array().items(d.array().ordered(d.string(), qu.fork(Object.keys(Oh), e => e.optional())))
    });
var E1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class $n extends Ne {
    get validationMap() {
        return { ...nt,
            ...ct,
            columns: d.number(),
            contentGap: d.number(),
            isHiddenOnMobile: d.boolean(),
            layout: d.allow(...Object.values(Ot)),
            productGap: d.number(),
            products: d.array().items({
                id: d.string()
            }),
            propertyStyles: T1,
            storeId: d.alternatives(d.string(), hi).allow(null),
            provider: d.alternatives(d.string(), hi).allow(null),
            storeCurrency: d.string().allow(null),
            keepLayoutOnMobile: d.boolean(),
            isImageVisible: d.boolean(),
            isProductNameVisible: d.boolean(),
            isDescriptionVisible: d.boolean(),
            isPriceVisible: d.boolean(),
            isButtonVisible: d.boolean()
        }
    }
    static fromJson(t) {
        return new $n(t.id, t.properties)
    }
    constructor(t, o = I1) {
        super(t, $n.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new C1(this.properties, this.getImageProperties())
    }
    stripUserInformation() {
        return super.stripUserInformation().withProperties({
            storeId: null,
            products: [],
            propertyStyles: {
                root: this.properties.propertyStyles.root,
                entries: []
            }
        })
    }
    withProperties(t) {
        return super.withProperties(this.applyDefaults(this.applySideEffects(t)))
    }
    applySideEffects(t) {
        var o;
        return t.products && (t.products.length !== this.properties.products.length || t.products.some(({
            id: r
        }) => !this.properties.products.some(i => i.id === r))) ? { ...t,
            propertyStyles: new pd((o = t.propertyStyles) !== null && o !== void 0 ? o : this.properties.propertyStyles, t.products.map(({
                id: r
            }) => r)).toJSON()
        } : t
    }
    applyDefaults(t) {
        var o, r;
        return typeof t.layout < "u" && t.layout !== this.properties.layout ? Mh({ ...t,
            layout: t.layout,
            propertyStyles: (o = t.propertyStyles) !== null && o !== void 0 ? o : this.properties.propertyStyles,
            products: (r = t.products) !== null && r !== void 0 ? r : this.properties.products
        }) : t
    }
}
Object.defineProperty($n, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.ProductBox
});
E1([Ue], $n.prototype, "validationMap", null);
const L1 = {
        buttonBackgroundColor: "backgroundColor",
        buttonTextColor: "textColor",
        buttonTextColorHover: "textColorHover",
        buttonBackgroundColorHover: "backgroundColorHover",
        buttonFontFamily: "fontFamily",
        buttonFontSize: "fontSize",
        buttonIsBold: "isBold",
        buttonIsItalic: "isItalic",
        buttonIsUnderline: "isUnderline",
        buttonShadowOffsetX: "shadowOffsetX",
        buttonShadowOffsetY: "shadowOffsetY",
        buttonShadowBlurRadius: "shadowBlurRadius",
        buttonShadowSpreadRadius: "shadowSpreadRadius",
        buttonShadowColor: "shadowColor",
        buttonShadowOpacity: "shadowOpacity",
        buttonIsShadowEnabled: "isShadowEnabled",
        buttonPaddingLeft: "paddingLeft",
        buttonPaddingRight: "paddingRight",
        buttonPaddingTop: "paddingTop",
        buttonPaddingBottom: "paddingBottom",
        buttonBorderRadiusTopLeft: "borderRadiusTopLeft",
        buttonBorderRadiusTopRight: "borderRadiusTopRight",
        buttonBorderRadiusBottomLeft: "borderRadiusBottomLeft",
        buttonBorderRadiusBottomRight: "borderRadiusBottomRight",
        buttonIsRadiusLocked: "isRadiusLocked",
        buttonIsRadiusEnabled: "isRadiusEnabled",
        buttonBorderColorTop: "borderColorTop",
        buttonBorderColorLeft: "borderColorLeft",
        buttonBorderColorRight: "borderColorRight",
        buttonBorderColorBottom: "borderColorBottom",
        buttonBorderStyleTop: "borderStyleTop",
        buttonBorderStyleLeft: "borderStyleLeft",
        buttonBorderStyleRight: "borderStyleRight",
        buttonBorderStyleBottom: "borderStyleBottom",
        buttonBorderWidthTop: "borderWidthTop",
        buttonBorderWidthLeft: "borderWidthLeft",
        buttonBorderWidthRight: "borderWidthRight",
        buttonBorderWidthBottom: "borderWidthBottom",
        buttonIsBorderEnabled: "isBorderEnabled"
    },
    M1 = {
        descriptionFontFamily: "fontFamily",
        descriptionFontSize: "fontSize",
        descriptionFontStyleIsBold: "isBold",
        descriptionFontStyleIsItalic: "isItalic",
        descriptionFontStyleIsUnderline: "isUnderline"
    },
    O1 = {
        priceFontFamily: "fontFamily",
        priceFontSize: "fontSize",
        priceFontStyleIsBold: "isBold",
        priceFontStyleIsItalic: "isItalic",
        priceFontStyleIsUnderline: "isUnderline"
    },
    A1 = {
        productNameFontFamily: "fontFamily",
        productNameFontSize: "fontSize",
        productNameFontStyleIsBold: "isBold",
        productNameFontStyleIsItalic: "isItalic",
        productNameFontStyleIsUnderline: "isUnderline"
    };
class W1 extends Ze {
    deleteContactList(t, o) {
        const r = super.deleteContactList(t, o);
        return r.subscriptionListId === o.getId() ? { ...r,
            subscriptionListId: null
        } : r
    }
    updateContactList(t, o) {
        const r = super.updateContactList(t, o);
        return r.subscriptionListId === o.getId() ? { ...r,
            subscriptionListId: o.getData().id
        } : r
    }
    updateCustomField(t, o) {
        const r = super.updateCustomField(t, o),
            i = o.getId();
        return r.contactInformationFields.some(n => n.id === i) && (r.contactInformationFields = r.contactInformationFields.map(n => n.id === i ? xa(n, o.getData()) : n)), r.billingDetailsFields.some(n => n.id === i) && (r.billingDetailsFields = r.billingDetailsFields.map(n => n.id === i ? xa(n, o.getData()) : n)), r
    }
    deleteCustomField(t, o) {
        const r = super.deleteCustomField(t, o),
            i = o.getId();
        return r.contactInformationFields.some(n => n.id === i) && (r.contactInformationFields = r.contactInformationFields.filter(n => n.id !== i)), r.billingDetailsFields.some(n => n.id === i) && (r.billingDetailsFields = r.billingDetailsFields.filter(n => n.id !== i)), r
    }
    updateGdprField(t, o) {
        const r = super.updateGdprField(t, o),
            i = o.getId();
        return r.consentFields[o.getId()] ? { ...r,
            consentFields: r.consentFields.map(n => {
                if (n.id === i) {
                    const {
                        name: l,
                        latestVersionContent: s
                    } = o.getData();
                    return { ...n,
                        name: l ? ? n.name,
                        latestVersionContent: s ? ? n.latestVersionContent
                    }
                }
                return n
            })
        } : r
    }
    deleteGdprField(t, o) {
        const r = super.deleteGdprField(t, o),
            i = o.getId();
        return r.consentFields[i] ? { ...r,
            consentFields: r.consentFields.filter(l => l.id !== i)
        } : r
    }
}
const D1 = [{
        defaultValues: go.defaultValues,
        format: go.format,
        id: go.id,
        name: go.name,
        label: "name",
        valueType: go.valueType,
        required: !0,
        min: null,
        max: null
    }, {
        defaultValues: po.defaultValues,
        format: po.format,
        id: po.id,
        name: po.name,
        label: "email",
        valueType: po.valueType,
        required: !0,
        min: null,
        max: null
    }],
    Ah = [...D1, {
        defaultValues: [""],
        format: Je.Text,
        id: "c21d27a1-69ab-4064-bbf5-2e40d14a2885",
        name: "phone",
        label: "Phone number",
        valueType: Pe.String,
        required: !0,
        min: null,
        max: null
    }],
    Wh = [{
        defaultValues: [""],
        format: Je.Text,
        id: "f804dcc8-16eb-44b9-9fad-f8e805cdc1b6",
        name: "country",
        label: "Country",
        valueType: Pe.String,
        required: !0,
        min: null,
        max: null
    }, {
        defaultValues: [""],
        format: Je.Text,
        id: "41c8383f-1853-48bd-a3a7-5c02a89ea47d",
        name: "street",
        label: "Street",
        valueType: Pe.String,
        required: !0,
        min: null,
        max: null
    }, {
        defaultValues: [""],
        format: Je.Text,
        id: "815932df-282f-48a1-b9f3-55c633e2e5b9",
        name: "postal_code",
        label: "Postal code",
        valueType: Pe.String,
        required: !0,
        min: null,
        max: null
    }, {
        defaultValues: [""],
        format: Je.Text,
        id: "ec0515e4-42c5-464d-a6ce-bcfdfefcbe53",
        name: "city",
        label: "City",
        valueType: Pe.String,
        required: !0,
        min: null,
        max: null
    }];
class N1 extends _e {
    getContactLists() {
        const {
            subscriptionListId: t
        } = this.props;
        return t ? [st.operation.getBaseAsset(t), ...super.getContactLists()] : super.getContactLists()
    }
    getCustomFields() {
        const t = [...Ah, ...Wh].map(tr),
            o = [...this.props.contactInformationFields, ...this.props.billingDetailsFields].map(tr).filter(r => !t.includes(r));
        return st.operation.getCustomsAssets(o).concat(super.getCustomFields())
    }
    getGDPRFields() {
        return this.props.consentFields.map(({
            id: t
        }) => st.operation.getBaseAsset(t)).concat(super.getGDPRFields())
    }
}
var U1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class Rn extends Ne {
    get validationMap() {
        return { ...nt,
            billingDetailsFields: d.array().items(ys),
            billingDetailsHeadingLabel: d.string(),
            contactInformationFields: d.array().items(ys),
            contactInformationHeadingLabel: d.string(),
            headingLabel: d.string(),
            hasConsentFields: d.boolean(),
            totalPriceLabel: d.string(),
            subscriptionListId: d.string().allow(null),
            consentFields: d.array().items(d.object({
                id: d.string(),
                latestVersionContent: d.string(),
                name: d.string(),
                required: d.boolean()
            }))
        }
    }
    static fromJson(t) {
        return new Rn(t.id, t.properties)
    }
    constructor(t, o = { ...rt,
        billingDetailsFields: Wh,
        billingDetailsHeadingLabel: "Billing details",
        contactInformationFields: Ah,
        contactInformationHeadingLabel: "Contact information",
        headingLabel: "Order summary",
        hasConsentFields: !1,
        totalPriceLabel: "Total price:",
        subscriptionListId: null,
        consentFields: []
    }) {
        super(t, Rn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new N1(this.properties, this.getImageProperties()), this.patcherService = new W1(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(Rn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.OrderForm
});
U1([Ue], Rn.prototype, "validationMap", null);
var V1 = globalThis && globalThis.__decorate || function(e, t, o, r) {
    var i = arguments.length,
        n = i < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, o) : r,
        l;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(e, t, o, r);
    else
        for (var s = e.length - 1; s >= 0; s--)(l = e[s]) && (n = (i < 3 ? l(n) : i > 3 ? l(t, o, n) : l(t, o)) || n);
    return i > 3 && n && Object.defineProperty(t, o, n), n
};
class Pn extends Ne {
    get validationMap() {
        return { ...nt
        }
    }
    static fromJson(t) {
        return new Pn(t.id, t.properties)
    }
    constructor(t, o = { ...rt
    }) {
        super(t, Pn.elementType, o), Object.defineProperty(this, "assetsService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "patcherService", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.assetsService = new _e(this.properties, this.getImageProperties()), this.patcherService = new Ze(this.properties, this.getImageProperties())
    }
}
Object.defineProperty(Pn, "elementType", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: I.ConfirmationPage
});
V1([Ue], Pn.prototype, "validationMap", null);

function H1(e) {
    return {
        type: e.elementType,
        implementation: e
    }
}
const Dh = new N0([An, an, ln, mi, sn, hn, cn, dn, mn, nn, Uo, un, en, bn, fn, gn, pn, fi, xn, yn, vn, Cn, wn, Bn, Sn, $n, Rn, Pn].map(H1));
class Jr extends U0 {
    static fromJson(t) {
        return new Jr(super.fromJson(t, {}, Dh.getDefinition()).getList())
    }
}
class Fn extends V0 {
    constructor(t = new Jr, o = new aa, r = new ba) {
        super(t, o, r, void 0, Dh)
    }
    static fromJson(t) {
        return new Fn(Jr.fromJson(t), aa.fromJson(t), new ba(t.customFonts))
    }
    static fromString(t) {
        return this.fromJson(JSON.parse(t))
    }
    factory(t, o, r) {
        return new Fn(t, o, r)
    }
    regenerateIds() {
        const t = {},
            o = [Kr, ...Object.values(Xt)];
        return this.withElements(Jr.fromJson({
            elements: this.elements.getList().toArray().map(r => {
                const i = o.includes(r.id) ? r.id : wr(r.type);
                return t[r.id] = i, r.withId(i).regenerateContentIds().toJSON()
            })
        })).withRelations(new aa(this.elementRelations.getList().map(r => r.withElementId(t[r.elementId]).withChildren(r.children.map(i => t[i])))))
    }
    getWebfonts() {
        return this.elements.getList().toArray().flatMap(t => t.getWebfonts())
    }
}
class yd {
    constructor(t, o, r, i, n) {
        Object.defineProperty(this, "isEnabled", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "title", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "message", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "button", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "decline", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.isEnabled = t, this.title = o, this.message = r, this.button = i, this.decline = n
    }
    static fromJson(t) {
        return new yd(t.isEnabled, t.title, t.message, t.button, t.decline)
    }
    toJSON() {
        return {
            title: this.title,
            message: this.message,
            button: this.button,
            isEnabled: this.isEnabled,
            decline: this.decline
        }
    }
}
class xd {
    constructor(t = null) {
        Object.defineProperty(this, "url", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.url = t
    }
    static fromJson(t) {
        return new xd(t.url)
    }
    toJSON() {
        return {
            url: this.url
        }
    }
    get hasIcon() {
        return this.url !== null
    }
}
var Te;
(function(e) {
    e[e.GoogleAnalytics = 0] = "GoogleAnalytics", e[e.GoogleTagManager = 1] = "GoogleTagManager", e[e.FacebookPixel = 2] = "FacebookPixel", e[e.YandexMetrica = 3] = "YandexMetrica", e[e.GoogleAds = 4] = "GoogleAds"
})(Te || (Te = {}));
class vd {
    constructor(t = new Ba, o = new Sa, r = new $a) {
        Object.defineProperty(this, "chats", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "analytics", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "stats", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.chats = t, this.analytics = o, this.stats = r
    }
    static fromJson(t) {
        return new vd(Ba.fromJson(t), Sa.fromJson(t), $a.fromJson(t))
    }
    toJSON() {
        return { ...this.chats.toJSON(),
            ...this.analytics.toJSON(),
            ...this.stats.toJSON()
        }
    }
}
class Ba {
    constructor(t = !1, o = null) {
        Object.defineProperty(this, "isEnabled", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "id", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.isEnabled = t, this.id = o
    }
    static fromJson(t) {
        return new Ba(t.isChatsEnabled, t.chatId)
    }
    toJSON() {
        return {
            isChatsEnabled: this.isEnabled,
            chatId: this.id
        }
    }
    get isConfigured() {
        return this.isEnabled && this.id !== null && this.id.trim().length > 0
    }
}
class Sa {
    constructor(t = !1, o = []) {
        Object.defineProperty(this, "isEnabled", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "platforms", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.isEnabled = t, this.platforms = o
    }
    static fromJson(t) {
        return new Sa(t.isAnalyticsEnabled, t.analyticsPlatforms)
    }
    toJSON() {
        return {
            isAnalyticsEnabled: this.isEnabled,
            analyticsPlatforms: this.platforms
        }
    }
    isPlatformConfigured(t) {
        if (!this.isEnabled) return !1;
        const o = this.platforms.find(r => r.type === t);
        if (o === void 0) return !1;
        switch (o.type) {
            case Te.FacebookPixel:
            case Te.GoogleAnalytics:
            case Te.GoogleTagManager:
            case Te.YandexMetrica:
                return o.id.length > 0;
            case Te.GoogleAds:
                return o.id.length > 0 && o.label.length > 0
        }
        throw new Error(`Unknown platform: ${t}`)
    }
}
class $a {
    constructor(t = !0) {
        Object.defineProperty(this, "isCookieEnabled", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.isCookieEnabled = t
    }
    static fromJson(t) {
        return new $a(t.isStatsCookieEnabled)
    }
    toJSON() {
        return {
            isStatsCookieEnabled: this.isCookieEnabled
        }
    }
}
class Cd {
    constructor(t = "", o = "", r = "", i = "", n = "", l = "", s = "", u = "") {
        Object.defineProperty(this, "company", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "country", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        }), Object.defineProperty(this, "state", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }), Object.defineProperty(this, "postalCode", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: i
        }), Object.defineProperty(this, "city", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: n
        }), Object.defineProperty(this, "street", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: l
        }), Object.defineProperty(this, "phoneNumber", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: s
        }), Object.defineProperty(this, "email", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: u
        })
    }
    static fromJson(t) {
        return new Cd(t.company, t.country, t.state, t.postalCode, t.city, t.street, t.phoneNumber, t.email)
    }
    toJSON() {
        return {
            company: this.company,
            country: this.country,
            state: this.state,
            postalCode: this.postalCode,
            city: this.city,
            street: this.street,
            phoneNumber: this.phoneNumber,
            email: this.email
        }
    }
}
class Go {
    constructor(t = !1) {
        Object.defineProperty(this, "isEnabled", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        })
    }
    static fromJson(t = !1) {
        return new Go(t)
    }
    toJSON() {
        return this.isEnabled
    }
}
class wd {
    constructor(t = new Go(!1), o = new Go(!1), r = new Go(!1)) {
        Object.defineProperty(this, "lazyShowElements", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "freemium", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        }), Object.defineProperty(this, "statsObfuscation", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        })
    }
    static fromJson(t) {
        return new wd(Go.fromJson(t.lazyShowElements), Go.fromJson(t.freemium), Go.fromJson(t.statsObfuscation))
    }
    toJSON() {
        return this.removeDisabledExperiments({
            lazyShowElements: this.lazyShowElements.toJSON(),
            freemium: this.freemium.toJSON(),
            statsObfuscation: this.statsObfuscation.toJSON()
        })
    }
    removeDisabledExperiments(t) {
        const o = {};
        for (const r in t) t[r] && (o[r] = t[r]);
        return o
    }
}
class Bd {
    constructor(t = null, o = null, r = null, i = null, n = !1, l = null) {
        Object.defineProperty(this, "webPushId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "webPushIdPanelApiEncoded", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "grUserId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "trackingUrl", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "isActive", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "domain", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.webPushId = t, this.webPushIdPanelApiEncoded = o, this.grUserId = r, this.trackingUrl = i, this.isActive = n, this.domain = l
    }
    static fromJson(t) {
        return new Bd(t.webPushId, t.webPushIdPanelApiEncoded, t.grUserId, t.trackingUrl, t.isActive, t.domain)
    }
    toJSON() {
        return {
            webPushId: this.webPushId,
            webPushIdPanelApiEncoded: this.webPushIdPanelApiEncoded,
            grUserId: this.grUserId,
            trackingUrl: this.trackingUrl,
            isActive: this.isActive,
            domain: this.domain
        }
    }
}
class Sd {
    constructor(t = hs.EN) {
        Object.defineProperty(this, "code", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.code = t
    }
    static fromJson(t) {
        return new Sd(t.code)
    }
    toJSON() {
        return {
            code: this.code
        }
    }
}
class $d {
    constructor(t = null, o = null) {
        Object.defineProperty(this, "storeId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "provider", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    static fromJson(t) {
        return new $d(t.storeId, t.provider)
    }
    toJSON() {
        return {
            storeId: this.storeId,
            provider: this.provider
        }
    }
}
class Ra {
    static fromJson(t) {
        return new Ra(t ? .id, t ? .autoresponderDay, t ? .doubleOptIn)
    }
    constructor(t = null, o = null, r = !1) {
        Object.defineProperty(this, "id", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "autoresponderDay", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        }), Object.defineProperty(this, "doubleOptIn", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        })
    }
    toJSON() {
        return this.id ? {
            id: this.id,
            autoresponderDay: this.autoresponderDay,
            doubleOptIn: this.doubleOptIn
        } : null
    }
    with({
        id: t = this.id,
        autoresponderDay: o = this.autoresponderDay,
        doubleOptIn: r = this.doubleOptIn
    }) {
        return new Ra(t, o, r)
    }
    withId(t) {
        return this.with({
            id: t
        })
    }
}
class gi {
    constructor(t, o, r, i, n, l, s, u, c) {
        Object.defineProperty(this, "favicon", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "cookieBanner", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        }), Object.defineProperty(this, "analytics", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }), Object.defineProperty(this, "businessInformation", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: i
        }), Object.defineProperty(this, "experiments", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: n
        }), Object.defineProperty(this, "webPush", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: l
        }), Object.defineProperty(this, "language", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: s
        }), Object.defineProperty(this, "ecommerce", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: u
        }), Object.defineProperty(this, "subscription", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: c
        })
    }
    static fromJson(t) {
        const o = t.webPush.map(r => Bd.fromJson(r));
        return new gi(xd.fromJson(t.favicon), yd.fromJson(t.cookieBanner), vd.fromJson(t.analytics), Cd.fromJson(t.businessInformation), wd.fromJson(t.experiments), o, Sd.fromJson(t.language), $d.fromJson(t.ecommerce), Ra.fromJson(t.subscription))
    }
    static fromWebsiteString(t) {
        return this.fromJson(JSON.parse(t).settings)
    }
    toJSON() {
        return {
            favicon: this.favicon.toJSON(),
            cookieBanner: this.cookieBanner.toJSON(),
            analytics: this.analytics.toJSON(),
            businessInformation: this.businessInformation.toJSON(),
            experiments: this.experiments.toJSON(),
            webPush: this.webPush.map(t => t.toJSON()),
            language: this.language.toJSON(),
            ecommerce: this.ecommerce.toJSON(),
            subscription: this.subscription.toJSON()
        }
    }
    with({
        favicon: t = this.favicon,
        cookieBanner: o = this.cookieBanner,
        analytics: r = this.analytics,
        businessInformation: i = this.businessInformation,
        experiments: n = this.experiments,
        webPush: l = this.webPush,
        language: s = this.language,
        ecommerce: u = this.ecommerce,
        subscription: c = this.subscription
    }) {
        return new gi(t, o, r, i, n, l, s, u, c)
    }
    withFavicon(t) {
        return this.with({
            favicon: t
        })
    }
    withCookieBanner(t) {
        return this.with({
            cookieBanner: t
        })
    }
    withAnalytics(t) {
        return this.with({
            analytics: t
        })
    }
    withBusinessInformation(t) {
        return this.with({
            businessInformation: t
        })
    }
    withExperiments(t) {
        return this.with({
            experiments: t
        })
    }
    withWebPush(t) {
        return this.with({
            webPush: t
        })
    }
    withLanguage(t) {
        return this.with({
            language: t
        })
    }
    withEcommerce(t) {
        return this.with({
            ecommerce: t
        })
    }
    withSubscription(t) {
        return this.with({
            subscription: t
        })
    }
}

function Yn(e) {
    return e === Te.GoogleAds ? {
        type: e,
        id: "",
        label: ""
    } : {
        type: e,
        id: ""
    }
}
Te.GoogleAnalytics + "", Yn(Te.GoogleAnalytics), Te.GoogleTagManager + "", Yn(Te.GoogleTagManager), Te.FacebookPixel + "", Yn(Te.FacebookPixel), Te.YandexMetrica + "", Yn(Te.YandexMetrica), Te.GoogleAds + "", Yn(Te.GoogleAds);

function j1() {
    const e = wr(Jo.Section);
    return new Fn(new Jr(new ba([new An(Kr), new Uo(Xt.Header), new Uo(e), new Uo(Xt.Footer)])), new aa(new ba([H0.createRelation(Kr, [Xt.Header, e, Xt.Footer])]))).toJSON()
}
Bo.Public, j1(), kr.Active, we.Internal, gd();
class Ju {
    constructor(t, o = {}) {
        Object.defineProperty(this, "page", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "params", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.page = t, this.params = o
    }
}
class Co {
    static prepareUrl(t) {
        return t.replace(/\s/g, "%20")
    }
    static isExternalPage(t) {
        return t.type === we.External
    }
    static isContentPage(t) {
        return [we.NotFound, we.Internal, we.EnterPassword, we.Login, we.Register, we.Order, we.Confirmation].includes(t.type)
    }
    static findPage(t, o) {
        const r = Co.prepareUrl(o);
        if (Co.isHomepagePath(r)) {
            const i = Co.findHomepage(t);
            return i === null ? null : new Ju(i)
        }
        for (const i of t.pages) {
            const l = new Mu(Co.prepareUrl(i.url)).match(r);
            if (!!l) return new Ju(i, l)
        }
        return null
    }
    static findPagesByPattern(t, o) {
        const r = new Mu(o);
        return t.filter(i => r.match(i.url))
    }
    static findHomepage(t) {
        var o;
        return (o = t.pages.find(r => r.isHomepage)) !== null && o !== void 0 ? o : null
    }
    static isHomepagePath(t) {
        return t === "/"
    }
    static getContentPageUrl(t) {
        return t.isHomepage ? "/" : t.url
    }
}
class z1 extends st {
    constructor(t) {
        super(t), Object.defineProperty(this, "props", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        })
    }
    getAutoresponders() {
        return []
    }
    getContactLists() {
        return []
    }
    getCustomFields() {
        return []
    }
    getGDPRFields() {
        return []
    }
    getWebinar() {
        return []
    }
    getHyperlinks() {
        const {
            hyperlink: t,
            url: o
        } = this.props;
        return t ? [{ ...t,
            href: o
        }] : []
    }
    getLandingPages() {
        return he.getLandingPageAssets(this.props.hyperlink)
    }
    getStorageFiles() {
        return he.getDocumentAssets(this.props.hyperlink)
    }
    getWebsites() {
        return he.getWebsitesAssets(this.props.hyperlink)
    }
    getPages() {
        return he.getPagesAssets(this.props.hyperlink)
    }
    getWebPush() {
        return []
    }
}
class _1 extends st {
    constructor(t) {
        super(t), Object.defineProperty(this, "props", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        })
    }
    getAutoresponders() {
        return []
    }
    getContactLists() {
        return []
    }
    getCustomFields() {
        return []
    }
    getGDPRFields() {
        return []
    }
    getHyperlinks() {
        return []
    }
    getLandingPages() {
        return []
    }
    getWebinar() {
        return []
    }
    getStorageFiles() {
        const {
            socialImage: t
        } = this.props;
        return Fr(t) ? [st.operation.getStorageAsset(t.data)] : []
    }
    getWebsites() {
        return []
    }
    getPages() {
        return []
    }
    getWebPush() {
        return []
    }
}
class G1 {
    static getAssets(t) {
        return Co.isExternalPage(t) ? new z1(t).getAllAssets() : new _1(t).getAllAssets()
    }
    static getUsedStorageImages(t) {
        const o = [t.socialImage];
        return t.content && o.push(...Fn.fromJson(t.content).elements.getList().map(r => r.getUsedStorageImages()).reduce((r, i) => [...r, ...i], [])), o
    }
}
class Rd {
    static getPixel(...t) {
        const o = [...new Set(t.filter(n => n && n.type === Ye.Storage).filter(n => {
                const {
                    showPixel: l,
                    provider: s,
                    externalId: u
                } = n.data;
                return l && u && s === ya.Unsplash
            }).map(n => n.data.externalId))],
            r = [],
            i = 20;
        for (let n = 0, l = o.length; n < l; n += i) r.push(o.slice(n, n + i));
        return r.map(n => `https://views.unsplash.com/v?app_id=225253&photo_id=${n.join(",")}`)
    }
    static getPixelsFromPage(t) {
        return Rd.getPixel(...G1.getUsedStorageImages(t))
    }
}
class Pa {
    constructor(t = Pa.defaultProperties, o = null) {
        Object.defineProperty(this, "properties", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "customProperties", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    toJSON() {
        return {
            customProperties: this.customProperties,
            defaultProperties: this.properties
        }
    }
    static fromJSON(t) {
        return new Pa(t.defaultProperties, t.customProperties)
    }
}
Object.defineProperty(Pa, "defaultProperties", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: {
        paddingTop: 18,
        paddingLeft: 44,
        paddingRight: 44,
        paddingBottom: 18,
        backgroundColor: {
            origin: O.Palette,
            name: D.Three
        },
        textColor: {
            origin: O.Palette,
            name: D.One
        },
        borderRadiusTopLeft: 0,
        borderRadiusTopRight: 0,
        borderRadiusBottomLeft: 0,
        borderRadiusBottomRight: 0,
        fontFamily: Ur,
        fontSize: 16,
        isBold: !0,
        isItalic: !1,
        isUnderline: !1,
        borderWidthTop: 1,
        borderWidthLeft: 1,
        borderWidthRight: 1,
        borderWidthBottom: 1,
        borderStyleTop: Me.Solid,
        borderStyleLeft: Me.Solid,
        borderStyleRight: Me.Solid,
        borderStyleBottom: Me.Solid,
        borderColorTop: {
            origin: O.Palette,
            name: D.Three
        },
        borderColorLeft: {
            origin: O.Palette,
            name: D.Three
        },
        borderColorRight: {
            origin: O.Palette,
            name: D.Three
        },
        borderColorBottom: {
            origin: O.Palette,
            name: D.Three
        },
        isBorderEnabled: !0,
        shadowColor: {
            origin: O.Custom,
            value: "#000000"
        },
        shadowOffsetX: -4,
        shadowOffsetY: 4,
        shadowSpreadRadius: 0,
        shadowBlurRadius: 0,
        shadowOpacity: 95,
        isShadowEnabled: !1,
        isRadiusLocked: !0,
        backgroundColorHover: {
            origin: O.Palette,
            name: D.Three
        },
        textColorHover: {
            origin: O.Palette,
            name: D.One
        },
        isRadiusEnabled: !1
    }
});
class Yr {
    constructor(t = Yr.defaultProperties.selectedPaletteUUID, o = Yr.defaultProperties.availablePalettes) {
        Object.defineProperty(this, "selectedPaletteUUID", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "availablePalettes", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    toJSON() {
        return {
            selectedPaletteUUID: this.selectedPaletteUUID,
            availablePalettes: this.availablePalettes
        }
    }
    static fromJSON(t) {
        return new Yr(t.selectedPaletteUUID, t.availablePalettes)
    }
    static generatePalette(t) {
        const o = Object.values(D).map((r, i) => {
            var n;
            return {
                name: r,
                origin: O.Palette,
                value: (n = t[i]) !== null && n !== void 0 ? n : "#000000"
            }
        });
        return {
            uuid: gd(),
            colors: o,
            defaultColors: o
        }
    }
    static generatePaletteTheming() {
        const t = this.generatePalette(["#FFFFFF", "#1C1C1CFF", "#FF0068FF", "#F8F8F8FF", "#727272FF"]);
        return {
            selectedPaletteUUID: t.uuid,
            availablePalettes: [t, this.generatePalette(["#202730", "#FFFFFF", "#00BAFF", "#A0C3D5FF", "#0E1014"])]
        }
    }
}
Object.defineProperty(Yr, "defaultProperties", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Yr.generatePaletteTheming()
});
class Fa {
    constructor(t = Fa.defaultProperties, o = null) {
        Object.defineProperty(this, "predefined", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "custom", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    toJSON() {
        return {
            predefined: this.predefined,
            custom: this.custom
        }
    }
    static fromJSON(t) {
        return new Fa(t.predefined, t.custom)
    }
}
Object.defineProperty(Fa, "defaultProperties", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: {
        [Ve.TopHeader]: {
            fontFamily: Ur,
            fontSize: 44,
            isBold: !0,
            isItalic: !1,
            isUnderline: !1
        },
        [Ve.Header]: {
            fontFamily: Ur,
            fontSize: 32,
            isBold: !0,
            isItalic: !1,
            isUnderline: !1
        },
        [Ve.Subheader]: {
            fontFamily: Ur,
            fontSize: 20,
            isBold: !0,
            isItalic: !1,
            isUnderline: !1
        },
        [Ve.Paragraph]: {
            fontFamily: Ur,
            fontSize: 14,
            isBold: !1,
            isItalic: !1,
            isUnderline: !1
        },
        [Ve.Meta]: {
            fontFamily: Ur,
            fontSize: 12,
            isBold: !1,
            isItalic: !1,
            isUnderline: !1
        },
        [Ve.Link]: {
            fontFamily: "inherit",
            fontSize: 14,
            isBold: !1,
            isItalic: !1,
            isUnderline: !0
        },
        [Ve.HoverLink]: {
            fontFamily: "inherit",
            fontSize: 14,
            isBold: !1,
            isItalic: !1,
            isUnderline: !0
        }
    }
});
const T = e => {
    const {
        viewBox: t,
        alt: o,
        id: r,
        children: i
    } = e, n = r ? `icon-title-${r}` : void 0;
    return y("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: t,
        role: "img",
        "aria-labelledby": n,
        children: [o ? a("title", {
            id: n,
            children: o
        }) : null, i]
    })
};
T.displayName = T.name;
T.defaultProps = {
    viewBox: "0 0 34 34"
};
const Z1 = e => a(T, {
        viewBox: "0 0 32 32",
        alt: e.alt,
        id: e.id,
        children: a("g", {
            children: a("path", {
                fill: "currentColor",
                d: "M12.7,24.9h3.7V16h2.5l0.3-3.1h-2.8v-1.5c0-0.8,0.1-1.2,1.2-1.2h1.5V7.1h-2.5c-2.9,0-4,1.5-4,4v1.8h-1.8V16h1.8L12.7,24.9z"
            })
        })
    }),
    q1 = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M14.69,25.9h3.68V17h2.45l.33-3.07H18.37V12.39c0-.8.08-1.22,1.23-1.22h1.53V8.1H18.68c-2.95,0-4,1.49-4,4v1.84H12.85V17h1.84Z"
        })]
    }),
    J1 = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M14.69,25.9h3.68V17h2.45l.33-3.07H18.37V12.39c0-.8.08-1.22,1.23-1.22h1.53V8.1H18.68c-2.95,0-4,1.49-4,4v1.84H12.85V17h1.84Z"
        })]
    }),
    Y1 = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#3b5998",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M14.69,25.9h3.68V17h2.45l.33-3.07H18.37V12.39c0-.8.08-1.22,1.23-1.22h1.53V8.1H18.68c-2.95,0-4,1.49-4,4v1.84H12.85V17h1.84Z"
        })]
    }),
    X1 = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "#3b5998",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#3b5998",
            d: "M14.69,25.9h3.68V17h2.45l.33-3.07H18.37V12.39c0-.8.08-1.22,1.23-1.22h1.53V8.1H18.68c-2.95,0-4,1.49-4,4v1.84H12.85V17h1.84Z"
        })]
    }),
    K1 = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#CCC",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M14.69,25.9h3.68V17h2.45l.33-3.07H18.37V12.39c0-.8.08-1.22,1.23-1.22h1.53V8.1H18.68c-2.95,0-4,1.49-4,4v1.84H12.85V17h1.84Z"
        })]
    }),
    Q1 = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M14.69,25.9h3.68V17h2.45l.33-3.07H18.37V12.39c0-.8.08-1.22,1.23-1.22h1.53V8.1H18.68c-2.95,0-4,1.49-4,4v1.84H12.85V17h1.84Z"
        })]
    }),
    ep = e => a(T, {
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: "currentColor",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Zm3.82,16H18.37v8.9H14.69V17H12.85V13.93h1.84V12.09c0-2.5,1-4,4-4h2.45v3.07H19.6c-1.15,0-1.23.43-1.23,1.22v1.54h2.78Z"
        })
    }),
    tp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M14.69,25.9h3.68V17h2.45l.33-3.07H18.37V12.39c0-.8.08-1.22,1.23-1.22h1.53V8.1H18.68c-2.95,0-4,1.49-4,4v1.84H12.85V17h1.84Z"
        })]
    }),
    op = e => a(T, {
        viewBox: "0 0 32 32",
        alt: e.alt,
        id: e.id,
        children: y("g", {
            children: [a("path", {
                fill: "currentColor",
                d: "M16,8.1c2.6,0,2.9,0,3.9,0.1c0.6,0,1.2,0.1,1.8,0.3c0.4,0.2,0.8,0.4,1.1,0.7c0.3,0.3,0.6,0.7,0.7,1.1c0.2,0.6,0.3,1.2,0.3,1.8c0,1,0,1.3,0,3.9s0,2.9,0,3.9c0,0.6-0.1,1.2-0.3,1.8c-0.3,0.8-1,1.5-1.8,1.8c-0.6,0.2-1.2,0.3-1.8,0.3c-1,0-1.3,0.1-3.9,0.1s-2.9,0-3.9-0.1c-0.6,0-1.2-0.1-1.8-0.3c-0.8-0.3-1.5-1-1.8-1.8c-0.2-0.6-0.3-1.2-0.3-1.8c-0.1-1-0.1-1.3-0.1-3.9s0-2.9,0.1-3.9c0-0.6,0.1-1.2,0.3-1.8C8.8,9.9,9,9.5,9.3,9.2c0.3-0.3,0.7-0.6,1.1-0.7c0.6-0.2,1.2-0.3,1.8-0.3C13.1,8.2,13.4,8.1,16,8.1 M16,6.4c-2.6,0-2.9,0-4,0c-0.8,0-1.6,0.2-2.3,0.4C9,7.1,8.5,7.5,8,8S7.1,9.1,6.9,9.7c-0.3,0.7-0.4,1.5-0.5,2.3c0,1-0.1,1.4-0.1,4s0,2.9,0.1,4c0,0.8,0.2,1.6,0.4,2.3C7.1,23,7.5,23.5,8,24s1.1,0.9,1.7,1.1c0.7,0.3,1.5,0.4,2.3,0.5c1,0,1.4,0,4,0s2.9,0,4,0c0.8,0,1.6-0.2,2.3-0.5c0.6-0.3,1.2-0.6,1.6-1.1c0.5-0.5,0.9-1.1,1.1-1.7c0.3-0.7,0.4-1.5,0.5-2.3c0-1,0.1-1.4,0.1-4s0-2.9-0.1-4c0-0.8-0.2-1.6-0.5-2.3C24.9,9,24.5,8.5,24,8s-1.1-0.9-1.7-1.1c-0.7-0.3-1.5-0.4-2.3-0.5C19,6.4,18.6,6.4,16,6.4L16,6.4z"
            }), a("path", {
                fill: "currentColor",
                d: "M16,11.1c-2.7,0-4.9,2.2-4.9,4.9s2.2,4.9,4.9,4.9s4.9-2.2,4.9-4.9l0,0C20.9,13.3,18.8,11.1,16,11.1z M16,19.2c-1.8,0-3.2-1.4-3.2-3.2s1.4-3.2,3.2-3.2s3.2,1.4,3.2,3.2l0,0C19.2,17.8,17.8,19.2,16,19.2z"
            }), a("circle", {
                fill: "currentColor",
                cx: "21.1",
                cy: "10.9",
                r: "1.1"
            })]
        })
    }),
    rp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), y("g", {
            children: [a("path", {
                fill: "currentColor",
                d: "M17,10.43c2.14,0,2.39,0,3.24.05a4.58,4.58,0,0,1,1.49.28,2.45,2.45,0,0,1,.92.6,2.49,2.49,0,0,1,.6.92,4.26,4.26,0,0,1,.27,1.48c0,.85.05,1.1.05,3.24s0,2.39-.05,3.24a4.39,4.39,0,0,1-.27,1.49,2.67,2.67,0,0,1-1.52,1.52,4.39,4.39,0,0,1-1.49.27c-.85,0-1.1.05-3.24.05s-2.39,0-3.24-.05a4.39,4.39,0,0,1-1.49-.27,2.67,2.67,0,0,1-1.52-1.52,4.39,4.39,0,0,1-.27-1.49c0-.85-.05-1.1-.05-3.24s0-2.39.05-3.24a4.26,4.26,0,0,1,.27-1.48,2.49,2.49,0,0,1,.6-.92,2.45,2.45,0,0,1,.92-.6,4.58,4.58,0,0,1,1.49-.28c.85,0,1.1-.05,3.24-.05M17,9c-2.18,0-2.45,0-3.3,0a6.13,6.13,0,0,0-1.95.37,4.06,4.06,0,0,0-1.42.93,3.9,3.9,0,0,0-.92,1.41A5.86,5.86,0,0,0,9,13.7c0,.85,0,1.12,0,3.3s0,2.45,0,3.3a5.8,5.8,0,0,0,.37,1.94,3.86,3.86,0,0,0,.92,1.42,4.06,4.06,0,0,0,1.42.93A5.86,5.86,0,0,0,13.7,25c.85,0,1.12.05,3.3.05s2.45,0,3.3-.05a6.13,6.13,0,0,0,1.95-.37,4.06,4.06,0,0,0,1.42-.93,3.86,3.86,0,0,0,.92-1.42A5.8,5.8,0,0,0,25,20.3c0-.85.05-1.13.05-3.3s0-2.45-.05-3.3a5.86,5.86,0,0,0-.37-1.95,3.9,3.9,0,0,0-.92-1.41,4,4,0,0,0-1.42-.93A5.85,5.85,0,0,0,20.31,9C19.45,9,19.18,9,17,9Z"
            }), a("path", {
                fill: "currentColor",
                d: "M17,12.89A4.11,4.11,0,1,0,21.11,17,4.11,4.11,0,0,0,17,12.89Zm0,6.78A2.67,2.67,0,1,1,19.67,17,2.66,2.66,0,0,1,17,19.67Z"
            }), a("circle", {
                fill: "currentColor",
                cx: "21.28",
                cy: "12.73",
                r: "0.96"
            })]
        })]
    }),
    np = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), y("g", {
            children: [a("path", {
                fill: "currentColor",
                d: "M17,10.43c2.14,0,2.39,0,3.24.05a4.58,4.58,0,0,1,1.49.28,2.45,2.45,0,0,1,.92.6,2.49,2.49,0,0,1,.6.92,4.26,4.26,0,0,1,.27,1.48c0,.85.05,1.1.05,3.24s0,2.39-.05,3.24a4.39,4.39,0,0,1-.27,1.49,2.67,2.67,0,0,1-1.52,1.52,4.39,4.39,0,0,1-1.49.27c-.85,0-1.1.05-3.24.05s-2.39,0-3.24-.05a4.39,4.39,0,0,1-1.49-.27,2.67,2.67,0,0,1-1.52-1.52,4.39,4.39,0,0,1-.27-1.49c0-.85-.05-1.1-.05-3.24s0-2.39.05-3.24a4.26,4.26,0,0,1,.27-1.48,2.49,2.49,0,0,1,.6-.92,2.45,2.45,0,0,1,.92-.6,4.58,4.58,0,0,1,1.49-.28c.85,0,1.1-.05,3.24-.05M17,9c-2.18,0-2.45,0-3.3,0a6.13,6.13,0,0,0-1.95.37,4.06,4.06,0,0,0-1.42.93,3.9,3.9,0,0,0-.92,1.41A5.86,5.86,0,0,0,9,13.7c0,.85,0,1.12,0,3.3s0,2.45,0,3.3a5.8,5.8,0,0,0,.37,1.94,3.86,3.86,0,0,0,.92,1.42,4.06,4.06,0,0,0,1.42.93A5.86,5.86,0,0,0,13.7,25c.85,0,1.12.05,3.3.05s2.45,0,3.3-.05a6.13,6.13,0,0,0,1.95-.37,4.06,4.06,0,0,0,1.42-.93,3.86,3.86,0,0,0,.92-1.42A5.8,5.8,0,0,0,25,20.3c0-.85.05-1.13.05-3.3s0-2.45-.05-3.3a5.86,5.86,0,0,0-.37-1.95,3.9,3.9,0,0,0-.92-1.41,4,4,0,0,0-1.42-.93A5.85,5.85,0,0,0,20.31,9C19.45,9,19.18,9,17,9Z"
            }), a("path", {
                fill: "currentColor",
                d: "M17,12.89A4.11,4.11,0,1,0,21.11,17,4.11,4.11,0,0,0,17,12.89Zm0,6.78A2.67,2.67,0,1,1,19.67,17,2.66,2.66,0,0,1,17,19.67Z"
            }), a("circle", {
                fill: "currentColor",
                cx: "21.28",
                cy: "12.73",
                r: "0.96"
            })]
        })]
    }),
    Yu = "instagram-icon-v4-linear-gradient",
    ip = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [y("linearGradient", {
            id: Yu,
            x1: "25",
            y1: "3.14",
            x2: "9",
            y2: "30.86",
            gradientUnits: "userSpaceOnUse",
            children: [a("stop", {
                offset: "0",
                stopColor: "#4f5bd5"
            }), a("stop", {
                offset: "0.31",
                stopColor: "#962fbf"
            }), a("stop", {
                offset: "0.55",
                stopColor: "#d62976"
            }), a("stop", {
                offset: "0.8",
                stopColor: "#fa7e1e"
            }), a("stop", {
                offset: "1",
                stopColor: "#feda75"
            })]
        }), a("path", {
            fill: `url(#${Yu})`,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), y("g", {
            children: [a("path", {
                fill: "#FFF",
                d: "M17,10.43c2.14,0,2.39,0,3.24.05a4.58,4.58,0,0,1,1.49.28,2.45,2.45,0,0,1,.92.6,2.49,2.49,0,0,1,.6.92,4.26,4.26,0,0,1,.27,1.48c0,.85.05,1.1.05,3.24s0,2.39-.05,3.24a4.39,4.39,0,0,1-.27,1.49,2.67,2.67,0,0,1-1.52,1.52,4.39,4.39,0,0,1-1.49.27c-.85,0-1.1.05-3.24.05s-2.39,0-3.24-.05a4.39,4.39,0,0,1-1.49-.27,2.67,2.67,0,0,1-1.52-1.52,4.39,4.39,0,0,1-.27-1.49c0-.85-.05-1.1-.05-3.24s0-2.39.05-3.24a4.26,4.26,0,0,1,.27-1.48,2.49,2.49,0,0,1,.6-.92,2.45,2.45,0,0,1,.92-.6,4.58,4.58,0,0,1,1.49-.28c.85,0,1.1-.05,3.24-.05M17,9c-2.18,0-2.45,0-3.3,0a6.13,6.13,0,0,0-1.95.37,4.06,4.06,0,0,0-1.42.93,3.9,3.9,0,0,0-.92,1.41A5.86,5.86,0,0,0,9,13.7c0,.85,0,1.12,0,3.3s0,2.45,0,3.3a5.8,5.8,0,0,0,.37,1.94,3.86,3.86,0,0,0,.92,1.42,4.06,4.06,0,0,0,1.42.93A5.86,5.86,0,0,0,13.7,25c.85,0,1.12.05,3.3.05s2.45,0,3.3-.05a6.13,6.13,0,0,0,1.95-.37,4.06,4.06,0,0,0,1.42-.93,3.86,3.86,0,0,0,.92-1.42A5.8,5.8,0,0,0,25,20.3c0-.85.05-1.13.05-3.3s0-2.45-.05-3.3a5.86,5.86,0,0,0-.37-1.95,3.9,3.9,0,0,0-.92-1.41,4,4,0,0,0-1.42-.93A5.85,5.85,0,0,0,20.31,9C19.45,9,19.18,9,17,9Z"
            }), a("path", {
                fill: "#FFF",
                d: "M17,12.89A4.11,4.11,0,1,0,21.11,17,4.11,4.11,0,0,0,17,12.89Zm0,6.78A2.67,2.67,0,1,1,19.67,17,2.66,2.66,0,0,1,17,19.67Z"
            }), a("circle", {
                fill: "#FFF",
                cx: "21.28",
                cy: "12.73",
                r: "0.96"
            })]
        })]
    }),
    ap = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "#c32aa3",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), y("g", {
            children: [a("path", {
                fill: "#c32aa3",
                d: "M17,10.43c2.14,0,2.39,0,3.24.05a4.58,4.58,0,0,1,1.49.28,2.45,2.45,0,0,1,.92.6,2.49,2.49,0,0,1,.6.92,4.26,4.26,0,0,1,.27,1.48c0,.85.05,1.1.05,3.24s0,2.39-.05,3.24a4.39,4.39,0,0,1-.27,1.49,2.67,2.67,0,0,1-1.52,1.52,4.39,4.39,0,0,1-1.49.27c-.85,0-1.1.05-3.24.05s-2.39,0-3.24-.05a4.39,4.39,0,0,1-1.49-.27,2.67,2.67,0,0,1-1.52-1.52,4.39,4.39,0,0,1-.27-1.49c0-.85-.05-1.1-.05-3.24s0-2.39.05-3.24a4.26,4.26,0,0,1,.27-1.48,2.49,2.49,0,0,1,.6-.92,2.45,2.45,0,0,1,.92-.6,4.58,4.58,0,0,1,1.49-.28c.85,0,1.1-.05,3.24-.05M17,9c-2.18,0-2.45,0-3.3,0a6.13,6.13,0,0,0-1.95.37,4.06,4.06,0,0,0-1.42.93,3.9,3.9,0,0,0-.92,1.41A5.86,5.86,0,0,0,9,13.7c0,.85,0,1.12,0,3.3s0,2.45,0,3.3a5.8,5.8,0,0,0,.37,1.94,3.86,3.86,0,0,0,.92,1.42,4.06,4.06,0,0,0,1.42.93A5.86,5.86,0,0,0,13.7,25c.85,0,1.12.05,3.3.05s2.45,0,3.3-.05a6.13,6.13,0,0,0,1.95-.37,4.06,4.06,0,0,0,1.42-.93,3.86,3.86,0,0,0,.92-1.42A5.8,5.8,0,0,0,25,20.3c0-.85.05-1.13.05-3.3s0-2.45-.05-3.3a5.86,5.86,0,0,0-.37-1.95,3.9,3.9,0,0,0-.92-1.41,4,4,0,0,0-1.42-.93A5.85,5.85,0,0,0,20.31,9C19.45,9,19.18,9,17,9Z"
            }), a("path", {
                fill: "#c32aa3",
                d: "M17,12.89A4.11,4.11,0,1,0,21.11,17,4.11,4.11,0,0,0,17,12.89Zm0,6.78A2.67,2.67,0,1,1,19.67,17,2.66,2.66,0,0,1,17,19.67Z"
            }), a("circle", {
                fill: "#c32aa3",
                cx: "21.28",
                cy: "12.73",
                r: "0.96"
            })]
        })]
    }),
    lp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#CCC",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), y("g", {
            children: [a("path", {
                fill: "#FFF",
                d: "M17,10.43c2.14,0,2.39,0,3.24.05a4.58,4.58,0,0,1,1.49.28,2.45,2.45,0,0,1,.92.6,2.49,2.49,0,0,1,.6.92,4.26,4.26,0,0,1,.27,1.48c0,.85.05,1.1.05,3.24s0,2.39-.05,3.24a4.39,4.39,0,0,1-.27,1.49,2.67,2.67,0,0,1-1.52,1.52,4.39,4.39,0,0,1-1.49.27c-.85,0-1.1.05-3.24.05s-2.39,0-3.24-.05a4.39,4.39,0,0,1-1.49-.27,2.67,2.67,0,0,1-1.52-1.52,4.39,4.39,0,0,1-.27-1.49c0-.85-.05-1.1-.05-3.24s0-2.39.05-3.24a4.26,4.26,0,0,1,.27-1.48,2.49,2.49,0,0,1,.6-.92,2.45,2.45,0,0,1,.92-.6,4.58,4.58,0,0,1,1.49-.28c.85,0,1.1-.05,3.24-.05M17,9c-2.18,0-2.45,0-3.3,0a6.13,6.13,0,0,0-1.95.37,4.06,4.06,0,0,0-1.42.93,3.9,3.9,0,0,0-.92,1.41A5.86,5.86,0,0,0,9,13.7c0,.85,0,1.12,0,3.3s0,2.45,0,3.3a5.8,5.8,0,0,0,.37,1.94,3.86,3.86,0,0,0,.92,1.42,4.06,4.06,0,0,0,1.42.93A5.86,5.86,0,0,0,13.7,25c.85,0,1.12.05,3.3.05s2.45,0,3.3-.05a6.13,6.13,0,0,0,1.95-.37,4.06,4.06,0,0,0,1.42-.93,3.86,3.86,0,0,0,.92-1.42A5.8,5.8,0,0,0,25,20.3c0-.85.05-1.13.05-3.3s0-2.45-.05-3.3a5.86,5.86,0,0,0-.37-1.95,3.9,3.9,0,0,0-.92-1.41,4,4,0,0,0-1.42-.93A5.85,5.85,0,0,0,20.31,9C19.45,9,19.18,9,17,9Z"
            }), a("path", {
                fill: "#FFF",
                d: "M17,12.89A4.11,4.11,0,1,0,21.11,17,4.11,4.11,0,0,0,17,12.89Zm0,6.78A2.67,2.67,0,1,1,19.67,17,2.66,2.66,0,0,1,17,19.67Z"
            }), a("circle", {
                fill: "#FFF",
                cx: "21.28",
                cy: "12.73",
                r: "0.96"
            })]
        })]
    }),
    sp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), y("g", {
            children: [a("path", {
                fill: "currentColor",
                d: "M17,10.43c2.14,0,2.39,0,3.24.05a4.58,4.58,0,0,1,1.49.28,2.45,2.45,0,0,1,.92.6,2.49,2.49,0,0,1,.6.92,4.26,4.26,0,0,1,.27,1.48c0,.85.05,1.1.05,3.24s0,2.39-.05,3.24a4.39,4.39,0,0,1-.27,1.49,2.67,2.67,0,0,1-1.52,1.52,4.39,4.39,0,0,1-1.49.27c-.85,0-1.1.05-3.24.05s-2.39,0-3.24-.05a4.39,4.39,0,0,1-1.49-.27,2.67,2.67,0,0,1-1.52-1.52,4.39,4.39,0,0,1-.27-1.49c0-.85-.05-1.1-.05-3.24s0-2.39.05-3.24a4.26,4.26,0,0,1,.27-1.48,2.49,2.49,0,0,1,.6-.92,2.45,2.45,0,0,1,.92-.6,4.58,4.58,0,0,1,1.49-.28c.85,0,1.1-.05,3.24-.05M17,9c-2.18,0-2.45,0-3.3,0a6.13,6.13,0,0,0-1.95.37,4.06,4.06,0,0,0-1.42.93,3.9,3.9,0,0,0-.92,1.41A5.86,5.86,0,0,0,9,13.7c0,.85,0,1.12,0,3.3s0,2.45,0,3.3a5.8,5.8,0,0,0,.37,1.94,3.86,3.86,0,0,0,.92,1.42,4.06,4.06,0,0,0,1.42.93A5.86,5.86,0,0,0,13.7,25c.85,0,1.12.05,3.3.05s2.45,0,3.3-.05a6.13,6.13,0,0,0,1.95-.37,4.06,4.06,0,0,0,1.42-.93,3.86,3.86,0,0,0,.92-1.42A5.8,5.8,0,0,0,25,20.3c0-.85.05-1.13.05-3.3s0-2.45-.05-3.3a5.86,5.86,0,0,0-.37-1.95,3.9,3.9,0,0,0-.92-1.41,4,4,0,0,0-1.42-.93A5.85,5.85,0,0,0,20.31,9C19.45,9,19.18,9,17,9Z"
            }), a("path", {
                fill: "currentColor",
                d: "M17,12.89A4.11,4.11,0,1,0,21.11,17,4.11,4.11,0,0,0,17,12.89Zm0,6.78A2.67,2.67,0,1,1,19.67,17,2.66,2.66,0,0,1,17,19.67Z"
            }), a("circle", {
                fill: "currentColor",
                cx: "21.28",
                cy: "12.73",
                r: "0.96"
            })]
        })]
    }),
    dp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "currentColor",
            d: "M23.25,12.28a2.49,2.49,0,0,0-.6-.92,2.45,2.45,0,0,0-.92-.6,4.58,4.58,0,0,0-1.49-.28c-.85,0-1.1-.05-3.24-.05s-2.39,0-3.24.05a4.58,4.58,0,0,0-1.49.28,2.45,2.45,0,0,0-.92.6,2.49,2.49,0,0,0-.6.92,4.26,4.26,0,0,0-.27,1.48c0,.85-.05,1.1-.05,3.24s0,2.39.05,3.24a4.39,4.39,0,0,0,.27,1.49,2.67,2.67,0,0,0,1.52,1.52,4.39,4.39,0,0,0,1.49.27c.85,0,1.1.05,3.24.05s2.39,0,3.24-.05a4.39,4.39,0,0,0,1.49-.27,2.67,2.67,0,0,0,1.52-1.52,4.39,4.39,0,0,0,.27-1.49c0-.85.05-1.1.05-3.24s0-2.39-.05-3.24A4.26,4.26,0,0,0,23.25,12.28ZM17,21.11A4.11,4.11,0,1,1,21.11,17,4.11,4.11,0,0,1,17,21.11Zm4.28-7.42a1,1,0,1,1,1-1A1,1,0,0,1,21.28,13.69Z"
        }), a("path", {
            fill: "currentColor",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Zm8,19.3a5.8,5.8,0,0,1-.37,1.94,3.86,3.86,0,0,1-.92,1.42,4.06,4.06,0,0,1-1.42.93A6.13,6.13,0,0,1,20.3,25c-.85,0-1.12.05-3.3.05s-2.45,0-3.3-.05a5.86,5.86,0,0,1-1.95-.37,4.06,4.06,0,0,1-1.42-.93,3.86,3.86,0,0,1-.92-1.42A5.8,5.8,0,0,1,9,20.3c0-.85,0-1.13,0-3.3s0-2.45,0-3.3a5.86,5.86,0,0,1,.37-1.95,3.9,3.9,0,0,1,.92-1.41,4.06,4.06,0,0,1,1.42-.93A6.13,6.13,0,0,1,13.7,9c.85,0,1.12,0,3.3,0s2.45,0,3.31,0a5.85,5.85,0,0,1,1.94.37,4,4,0,0,1,1.42.93,3.9,3.9,0,0,1,.92,1.41A5.86,5.86,0,0,1,25,13.7c0,.85.05,1.12.05,3.3S25,19.45,25,20.3Z"
        }), a("path", {
            fill: "currentColor",
            d: "M17,14.33A2.67,2.67,0,1,0,19.67,17,2.67,2.67,0,0,0,17,14.33Z"
        })]
    }),
    up = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), y("g", {
            children: [a("path", {
                fill: "currentColor",
                d: "M17,10.43c2.14,0,2.39,0,3.24.05a4.58,4.58,0,0,1,1.49.28,2.45,2.45,0,0,1,.92.6,2.49,2.49,0,0,1,.6.92,4.26,4.26,0,0,1,.27,1.48c0,.85.05,1.1.05,3.24s0,2.39-.05,3.24a4.39,4.39,0,0,1-.27,1.49,2.67,2.67,0,0,1-1.52,1.52,4.39,4.39,0,0,1-1.49.27c-.85,0-1.1.05-3.24.05s-2.39,0-3.24-.05a4.39,4.39,0,0,1-1.49-.27,2.67,2.67,0,0,1-1.52-1.52,4.39,4.39,0,0,1-.27-1.49c0-.85-.05-1.1-.05-3.24s0-2.39.05-3.24a4.26,4.26,0,0,1,.27-1.48,2.49,2.49,0,0,1,.6-.92,2.45,2.45,0,0,1,.92-.6,4.58,4.58,0,0,1,1.49-.28c.85,0,1.1-.05,3.24-.05M17,9c-2.18,0-2.45,0-3.3,0a6.13,6.13,0,0,0-1.95.37,4.06,4.06,0,0,0-1.42.93,3.9,3.9,0,0,0-.92,1.41A5.86,5.86,0,0,0,9,13.7c0,.85,0,1.12,0,3.3s0,2.45,0,3.3a5.8,5.8,0,0,0,.37,1.94,3.86,3.86,0,0,0,.92,1.42,4.06,4.06,0,0,0,1.42.93A5.86,5.86,0,0,0,13.7,25c.85,0,1.12.05,3.3.05s2.45,0,3.3-.05a6.13,6.13,0,0,0,1.95-.37,4.06,4.06,0,0,0,1.42-.93,3.86,3.86,0,0,0,.92-1.42A5.8,5.8,0,0,0,25,20.3c0-.85.05-1.13.05-3.3s0-2.45-.05-3.3a5.86,5.86,0,0,0-.37-1.95,3.9,3.9,0,0,0-.92-1.41,4,4,0,0,0-1.42-.93A5.85,5.85,0,0,0,20.31,9C19.45,9,19.18,9,17,9Z"
            }), a("path", {
                fill: "currentColor",
                d: "M17,12.89A4.11,4.11,0,1,0,21.11,17,4.11,4.11,0,0,0,17,12.89Zm0,6.78A2.67,2.67,0,1,1,19.67,17,2.66,2.66,0,0,1,17,19.67Z"
            }), a("circle", {
                fill: "currentColor",
                cx: "21.28",
                cy: "12.73",
                r: "0.96"
            })]
        })]
    }),
    cp = e => a(T, {
        viewBox: "0 0 32 32",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: "currentColor",
            d: "M26,16a26.59,26.59,0,0,0-.43-4.85A2.51,2.51,0,0,0,23.8,9.34C22.24,8.92,16,9,16,9S9.71,9,8.15,9.4a2.49,2.49,0,0,0-1.76,1.79A25.67,25.67,0,0,0,6,16a26.59,26.59,0,0,0,.43,4.85A2.51,2.51,0,0,0,8.2,22.66c1.56.42,7.83.39,7.83.39s6.26,0,7.82-.45a2.49,2.49,0,0,0,1.76-1.79A25.67,25.67,0,0,0,26,16ZM14,19l0-6,5.25,3Z"
        })
    }),
    hp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25.47,17a22.8,22.8,0,0,0-.37-4.15,2.16,2.16,0,0,0-1.52-1.52,51.72,51.72,0,0,0-6.7-.33,50.37,50.37,0,0,0-6.7.39,2.16,2.16,0,0,0-1.51,1.53A22.73,22.73,0,0,0,8.33,17a22.13,22.13,0,0,0,.38,4.15,2.14,2.14,0,0,0,1.52,1.52,50.32,50.32,0,0,0,6.7.34,50.16,50.16,0,0,0,6.69-.39,2.14,2.14,0,0,0,1.51-1.53A22.88,22.88,0,0,0,25.47,17ZM15.16,19.55l0-5.09L19.63,17Z"
        })]
    }),
    mp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25.47,17a22.8,22.8,0,0,0-.37-4.15,2.16,2.16,0,0,0-1.52-1.52,51.72,51.72,0,0,0-6.7-.33,50.37,50.37,0,0,0-6.7.39,2.16,2.16,0,0,0-1.51,1.53A22.73,22.73,0,0,0,8.33,17a22.13,22.13,0,0,0,.38,4.15,2.14,2.14,0,0,0,1.52,1.52,50.32,50.32,0,0,0,6.7.34,50.16,50.16,0,0,0,6.69-.39,2.14,2.14,0,0,0,1.51-1.53A22.88,22.88,0,0,0,25.47,17ZM15.16,19.55l0-5.09L19.63,17Z"
        })]
    }),
    bp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "red",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M25.47,17a22.8,22.8,0,0,0-.37-4.15,2.16,2.16,0,0,0-1.52-1.52,51.72,51.72,0,0,0-6.7-.33,50.37,50.37,0,0,0-6.7.39,2.16,2.16,0,0,0-1.51,1.53A22.73,22.73,0,0,0,8.33,17a22.13,22.13,0,0,0,.38,4.15,2.14,2.14,0,0,0,1.52,1.52,50.32,50.32,0,0,0,6.7.34,50.16,50.16,0,0,0,6.69-.39,2.14,2.14,0,0,0,1.51-1.53A22.88,22.88,0,0,0,25.47,17ZM15.16,19.55l0-5.09L19.63,17Z"
        })]
    }),
    fp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "red",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Zm8.23,20.12a2.16,2.16,0,0,1-1.51,1.53A50.37,50.37,0,0,1,17,23a50.11,50.11,0,0,1-6.69-.34A2.16,2.16,0,0,1,8.8,21.18,22.74,22.74,0,0,1,8.43,17a22.73,22.73,0,0,1,.34-4.15,2.14,2.14,0,0,1,1.51-1.53A50.37,50.37,0,0,1,17,11a51.51,51.51,0,0,1,6.69.33,2.17,2.17,0,0,1,1.53,1.52A22.8,22.8,0,0,1,25.57,17,22.88,22.88,0,0,1,25.23,21.12Z"
        }), a("path", {
            fill: "red",
            d: "M25.47,17a22.8,22.8,0,0,0-.37-4.15,2.16,2.16,0,0,0-1.52-1.52,51.72,51.72,0,0,0-6.7-.33,50.37,50.37,0,0,0-6.7.39,2.16,2.16,0,0,0-1.51,1.53A22.73,22.73,0,0,0,8.33,17a22.13,22.13,0,0,0,.38,4.15,2.14,2.14,0,0,0,1.52,1.52,50.32,50.32,0,0,0,6.7.34,50.16,50.16,0,0,0,6.69-.39,2.14,2.14,0,0,0,1.51-1.53A22.88,22.88,0,0,0,25.47,17ZM15.16,19.55l0-5.09L19.63,17Z"
        })]
    }),
    gp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#CCC",
            d: "M16.9,1a16,16,0,1,0,16,16A16,16,0,0,0,16.9,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M25.47,17a22.8,22.8,0,0,0-.37-4.15,2.16,2.16,0,0,0-1.52-1.52,51.72,51.72,0,0,0-6.7-.33,50.37,50.37,0,0,0-6.7.39,2.16,2.16,0,0,0-1.51,1.53A22.73,22.73,0,0,0,8.33,17a22.13,22.13,0,0,0,.38,4.15,2.14,2.14,0,0,0,1.52,1.52,50.32,50.32,0,0,0,6.7.34,50.16,50.16,0,0,0,6.69-.39,2.14,2.14,0,0,0,1.51-1.53A22.88,22.88,0,0,0,25.47,17ZM15.16,19.55l0-5.09L19.63,17Z"
        })]
    }),
    pp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M16.9,1a16,16,0,1,0,16,16A16,16,0,0,0,16.9,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25.47,17a22.8,22.8,0,0,0-.37-4.15,2.16,2.16,0,0,0-1.52-1.52,51.72,51.72,0,0,0-6.7-.33,50.37,50.37,0,0,0-6.7.39,2.16,2.16,0,0,0-1.51,1.53A22.73,22.73,0,0,0,8.33,17a22.13,22.13,0,0,0,.38,4.15,2.14,2.14,0,0,0,1.52,1.52,50.32,50.32,0,0,0,6.7.34,50.16,50.16,0,0,0,6.69-.39,2.14,2.14,0,0,0,1.51-1.53A22.88,22.88,0,0,0,25.47,17ZM15.16,19.55l0-5.09L19.63,17Z"
        })]
    }),
    yp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "currentColor",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Zm8.23,20.12a2.16,2.16,0,0,1-1.51,1.53A50.37,50.37,0,0,1,17,23a50.11,50.11,0,0,1-6.69-.34A2.16,2.16,0,0,1,8.8,21.18,22.74,22.74,0,0,1,8.43,17a22.73,22.73,0,0,1,.34-4.15,2.14,2.14,0,0,1,1.51-1.53A50.37,50.37,0,0,1,17,11a51.51,51.51,0,0,1,6.69.33,2.17,2.17,0,0,1,1.53,1.52A22.8,22.8,0,0,1,25.57,17,22.88,22.88,0,0,1,25.23,21.12Z"
        }), a("polygon", {
            fill: "currentColor",
            points: "15.26 19.55 15.24 14.46 19.73 16.99 15.26 19.55"
        })]
    }),
    xp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M16.9,1a16,16,0,1,0,16,16A16,16,0,0,0,16.9,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25.47,17a22.8,22.8,0,0,0-.37-4.15,2.16,2.16,0,0,0-1.52-1.52,51.72,51.72,0,0,0-6.7-.33,50.37,50.37,0,0,0-6.7.39,2.16,2.16,0,0,0-1.51,1.53A22.73,22.73,0,0,0,8.33,17a22.13,22.13,0,0,0,.38,4.15,2.14,2.14,0,0,0,1.52,1.52,50.32,50.32,0,0,0,6.7.34,50.16,50.16,0,0,0,6.69-.39,2.14,2.14,0,0,0,1.51-1.53A22.88,22.88,0,0,0,25.47,17ZM15.16,19.55l0-5.09L19.63,17Z"
        })]
    }),
    vp = e => a(T, {
        viewBox: "0 0 32 32",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: "currentColor",
            d: "M18.2,8.9c-1.6,0.5-2.6,2-2.5,3.7v0.6l-0.6-0.1c-2.3-0.3-4.4-1.3-6.1-3L8.2,9.3L8,9.9c-0.5,1.3-0.2,2.8,0.8,3.8c0.5,0.5,0.4,0.6-0.5,0.3c-0.3-0.1-0.6-0.2-0.6-0.1c0,0.6,0.2,1.2,0.5,1.7c0.4,0.7,1,1.3,1.7,1.6l0.6,0.3H9.8c-0.7,0-0.7,0-0.7,0.3c0.4,1,1.3,1.8,2.4,2.2l0.8,0.3l-0.7,0.4c-1,0.6-2.2,0.9-3.4,1c-0.3,0-0.7,0-1,0.1c0.8,0.5,1.6,0.9,2.4,1.1c2.8,0.8,5.8,0.5,8.3-1c1.9-1.2,3.4-2.9,4.2-5c0.5-1.2,0.8-2.6,0.9-3.9c0-0.6,0-0.7,0.8-1.4c0.3-0.3,0.6-0.6,0.9-1c0.1-0.2,0.1-0.2-0.5,0C23.1,11,23,11,23.5,10.4c0.4-0.4,0.7-0.9,0.9-1.4c0,0-0.2,0-0.4,0.1c-0.4,0.2-0.7,0.3-1.1,0.4l-0.7,0.2l-0.6-0.4c-0.3-0.2-0.7-0.4-1.1-0.6C19.7,8.6,18.9,8.7,18.2,8.9z"
        })
    }),
    Cp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M20.23,10.89a3.69,3.69,0,0,0-2.49,3.7l0,.63-.63-.08a10.34,10.34,0,0,1-6.06-3l-.84-.84-.21.62a3.72,3.72,0,0,0,.78,3.81c.51.54.4.61-.48.29-.3-.1-.57-.18-.6-.14a4.7,4.7,0,0,0,.46,1.73,4.13,4.13,0,0,0,1.74,1.64l.63.3h-.74c-.71,0-.74,0-.66.28A3.85,3.85,0,0,0,13.55,22l.79.27-.69.41a7.22,7.22,0,0,1-3.41.95,3.62,3.62,0,0,0-1,.1,9.53,9.53,0,0,0,2.45,1.13A10.72,10.72,0,0,0,20,23.89a11.14,11.14,0,0,0,4.23-5A13.08,13.08,0,0,0,25.1,15c0-.59,0-.67.75-1.37a10.58,10.58,0,0,0,.89-1c.13-.25.11-.25-.53,0-1.09.39-1.24.33-.7-.24A3.84,3.84,0,0,0,26.37,11s-.19,0-.41.14a6.7,6.7,0,0,1-1.12.44l-.68.22-.63-.43a5.19,5.19,0,0,0-1.08-.57A4.27,4.27,0,0,0,20.23,10.89Z"
        })]
    }),
    wp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M20.23,10.89a3.69,3.69,0,0,0-2.49,3.7l0,.63-.63-.08a10.34,10.34,0,0,1-6.06-3l-.84-.84-.21.62a3.72,3.72,0,0,0,.78,3.81c.51.54.4.61-.48.29-.3-.1-.57-.18-.6-.14a4.7,4.7,0,0,0,.46,1.73,4.13,4.13,0,0,0,1.74,1.64l.63.3h-.74c-.71,0-.74,0-.66.28A3.85,3.85,0,0,0,13.55,22l.79.27-.69.41a7.22,7.22,0,0,1-3.41.95,3.62,3.62,0,0,0-1,.1,9.53,9.53,0,0,0,2.45,1.13A10.72,10.72,0,0,0,20,23.89a11.14,11.14,0,0,0,4.23-5A13.08,13.08,0,0,0,25.1,15c0-.59,0-.67.75-1.37a10.58,10.58,0,0,0,.89-1c.13-.25.11-.25-.53,0-1.09.39-1.24.33-.7-.24A3.84,3.84,0,0,0,26.37,11s-.19,0-.41.14a6.7,6.7,0,0,1-1.12.44l-.68.22-.63-.43a5.19,5.19,0,0,0-1.08-.57A4.27,4.27,0,0,0,20.23,10.89Z"
        })]
    }),
    Bp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#1da1f2",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M20.23,10.89a3.69,3.69,0,0,0-2.49,3.7l0,.63-.63-.08a10.34,10.34,0,0,1-6.06-3l-.84-.84-.21.62a3.72,3.72,0,0,0,.78,3.81c.51.54.4.61-.48.29-.3-.1-.57-.18-.6-.14a4.7,4.7,0,0,0,.46,1.73,4.13,4.13,0,0,0,1.74,1.64l.63.3h-.74c-.71,0-.74,0-.66.28A3.85,3.85,0,0,0,13.55,22l.79.27-.69.41a7.22,7.22,0,0,1-3.41.95,3.62,3.62,0,0,0-1,.1,9.53,9.53,0,0,0,2.45,1.13A10.72,10.72,0,0,0,20,23.89a11.14,11.14,0,0,0,4.23-5A13.08,13.08,0,0,0,25.1,15c0-.59,0-.67.75-1.37a10.58,10.58,0,0,0,.89-1c.13-.25.11-.25-.53,0-1.09.39-1.24.33-.7-.24A3.84,3.84,0,0,0,26.37,11s-.19,0-.41.14a6.7,6.7,0,0,1-1.12.44l-.68.22-.63-.43a5.19,5.19,0,0,0-1.08-.57A4.27,4.27,0,0,0,20.23,10.89Z"
        })]
    }),
    Sp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "#1da1f2",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#1da1f2",
            d: "M20.23,10.89a3.69,3.69,0,0,0-2.49,3.7l0,.63-.63-.08a10.34,10.34,0,0,1-6.06-3l-.84-.84-.21.62a3.72,3.72,0,0,0,.78,3.81c.51.54.4.61-.48.29-.3-.1-.57-.18-.6-.14a4.7,4.7,0,0,0,.46,1.73,4.13,4.13,0,0,0,1.74,1.64l.63.3h-.74c-.71,0-.74,0-.66.28A3.85,3.85,0,0,0,13.55,22l.79.27-.69.41a7.22,7.22,0,0,1-3.41.95,3.62,3.62,0,0,0-1,.1,9.53,9.53,0,0,0,2.45,1.13A10.72,10.72,0,0,0,20,23.89a11.14,11.14,0,0,0,4.23-5A13.08,13.08,0,0,0,25.1,15c0-.59,0-.67.75-1.37a10.58,10.58,0,0,0,.89-1c.13-.25.11-.25-.53,0-1.09.39-1.24.33-.7-.24A3.84,3.84,0,0,0,26.37,11s-.19,0-.41.14a6.7,6.7,0,0,1-1.12.44l-.68.22-.63-.43a5.19,5.19,0,0,0-1.08-.57A4.27,4.27,0,0,0,20.23,10.89Z"
        })]
    }),
    $p = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#CCC",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M20.23,10.89a3.69,3.69,0,0,0-2.49,3.7l0,.63-.63-.08a10.34,10.34,0,0,1-6.06-3l-.84-.84-.21.62a3.72,3.72,0,0,0,.78,3.81c.51.54.4.61-.48.29-.3-.1-.57-.18-.6-.14a4.7,4.7,0,0,0,.46,1.73,4.13,4.13,0,0,0,1.74,1.64l.63.3h-.74c-.71,0-.74,0-.66.28A3.85,3.85,0,0,0,13.55,22l.79.27-.69.41a7.22,7.22,0,0,1-3.41.95,3.62,3.62,0,0,0-1,.1,9.53,9.53,0,0,0,2.45,1.13A10.72,10.72,0,0,0,20,23.89a11.14,11.14,0,0,0,4.23-5A13.08,13.08,0,0,0,25.1,15c0-.59,0-.67.75-1.37a10.58,10.58,0,0,0,.89-1c.13-.25.11-.25-.53,0-1.09.39-1.24.33-.7-.24A3.84,3.84,0,0,0,26.37,11s-.19,0-.41.14a6.7,6.7,0,0,1-1.12.44l-.68.22-.63-.43a5.19,5.19,0,0,0-1.08-.57A4.27,4.27,0,0,0,20.23,10.89Z"
        })]
    }),
    Rp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M20.23,10.89a3.69,3.69,0,0,0-2.49,3.7l0,.63-.63-.08a10.34,10.34,0,0,1-6.06-3l-.84-.84-.21.62a3.72,3.72,0,0,0,.78,3.81c.51.54.4.61-.48.29-.3-.1-.57-.18-.6-.14a4.7,4.7,0,0,0,.46,1.73,4.13,4.13,0,0,0,1.74,1.64l.63.3h-.74c-.71,0-.74,0-.66.28A3.85,3.85,0,0,0,13.55,22l.79.27-.69.41a7.22,7.22,0,0,1-3.41.95,3.62,3.62,0,0,0-1,.1,9.53,9.53,0,0,0,2.45,1.13A10.72,10.72,0,0,0,20,23.89a11.14,11.14,0,0,0,4.23-5A13.08,13.08,0,0,0,25.1,15c0-.59,0-.67.75-1.37a10.58,10.58,0,0,0,.89-1c.13-.25.11-.25-.53,0-1.09.39-1.24.33-.7-.24A3.84,3.84,0,0,0,26.37,11s-.19,0-.41.14a6.7,6.7,0,0,1-1.12.44l-.68.22-.63-.43a5.19,5.19,0,0,0-1.08-.57A4.27,4.27,0,0,0,20.23,10.89Z"
        })]
    }),
    Pp = e => a(T, {
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: "currentColor",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Zm9.74,11.67a8.47,8.47,0,0,1-.89,1c-.71.71-.75.79-.75,1.38a13.08,13.08,0,0,1-.87,3.86,11.08,11.08,0,0,1-4.23,5,10.72,10.72,0,0,1-8.35.95A9.53,9.53,0,0,1,9.2,23.71a3.62,3.62,0,0,1,1-.1,7.22,7.22,0,0,0,3.41-.95l.69-.42L13.55,22a3.83,3.83,0,0,1-2.38-2.1c-.08-.28-.05-.29.66-.29h.74l-.62-.3a4.1,4.1,0,0,1-1.75-1.64,4.91,4.91,0,0,1-.46-1.73s.3,0,.6.14c.88.33,1,.25.49-.29A3.7,3.7,0,0,1,10,11.94l.21-.62.84.84a10.34,10.34,0,0,0,6.06,3l.63.08,0-.63a3.69,3.69,0,0,1,2.49-3.7,4.27,4.27,0,0,1,2.22-.06,5.19,5.19,0,0,1,1.08.57l.63.43.68-.22A7.23,7.23,0,0,0,26,11.17c.21-.12.4-.18.4-.14a3.74,3.74,0,0,1-.86,1.37c-.54.58-.39.63.7.25C26.85,12.43,26.87,12.43,26.74,12.67Z"
        })
    }),
    Fp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M20.23,10.89a3.69,3.69,0,0,0-2.49,3.7l0,.63-.63-.08a10.34,10.34,0,0,1-6.06-3l-.84-.84-.21.62a3.72,3.72,0,0,0,.78,3.81c.51.54.4.61-.48.29-.3-.1-.57-.18-.6-.14a4.7,4.7,0,0,0,.46,1.73,4.13,4.13,0,0,0,1.74,1.64l.63.3h-.74c-.71,0-.74,0-.66.28A3.81,3.81,0,0,0,13.55,22l.79.27-.69.42a7.22,7.22,0,0,1-3.41.95,3.62,3.62,0,0,0-1,.1,9.53,9.53,0,0,0,2.45,1.13A10.72,10.72,0,0,0,20,23.89a11.25,11.25,0,0,0,4.23-5A13.08,13.08,0,0,0,25.1,15c0-.59,0-.67.75-1.38a8.47,8.47,0,0,0,.89-1c.13-.24.11-.24-.53,0-1.09.38-1.24.33-.7-.25A3.74,3.74,0,0,0,26.37,11s-.19,0-.41.14a6.7,6.7,0,0,1-1.12.44l-.68.22-.63-.43a5.19,5.19,0,0,0-1.08-.57A4.27,4.27,0,0,0,20.23,10.89Z"
        })]
    }),
    Ip = e => a(T, {
        viewBox: "0 0 32 32",
        alt: e.alt,
        id: e.id,
        children: a("g", {
            children: a("path", {
                fill: "currentColor",
                d: "M24.2,23.9v-6.1c0-3.3-1.8-4.8-4.1-4.8c-1.3-0.1-2.5,0.6-3.2,1.8v-1.5h-3.6c0,1,0,10.7,0,10.7h3.6V18c0-0.3,0-0.6,0.1-0.9c0.3-0.8,1-1.3,1.8-1.3c1.3,0,1.8,1,1.8,2.4v5.7H24.2z M9.6,11.8c1,0.1,1.9-0.6,2-1.7c0.1-1-0.6-1.9-1.7-2c-0.1,0-0.3,0-0.4,0c-1-0.1-1.9,0.6-2,1.7s0.6,1.9,1.7,2C9.3,11.8,9.4,11.8,9.6,11.8z M11.3,23.9V13.2H7.8v10.7H11.3z"
            })
        })
    }),
    kp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25.16,23.94V17.81c0-3.29-1.75-4.82-4.1-4.82a3.53,3.53,0,0,0-3.2,1.77V13.24H14.3c0,1,0,10.7,0,10.7h3.56V18A2.3,2.3,0,0,1,18,17.1a1.93,1.93,0,0,1,1.82-1.3c1.29,0,1.8,1,1.8,2.42v5.72ZM10.55,11.78a1.86,1.86,0,1,0,0-3.7,1.86,1.86,0,1,0,0,3.7Zm1.78,12.16V13.24H8.77v10.7Z"
        })]
    }),
    Tp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25.16,23.94V17.81c0-3.29-1.75-4.82-4.1-4.82a3.53,3.53,0,0,0-3.2,1.77V13.24H14.3c0,1,0,10.7,0,10.7h3.56V18A2.3,2.3,0,0,1,18,17.1a1.93,1.93,0,0,1,1.82-1.3c1.29,0,1.8,1,1.8,2.42v5.72ZM10.55,11.78a1.86,1.86,0,1,0,0-3.7,1.86,1.86,0,1,0,0,3.7Zm1.78,12.16V13.24H8.77v10.7Z"
        })]
    }),
    Ep = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#007bb5",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M25.3,23.94V17.81c0-3.29-1.76-4.82-4.1-4.82A3.51,3.51,0,0,0,18,14.76V13.24H14.44c.05,1,0,10.7,0,10.7H18V18a2.53,2.53,0,0,1,.11-.86,2,2,0,0,1,1.83-1.3c1.29,0,1.8,1,1.8,2.42v5.72ZM10.69,11.78a1.86,1.86,0,1,0,0-3.7,1.86,1.86,0,1,0,0,3.7Zm1.78,12.16V13.24H8.91v10.7Z"
        })]
    }),
    Lp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "#007bb5",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#007bb5",
            d: "M25.3,23.94V17.81c0-3.29-1.76-4.82-4.1-4.82A3.51,3.51,0,0,0,18,14.76V13.24H14.44c.05,1,0,10.7,0,10.7H18V18a2.53,2.53,0,0,1,.11-.86,2,2,0,0,1,1.83-1.3c1.29,0,1.8,1,1.8,2.42v5.72ZM10.69,11.78a1.86,1.86,0,1,0,0-3.7,1.86,1.86,0,1,0,0,3.7Zm1.78,12.16V13.24H8.91v10.7Z"
        })]
    }),
    Mp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#CCC",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M25.3,23.94V17.81c0-3.29-1.76-4.82-4.1-4.82A3.51,3.51,0,0,0,18,14.76V13.24H14.44c.05,1,0,10.7,0,10.7H18V18a2.53,2.53,0,0,1,.11-.86,2,2,0,0,1,1.83-1.3c1.29,0,1.8,1,1.8,2.42v5.72ZM10.69,11.78a1.86,1.86,0,1,0,0-3.7,1.86,1.86,0,1,0,0,3.7Zm1.78,12.16V13.24H8.91v10.7Z"
        })]
    }),
    Op = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25.3,23.94V17.81c0-3.29-1.76-4.82-4.1-4.82A3.51,3.51,0,0,0,18,14.76V13.24H14.44c.05,1,0,10.7,0,10.7H18V18a2.53,2.53,0,0,1,.11-.86,2,2,0,0,1,1.83-1.3c1.29,0,1.8,1,1.8,2.42v5.72ZM10.69,11.78a1.86,1.86,0,1,0,0-3.7,1.86,1.86,0,1,0,0,3.7Zm1.78,12.16V13.24H8.91v10.7Z"
        })]
    }),
    Ap = e => a(T, {
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: "currentColor",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1ZM12.46,23.94H8.91V13.24h3.55ZM10.68,11.78h0a1.85,1.85,0,1,1,.05-3.7,1.86,1.86,0,1,1,0,3.7ZM25.29,23.94H21.74V18.22c0-1.44-.52-2.42-1.81-2.42a1.94,1.94,0,0,0-1.82,1.3A2.45,2.45,0,0,0,18,18v6H14.43s.05-9.7,0-10.7H18v1.51A3.55,3.55,0,0,1,21.2,13c2.34,0,4.09,1.53,4.09,4.81Z"
        })
    }),
    Wp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25.3,23.94V17.8c0-3.28-1.76-4.81-4.1-4.81A3.53,3.53,0,0,0,18,14.75V13.24H14.44c.05,1,0,10.7,0,10.7H18V18a2.46,2.46,0,0,1,.11-.86,2,2,0,0,1,1.83-1.3c1.29,0,1.8,1,1.8,2.42v5.72ZM10.69,11.78a1.86,1.86,0,1,0,0-3.7,1.86,1.86,0,1,0,0,3.7Zm1.78,12.16V13.24H8.91v10.7Z"
        })]
    }),
    Dp = e => a(T, {
        viewBox: "0 0 32 32",
        alt: e.alt,
        id: e.id,
        children: a("g", {
            children: a("path", {
                fill: "currentColor",
                d: "M24,12.5c0,4.6-2.6,8.1-6.4,8.1c-1.2,0-2.2-0.5-2.9-1.5c0,0-0.7,2.7-0.8,3.3c-0.5,1.4-1.2,2.7-2.1,3.9c0,0.1-0.1,0.1-0.2,0.1c0,0-0.1-0.1-0.1-0.1c-0.3-1.5-0.3-3,0-4.5c0.2-1,1.5-6.5,1.5-6.5c-0.3-0.6-0.4-1.2-0.4-1.9c0-1.8,1-3.1,2.3-3.1c0.9,0,1.6,0.7,1.6,1.6c0,0.1,0,0.1,0,0.2c-0.2,1.4-0.5,2.8-1,4.2c-0.2,1,0.3,2,1.3,2.2c0.2,0,0.4,0.1,0.5,0.1c2.2,0,3.8-2.9,3.8-6.3c0-2.6-1.8-4.6-4.9-4.6c-3.1-0.1-5.7,2.3-5.8,5.4c0,0.1,0,0.2,0,0.3c0,0.8,0.2,1.7,0.8,2.3c0.2,0.2,0.3,0.4,0.2,0.7c-0.1,0.2-0.2,0.8-0.2,1c0,0.2-0.3,0.4-0.5,0.3c0,0-0.1,0-0.1,0C8.8,16.9,8,15.1,8,13.1c0-3.4,2.9-7.4,8.5-7.4C21,5.7,24,8.9,24,12.5z"
            })
        })
    }),
    Np = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25,13.47c0,4.65-2.59,8.13-6.41,8.13a3.39,3.39,0,0,1-2.9-1.48s-.69,2.74-.84,3.27a12.52,12.52,0,0,1-2.14,3.88.15.15,0,0,1-.28-.07,13.42,13.42,0,0,1,0-4.51c.23-1,1.53-6.47,1.53-6.47a4.57,4.57,0,0,1-.38-1.88c0-1.76,1-3.07,2.29-3.07a1.59,1.59,0,0,1,1.6,1.78,25.83,25.83,0,0,1-1,4.21,1.84,1.84,0,0,0,1.87,2.29c2.25,0,3.76-2.89,3.76-6.31,0-2.6-1.75-4.55-4.94-4.55a5.61,5.61,0,0,0-5.84,5.68,3.4,3.4,0,0,0,.78,2.33.57.57,0,0,1,.17.66c-.06.22-.19.75-.24,1a.41.41,0,0,1-.6.29C9.78,17.94,9,16.12,9,14.08c0-3.38,2.85-7.42,8.49-7.42C22,6.66,25,9.94,25,13.47Z"
        })]
    }),
    Up = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25,13.47c0,4.65-2.59,8.13-6.41,8.13a3.39,3.39,0,0,1-2.9-1.48s-.69,2.74-.84,3.27a12.52,12.52,0,0,1-2.14,3.88.15.15,0,0,1-.28-.07,13.42,13.42,0,0,1,0-4.51c.23-1,1.53-6.47,1.53-6.47a4.57,4.57,0,0,1-.38-1.88c0-1.76,1-3.07,2.29-3.07a1.59,1.59,0,0,1,1.6,1.78,25.83,25.83,0,0,1-1,4.21,1.84,1.84,0,0,0,1.87,2.29c2.25,0,3.76-2.89,3.76-6.31,0-2.6-1.75-4.55-4.94-4.55a5.61,5.61,0,0,0-5.84,5.68,3.4,3.4,0,0,0,.78,2.33.57.57,0,0,1,.17.66c-.06.22-.19.75-.24,1a.41.41,0,0,1-.6.29C9.78,17.94,9,16.12,9,14.08c0-3.38,2.85-7.42,8.49-7.42C22,6.66,25,9.94,25,13.47Z"
        })]
    }),
    Vp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#bd081c",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M25,13.47c0,4.65-2.59,8.13-6.41,8.13a3.39,3.39,0,0,1-2.9-1.48s-.69,2.74-.84,3.27a12.52,12.52,0,0,1-2.14,3.88.15.15,0,0,1-.28-.07,13.42,13.42,0,0,1,0-4.51c.23-1,1.53-6.47,1.53-6.47a4.57,4.57,0,0,1-.38-1.88c0-1.76,1-3.07,2.29-3.07a1.59,1.59,0,0,1,1.6,1.78,25.83,25.83,0,0,1-1,4.21,1.84,1.84,0,0,0,1.87,2.29c2.25,0,3.76-2.89,3.76-6.31,0-2.6-1.75-4.55-4.94-4.55a5.61,5.61,0,0,0-5.84,5.68,3.4,3.4,0,0,0,.78,2.33.57.57,0,0,1,.17.66c-.06.22-.19.75-.24,1a.41.41,0,0,1-.6.29C9.78,17.94,9,16.12,9,14.08c0-3.38,2.85-7.42,8.49-7.42C22,6.66,25,9.94,25,13.47Z"
        })]
    }),
    Hp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "#bd081c",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#bd081c",
            d: "M25,13.47c0,4.65-2.59,8.13-6.41,8.13a3.39,3.39,0,0,1-2.9-1.48s-.69,2.74-.84,3.27a12.52,12.52,0,0,1-2.14,3.88.15.15,0,0,1-.28-.07,13.42,13.42,0,0,1,0-4.51c.23-1,1.53-6.47,1.53-6.47a4.57,4.57,0,0,1-.38-1.88c0-1.76,1-3.07,2.29-3.07a1.59,1.59,0,0,1,1.6,1.78,25.83,25.83,0,0,1-1,4.21,1.84,1.84,0,0,0,1.87,2.29c2.25,0,3.76-2.89,3.76-6.31,0-2.6-1.75-4.55-4.94-4.55a5.61,5.61,0,0,0-5.84,5.68,3.4,3.4,0,0,0,.78,2.33.57.57,0,0,1,.17.66c-.06.22-.19.75-.24,1a.41.41,0,0,1-.6.29C9.78,17.94,9,16.12,9,14.08c0-3.38,2.85-7.42,8.49-7.42C22,6.66,25,9.94,25,13.47Z"
        })]
    }),
    jp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#CCC",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            d: "M25,13.47c0,4.65-2.59,8.13-6.41,8.13a3.39,3.39,0,0,1-2.9-1.48s-.69,2.74-.84,3.27a12.52,12.52,0,0,1-2.14,3.88.15.15,0,0,1-.28-.07,13.42,13.42,0,0,1,0-4.51c.23-1,1.53-6.47,1.53-6.47a4.57,4.57,0,0,1-.38-1.88c0-1.76,1-3.07,2.29-3.07a1.59,1.59,0,0,1,1.6,1.78,25.83,25.83,0,0,1-1,4.21,1.84,1.84,0,0,0,1.87,2.29c2.25,0,3.76-2.89,3.76-6.31,0-2.6-1.75-4.55-4.94-4.55a5.61,5.61,0,0,0-5.84,5.68,3.4,3.4,0,0,0,.78,2.33.57.57,0,0,1,.17.66c-.06.22-.19.75-.24,1a.41.41,0,0,1-.6.29C9.78,17.94,9,16.12,9,14.08c0-3.38,2.85-7.42,8.49-7.42C22,6.66,25,9.94,25,13.47Z"
        })]
    }),
    zp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25,13.47c0,4.65-2.59,8.13-6.41,8.13a3.39,3.39,0,0,1-2.9-1.48s-.69,2.74-.84,3.27a12.52,12.52,0,0,1-2.14,3.88.15.15,0,0,1-.28-.07,13.42,13.42,0,0,1,0-4.51c.23-1,1.53-6.47,1.53-6.47a4.57,4.57,0,0,1-.38-1.88c0-1.76,1-3.07,2.29-3.07a1.59,1.59,0,0,1,1.6,1.78,25.83,25.83,0,0,1-1,4.21,1.84,1.84,0,0,0,1.87,2.29c2.25,0,3.76-2.89,3.76-6.31,0-2.6-1.75-4.55-4.94-4.55a5.61,5.61,0,0,0-5.84,5.68,3.4,3.4,0,0,0,.78,2.33.57.57,0,0,1,.17.66c-.06.22-.19.75-.24,1a.41.41,0,0,1-.6.29C9.78,17.94,9,16.12,9,14.08c0-3.38,2.85-7.42,8.49-7.42C22,6.66,25,9.94,25,13.47Z"
        })]
    }),
    _p = e => a(T, {
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: "currentColor",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Zm1.6,20.6a3.39,3.39,0,0,1-2.9-1.48s-.69,2.74-.84,3.27a12.52,12.52,0,0,1-2.14,3.88.15.15,0,0,1-.28-.07,13.42,13.42,0,0,1,0-4.51c.23-1,1.53-6.47,1.53-6.47a4.57,4.57,0,0,1-.38-1.88c0-1.76,1-3.07,2.29-3.07a1.59,1.59,0,0,1,1.6,1.78,25.83,25.83,0,0,1-1,4.21,1.84,1.84,0,0,0,1.87,2.29c2.25,0,3.76-2.89,3.76-6.31,0-2.6-1.75-4.55-4.94-4.55a5.61,5.61,0,0,0-5.84,5.68,3.4,3.4,0,0,0,.78,2.33.59.59,0,0,1,.17.67c-.06.21-.19.74-.24.95a.41.41,0,0,1-.6.3C9.78,17.94,9,16.12,9,14.08c0-3.38,2.85-7.42,8.49-7.42C22,6.66,25,9.94,25,13.46,25,18.12,22.42,21.6,18.6,21.6Z"
        })
    }),
    Gp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            d: "M25,13.46c0,4.66-2.59,8.14-6.41,8.14a3.39,3.39,0,0,1-2.9-1.48s-.69,2.74-.84,3.27a12.52,12.52,0,0,1-2.14,3.88.15.15,0,0,1-.28-.07,13.42,13.42,0,0,1,0-4.51c.23-1,1.53-6.47,1.53-6.47a4.57,4.57,0,0,1-.38-1.88c0-1.76,1-3.07,2.29-3.07a1.59,1.59,0,0,1,1.6,1.78,25.83,25.83,0,0,1-1,4.21,1.84,1.84,0,0,0,1.87,2.29c2.25,0,3.76-2.89,3.76-6.31,0-2.6-1.75-4.55-4.94-4.55a5.61,5.61,0,0,0-5.84,5.68,3.4,3.4,0,0,0,.78,2.33.57.57,0,0,1,.17.66c-.06.22-.19.75-.24,1a.41.41,0,0,1-.6.29C9.78,17.94,9,16.12,9,14.08c0-3.38,2.85-7.42,8.49-7.42C22,6.66,25,9.94,25,13.46Z"
        })]
    }),
    Zp = e => a(T, {
        viewBox: "0 0 32 32",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fillRule: "evenodd",
            fill: "currentColor",
            d: "M26,10.5c0.1-0.5,0-0.9-0.7-0.9h-2.4c-0.4,0-0.8,0.2-1,0.7c-0.7,1.7-1.7,3.3-2.9,4.8c-0.5,0.5-0.8,0.7-1.1,0.7c-0.1,0-0.4-0.2-0.4-0.7v-4.6c0-0.6-0.2-0.9-0.7-0.9h-3.7c-0.3,0-0.6,0.2-0.6,0.5c0,0,0,0,0,0c0,0.6,0.8,0.7,0.9,2.3v3.4c0,0.8-0.1,0.9-0.4,0.9c-0.8,0-2.7-2.9-3.9-6.2c-0.2-0.6-0.4-0.9-1-0.9H6c-0.7,0-0.8,0.3-0.8,0.7C5.2,10.9,6,14,8.9,18c1.9,2.8,4.6,4.3,7.1,4.3c1.5,0,1.7-0.3,1.7-0.9v-2.1c0-0.7,0.1-0.8,0.6-0.8s0.9,0.2,2.3,1.5c1.6,1.6,1.8,2.3,2.7,2.3h2.3c0.7,0,1-0.3,0.8-1c-0.5-1-1.2-1.9-2-2.7c-0.5-0.6-1.4-1.3-1.6-1.7s-0.2-0.6,0-1C22.8,15.9,25.7,11.9,26,10.5z"
        })
    }),
    qp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            fillRule: "evenodd",
            d: "M25.84,12.64c.13-.44,0-.76-.63-.76H23.14a.89.89,0,0,0-.9.58,17.53,17.53,0,0,1-2.55,4.24c-.48.48-.7.64-1,.64s-.32-.16-.32-.6v-4.1c0-.53-.16-.76-.6-.76H14.56a.5.5,0,0,0-.53.47c0,.5.75.62.83,2v3.05c0,.67-.13.79-.39.79-.7,0-2.41-2.58-3.42-5.53-.2-.57-.4-.8-.93-.8H8.05c-.59,0-.71.28-.71.58,0,.55.7,3.27,3.27,6.87a8.06,8.06,0,0,0,6.32,3.79c1.31,0,1.48-.3,1.48-.8V20.46c0-.59.12-.71.54-.71s.83.15,2.06,1.34c1.4,1.4,1.64,2,2.42,2h2.08c.59,0,.88-.3.71-.88a8.84,8.84,0,0,0-1.74-2.43c-.49-.57-1.21-1.18-1.43-1.49s-.22-.57,0-.92C23.05,17.4,25.57,13.85,25.84,12.64Z"
        })]
    }),
    Jp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fillRule: "evenodd",
            fill: "currentColor",
            d: "M25.84,12.64c.13-.44,0-.76-.63-.76H23.14a.89.89,0,0,0-.9.58,17.53,17.53,0,0,1-2.55,4.24c-.48.48-.7.64-1,.64s-.32-.16-.32-.6v-4.1c0-.53-.16-.76-.6-.76H14.56a.5.5,0,0,0-.53.47c0,.5.75.62.83,2v3.05c0,.67-.13.79-.39.79-.7,0-2.41-2.58-3.42-5.53-.2-.57-.4-.8-.93-.8H8.05c-.59,0-.71.28-.71.58,0,.55.7,3.27,3.27,6.87a8.06,8.06,0,0,0,6.32,3.79c1.31,0,1.48-.3,1.48-.8V20.46c0-.59.12-.71.54-.71s.83.15,2.06,1.34c1.4,1.4,1.64,2,2.42,2h2.08c.59,0,.88-.3.71-.88a8.84,8.84,0,0,0-1.74-2.43c-.49-.57-1.21-1.18-1.43-1.49s-.22-.57,0-.92C23.05,17.4,25.57,13.85,25.84,12.64Z"
        })]
    }),
    Yp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#5181b8",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            fillRule: "evenodd",
            d: "M25.84,12.64c.13-.44,0-.76-.63-.76H23.14a.89.89,0,0,0-.9.58,17.53,17.53,0,0,1-2.55,4.24c-.48.48-.7.64-1,.64s-.32-.16-.32-.6v-4.1c0-.53-.16-.76-.6-.76H14.56a.5.5,0,0,0-.53.47c0,.5.75.62.83,2v3.05c0,.67-.13.79-.39.79-.7,0-2.41-2.58-3.42-5.53-.2-.57-.4-.8-.93-.8H8.05c-.59,0-.71.28-.71.58,0,.55.7,3.27,3.27,6.87a8.06,8.06,0,0,0,6.32,3.79c1.31,0,1.48-.3,1.48-.8V20.46c0-.59.12-.71.54-.71s.83.15,2.06,1.34c1.4,1.4,1.64,2,2.42,2h2.08c.59,0,.88-.3.71-.88a8.84,8.84,0,0,0-1.74-2.43c-.49-.57-1.21-1.18-1.43-1.49s-.22-.57,0-.92C23.05,17.4,25.57,13.85,25.84,12.64Z"
        })]
    }),
    Xp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "#5181b8",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#5181b8",
            fillRule: "evenodd",
            d: "M25.84,12.64c.13-.44,0-.76-.63-.76H23.14a.89.89,0,0,0-.9.58,17.53,17.53,0,0,1-2.55,4.24c-.48.48-.7.64-1,.64s-.32-.16-.32-.6v-4.1c0-.53-.16-.76-.6-.76H14.56a.5.5,0,0,0-.53.47c0,.5.75.62.83,2v3.05c0,.67-.13.79-.39.79-.7,0-2.41-2.58-3.42-5.53-.2-.57-.4-.8-.93-.8H8.05c-.59,0-.71.28-.71.58,0,.55.7,3.27,3.27,6.87a8.06,8.06,0,0,0,6.32,3.79c1.31,0,1.48-.3,1.48-.8V20.46c0-.59.12-.71.54-.71s.83.15,2.06,1.34c1.4,1.4,1.64,2,2.42,2h2.08c.59,0,.88-.3.71-.88a8.84,8.84,0,0,0-1.74-2.43c-.49-.57-1.21-1.18-1.43-1.49s-.22-.57,0-.92C23.05,17.4,25.57,13.85,25.84,12.64Z"
        })]
    }),
    Kp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#CCC",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "#FFF",
            fillRule: "evenodd",
            d: "M25.84,12.64c.13-.44,0-.76-.63-.76H23.14a.89.89,0,0,0-.9.58,17.53,17.53,0,0,1-2.55,4.24c-.48.48-.7.64-1,.64s-.32-.16-.32-.6v-4.1c0-.53-.16-.76-.6-.76H14.56a.5.5,0,0,0-.53.47c0,.5.75.62.83,2v3.05c0,.67-.13.79-.39.79-.7,0-2.41-2.58-3.42-5.53-.2-.57-.4-.8-.93-.8H8.05c-.59,0-.71.28-.71.58,0,.55.7,3.27,3.27,6.87a8.06,8.06,0,0,0,6.32,3.79c1.31,0,1.48-.3,1.48-.8V20.46c0-.59.12-.71.54-.71s.83.15,2.06,1.34c1.4,1.4,1.64,2,2.42,2h2.08c.59,0,.88-.3.71-.88a8.84,8.84,0,0,0-1.74-2.43c-.49-.57-1.21-1.18-1.43-1.49s-.22-.57,0-.92C23.05,17.4,25.57,13.85,25.84,12.64Z"
        })]
    }),
    Qp = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            fillRule: "evenodd",
            d: "M25.84,12.64c.13-.44,0-.76-.63-.76H23.14a.89.89,0,0,0-.9.58,17.53,17.53,0,0,1-2.55,4.24c-.48.48-.7.64-1,.64s-.32-.16-.32-.6v-4.1c0-.53-.16-.76-.6-.76H14.56a.5.5,0,0,0-.53.47c0,.5.75.62.83,2v3.05c0,.67-.13.79-.39.79-.7,0-2.41-2.58-3.42-5.53-.2-.57-.4-.8-.93-.8H8.05c-.59,0-.71.28-.71.58,0,.55.7,3.27,3.27,6.87a8.06,8.06,0,0,0,6.32,3.79c1.31,0,1.48-.3,1.48-.8V20.46c0-.59.12-.71.54-.71s.83.15,2.06,1.34c1.4,1.4,1.64,2,2.42,2h2.08c.59,0,.88-.3.71-.88a8.84,8.84,0,0,0-1.74-2.43c-.49-.57-1.21-1.18-1.43-1.49s-.22-.57,0-.92C23.05,17.4,25.57,13.85,25.84,12.64Z"
        })]
    }),
    e2 = e => a(T, {
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: "currentColor",
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Zm8.7,22.12H23.63c-.79,0-1-.63-2.43-2-1.22-1.19-1.75-1.34-2.06-1.34s-.54.12-.54.71v1.86c0,.5-.16.8-1.48.8a8.09,8.09,0,0,1-6.32-3.79C8.24,15.73,7.54,13,7.54,12.46c0-.3.11-.58.71-.58h2.07c.53,0,.72.23.92.8,1,3,2.72,5.53,3.43,5.53.26,0,.38-.12.38-.79V14.37c-.08-1.4-.82-1.52-.82-2a.49.49,0,0,1,.52-.47H18c.44,0,.59.23.59.76v4.1c0,.44.19.59.32.59s.48-.15,1-.63a17.33,17.33,0,0,0,2.54-4.24.9.9,0,0,1,.9-.58H25.4c.63,0,.76.32.63.76-.26,1.21-2.79,4.76-2.79,4.76-.22.35-.3.53,0,.92s1,.92,1.43,1.49a9,9,0,0,1,1.75,2.43C26.59,22.82,26.29,23.12,25.7,23.12Z"
        })
    }),
    t2 = e => y(T, {
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "none",
            stroke: "currentColor",
            strokeMiterlimit: 10,
            d: "M17,1A16,16,0,1,0,33,17,16,16,0,0,0,17,1Z"
        }), a("path", {
            fill: "currentColor",
            fillRule: "evenodd",
            d: "M25.84,12.64c.13-.44,0-.76-.63-.76H23.14a.89.89,0,0,0-.9.58,17.53,17.53,0,0,1-2.55,4.24c-.48.48-.7.63-1,.63s-.32-.15-.32-.59v-4.1c0-.53-.16-.76-.6-.76H14.56a.5.5,0,0,0-.53.47c0,.5.75.62.83,2v3.05c0,.67-.13.79-.39.79-.7,0-2.41-2.58-3.42-5.53-.2-.57-.4-.8-.93-.8H8.05c-.59,0-.71.28-.71.58,0,.55.7,3.27,3.27,6.87a8.06,8.06,0,0,0,6.32,3.79c1.31,0,1.48-.3,1.48-.8V20.46c0-.59.12-.71.54-.71s.83.15,2.06,1.34c1.4,1.4,1.64,2,2.42,2h2.08c.59,0,.88-.3.71-.88a8.69,8.69,0,0,0-1.74-2.43c-.49-.57-1.21-1.18-1.43-1.49s-.22-.57,0-.92C23.05,17.4,25.57,13.85,25.84,12.64Z"
        })]
    }),
    o2 = e => a(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            fill: "currentColor",
            d: `M18.1,7L18.1,7c0,0.3,0.1,3.8,3.8,4c0,3.3,0,0,0,2.7c-0.3,0-2.4-0.1-3.8-1.3l0,5.3c0,2.4-1.3,4.8-3.8,5.2
c-0.7,0.1-1.3,0.1-2.4-0.1C5.8,21,7.8,12,13.9,12.9c0,2.9,0,0,0,2.9c-2.5-0.4-3.4,1.7-2.7,3.2c0.6,1.4,3.1,1.7,4-0.3
c0.1-0.4,0.1-0.8,0.1-1.3V7H18.1z`
        })
    }),
    r2 = e => y(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            d: "M15,1C7.3,1,1,7.3,1,15s6.3,14,14,14s14-6.3,14-14S22.7,1,15,1z"
        }), a("path", {
            fill: "currentColor",
            d: `M18.1,7L18.1,7c0,0.3,0.1,3.8,3.8,4c0,3.3,0,0,0,2.7c-0.3,0-2.4-0.1-3.8-1.3l0,5.3c0,2.4-1.3,4.8-3.8,5.2
c-0.7,0.1-1.3,0.1-2.4-0.1C5.8,21,7.8,12,13.9,12.9c0,2.9,0,0,0,2.9c-2.5-0.4-3.4,1.7-2.7,3.2c0.6,1.4,3.1,1.7,4-0.3
c0.1-0.4,0.1-0.8,0.1-1.3V7H18.1z`
        })]
    }),
    n2 = e => y(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "currentColor",
            d: `M15,2c7.2,0,13,5.8,13,13s-5.8,13-13,13S2,22.2,2,15S7.8,2,15,2 M15,1C7.3,1,1,7.3,1,15c0,7.7,6.3,14,14,14s14-6.3,14-14
C29,7.3,22.7,1,15,1z`
        }), a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            fill: "currentColor",
            d: `M18.1,7L18.1,7c0,0.3,0.1,3.8,3.8,4c0,3.3,0,0,0,2.7c-0.3,0-2.4-0.1-3.8-1.3l0,5.3c0,2.4-1.3,4.8-3.8,5.2
c-0.7,0.1-1.3,0.1-2.4-0.1C5.8,21,7.8,12,13.9,12.9c0,2.9,0,0,0,2.9c-2.5-0.4-3.4,1.7-2.7,3.2c0.6,1.4,3.1,1.7,4-0.3
c0.1-0.4,0.1-0.8,0.1-1.3V7H18.1z`
        })]
    }),
    i2 = e => y(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M15,1C7.3,1,1,7.3,1,15s6.3,14,14,14s14-6.3,14-14S22.7,1,15,1z"
        }), y("g", {
            children: [a("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                fill: "#00F7EF",
                d: `M9.4,21.5c-3.5-3-1.2-9.8,4.2-9v0.6C9,12.9,7,18.4,9.4,21.5z M19.3,9.7c0.6,0.4,1.3,0.8,2.4,0.8v0.6
C20.5,11,19.7,10.4,19.3,9.7z M17.8,6.5c0,0.2,0,0.5,0.1,0.7h-2.2v10.7c0,0.5-0.1,0.9-0.2,1.3c-0.9,1.9-3.4,1.7-4,0.4
c1,0.6,2.7,0.5,3.4-1c0.1-0.4,0.2-0.8,0.2-1.3V6.5H17.8z`
            }), a("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                fill: "#FFFFFF",
                d: `M18.4,7.2L18.4,7.2c0,0.3,0.1,3.9,3.8,4.1c0,3.3,0,0,0,2.8c-0.3,0-2.5-0.1-3.8-1.4l0,5.4
c0,2.4-1.3,4.8-3.9,5.3c-0.7,0.1-1.4,0.2-2.4-0.1C5.9,21.5,8,12.2,14.2,13.2c0,3,0,0,0,3c-2.6-0.4-3.4,1.8-2.8,3.3
c0.6,1.4,3.2,1.7,4.1-0.3c0.1-0.4,0.2-0.8,0.2-1.3V7.2H18.4z`
            }), a("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                fill: "#FF004F",
                d: `M13.6,13.2c0.2,0,0.4,0,0.7,0.1c0,3,0,0,0,3c-2.6-0.4-3.4,1.8-2.8,3.3c0,0,0,0.1,0,0.1
c-0.3-0.2-0.6-0.5-0.7-0.8c-0.7-1.5,0.2-3.7,2.8-3.3C13.6,12.8,13.6,15.1,13.6,13.2z M21.6,11.2c0.2,0,0.4,0.1,0.7,0.1
c0,3.3,0,0,0,2.8c-0.3,0-2.5-0.1-3.8-1.4l0,5.4c0,2.4-1.3,4.8-3.9,5.3c-0.7,0.1-1.4,0.2-2.4-0.1c-1.2-0.4-2.1-1-2.7-1.8
c0.5,0.5,1.2,0.9,2.1,1.1c1.1,0.2,1.7,0.2,2.4,0.1c2.5-0.5,3.9-2.9,3.9-5.3l0-5.4c1.4,1.2,3.6,1.4,3.8,1.4
C21.6,10.8,21.6,13.5,21.6,11.2z M18.4,7.2L18.4,7.2c0,0.2,0,1.5,0.8,2.5C18.3,9,18,7.9,17.9,7.2H18.4z`
            })]
        })]
    }),
    a2 = e => y(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#fe2c55",
            d: `M15,2c7.2,0,13,5.8,13,13s-5.8,13-13,13S2,22.2,2,15S7.8,2,15,2 M15,1C7.3,1,1,7.3,1,15c0,7.7,6.3,14,14,14s14-6.3,14-14
C29,7.3,22.7,1,15,1z`
        }), a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            fill: "#fe2c55",
            d: `M18.1,7L18.1,7c0,0.3,0.1,3.8,3.8,4c0,3.3,0,0,0,2.7c-0.3,0-2.4-0.1-3.8-1.3l0,5.3c0,2.4-1.3,4.8-3.8,5.2
c-0.7,0.1-1.3,0.1-2.4-0.1C5.8,21,7.8,12,13.9,12.9c0,2.9,0,0,0,2.9c-2.5-0.4-3.4,1.7-2.7,3.2c0.6,1.4,3.1,1.7,4-0.3
c0.1-0.4,0.1-0.8,0.1-1.3V7H18.1z`
        })]
    }),
    l2 = e => y(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "#CCC",
            d: "M15,1C7.3,1,1,7.3,1,15s6.3,14,14,14s14-6.3,14-14S22.7,1,15,1z"
        }), a("path", {
            fill: "#FFF",
            d: `M18.1,7L18.1,7c0,0.3,0.1,3.8,3.8,4c0,3.3,0,0,0,2.7c-0.3,0-2.4-0.1-3.8-1.3l0,5.3c0,2.4-1.3,4.8-3.8,5.2
c-0.7,0.1-1.3,0.1-2.4-0.1C5.8,21,7.8,12,13.9,12.9c0,2.9,0,0,0,2.9c-2.5-0.4-3.4,1.7-2.7,3.2c0.6,1.4,3.1,1.7,4-0.3
c0.1-0.4,0.1-0.8,0.1-1.3V7H18.1z`
        })]
    }),
    s2 = e => y(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "currentColor",
            d: `M15,2c7.2,0,13,5.8,13,13s-5.8,13-13,13S2,22.2,2,15S7.8,2,15,2 M15,1C7.3,1,1,7.3,1,15c0,7.7,6.3,14,14,14s14-6.3,14-14
C29,7.3,22.7,1,15,1z`
        }), a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            fill: "currentColor",
            d: `M18.1,7L18.1,7c0,0.3,0.1,3.8,3.8,4c0,3.3,0,0,0,2.7c-0.3,0-2.4-0.1-3.8-1.3l0,5.3c0,2.4-1.3,4.8-3.8,5.2
c-0.7,0.1-1.3,0.1-2.4-0.1C5.8,21,7.8,12,13.9,12.9c0,2.9,0,0,0,2.9c-2.5-0.4-3.4,1.7-2.7,3.2c0.6,1.4,3.1,1.7,4-0.3
c0.1-0.4,0.1-0.8,0.1-1.3V7H18.1z`
        })]
    }),
    d2 = e => a(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            fill: "currentColor",
            d: `M15,1C7.3,1,1,7.3,1,15s6.3,14,14,14s14-6.3,14-14S22.7,1,15,1z M18.1,12.4l0,5.3c0,2.4-1.3,4.8-3.8,5.2
c-0.7,0.1-1.3,0.1-2.4-0.1C5.8,21,7.8,12,13.9,12.9c0,2.9,0,0,0,2.9c-2.5-0.4-3.4,1.7-2.7,3.2c0.6,1.4,3.1,1.7,4-0.3
c0.1-0.4,0.1-0.8,0.1-1.3V7h2.7v0c0,0.2,0.1,3.8,3.8,4c0,3.3,0,0,0,2.7C21.5,13.7,19.4,13.6,18.1,12.4z`
        })
    }),
    u2 = e => y(T, {
        viewBox: "0 0 30 30",
        alt: e.alt,
        id: e.id,
        children: [a("path", {
            fill: "currentColor",
            d: `M15,2c7.2,0,13,5.8,13,13s-5.8,13-13,13S2,22.2,2,15S7.8,2,15,2 M15,1C7.3,1,1,7.3,1,15c0,7.7,6.3,14,14,14s14-6.3,14-14
C29,7.3,22.7,1,15,1z`
        }), a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            fill: "currentColor",
            d: `M18.1,7L18.1,7c0,0.3,0.1,3.8,3.8,4c0,3.3,0,0,0,2.7c-0.3,0-2.4-0.1-3.8-1.3l0,5.3c0,2.4-1.3,4.8-3.8,5.2
c-0.7,0.1-1.3,0.1-2.4-0.1C5.8,21,7.8,12,13.9,12.9c0,2.9,0,0,0,2.9c-2.5-0.4-3.4,1.7-2.7,3.2c0.6,1.4,3.1,1.7,4-0.3
c0.1-0.4,0.1-0.8,0.1-1.3V7H18.1z`
        })]
    }),
    c2 = "#1877F2",
    h2 = e => a(T, {
        viewBox: "0 0 50 50",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: e.focused ? "currentColor" : c2,
            d: `M45,25.1c0-11-9-20-20-20s-20,9-20,20c0,10,7.3,18.3,16.9,19.8v-14h-5.1v-5.8h5.1v-4.4c0-5,3-7.8,7.6-7.8
c2.2,0,4.5,0.4,4.5,0.4v4.9h-2.5c-2.5,0-3.3,1.5-3.3,3.1v3.8h5.5l-0.9,5.8h-4.7v14C37.7,43.4,45,35.1,45,25.1z`
        })
    }),
    Xu = "instagramId",
    m2 = e => y(T, {
        viewBox: "0 0 50 50",
        alt: e.alt,
        id: e.id,
        children: [y("linearGradient", {
            id: Xu,
            gradientUnits: "userSpaceOnUse",
            x1: "8.3568",
            y1: "41.6432",
            x2: "41.6432",
            y2: "8.3568",
            children: [a("stop", {
                offset: "0",
                stopColor: "#FCC36A"
            }), a("stop", {
                offset: "0.25",
                stopColor: "#F36F35"
            }), a("stop", {
                offset: "0.5",
                stopColor: "#C23779"
            }), a("stop", {
                offset: "0.75",
                stopColor: "#8E45A2"
            }), a("stop", {
                offset: "1",
                stopColor: "#6E54BA"
            })]
        }), a("path", {
            fill: e.focused ? "currentColor" : `url(#${Xu})`,
            d: `M25,8.6c5.3,0,6,0,8.1,0.1c1.9,0.1,3,0.4,3.7,0.7c0.9,0.4,1.6,0.8,2.3,1.5c0.7,0.7,1.1,1.4,1.5,2.3
c0.3,0.7,0.6,1.8,0.7,3.7c0.1,2.1,0.1,2.7,0.1,8.1s0,6-0.1,8.1c-0.1,1.9-0.4,3-0.7,3.7c-0.4,0.9-0.8,1.6-1.5,2.3
c-0.7,0.7-1.4,1.1-2.3,1.5c-0.7,0.3-1.8,0.6-3.7,0.7c-2.1,0.1-2.7,0.1-8.1,0.1s-6,0-8.1-0.1c-1.9-0.1-3-0.4-3.7-0.7
c-0.9-0.4-1.6-0.8-2.3-1.5c-0.7-0.7-1.1-1.4-1.5-2.3c-0.3-0.7-0.6-1.8-0.7-3.7C8.6,31,8.6,30.3,8.6,25s0-6,0.1-8.1
c0.1-1.9,0.4-3,0.7-3.7c0.4-0.9,0.8-1.6,1.5-2.3c0.7-0.7,1.4-1.1,2.3-1.5c0.7-0.3,1.8-0.6,3.7-0.7C19,8.6,19.7,8.6,25,8.6 M25,5
c-5.4,0-6.1,0-8.2,0.1c-2.1,0.1-3.6,0.4-4.9,0.9c-1.3,0.5-2.4,1.2-3.5,2.3C7.2,9.5,6.6,10.6,6,11.9c-0.5,1.3-0.8,2.7-0.9,4.9
C5,18.9,5,19.6,5,25c0,5.4,0,6.1,0.1,8.2c0.1,2.1,0.4,3.6,0.9,4.9c0.5,1.3,1.2,2.4,2.3,3.5c1.1,1.1,2.2,1.8,3.5,2.3
c1.3,0.5,2.7,0.8,4.9,0.9C18.9,45,19.6,45,25,45s6.1,0,8.2-0.1c2.1-0.1,3.6-0.4,4.9-0.9c1.3-0.5,2.4-1.2,3.5-2.3
c1.1-1.1,1.8-2.2,2.3-3.5c0.5-1.3,0.8-2.7,0.9-4.9C45,31.1,45,30.4,45,25s0-6.1-0.1-8.2c-0.1-2.1-0.4-3.6-0.9-4.9
c-0.5-1.3-1.2-2.4-2.3-3.5c-1.1-1.1-2.2-1.8-3.5-2.3c-1.3-0.5-2.7-0.8-4.9-0.9C31.1,5,30.4,5,25,5L25,5z M25,14.7
c-5.7,0-10.3,4.6-10.3,10.3c0,5.7,4.6,10.3,10.3,10.3S35.3,30.7,35.3,25C35.3,19.3,30.7,14.7,25,14.7z M25,31.7
c-3.7,0-6.7-3-6.7-6.7c0-3.7,3-6.7,6.7-6.7s6.7,3,6.7,6.7C31.7,28.7,28.7,31.7,25,31.7z M35.7,11.9c-1.3,0-2.4,1.1-2.4,2.4
c0,1.3,1.1,2.4,2.4,2.4c1.3,0,2.4-1.1,2.4-2.4C38.1,13,37,11.9,35.7,11.9z`
        })]
    }),
    b2 = "#FF0000",
    f2 = e => a(T, {
        viewBox: "0 0 50 50",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: e.focused ? "currentColor" : b2,
            d: `M44.2,15.4c-0.5-1.7-1.8-3.1-3.5-3.5C37.5,11,25,11,25,11s-12.5,0-15.6,0.8c-1.7,0.5-3.1,1.8-3.5,3.5
C5,18.5,5,25,5,25s0,6.5,0.8,9.6c0.5,1.7,1.8,3.1,3.5,3.5C12.5,39,25,39,25,39s12.5,0,15.6-0.8c1.7-0.5,3.1-1.8,3.5-3.5
C45,31.5,45,25,45,25S45,18.5,44.2,15.4z M21,31V19l10.4,6L21,31z`
        })
    }),
    g2 = "#1D9BF0",
    p2 = e => a(T, {
        viewBox: "0 0 50 50",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: e.focused ? "currentColor" : g2,
            d: `M40.9,16.8c0,0.4,0,0.7,0,1.1c0,10.8-8.3,23.4-23.4,23.4v0c-4.5,0-8.8-1.3-12.6-3.7
c0.6,0.1,1.3,0.1,2,0.1c3.7,0,7.3-1.2,10.2-3.5c-3.5-0.1-6.6-2.4-7.7-5.7c1.2,0.2,2.5,0.2,3.7-0.1c-3.8-0.8-6.6-4.1-6.6-8
c0,0,0-0.1,0-0.1c1.1,0.6,2.4,1,3.7,1c-3.6-2.4-4.7-7.2-2.5-11c4.2,5.1,10.3,8.2,16.9,8.6C24,16,24.9,13,27.1,11
c3.3-3.1,8.5-2.9,11.6,0.4c1.8-0.4,3.6-1,5.2-2c-0.6,1.9-1.9,3.5-3.6,4.5c1.6-0.2,3.2-0.6,4.7-1.3C43.9,14.2,42.5,15.7,40.9,16.8z`
        })
    }),
    y2 = "#2867B2",
    x2 = e => a(T, {
        viewBox: "0 0 50 50",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: e.focused ? "currentColor" : y2,
            d: `M42.2,5H7.8C6.3,5,5,6.3,5,7.8v34.4C5,43.7,6.3,45,7.8,45h34.4c1.6,0,2.8-1.3,2.8-2.8V7.8C45,6.3,43.7,5,42.2,5
z M13.6,11.1c1.7,0,3,1.4,3,3c0,1.7-1.3,3-3,3c-1.7,0-3-1.4-3-3C10.6,12.4,11.9,11.1,13.6,11.1z M16.6,38.9h-6V19.5h6V38.9z
M39.5,38.9h-6V28.8c0-6.1-7.3-5.7-7.3,0v10.2h-6V19.5h6v2.6c2.5-4.7,13.3-5.1,13.3,4.5V38.9z`
        })
    }),
    v2 = "#E60023",
    C2 = e => a(T, {
        viewBox: "0 0 50 50",
        alt: e.alt,
        id: e.id,
        children: a("g", {
            id: "g62",
            transform: "translate(123.0422,246.9921)",
            children: a("path", {
                id: "path64",
                fill: e.focused ? "currentColor" : v2,
                d: `M-98-242c-11,0-20,9-20,20c0,8.5,5.3,15.7,12.7,18.6c-0.2-1.6-0.3-4,0.1-5.7
c0.4-1.6,2.3-9.9,2.3-9.9s-0.6-1.2-0.6-3c0-2.8,1.6-4.9,3.6-4.9c1.7,0,2.5,1.3,2.5,2.8c0,1.7-1.1,4.3-1.7,6.7c-0.5,2,1,3.6,3,3.6
c3.6,0,6.3-3.7,6.3-9.2c0-4.8-3.4-8.1-8.4-8.1c-5.7,0-9,4.3-9,8.7c0,1.7,0.7,3.6,1.5,4.6c0.2,0.2,0.2,0.4,0.1,0.6
c-0.2,0.6-0.5,2-0.6,2.3c-0.1,0.4-0.3,0.4-0.7,0.3c-2.5-1.2-4.1-4.8-4.1-7.7c0-6.3,4.6-12.1,13.2-12.1c6.9,0,12.3,4.9,12.3,11.6
c0,6.9-4.3,12.4-10.4,12.4c-2,0-3.9-1.1-4.6-2.3c0,0-1,3.8-1.2,4.8c-0.5,1.7-1.7,3.9-2.5,5.2c1.9,0.6,3.9,0.9,5.9,0.9
c11,0,20-9,20-20C-78-233-87-242-98-242`
            })
        })
    }),
    w2 = "#0077FF",
    B2 = e => a(T, {
        viewBox: "0 0 50 50",
        alt: e.alt,
        id: e.id,
        children: a("path", {
            fill: e.focused ? "currentColor" : w2,
            d: `M42.2,7.8C39.4,5,34.9,5,25.8,5h-1.6C15.1,5,10.6,5,7.8,7.8C5,10.6,5,15.1,5,24.2v1.6c0,9.1,0,13.6,2.8,16.4
C10.6,45,15.1,45,24.2,45h1.6c9.1,0,13.6,0,16.4-2.8C45,39.4,45,34.9,45,25.8v-1.6C45,15.1,45,10.6,42.2,7.8z M33.7,33.8
c-1-3.2-3.5-5.6-6.9-5.9v5.9h-0.5c-9.1,0-14.3-6.2-14.5-16.6h4.6c0.1,7.6,3.5,10.9,6.2,11.5V17.2h4.3v6.6c2.6-0.3,5.4-3.3,6.3-6.6
h4.3c-0.7,4.1-3.7,7.1-5.9,8.3c2.1,1,5.6,3.6,6.9,8.3H33.7z`
        })
    }),
    S2 = ({
        focused: e,
        ...t
    }) => a(T, {
        viewBox: "0 0 50 50",
        alt: t.alt,
        id: t.id,
        children: y("g", {
            children: [e ? null : a("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                fill: "#00F7EF",
                d: `M11.8,40.3c-8.3-7.2-2.9-23.1,9.8-21.1v1.5C10.9,20.2,6.2,33,11.8,40.3z M35,12.6c1.3,1,3.1,1.8,5.6,2V16
C37.8,15.5,36.1,14.2,35,12.6z M31.6,5c0,0.5,0.1,1.1,0.2,1.6h-5.1v25.2c0,1.2-0.1,2.2-0.4,3.1c-2.1,4.5-7.9,4-9.5,0.8
c2.4,1.5,6.4,1.1,8-2.5c0.2-0.9,0.4-1.9,0.4-3.1V5H31.6z`
            }), a("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                fill: e ? "currentColor" : "",
                d: `M33.1,6.6L33.1,6.6c0,0.6,0.2,9.1,9,9.6c0,7.9,0,0,0,6.5c-0.7,0-5.8-0.3-9-3.2l0,12.7C33.2,38,30,43.6,24,44.8
c-1.7,0.3-3.2,0.4-5.7-0.2c-14.6-4.4-9.8-26.1,4.9-23.7c0,7,0,0,0,7c-6.1-0.9-8.1,4.2-6.5,7.8c1.5,3.3,7.5,4,9.6-0.6
c0.2-0.9,0.4-1.9,0.4-3.1V6.6H33.1z`
            }), e ? null : a("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                fill: "#FF004F",
                d: `M21.6,20.7c0.5,0,1,0.1,1.5,0.2c0,7,0,0,0,7c-6.1-0.9-8.1,4.2-6.5,7.8c0,0.1,0.1,0.1,0.1,0.2
c-0.7-0.5-1.3-1.1-1.6-1.8c-1.6-3.6,0.4-8.7,6.5-7.8C21.6,19.8,21.6,25.1,21.6,20.7z M40.6,16c0.5,0.1,1,0.2,1.5,0.2
c0,7.9,0,0,0,6.5c-0.7,0-5.8-0.3-9-3.2l0,12.7C33.2,38,30,43.6,24,44.8c-1.7,0.3-3.2,0.4-5.7-0.2c-2.9-0.9-5-2.4-6.4-4.2
c1.3,1.1,2.9,2,4.9,2.6c2.5,0.6,4,0.5,5.7,0.2c6-1.1,9.2-6.8,9.1-12.5l0-12.7c3.2,2.9,8.4,3.2,9,3.2C40.6,15.1,40.6,21.4,40.6,16z
M33.1,6.6L33.1,6.6c0,0.4,0.1,3.4,1.9,6c-2.2-1.8-3-4.3-3.3-6H33.1z`
            })]
        })
    }),
    $2 = {
        name: Qe.Variant1,
        color: {
            value: "#000000",
            origin: O.Custom
        },
        iconsSet: {
            [R.Facebook]: Z1,
            [R.Twitter]: vp,
            [R.YouTube]: cp,
            [R.Instagram]: op,
            [R.Pinterest]: Dp,
            [R.VKontakte]: Zp,
            [R.LinkedIn]: Ip,
            [R.TikTok]: o2
        },
        disabled: !1
    },
    R2 = {
        name: Qe.Variant2,
        color: {
            value: "#FFFFFF",
            origin: O.Custom
        },
        iconsSet: {
            [R.Facebook]: q1,
            [R.Twitter]: Cp,
            [R.YouTube]: hp,
            [R.Instagram]: rp,
            [R.Pinterest]: Np,
            [R.VKontakte]: qp,
            [R.LinkedIn]: kp,
            [R.TikTok]: r2
        },
        disabled: !1
    },
    P2 = {
        name: Qe.Variant3,
        color: {
            value: "#000000",
            origin: O.Custom
        },
        iconsSet: {
            [R.Facebook]: J1,
            [R.Twitter]: wp,
            [R.YouTube]: mp,
            [R.Instagram]: np,
            [R.Pinterest]: Up,
            [R.VKontakte]: Jp,
            [R.LinkedIn]: Tp,
            [R.TikTok]: n2
        },
        disabled: !1
    },
    F2 = {
        name: Qe.Variant4,
        color: null,
        iconsSet: {
            [R.Facebook]: Y1,
            [R.Twitter]: Bp,
            [R.YouTube]: bp,
            [R.Instagram]: ip,
            [R.Pinterest]: Vp,
            [R.VKontakte]: Yp,
            [R.LinkedIn]: Ep,
            [R.TikTok]: i2
        },
        disabled: !1
    },
    I2 = {
        name: Qe.Variant5,
        color: null,
        iconsSet: {
            [R.Facebook]: X1,
            [R.Twitter]: Sp,
            [R.YouTube]: fp,
            [R.Instagram]: ap,
            [R.Pinterest]: Hp,
            [R.VKontakte]: Xp,
            [R.LinkedIn]: Lp,
            [R.TikTok]: a2
        },
        disabled: !1
    },
    k2 = {
        name: Qe.Variant6,
        color: null,
        iconsSet: {
            [R.Facebook]: K1,
            [R.Twitter]: $p,
            [R.YouTube]: gp,
            [R.Instagram]: lp,
            [R.Pinterest]: jp,
            [R.VKontakte]: Kp,
            [R.LinkedIn]: Mp,
            [R.TikTok]: l2
        },
        disabled: !1
    },
    T2 = {
        name: Qe.Variant7,
        color: {
            value: "#CCCCCC",
            origin: O.Custom
        },
        iconsSet: {
            [R.Facebook]: Q1,
            [R.Twitter]: Rp,
            [R.YouTube]: pp,
            [R.Instagram]: sp,
            [R.Pinterest]: zp,
            [R.VKontakte]: Qp,
            [R.LinkedIn]: Op,
            [R.TikTok]: s2
        },
        disabled: !1
    },
    E2 = {
        name: Qe.Variant8,
        color: {
            value: "#FFFFFF",
            origin: O.Custom
        },
        iconsSet: {
            [R.Facebook]: ep,
            [R.Twitter]: Pp,
            [R.YouTube]: yp,
            [R.Instagram]: dp,
            [R.Pinterest]: _p,
            [R.VKontakte]: e2,
            [R.LinkedIn]: Ap,
            [R.TikTok]: d2
        },
        disabled: !1
    },
    L2 = {
        name: Qe.Variant9,
        color: {
            value: "#FFFFFF",
            origin: O.Custom
        },
        iconsSet: {
            [R.Facebook]: tp,
            [R.Twitter]: Fp,
            [R.YouTube]: xp,
            [R.Instagram]: up,
            [R.Pinterest]: Gp,
            [R.VKontakte]: t2,
            [R.LinkedIn]: Wp,
            [R.TikTok]: u2
        },
        disabled: !1
    },
    M2 = {
        [Qe.Variant1]: $2,
        [Qe.Variant2]: R2,
        [Qe.Variant3]: P2,
        [Qe.Variant4]: F2,
        [Qe.Variant5]: I2,
        [Qe.Variant6]: k2,
        [Qe.Variant7]: T2,
        [Qe.Variant8]: E2,
        [Qe.Variant9]: L2
    };
R.Facebook + "", R.Twitter + "", R.YouTube + "", R.Instagram + "", R.Pinterest + "", R.VKontakte + "", R.LinkedIn + "", R.TikTok + "";
const O2 = () => {};

function A2(...e) {
    const t = e.some(o => o === O2);
    return o => {
        if (!(t && !o))
            for (const r of e) {
                const i = r(o);
                if (i) return i
            }
    }
}

function W2({
    protocol: e = "",
    allowEmpty: t = !1
}, o) {
    return r => {
        if (!(t && !e && !r)) try {
            new URL(e + r)
        } catch {
            return o()
        }
    }
}
const D2 = /^(?=.{1,128}$)[0-9A-Za-z_\-+']([0-9A-Za-z_\-+']|\.(?=[0-9A-Za-z_\-+'])){0,122}@(?=.{1,126}$)[A-Za-z0-9]([A-Za-z0-9]|-+(?=[A-Za-z0-9])|\.(?=[A-Za-z0-9]))*\.[A-Za-z]{2,63}$/;

function N2(e) {
    return t => {
        if (!D2.test(t)) return e()
    }
}
const U2 = new RegExp(/^[+][(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}/),
    V2 = new RegExp(/\b(\(?(\+|00)?48\)?)?[ -]?\d{3}[ -]?\d{3}[ -]?\d{3}\b/);
var vs;
(function(e) {
    e.Polish = "Polish"
})(vs || (vs = {}));
const H2 = {
    [vs.Polish]: V2
};

function j2(e, t = null) {
    return o => {
        const r = o.replace(/ /g, "");
        if (!(t ? H2[t] : U2).test(r)) return e()
    }
}
const z2 = /^(?=.{8,15}$)(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/,
    _2 = /([0-9a-fA-F]{4}:){7}([0-9a-fA-F]{4})/;

function G2(e) {
    return t => {
        if (!z2.test(t) && !_2.test(t)) return e()
    }
}

function Z2(e, t, o) {
    return r => {
        if (r < e || r > t) return o({
            max: t,
            min: e
        })
    }
}

function q2(e) {
    return t => {
        if (!t ? .trim()) return e()
    }
}

function J2(e, t, o) {
    return r => {
        const i = new Date(r).getTime();
        return Z2(new Date(e).getTime(), new Date(t).getTime(), o)(i)
    }
}

function gt(e, t, o) {
    return e ? t : o || null
}
const Ku = [];

function Qu(e, t, o) {
    return e.sort((r, i) => t.indexOf(o ? o(r) : r) - t.indexOf(o ? o(i) : i))
}

function pi(e, t) {
    return e.reduce((o, r) => (o[t(r) ? 0 : 1].push(r), o), [
        [],
        []
    ])
}
var Tr;
(function(e) {
    e.Enter = "Enter", e.Escape = "Escape", e.SpaceBar = " "
})(Tr || (Tr = {}));
const ec = e => x.useCallback(o => {
    o.stopPropagation(), e && e()
}, [e]);

function Y2(e) {
    const t = f.exports.useRef();
    return f.exports.useEffect(() => {
        t.current = e
    }, [e]), t.current
}

function Er() {
    return typeof window > "u" ? void 0 : window
}

function Nh(e, t) {
    return Object.keys(e).reduce((o, r) => ({ ...o,
        [r]: t[e[r]]
    }), {})
}
var ni;
(function(e) {
    e[e.Days = 0] = "Days", e[e.Hours = 1] = "Hours", e[e.Minutes = 2] = "Minutes", e[e.Seconds = 3] = "Seconds"
})(ni || (ni = {}));
const Yl = 60,
    tc = 3600,
    oc = 86400,
    X2 = 24,
    K2 = 60;

function Q2(e, t) {
    const o = Math.floor(e / oc);
    let r = Math.floor(e % oc / tc),
        i = Math.floor(e % tc / Yl),
        n = e % Yl;
    return t.includes(ni.Days) || (r += o * X2), t.includes(ni.Hours) || (i += r * K2), t.includes(ni.Minutes) || (n += i * Yl), {
        days: o,
        hours: r,
        minutes: i,
        seconds: n
    }
}
const ey = e => {
        const t = f.exports.useMemo(() => {
                var i;
                return (i = Er()) === null || i === void 0 ? void 0 : i.matchMedia(e)
            }, [e]),
            [o, r] = f.exports.useState(t ? .matches);
        return f.exports.useEffect(() => {
            const i = () => {
                r(t ? .matches)
            };
            try {
                t ? .addEventListener("change", i)
            } catch {
                t ? .addListener(i)
            }
            return () => {
                try {
                    t ? .removeEventListener("change", i)
                } catch {
                    t ? .removeListener(i)
                }
            }
        }, [t]), o
    },
    ty = (e, t) => {
        var o;
        const r = (o = e.split(";").map(i => i.trim()).map(i => i.split("=")).find(([i]) => t === i)) === null || o === void 0 ? void 0 : o[1];
        return r ? decodeURIComponent(r) : null
    },
    oy = e => `${e}=; Max-Age=0`,
    ry = (e, t) => `${e}=${encodeURIComponent(t)}; path=/`,
    Gt = () => {},
    ze = e => `screen and (max-width: ${e}px)`;

function Uh() {
    var e;
    const t = oh();
    return ey(ze((e = t.globalDesign) === null || e === void 0 ? void 0 : e.contentWidth))
}
const Pd = (e, t) => {
        if (t === 0) {
            e();
            return
        }
        return window.setTimeout(e, t)
    },
    ny = ({
        delay: e
    }) => t => {
        function o(n) {
            return !n.relatedTarget && (n.clientY <= 0 || n.clientY >= n.screenY || n.clientX <= 0 || n.clientX >= n.screenX)
        }
        let r;
        const i = n => {
            o(n) && !r && (r = Pd(t, e))
        };
        return document.addEventListener("mouseout", i), () => {
            document.removeEventListener("mouseout", i), clearTimeout(r)
        }
    },
    iy = ({
        delay: e
    }) => t => {
        const o = Pd(t, e);
        return () => {
            clearTimeout(o)
        }
    },
    ay = ({
        minScrollPercentageWhenTriggers: e,
        scrollableElementSelector: t,
        delay: o
    }) => r => {
        const i = document.querySelector(t);
        if (!i) throw new Error("Scrollable element container cannot be found");
        const n = document.createElement("div");
        n.id = "on-scroll-indicator-element", n.style.position = "absolute", n.style.top = `${e}%`, i.appendChild(n);
        let l;
        const s = new IntersectionObserver(u => {
            u.forEach(c => {
                c.isIntersecting && !l && (l = Pd(r, o))
            })
        });
        return s.observe(n), () => {
            s.unobserve(n), n.remove(), clearTimeout(l)
        }
    },
    ly = {
        OnLanding: iy,
        OnExit: ny,
        OnScroll: ay
    },
    sy = e => {
        x.useEffect(() => {
            if (e.disabled) return;
            const t = ly[e.trigger];
            return t({
                delay: e.delay,
                scrollableElementSelector: e.scrollableElementSelector,
                minScrollPercentageWhenTriggers: e.minScrollPercentageWhenTriggers
            })(e.onTrigger)
        }, [e.delay, e.trigger, e.onTrigger, e.minScrollPercentageWhenTriggers, e.scrollableElementSelector, e.disabled])
    };
let Xl = !1;
const Vh = {
        setValue: Gt,
        clearValue: Gt,
        getValue: () => !1
    },
    dy = e => {
        const t = `${e.elementId}-frequency`;
        switch (e.frequency) {
            case Zo.Custom:
                return {
                    getValue() {
                        const r = ty(document.cookie, t);
                        return (r ? parseInt(r) - Date.now() : 0) > 0
                    },
                    setValue() {
                        const r = vh([e.customFrequencyValue, e.customFrequencyUnit]);
                        document.cookie = ry(t, r + Date.now())
                    },
                    clearValue() {
                        document.cookie = oy(t)
                    }
                };
            case Zo.EverySession:
                return {
                    getValue() {
                        return sessionStorage.getItem(t) !== null
                    },
                    setValue() {
                        sessionStorage.setItem(t, "")
                    },
                    clearValue() {
                        sessionStorage.removeItem(t)
                    }
                };
            case Zo.EveryPageLoad:
                return {
                    getValue() {
                        return Xl
                    },
                    setValue() {
                        Xl = !0
                    },
                    clearValue() {
                        Xl = !1
                    }
                };
            case Zo.EveryTime:
                return Vh
        }
    };

function uy({
    customFrequencyUnit: e,
    customFrequencyValue: t,
    elementId: o,
    frequency: r,
    disabled: i
}) {
    const n = f.exports.useMemo(() => i ? Vh : dy({
        customFrequencyUnit: e,
        customFrequencyValue: t,
        elementId: o,
        frequency: r
    }), [e, t, i, o, r]);
    return {
        isDisabled: x.useCallback(() => {
            const s = n.getValue();
            return s || n.setValue(), s
        }, [n])
    }
}
const Hh = x.createContext(null),
    jh = x.createContext(null),
    zh = f.exports.createContext(null);

function cy(e) {
    return new Promise(t => {
        const o = new Image;
        o.onload = () => t(!0), o.onerror = () => t(!1), o.src = e
    })
}

function hy() {
    return cy("data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA=")
}
const my = ({
    initialState: e,
    children: t
}) => {
    const [o, r] = f.exports.useState(() => ({
        isWebPSupported: !0,
        ...e
    }));
    return f.exports.useEffect(() => {
        Promise.all([hy()]).then(([i]) => {
            r(n => {
                const l = { ...n,
                    isWebPSupported: i
                };
                return Object.entries(l).some(([s, u]) => u !== n[s]) ? l : n
            })
        })
    }, []), a(zh.Provider, {
        value: o,
        children: t
    })
};

function by() {
    const e = f.exports.useContext(zh);
    if (e) return e;
    throw new Error("Missing BrowserFeaturesContext Provider")
}
class fy {
    constructor(t) {
        Object.defineProperty(this, "internalPages", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.internalPages = t
    }
    render(t) {
        return this.isPage(t) ? this.renderPage(t) : this.renderHyperlink(t)
    }
    isPage(t) {
        return t ? .status !== void 0 && t ? .parentId !== void 0
    }
    isExternalPage(t) {
        return t ? .type === we.External
    }
    renderPage(t) {
        return this.isExternalPage(t) ? this.renderHyperlink({ ...t.hyperlink,
            href: t.url
        }) : this.renderInternalPage(t)
    }
    renderInternalPage(t, o = "") {
        const r = t.isHomepage ? "/" : t.url;
        return this.getUrlByHyperlinkType(r + o, k.Web)
    }
    getUrlByHyperlinkType(t, o) {
        return o === k.Email ? t.startsWith(jr.Email) ? t : `${jr.Email}${t}` : o === k.Phone ? t.startsWith(jr.Phone) ? t : `${jr.Phone}${t}` : t
    }
    renderHyperlink(t) {
        var o;
        switch (t.type) {
            case k.Internal:
                return this.generateInternalUrl(t);
            case k.Anchor:
                return this.generateAnchorUrl(t);
            case k.SpecialPage:
                return this.generateSpecialPageUrl(t);
            default:
                return this.getUrlByHyperlinkType((o = t.href) !== null && o !== void 0 ? o : "", t.type)
        }
    }
    generateSpecialPageUrl({
        pageType: t,
        href: o
    }) {
        const r = this.internalPages.find(i => i.type === t);
        return r ? `${r.url}${o}` : "INVALID_PAGE"
    }
    generateInternalUrl({
        pageUuid: t
    }) {
        const o = t ? this.internalPages.find(r => r.uuid === t) : this.internalPages.find(r => r.isHomepage);
        return o ? this.renderInternalPage(o) : "INVALID_PAGE"
    }
    generateAnchorUrl({
        pageUuid: t,
        sectionId: o
    }) {
        const r = t ? this.internalPages.find(i => i.uuid === t) : this.internalPages.find(i => i.isHomepage);
        return r ? this.renderInternalPage(r, `#${o}`) : "INVALID_PAGE"
    }
}
const _h = x.createContext(null);

function hl() {
    const e = f.exports.useContext(_h);
    if (e === null) throw new Error("Missing HyperlinkResolverContext");
    return e
}

function Gh(e) {
    const t = e.theming[De.Palette],
        o = t.availablePalettes.find(r => r.uuid === t.selectedPaletteUUID);
    if (o === void 0) throw new Error(`Unknown selectedPaletteId: ${t.selectedPaletteUUID}`);
    return o
}
const Zh = "withToMaxWidthRatioIndicator",
    Fd = "topHeaderFontSize",
    Id = "headerFontSize",
    kd = "subheaderFontSize",
    Td = "paragraphFontSize",
    qh = "verticalSpacingRatio",
    Jh = "horizontalSpacingRatio";

function gy(e) {
    var t;
    const o = Gh(e).colors.reduce((r, i) => (r[i.name] = i.value, r), {});
    return {
        globalDesign: {
            contentWidth: (t = e.theming[De.Body].contentWidth) !== null && t !== void 0 ? t : e.theming[De.Body].defaultContentWidth,
            isFullWidth: e.kind === gs.Form,
            withToMaxWidthRatioIndicator: `var(--${Zh}, 1)`,
            colors: {
                background: o[D.One],
                text: o[D.Two],
                buttonBackground: o[D.Three],
                specialOne: o[D.Four],
                specialTwo: o[D.Five]
            },
            mobile: {
                topHeaderFontSize: `var(--${Fd}, ${Hr.TopHeader})`,
                headerFontSize: `var(--${Id}, ${Hr.Header})`,
                subheaderFontSize: `var(--${kd}, ${Hr.Subheader})`,
                paragraphFontSize: `var(--${Td}, ${Hr.Paragraph})`,
                verticalSpacingRatio: `var(--${qh}, 1)`,
                horizontalSpacingRatio: `var(--${Jh}, 1)`
            }
        }
    }
}
const Yh = x.createContext(!0);

function Fi() {
    return f.exports.useContext(Yh)
}
const py = Yh.Provider,
    Xh = x.createContext(!0);

function yy() {
    return x.useContext(Xh)
}
const Kh = x.createContext(!1);

function xy(e, t) {
    return f.exports.useContext(Kh) && e ? t ? `${e} ${t}` : e : t ? ? void 0
}

function vy(e) {
    var t, o, r;
    const i = f.exports.useMemo(() => Gh(e.content).colors.map(u => u.value), [e.content]),
        n = f.exports.useMemo(() => new fy(e.content.pages), [e.content.pages]),
        l = f.exports.useMemo(() => gy(e.content), [e.content]),
        s = (t = e.content.theming[De.Typography].custom) !== null && t !== void 0 ? t : e.content.theming[De.Typography].predefined;
    return a(Kh.Provider, {
        value: e.hasClassesAndIds,
        children: a(j0, {
            theme: l,
            children: a(Hh.Provider, {
                value: i,
                children: a(jh.Provider, {
                    value: s,
                    children: a(_h.Provider, {
                        value: n,
                        children: a(my, {
                            initialState: e.browserFeatures,
                            children: a(py, {
                                value: (o = e.isLazyLoadingEnabled) !== null && o !== void 0 ? o : !0,
                                children: a(Xh.Provider, {
                                    value: (r = e.isDynamicContentRunning) !== null && r !== void 0 ? r : !0,
                                    children: e.children
                                })
                            })
                        })
                    })
                })
            })
        })
    })
}

function Ed() {
    const e = f.exports.useContext(jh);
    if (e === null) throw new Error("Missing TypographyContext");
    return e
}

function Cy(e, t) {
    const {
        isWebPSupported: o
    } = by();
    return f.exports.useMemo(() => {
        if (e && o) {
            const r = t ? .find(i => i.type === di.WebP);
            if (r) return r.src
        }
        return e ? ? void 0
    }, [e, t, o])
}

function wy(e) {
    return e.$isBoxShadowEnabled ? P `box-shadow: ${e.$boxShadowOffsetX}
         ${e.$boxShadowOffsetY}
         ${e.$boxShadowBlurRadius}
         ${e.$boxShadowSpreadRadius}
         ${e.$boxShadowColor};` : ""
}

function By(e) {
    return e.$isBoxBorderEnabled ? P `border-top-width: ${e.$boxBorderWidthTop};
        border-left-width: ${e.$boxBorderWidthLeft};
        border-right-width: ${e.$boxBorderWidthRight};
        border-bottom-width: ${e.$boxBorderWidthBottom};

        border-top-color: ${e.$boxBorderColorTop};
        border-left-color: ${e.$boxBorderColorLeft};
        border-right-color: ${e.$boxBorderColorRight};
        border-bottom-color: ${e.$boxBorderColorBottom};

        border-top-style: ${e.$boxBorderStyleTop};
        border-left-style: ${e.$boxBorderStyleLeft};
        border-right-style: ${e.$boxBorderStyleRight};
        border-bottom-style: ${e.$boxBorderStyleBottom};` : ""
}

function Sy(e) {
    return e.$isBoxPaddingEnabled ? P `
        padding-top: ${e.$boxPaddingTop};
        padding-left: ${e.$boxPaddingLeft};
        padding-right: ${e.$boxPaddingRight};
        padding-bottom: ${e.$boxPaddingBottom};` : ""
}

function Qi(e, t, o) {
    return `calc(min(${e}, max(10px, ${e} * ${t})) * ${o})`
}

function Ii({
    $isBoxPaddingEnabled: e,
    $boxPaddingLeft: t,
    $boxPaddingRight: o,
    $boxPaddingTop: r,
    $boxPaddingBottom: i,
    theme: n
}) {
    if (e) {
        const {
            withToMaxWidthRatioIndicator: l,
            mobile: {
                horizontalSpacingRatio: s,
                verticalSpacingRatio: u
            }
        } = n.globalDesign;
        return `@media ${ze(n.globalDesign.contentWidth)} {
            padding-left: ${Qi(t,l,s)};
            padding-right: ${Qi(o,l,s)};
            padding-top: ${Qi(r,l,u)};
            padding-bottom: ${Qi(i,l,u)};
        }`
    }
    return ""
}

function $y(e) {
    return e.$isBoxRadiusEnabled ? P `
        border-radius: ${e.$boxBorderRadiusTopLeft}
            ${e.$boxBorderRadiusTopRight}
            ${e.$boxBorderRadiusBottomRight}
            ${e.$boxBorderRadiusBottomLeft};` : ""
}

function Ry(e) {
    return P `background: ${e.$boxBackgroundColor};`
}

function Ro(e) {
    return P `
        ${Ry(e)}
        ${$y(e)}
        ${Sy(e)}
        ${By(e)}
        ${wy(e)}
        ${Ii}
`
}

function Ae(e, t) {
    return {
        [`data-ats-${e}`]: t
    }
}

function Pt(e) {
    return Ae("wb-element", e)
}

function ea({
    $iconsSize: e,
    $customIconsSize: t
}) {
    switch (e) {
        case Yt.Small:
            return Br.Small;
        case Yt.Medium:
            return Br.Medium;
        case Yt.Large:
            return Br.Large;
        case Yt.Custom:
            return t;
        default:
            return Br.Medium
    }
}
const Qh = v(({
    $iconsSize: e,
    $customIconsSize: t,
    $color: o,
    ...r
}) => a("div", { ...r
})).attrs(Ae("social-media", "icon"))
`
    display: inline-block;

    svg {
        color: ${({$color:e})=>e};
    }

    svg,
    img {
        width: ${ea}px;
        height: ${ea}px;
        min-width: ${ea}px;
        min-height: ${ea}px;
    }
`, Ld = 10, em = 10, tm = em + Ld, rc = tm + Ld, Qo = {
    Element: em,
    HeaderSticky: tm,
    Navbar: rc,
    GalleryModal: rc + Ld
}, Py = e => [Vo.Absolute, Vo.Fixed].includes(e ? .type), Fy = (e, t = Qo.Element) => {
    var o, r, i, n, l, s, u;
    return e && Py(e) ? {
        position: e.type,
        left: (o = e.left) !== null && o !== void 0 ? o : void 0,
        right: (r = e.right) !== null && r !== void 0 ? r : void 0,
        top: (i = e.top) !== null && i !== void 0 ? i : void 0,
        bottom: (n = e.bottom) !== null && n !== void 0 ? n : void 0,
        width: (l = e.width) !== null && l !== void 0 ? l : void 0,
        zIndex: ((s = e.zIndex) !== null && s !== void 0 ? s : 0) + (t ? ? 0) || void 0
    } : e ? .isContainer ? {
        position: (u = e.type) !== null && u !== void 0 ? u : Vo.Relative
    } : {}
}, Dt = ({
    $position: e,
    theme: t
}) => e ? P `
            @media (min-width: ${t.globalDesign.contentWidth}px) {
                ${Fy(e)}
                height: auto;
            }
        ` : "", nc = (e, t) => typeof t == "number" ? `${t}px` : typeof t == "string" ? t : null;

function ve(e = []) {
    return t => {
        const o = {},
            {
                className: r,
                ...i
            } = t;
        return { ...Object.entries(i).reduce((l, [s, u]) => {
                if (!s.startsWith("$") || s === "$$props") return l;
                o[s] = u;
                let c;
                if (typeof e == "function" ? c = e(s, u, nc) : e.includes(s) ? c = null : c = nc(s, u), c === null) return l;
                if (t.$inlineMode) {
                    const h = s.slice(1);
                    return { ...l,
                        style: { ...l ? .style,
                            [`--${h}`] : c
                        },
                        [s]: `var(--${h})`
                    }
                }
                return { ...l,
                    [s]: c
                }
            }, i),
            $$props: o
        }
    }
}

function Iy(e, t) {
    const o = f.exports.forwardRef(({
        passedProps: r,
        ...i
    }, n) => {
        const l = t({ ...r,
            ...i
        });
        return a(e, { ...i,
            ...r,
            ...l,
            ref: n
        })
    });
    return v(o).attrs(r => ({ ...r,
        passedProps: r
    }))
}

function dt(e) {
    return Iy(e, ({
        globalClassName: o,
        className: r
    }) => ({
        className: xy(o, r)
    }))
    ``
}

function ky(e) {
    switch (e) {
        case W.Right:
            return P `
                flex-direction: row;
                justify-content: flex-end;
            `;
        case W.Left:
            return P `
                flex-direction: row;
                justify-content: flex-start;
            `;
        case W.Center:
        default:
            return P `
                flex-direction: row;
                justify-content: center;
            `
    }
}

function Ty(e) {
    switch (e) {
        case W.Right:
            return P `
                flex-direction: column;
                align-items: flex-end;
            `;
        case W.Left:
            return P `
                flex-direction: column;
                align-items: flex-start;
            `;
        case W.Center:
        default:
            return P `
                flex-direction: column;
                align-items: center;
            `
    }
}

function Ey(e) {
    const {
        $direction: t,
        $align: o
    } = e;
    switch (t) {
        case pt.Row:
            return ky(o);
        case pt.Column:
            return Ty(o);
        default:
            return P `
                flex-direction: row;
                justify-content: center;
            `
    }
}

function Ly(e) {
    const {
        $direction: t,
        $spacing: o
    } = e;
    switch (t) {
        case pt.Column:
            return P `padding: ${o} 0;`;
        case pt.Row:
        default:
            return P `padding: 0 ${o};`
    }
}
const My = v.div.attrs(ve(["$direction", "$align"])).attrs(Pt("social-media"))
`

  display: flex;
  flex-wrap: wrap;
  ${Ro};
  ${Ey};

  ${Dt}
  ${Ii}
  ${Qh} {
    display: inline-flex;
    align-items: center;
    ${Ly};
  }
`, Oy = dt(My), yr = v.span `
    padding-left: 5px;
    word-break: break-all;
    word-wrap: break-word;
`, om = x.createContext(null);

function Md() {
    return x.useContext(om)
}
const rm = Object.values(k).filter(e => typeof e == "number"),
    nm = Object.values(Ce),
    Ay = {
        allowedHyperlinkTypes: rm,
        allowedTargets: nm
    },
    im = f.exports.createContext(Ay);

function Wy() {
    return f.exports.useContext(im)
}
const am = f.exports.createContext(null);

function Dn() {
    return f.exports.useContext(am)
}
const lm = x.createContext(null);
lm.Provider;

function Dy() {
    return f.exports.useContext(lm)
}
const $o = e => {
    var t;
    const {
        hyperlink: o,
        className: r,
        children: i = null,
        emptyContainer: n = null,
        isClickable: l = !0,
        onClick: s,
        description: u,
        ...c
    } = e, h = Md(), m = Dy(), {
        allowedHyperlinkTypes: g,
        allowedTargets: p
    } = Wy(), b = hl(), {
        id: C,
        href: w,
        target: B,
        type: S
    } = o ? ? j.createDefaultHyperlink(), $ = S === k.Web || S === k.Protocol, L = g.includes(S) && p.includes(B), M = Dn(), F = o ? b.render(o) : void 0, A = f.exports.useCallback(z => {
        if (o && m ? .handleClick(o), s) {
            s(z);
            return
        }
        if (!o) return;
        if (j.isActionHyperlink(o) && z.preventDefault(), (j.isInternalHyperlink(o) || j.isAnchorHyperlink(o) || j.isSpecialPageHyperlink(o)) && o.target === Ce.Self) {
            if (z.preventDefault(), M === null) throw new Error("Missing SpaNavigationService");
            M.navigate(F)
        }
    }, [m, o, s, F, M]);
    return x.useEffect(() => (w && l && h ? .register(C, { ...o,
        description: u
    }), () => {
        h ? .unregister(C)
    }), [u, w, o, h, C, l]), w && l && L ? a("a", {
        href: F,
        "data-hyperlink-id": C,
        target: B,
        className: r,
        rel: $ ? "noreferrer nofollow noopener" : void 0,
        download: j.isDocumentHyperlink(o) ? o.fileName : null,
        onClick: A,
        ...Ae("hyperlink", "anchor"),
        ...c,
        children: i
    }) : n ? x.cloneElement(n, {
        className: r,
        ...n.props,
        ...c
    }, i) : a("a", {
        className: r,
        style: (t = e.style) !== null && t !== void 0 ? t : {},
        children: i
    })
};
class Xn {
    constructor(t, o, r) {
        Object.defineProperty(this, "id", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "type", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        }), Object.defineProperty(this, "mobileFontSize", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }), Object.defineProperty(this, "tagName", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "className", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "selector", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        });
        const i = fs.find(n => n.id === t);
        if (!i) throw new Error("Not found TextBlockType");
        this.tagName = i.tagName, this.className = i.className, this.selector = this.className ? `${this.tagName}.${this.className}` : this.tagName
    }
}
const Mo = {
        [q.TopHeader]: new Xn(q.TopHeader, Ve.TopHeader, `var(--${Fd})`),
        [q.Header]: new Xn(q.Header, Ve.Header, `var(--${Id})`),
        [q.Subheader]: new Xn(q.Subheader, Ve.Subheader, `var(--${kd})`),
        [q.Paragraph]: new Xn(q.Paragraph, Ve.Paragraph, `var(--${Td})`),
        [q.Disclaimer]: new Xn(q.Disclaimer, Ve.Meta, 14)
    },
    sm = Object.values(Mo);

function Ny(e) {
    let t;
    if (typeof e == "string" || typeof e == "number") t = Kl(e);
    else if ("$fontSize" in e) {
        if (!e.$fontSize) return;
        t = Kl(e.$fontSize)
    } else {
        if (!e.fontSize) return;
        t = Kl(e.fontSize)
    }
    return `font-size: min(20vw,${t});`
}

function Kl(e) {
    return typeof e == "string" ? e : `${e}px`
}

function Uy(e) {
    return {
        "background-image": e,
        color: "transparent",
        "background-clip": "text",
        "-webkit-background-clip": "text",
        "text-fill-color": "transparent",
        "-webkit-text-fill-color": "transparent",
        "caret-color": "#000",
        "text-decoration-color": "#000"
    }
}

function Lr(e) {
    if (dm(e)) {
        const t = Vy(e);
        if (t !== null) return Uy(`linear-gradient(90deg, ${t.join(",")})`)
    }
    return {
        color: e
    }
}

function Vy(e) {
    const t = e.match(/linear-gradient\((.*)\)/i);
    return t ? t[1].split(",").map(r => r.trim()).filter(r => !r.endsWith("deg")) : null
}

function dm(e) {
    return e.startsWith("linear-gradient")
}

function um(e) {
    var t, o;
    return P `
      font-family: ${e.$fontFamily};
      ${Lr((o=(t=e.$$props)===null||t===void 0?void 0:t.$textColor)!==null&&o!==void 0?o:e.$textColor)}
      ${Ny(e.$fontSize)}
    `
}

function cm(e) {
    return P `
      font-weight: ${e.$isBold?"bold":"normal"};
      font-style: ${e.$isItalic?"italic":"normal"};
      text-decoration: ${e.$isUnderline?"underline":"none"};
    `
}

function uo(e) {
    return P `
      ${cm(e)}
      ${um(e)}
    `
}

function Hy(e) {
    var t, o;
    return e.$isHoverBold === null ? "" : P `
      font-weight: ${e.$isHoverBold?"bold":"normal"};
      font-style: ${e.$isHoverItalic?"italic":"normal"};
      text-decoration: ${e.$isHoverUnderline?"underline":"none"};
      ${Lr((o=(t=e.$$props)===null||t===void 0?void 0:t.$hoverTextColor)!==null&&o!==void 0?o:e.$hoverTextColor)}
    `
}

function hm(e) {
    const t = Hy(e);
    return t ? P `&:hover {
      ${t}
    }` : ""
}
const jy = e => `calc(${e} * 1px)`;

function Od(e) {
    return P `
      font-size: ${jy(e)};
    `
}

function ml() {
    return Od(Mo[q.Paragraph].mobileFontSize)
}
const fe = 3,
    mm = v(e => {
        const {
            $cursor: t,
            $labelColor: o,
            $fontFamily: r,
            $fontSize: i,
            $isBold: n,
            $isItalic: l,
            $isUnderline: s,
            ...u
        } = e;
        return a($o, { ...u
        })
    }).attrs(Ae("social-media", "anchor"))
`
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: ${({$cursor:e})=>e};

    &:focus-visible {
      outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }

    &,
    :hover,
    :visited,
    :active,
    ${yr}:hover,
    ${yr}:visited,
    ${yr}:active {
        ${({$labelColor:e,...t})=>uo({$textColor:e,...t})};
    }

    ${({theme:e})=>P`
@media $ {
    ze(e.globalDesign.contentWidth)
} { &
    ,: hover,: visited,: active,
    $ {
        yr
    }: hover,
    $ {
        yr
    }: visited,
    $ {
        yr
    }: active {
        $ {
            ml
        }
    }
}
`}
`;
mm.defaultProps = {
    $cursor: "pointer"
};

function Po(e) {
    return e.$isShadowEnabled ? P `box-shadow:
            ${e.$shadowOffsetX} ${e.$shadowOffsetY}
            ${e.$shadowBlurRadius} ${e.$shadowSpreadRadius}
            ${e.$shadowColor};
    ` : ""
}

function co(e) {
    return e.$isBorderEnabled ? P `border-top-width: ${e.$borderWidthTop};
      border-left-width: ${e.$borderWidthLeft};
      border-right-width: ${e.$borderWidthRight};
      border-bottom-width: ${e.$borderWidthBottom};

      border-top-color: ${e.$borderColorTop};
      border-left-color: ${e.$borderColorLeft};
      border-right-color: ${e.$borderColorRight};
      border-bottom-color: ${e.$borderColorBottom};

      border-top-style: ${e.$borderStyleTop};
      border-left-style: ${e.$borderStyleLeft};
      border-right-style: ${e.$borderStyleRight};
      border-bottom-style: ${e.$borderStyleBottom};` : ""
}

function ki(e) {
    return typeof e.$isPaddingEnabled == "boolean" && !e.$isPaddingEnabled ? "" : {
        paddingTop: e.$paddingTop,
        paddingLeft: e.$paddingLeft,
        paddingRight: e.$paddingRight,
        paddingBottom: e.$paddingBottom
    }
}

function Ct(e) {
    return e.$isRadiusEnabled ? P `
          border-radius:
                  ${e.$borderRadiusTopLeft} ${e.$borderRadiusTopRight}
                  ${e.$borderRadiusBottomRight} ${e.$borderRadiusBottomLeft};
        ` : ""
}

function Ad(e) {
    const {
        $borderRadiusTopLeft: t,
        $borderRadiusTopRight: o,
        $borderRadiusBottomRight: r,
        $borderRadiusBottomLeft: i,
        $borderWidthTop: n,
        $borderWidthLeft: l,
        $borderWidthRight: s,
        $borderWidthBottom: u,
        $isBorderEnabled: c,
        $isRadiusEnabled: h
    } = e;
    if (!c) return Ct({
        $borderRadiusTopLeft: t,
        $borderRadiusTopRight: o,
        $borderRadiusBottomRight: r,
        $borderRadiusBottomLeft: i,
        $isRadiusEnabled: h
    });
    if (h) {
        const g = t - (n > l ? n : l),
            p = o - (n > s ? n : s),
            b = r - (u > s ? u : s),
            C = i - (u > l ? u : l);
        return P `border-radius:
                ${Math.max(g,0)}px ${Math.max(p,0)}px
                ${Math.max(b,0)}px ${Math.max(C,0)}px;
        `
    }
    return ""
}

function bm(e) {
    return Math.min(e / 100, 1)
}

function fm(e) {
    return P `
        ${Po(e)}
        ${co(e)}
        ${ki(e)}
        ${Ct(e)}
    `
}

function Qn(e, t) {
    const o = e[t],
        {
            fontSize: r
        } = o;
    return P `
        ${o.fontFamily&&`--font-family: ${o.fontFamily}`};
        ${r&&`--font-size: ${r}px`};
        --font-weight: ${o.isBold?"bold":"normal"};
        --font-style: ${o.isItalic?"italic":"normal"};
        --text-decoration: ${o.isUnderline?"underline":"none"};
    `
}

function gm() {
    return P `
        font-size: var(--font-size);
        font-family: var(--font-family);
        text-decoration: var(--text-decoration);
        font-style: var(--font-style);
        font-weight: var(--font-weight);
    `
}
const zy = v.form.attrs(ve()).attrs(Ae("enter-password", "form"))
`
    padding: 10px;
    align-items: center;
    display: flex;
    justify-content: center;

    ${e=>Qn(e.typography,Ve.Paragraph)}
    ${gm}
    &, * {
        ${e=>e.$isInteractionEnabled?"":"user-select: none;cursor: default;"}
    }

    .content-wrapper {
        display: inline-flex;
        flex-wrap: wrap;
        max-width: 450px;
        width: 100%;
        justify-content: center;
    }

    .field-wrapper {
        display: flex;
        justify-content: start;
        align-items: center;
        flex-wrap: wrap;
        max-width: 300px;
    }

    .label-container {
        display: flex;
        margin: 5px 10px;
        width: 100%;
        color: ${({theme:e})=>e.globalDesign.colors.text};
    }
    
    .button-wrapper {
        display: inline-flex;
        justify-content: center;
        flex-wrap: wrap;
        align-self: flex-end;
        margin: 20px 0 5px;
        max-width: 300px;
    }

    .submit-button {
        font-family: ${({$fontFamily:e})=>e};
        font-size: ${({$fontSize:e})=>e};
        line-height: 1;
        font-weight: ${({$isBold:e})=>e?"bold":"normal"};
        font-style: ${({$isItalic:e})=>e?"italic":"normal"};
        text-decoration: ${({$isUnderline:e})=>e?"underline":"none"};
        text-align: center;
        display: flex;
        align-self: center;
        max-width: 100%;
        vertical-align: middle;
        outline: none;
        cursor: ${e=>e.$isInteractionEnabled?"pointer":"default"};
        color: ${({$textColor:e})=>e};
        background: ${({$backgroundColor:e})=>e};
        position: relative;
        ${co};
        ${Ct};
        ${Po};
        ${ki};
    }
  
    button:focus-visible {
      outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }

    .submit-button:hover {
        background: ${({$backgroundColorHover:e,$isInteractionEnabled:t})=>t?e:""};
        color: ${({$textColorHover:e,$isInteractionEnabled:t})=>t?e:""};
    }


    .submit-button.processing::after {
        animation: dotAnimation 1s infinite linear;
        position: absolute;
        right: 5px;
        content: "   ";
        white-space: pre;
    }

    @keyframes dotAnimation {
        0% {
            content: "   ";
        }
        33% {
            content: ".  ";
        }
        66% {
            content: ".. ";
        }
        100% {
            content: "...";
        }
    }
    .submit-button.processing {
        opacity: .6;
    }
`, _y = dt(zy), ta = 5, Ql = 3, Gy = v.div.attrs(Ae("canvas", "input-container"))
`
  position: relative;
  width: 100%;
  max-width: 300px;
  display: flex;
  margin: ${({$shouldShowHHorizontalMargin:e})=>e?"5px 10px":"5px 0"};

  .input-wrapper {
    border: 1px solid ${({$hasError:e,$borderColor:t})=>e?"#ff0000":`
$ {
    t
}
`};
    border-radius: ${ta}px;
    background-color: var(--${D.One});
    color: var(--ColorTwo);
    z-index: 1;
    width: 100%;
    transition: border 0.2s;
  }

  input {
    padding: 12px 5px;
    border: none;
    border-radius: ${ta}px;
    outline: none;
    background: transparent;
    height: 100%;
    width: 100%;
    flex: 1;
    color: ${({$borderColor:e})=>e};
  }

  input:-webkit-autofill, input:-webkit-autofill:focus {
    -webkit-text-fill-color: ${({$borderColor:e})=>e};
  }

  input:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }

  .error-message {
    position: absolute;
    top: calc(100% - ${ta}px);
    background-color: #FF0000;
    color: #FFFFFF;
    padding: ${ta+Ql}px ${Ql}px ${Ql}px;
    border-radius: 4px;
    font-size: 13px;
    opacity: 1;
    transition: opacity 0.2s;
  }
`;

function Wd(e) {
    e.preventDefault()
}
const Zy = `var(--${D.Two})`,
    yi = e => {
        const {
            onChange: t,
            error: o = null,
            onFocus: r,
            shouldShowHHorizontalMargin: i = !0,
            autocomplete: n,
            color: l = Zy,
            globalError: s
        } = e, u = x.useCallback(c => {
            t(c.target.value)
        }, [t]);
        return y(Gy, {
            $hasError: !!o || s,
            $shouldShowHHorizontalMargin: i,
            $borderColor: l,
            children: [gt(!!o, a("div", {
                className: "error-message",
                children: o
            })), a("div", {
                className: "input-wrapper",
                children: a("input", {
                    type: e.type,
                    onMouseDown: e.isInteractionEnabled ? void 0 : Wd,
                    value: e.value,
                    onChange: u,
                    onFocus: r,
                    autoComplete: n,
                    ...Ae("canvas", "input")
                })
            })]
        })
    },
    qy = e => {
        const [t, o] = x.useState(""), [r, i] = x.useState(!1), {
            onSubmit: n,
            onClick: l,
            typography: s,
            button: u,
            error: c,
            onPasswordFieldFocus: h,
            isActive: m,
            dataAttrs: g
        } = e, p = x.useCallback(async b => {
            i(!0), await n(t, b), i(!1)
        }, [n, t]);
        return a(_y, {
            globalClassName: I.EnterPasswordForm,
            $inlineMode: m,
            onSubmit: p,
            onClick: l,
            $isInteractionEnabled: e.isInteractionEnabled,
            className: e.className,
            typography: s,
            $backgroundColor: u.backgroundColor,
            $backgroundColorHover: u.backgroundColorHover,
            $borderColorBottom: u.borderColorBottom,
            $borderColorLeft: u.borderColorLeft,
            $borderColorRight: u.borderColorRight,
            $borderColorTop: u.borderColorTop,
            $borderRadiusBottomLeft: u.borderRadiusBottomLeft,
            $borderRadiusBottomRight: u.borderRadiusBottomRight,
            $borderRadiusTopLeft: u.borderRadiusTopLeft,
            $borderRadiusTopRight: u.borderRadiusTopRight,
            $borderStyleBottom: u.borderStyleBottom,
            $borderStyleLeft: u.borderStyleLeft,
            $borderStyleRight: u.borderStyleRight,
            $borderStyleTop: u.borderStyleTop,
            $borderWidthBottom: u.borderWidthBottom,
            $borderWidthLeft: u.borderWidthLeft,
            $borderWidthRight: u.borderWidthRight,
            $borderWidthTop: u.borderWidthTop,
            $fontFamily: u.fontFamily,
            $fontSize: u.fontSize,
            $isBold: u.isBold,
            $isBorderEnabled: u.isBorderEnabled,
            $isItalic: u.isItalic,
            $isRadiusEnabled: u.isRadiusEnabled,
            $isRadiusLocked: u.isRadiusLocked,
            $isShadowEnabled: u.isShadowEnabled,
            $isUnderline: u.isUnderline,
            $paddingBottom: u.paddingBottom,
            $paddingLeft: u.paddingLeft,
            $paddingRight: u.paddingRight,
            $paddingTop: u.paddingTop,
            $shadowBlurRadius: u.shadowBlurRadius,
            $shadowColor: u.shadowColor,
            $shadowOffsetX: u.shadowOffsetX,
            $shadowOffsetY: u.shadowOffsetY,
            $shadowOpacity: u.shadowOpacity,
            $shadowSpreadRadius: u.shadowSpreadRadius,
            $textColor: u.textColor,
            $textColorHover: u.textColorHover,
            ...g,
            children: y("div", {
                className: "content-wrapper",
                children: [y("div", {
                    className: "field-wrapper",
                    children: [a("div", {
                        className: "label-container",
                        children: e.labelContent
                    }), a(yi, {
                        isInteractionEnabled: e.isInteractionEnabled,
                        value: t,
                        onChange: o,
                        type: "password",
                        error: c,
                        onFocus: h
                    })]
                }), a("div", {
                    className: "button-wrapper",
                    children: a("button", {
                        type: "submit",
                        className: `submit-button ${r?"processing":""}`,
                        children: a("span", {
                            children: e.buttonContent
                        })
                    })
                })]
            })
        })
    },
    Jy = P `
    *,
    *::before,
    *::after {
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
    }
    /* http://meyerweb.com/eric/tools/css/reset/
       v2.0 | 20110126
       License: none (public domain)
    */
    html, body, div, span, applet, object, iframe,
    h1, h2, h3, h4, h5, h6, p, blockquote, pre,
    a, abbr, acronym, address, big, cite, code,
    del, dfn, img, ins, kbd, q, s, samp,
    small, tt, var, center,
    dl, dt, dd, ol, ul, li,
    fieldset, form, label, legend,
    table, caption, tbody, tfoot, thead, tr, th, td,
    article, aside, canvas, details, embed,
    figure, figcaption, footer, header, hgroup,
    menu, nav, output, ruby, section, summary,
    time, mark, audio, video {
        margin: 0;
        padding: 0;
        border: 0;
        font-size: 100%;
        font: inherit;
        vertical-align: baseline;
    }
    /* HTML5 display-role reset for older browsers */
    article, aside, details, figcaption, figure,
    footer, header, hgroup, menu, nav, section {
        display: block;
    }
    body {
        line-height: 1;
    }
    ol, ul {
        list-style: none;
    }
    blockquote, q {
        quotes: none;
    }
    blockquote:before, blockquote:after,
    q:before, q:after {
        content: '';
        content: none;
    }
    table {
        border-collapse: collapse;
        border-spacing: 0;
    }
    button {
        border: none;
        background: none;
        padding: 0;
        margin: 0;
    }
    :focus {
        outline: none;
    }
`,
    Yy = v.div `
  input {
    margin-left: 0;
  }

  input:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
`,
    Xy = e => {
        const {
            onChange: t,
            isChecked: o
        } = e, r = x.useCallback(() => {
            t(!o)
        }, [t, o]);
        return a(Yy, {
            children: y("label", {
                className: e.labelClassName,
                children: [a("input", {
                    type: "checkbox",
                    readOnly: !e.isInteractionEnabled,
                    id: e.id,
                    checked: e.isChecked,
                    onClick: e.isInteractionEnabled ? void 0 : Wd,
                    onChange: e.isInteractionEnabled ? r : void 0,
                    ...Ae("canvas", "checkbox")
                }), e.label]
            })
        })
    };
var er;
(function(e) {
    e[e.Small = 0] = "Small", e[e.Medium = 1] = "Medium", e[e.Large = 2] = "Large"
})(er || (er = {}));
const ic = {
        [er.Large]: 32,
        [er.Medium]: 16,
        [er.Small]: 8
    },
    Ky = v.div `
  animation: 0.54s linear 0s infinite normal none running iconSpin;
  width: ${e=>ic[e.$size]}px;
  height: ${e=>ic[e.$size]}px;
  ${e=>e.$center?"display: flex; justify-content: center; align-items: center; width: 100%;":""}

  svg {
    fill: rgb(0, 186, 255);
    width: 100%;
    height: 100%;
    stroke: none;
  }

  @keyframes iconSpin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
`;

function pm(e) {
    var t, o;
    return a(Ky, {
        $size: (t = e.size) !== null && t !== void 0 ? t : er.Large,
        $center: (o = e.center) !== null && o !== void 0 ? o : !0,
        children: a("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 32 32",
            children: a("path", {
                d: "M16 30.3c-3.8.1-7.6-1.3-10.4-3.9C2.8 23.8 1.1 19.9 1 16 .8 12.1 2.3 8 5.1 5.1 7.9 2.2 11.9.4 16 .3c.8 0 1.4.6 1.5 1.4s-.6 1.4-1.4 1.5H16C12.6 3 9.2 4.3 6.6 6.6 4.1 9 2.5 12.4 2.4 16c-.1 3.6 1.2 7.2 3.7 9.9 2.5 2.6 6.1 4.3 9.9 4.4z"
            })
        })
    })
}
const ym = P `
  & a, & button {
    line-height: 1;
    text-align: center;
    display: inline-block;
    max-width: 100%;
    vertical-align: middle;
    margin: 0;
    outline: none;
    background: ${e=>e.$backgroundColor};
    cursor: ${({$cursor:e,$disabled:t})=>t?"not-allowed":e};
    opacity: ${({$disabled:e})=>e?"0.5":"1"};
    ${co}
    ${Ct}
    ${Po}
    ${ki}
    text-decoration: none;
    
    span {
        ${uo}
    }

    &:hover {
      background: ${({$backgroundColorHover:e})=>e};
      span {
          ${e=>{var t,o;return Lr((o=(t=e.$$props)===null||t===void 0?void 0:t.$textColorHover)!==null&&o!==void 0?o:e.$textColorHover)}}
      }
    }
  }
`,
    Qy = v.div.attrs(ve()).attrs(Pt("button"))
`
    text-align: ${e=>e.$align};
    word-break: break-word;
    ${Ro};
    ${Dt};
    ${Ii}

    ${ym}
    a, button[type=submit] {
      &:focus-visible {
        outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
      }
    }
`, xm = dt(Qy), ex = v.form.attrs(ve()).attrs(Ae("login-form", "container"))
`
    padding: 10px;
    align-items: center;

    &, * {
        ${e=>e.isInteractionEnabled?"":"user-select: none;cursor: default;"}
    }

    &, .content {
        display: flex;
        flex-flow: column;
    }

    .content {
        align-items: flex-start;
        width: 200px;
    }

    .label-container {
        font-size: ${({$labelFontSize:e})=>e};
        font-family: ${({$labelFontFamily:e})=>e};
        color: ${({$color:e})=>e};
        font-weight: ${({$isLabelBold:e})=>e?"bold":"normal"};
        font-style: ${({$isLabelItalic:e})=>e?"italic":null};
        text-decoration: ${({$isLabelUnderline:e})=>e?"underline":"none"};
        margin-bottom: 3px;
    }

    .content > * {
        width: 100%;
        margin-bottom: 10px;
    }

    .content > *:nth-last-child(2) {
        margin-bottom: 20px;
    }
    
    .checkbox-label {
        font-size: 14px;
        font-family: ${({$labelFontFamily:e})=>e};
        color: ${({$color:e})=>e};
        display: flex;
        align-items: center;
    }
  
    ${ym}
    button {
      display: flex;
      justify-content: center;
      align-items: center;
      ${e=>e.$isSubmitDisabled?"opacity: .8;":""}
    }

    button:focus-visible {
      outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }
  
    .button-text {
        flex: 1;
    }

  
    ${e=>e.$isSubmitDisabled?`&&& button:hover { background: ${e.$backgroundColor}; color: ${e.$textColor}; }`:""}
  
  .global-error {
      color: #ff0000;
      font-size: 13px;
      height: 30px;
    }
`, vm = dt(ex), tx = e => {
    var t, o, r, i;
    const [n, l] = x.useState(""), [s, u] = x.useState(""), [c, h] = x.useState(!0), {
        onSubmit: m,
        onClick: g,
        onFocus: p,
        error: b
    } = e, C = x.useCallback(B => {
        m({
            email: n,
            password: s,
            isRememberMeEnabled: e.isRememberMeVisible ? c : !1
        }, B)
    }, [n, c, m, s, e.isRememberMeVisible]), w = (t = b ? .find(B => B.type === _t.Global)) === null || t === void 0 ? void 0 : t.message;
    return y(vm, { ...e.buttonProps,
        globalClassName: I.LoginForm,
        $labelFontFamily: e.fontFamily,
        $labelFontSize: e.fontSize,
        $color: e.color,
        $isLabelBold: e.isBold,
        $isLabelItalic: e.isItalic,
        $isLabelUnderline: e.isUnderline,
        $isEditMode: e.isInteractionEnabled,
        $inlineMode: !e.isInteractionEnabled,
        onSubmit: C,
        onClick: g,
        isInteractionEnabled: e.isInteractionEnabled,
        className: e.className,
        $isSubmitDisabled: (o = e.isSubmitting) !== null && o !== void 0 ? o : !1,
        children: [a("div", {
            className: "global-error",
            children: w ? ? null
        }), y("div", {
            className: "content",
            children: [y("div", {
                children: [a("div", {
                    className: "label-container",
                    children: e.emailLabelContent
                }), a(yi, {
                    isInteractionEnabled: e.isInteractionEnabled,
                    onChange: l,
                    value: n,
                    type: "email",
                    shouldShowHHorizontalMargin: !1,
                    autocomplete: "email",
                    color: e.color,
                    error: (r = b ? .find(B => B.type === _t.Email)) === null || r === void 0 ? void 0 : r.message,
                    globalError: !!w,
                    onFocus: p
                })]
            }), y("div", {
                children: [a("div", {
                    className: "label-container",
                    children: e.passwordLabelContent
                }), a(yi, {
                    isInteractionEnabled: e.isInteractionEnabled,
                    onChange: u,
                    value: s,
                    type: "password",
                    shouldShowHHorizontalMargin: !1,
                    autocomplete: "password",
                    color: e.color,
                    error: (i = b ? .find(B => B.type === _t.Password)) === null || i === void 0 ? void 0 : i.message,
                    globalError: !!w,
                    onFocus: p
                })]
            }), e.isRememberMeVisible ? a("div", {
                children: a(Xy, {
                    isInteractionEnabled: e.isInteractionEnabled,
                    onChange: h,
                    isChecked: c,
                    label: e.rememberMeLabelContent,
                    labelClassName: "checkbox-label"
                })
            }) : null, y("button", {
                type: "submit",
                ...Ae("login-form", "submit"),
                disabled: e.isSubmitting,
                children: [a("span", {
                    className: "button-text",
                    children: e.submitButtonContent
                }), gt(!!e.isSubmitting, a(pm, {
                    center: !1,
                    size: er.Medium
                }))]
            })]
        })]
    })
}, Nn = 25, ox = v.div.attrs(Pt("custom-html"))
`
    min-height: ${Nn}px;
    ${Dt};
`, Cm = f.exports.createContext(null), xi = () => {
    const e = f.exports.useContext(Cm);
    if (e) return e;
    throw new Error("NavbarContext must have provider!")
};
var vi;
(function(e) {
    e[e.SetActivePage = 0] = "SetActivePage"
})(vi || (vi = {}));
const Cs = e => ({
        type: vi.SetActivePage,
        payload: e
    }),
    wm = () => ({
        type: vi.SetActivePage
    }),
    rx = (e, {
        type: t,
        payload: o
    }) => {
        switch (t) {
            case vi.SetActivePage:
                return { ...e,
                    activePage: o
                };
            default:
                return e
        }
    },
    Bm = f.exports.createContext(null);

function Un() {
    const e = f.exports.useContext(Bm);
    if (e) return e;
    throw new Error("NavbarThemeContext must have provider!")
}

function nx(e) {
    const t = Y2(e);
    return t && Object.entries(e).every(([r, i]) => i === t[r]) ? t : e
}
const ix = v.div.attrs(Pt("navbar"))
`
    ${Dt}

    ${({$hasMobileView:e,theme:t})=>e&&`
@media $ {
    ze(t.globalDesign.contentWidth)
} {
    display: none;
}
`}
`, ax = dt(ix);

function Dd(e) {
    const {
        depth: t = 0,
        dataAts: o = "navbar-list",
        pages: r
    } = e, i = Un(), {
        MenuItem: n,
        MenuContainer: l
    } = xi();
    return a(l, {
        $depth: t,
        ...i,
        "data-ats-canvas-view-element": o,
        children: r.map(s => a(n, {
            entry: s,
            depth: t,
            dataAts: "navbar-list-item"
        }, s.page.uuid))
    })
}
const lx = e => {
        const {
            containerRef: t,
            dataAts: o,
            dataAttrs: r,
            className: i,
            pages: n
        } = e, {
            $position: l,
            hasMobileView: s
        } = Un();
        return a(ax, {
            globalClassName: I.Navbar,
            ref: t,
            $position: l,
            $hasMobileView: s,
            className: i,
            ...r,
            children: a(Dd, {
                pages: n,
                dataAts: o
            })
        })
    },
    sx = v.div.attrs(Pt("navbar"))
`
  font-size: 18px;
  color: ${({$navbarTheme:e})=>e.$textColor};
`, dx = dt(sx), Nd = new Map().set(W.Left, "flex-start").set(W.Center, "center").set(W.Right, "flex-end"), ux = new Map().set(W.Left, "flex-start").set(W.Center, "center").set(W.Right, "flex-end"), Sm = ({
    $navbarTheme: {
        $boxBackgroundColor: e,
        $textColor: t,
        paletteColors: o,
        parentBackgroundColor: r
    }
}) => {
    if (e && e !== At) return e;
    if (r) return r;
    if (t) {
        const [i, , n] = o;
        return z0(t, i ? .value, n ? .value)
    }
    return At
}, cx = v.div `
    max-height: 100%;
    overflow: auto;
    padding: 3em 0;
    position: fixed;
    transition: top 0.5s;
    left: 0;
    right: 0;
    top: -100%;
    z-index: ${Qo.Navbar};
    will-change: top;
    background: ${Sm};

    ${({$isActive:e})=>e&&"top: 0;"}
`, $m = Dd, hx = v.button `
    color: ${({$navbarTheme:e})=>e.$textColor};
    font-size: inherit;
    margin: 0.75em;
    padding: 0.75em;
    cursor: pointer;
    position: fixed;
    top: 0;
    right: 0;
    z-index: ${Qo.Navbar+1};
    background: ${Sm};
  
    &:focus-visible {
        outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }

    hr {
        display: block;
        height: 0.125em;
        border: none;
        width: 2em;
        background: currentColor;
        margin: 0.375em auto;
        transition: all 0.5s ease;
    }

    ${({$isActive:e})=>e&&`
hr: first - child {
    transform: translateY(.5e m) rotateZ(45 deg);
}
hr: nth - child(2) {
    width: 0;
}
hr: last - child {
    transform: translateY(-.5e m) rotateZ(-45 deg);
}
`}
`, mx = e => y(hx, { ...e,
    children: [a("hr", {}), a("hr", {}), a("hr", {})]
}), bx = e => {
    const {
        containerRef: t,
        dataAts: o,
        dataAttrs: r,
        className: i,
        pages: n
    } = e, [l, s] = f.exports.useState(!1), {
        state: {
            activePage: u
        }
    } = xi(), c = Un(), h = f.exports.useCallback(() => s(!l), [l]);
    return f.exports.useEffect(() => {
        u || s(!1)
    }, [u]), n.length ? rh.exports.createPortal(y(dx, {
        ref: t,
        className: i,
        $navbarTheme: c,
        globalClassName: I.Navbar,
        ...r,
        children: [a(mx, {
            $isActive: l,
            $navbarTheme: c,
            onClick: h
        }), a(cx, {
            $isActive: l,
            $navbarTheme: c,
            children: a($m, {
                pages: n,
                dataAts: o
            })
        })]
    }), document.body) : null
}, fx = ({
    page: e
}) => a(f.exports.Fragment, {
    children: e.name
});
var pe;
(function(e) {
    e[e.FromLeftAlignTop = 0] = "FromLeftAlignTop", e[e.FromLeftAlignCenter = 1] = "FromLeftAlignCenter", e[e.FromLeftAlignBottom = 2] = "FromLeftAlignBottom", e[e.FromRightAlignTop = 3] = "FromRightAlignTop", e[e.FromRightAlignCenter = 4] = "FromRightAlignCenter", e[e.FromRightAlignBottom = 5] = "FromRightAlignBottom", e[e.FromTopAlignLeft = 6] = "FromTopAlignLeft", e[e.FromTopAlignCenter = 7] = "FromTopAlignCenter", e[e.FromTopAlignRight = 8] = "FromTopAlignRight", e[e.FromBottomAlignLeft = 9] = "FromBottomAlignLeft", e[e.FromBottomAlignCenter = 10] = "FromBottomAlignCenter", e[e.FromBottomAlignRight = 11] = "FromBottomAlignRight", e[e.FromInsideAlignLeftTop = 12] = "FromInsideAlignLeftTop", e[e.FromInsideAlignLeftCenter = 13] = "FromInsideAlignLeftCenter", e[e.FromInsideAlignLeftBottom = 14] = "FromInsideAlignLeftBottom", e[e.FromInsideAlignCenterTop = 15] = "FromInsideAlignCenterTop", e[e.FromInsideAlignCenterCenter = 16] = "FromInsideAlignCenterCenter", e[e.FromInsideAlignCenterBottom = 17] = "FromInsideAlignCenterBottom", e[e.FromInsideAlignRightTop = 18] = "FromInsideAlignRightTop", e[e.FromInsideAlignRightCenter = 19] = "FromInsideAlignRightCenter", e[e.FromInsideAlignRightBottom = 20] = "FromInsideAlignRightBottom"
})(pe || (pe = {}));

function gx(e, t) {
    return t === pt.Column || e === 2 ? [pe.FromRightAlignTop, pe.FromLeftAlignTop, pe.FromRightAlignTop] : [pe.FromBottomAlignLeft, pe.FromTopAlignLeft, pe.FromBottomAlignLeft]
}
class px extends x.PureComponent {
    componentDidMount() {
        const {
            isOpen: t,
            onOpen: o
        } = this.props;
        t && o && o()
    }
    componentDidUpdate(t) {
        const {
            isOpen: o,
            onOpen: r,
            onClose: i
        } = this.props;
        t.isOpen !== o && (r && o ? r() : i && !o && i())
    }
    componentWillUnmount() {
        const {
            isOpen: t,
            onClose: o
        } = this.props;
        t && o && o()
    }
    render() {
        const {
            isOpen: t,
            children: o
        } = this.props;
        return t ? rh.exports.createPortal(a("div", {
            children: o
        }), document.body) : null
    }
}
const yx = v.div `
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: ${({$depth:e})=>e};

    .positioning-element {
        position: absolute;
        pointer-events: all;
    }
`;

function ac(e, t, o, r, i) {
    if (!e || !t || !o) return {
        position: {
            top: 0,
            left: 0
        },
        pointOfMatch: null
    };
    const {
        ownerDocument: {
            scrollingElement: n,
            documentElement: l
        }
    } = e, {
        scrollTop: s,
        scrollLeft: u
    } = n || l, {
        width: c,
        height: h,
        left: m,
        top: g
    } = e.getBoundingClientRect(), {
        width: p,
        height: b
    } = t.getBoundingClientRect(), {
        offsetWidth: C,
        offsetHeight: w
    } = o;
    for (let B = 0, S = r.length; B < S; B++) {
        const $ = r[B],
            L = B === S - 1;
        let M = g + s,
            F = m + u;
        switch ($) {
            case pe.FromLeftAlignTop:
                F -= p + i;
                break;
            case pe.FromLeftAlignCenter:
                F -= p + i, M += (h - b) / 2;
                break;
            case pe.FromLeftAlignBottom:
                F -= p + i, M += h - b;
                break;
            case pe.FromRightAlignTop:
                F += c + i;
                break;
            case pe.FromRightAlignCenter:
                F += c + i, M += (h - b) / 2;
                break;
            case pe.FromRightAlignBottom:
                F += c + i, M += h - b;
                break;
            case pe.FromTopAlignLeft:
                M -= b + i;
                break;
            case pe.FromTopAlignCenter:
                F += (c - p) / 2, M -= b + i;
                break;
            case pe.FromTopAlignRight:
                F += c - p, M -= b + i;
                break;
            case pe.FromBottomAlignLeft:
                M += h + i;
                break;
            case pe.FromBottomAlignCenter:
                F += (c - p) / 2, M += h + i;
                break;
            case pe.FromBottomAlignRight:
                F += c - p, M += h + i;
                break;
            case pe.FromInsideAlignLeftTop:
                break;
            case pe.FromInsideAlignLeftCenter:
                M += (h - b) / 2;
                break;
            case pe.FromInsideAlignLeftBottom:
                M += h - b;
                break;
            case pe.FromInsideAlignCenterTop:
                F += (c - p) / 2;
                break;
            case pe.FromInsideAlignCenterCenter:
                F += (c - p) / 2, M += (h - b) / 2;
                break;
            case pe.FromInsideAlignCenterBottom:
                F += (c - p) / 2, M += h - b;
                break;
            case pe.FromInsideAlignRightTop:
                F += c - p;
                break;
            case pe.FromInsideAlignRightCenter:
                F += c - p, M += (h - b) / 2;
                break;
            case pe.FromInsideAlignRightBottom:
                F += c - p, M += h - b;
                break
        }
        if (L || M >= s && F >= u && M - s + b <= w && F - u + p <= C) return {
            position: {
                left: F,
                top: M
            },
            pointOfMatch: $
        }
    }
    return {
        position: {
            left: m,
            top: g
        },
        pointOfMatch: null
    }
}
class Ud extends x.PureComponent {
    constructor() {
        super(...arguments), Object.defineProperty(this, "state", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: {
                position: {
                    left: 0,
                    top: 0
                },
                pointOfMatch: null
            }
        }), Object.defineProperty(this, "positionerRef", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: x.createRef()
        }), Object.defineProperty(this, "containerRef", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: x.createRef()
        }), Object.defineProperty(this, "handleClickOutside", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t => {
                var o;
                !((o = this.containerRef.current) === null || o === void 0) && o.contains(t.target) || !this.props.onOutsideClick || this.props.onOutsideClick(t)
            }
        })
    }
    componentDidMount() {
        const {
            neighborRef: t,
            matchingPointsOrder: o,
            distanceToFence: r,
            onPointOfMatchChange: i
        } = this.props;
        this.toggleOutsideClickEvents(!0);
        const n = ac(t.current, this.positionerRef.current, this.containerRef.current, o, r),
            l = this.state.pointOfMatch !== n.pointOfMatch;
        this.setState(n), l && i ? .(n.pointOfMatch)
    }
    componentDidUpdate(t, o) {
        if (!t.isOpen && this.props.isOpen || t.matchingPointsOrder !== this.props.matchingPointsOrder) {
            const {
                neighborRef: r,
                matchingPointsOrder: i,
                distanceToFence: n,
                onPointOfMatchChange: l
            } = this.props, s = ac(r.current, this.positionerRef.current, this.containerRef.current, i, n), u = o.pointOfMatch !== s.pointOfMatch;
            this.setState(s), u && l ? .(s.pointOfMatch)
        }
    }
    componentWillUnmount() {
        this.toggleOutsideClickEvents(!1)
    }
    toggleOutsideClickEvents(t) {
        t ? (document.addEventListener("touchstart", this.handleClickOutside), document.addEventListener("mouseup", this.handleClickOutside)) : (document.removeEventListener("touchstart", this.handleClickOutside), document.removeEventListener("mouseup", this.handleClickOutside))
    }
    render() {
        const {
            children: t,
            isOpen: o,
            onClose: r,
            onOpen: i,
            portalDepth: n = fa.Default
        } = this.props;
        return a(px, {
            isOpen: o,
            onClose: r,
            onOpen: i,
            children: a(yx, {
                ref: this.containerRef,
                $depth: n,
                children: a("div", {
                    className: "positioning-element",
                    ref: this.positionerRef,
                    style: this.state.position,
                    children: t
                })
            })
        })
    }
}
Object.defineProperty(Ud, "defaultProps", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: {
        matchingPointsOrder: [pe.FromLeftAlignTop, pe.FromRightAlignTop, pe.FromBottomAlignLeft, pe.FromTopAlignLeft, pe.FromInsideAlignLeftTop],
        distanceToFence: 5
    }
});
const xx = e => {
        const t = Un(),
            {
                neighborRef: o,
                depth: r = 0
            } = e,
            i = f.exports.useMemo(() => gx(r, t.direction), [r, t.direction]);
        return a(Ud, {
            neighborRef: o,
            isOpen: !0,
            matchingPointsOrder: i,
            portalDepth: fa.Background,
            distanceToFence: -1,
            children: a(Dd, { ...e,
                dataAts: "navbar-list"
            })
        })
    },
    vx = ({
        className: e
    }) => a("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 16 16",
        fill: "currentColor",
        className: e,
        children: a("path", {
            d: "M1.6 5.4L2.4 4.6 8 10.3 13.6 4.6 14.4 5.4 8.4 11.4C8.2 11.6 7.8 11.6 7.6 11.4L1.6 5.4Z"
        })
    });
var Rr;
(function(e) {
    e[e.Right = -90] = "Right", e[e.Top = 180] = "Top", e[e.Bottom = 0] = "Bottom", e[e.left = 90] = "left"
})(Rr || (Rr = {}));
const Rm = v(vx)
`
    width: 1.25em;
    transition: 0.25s transform;
    ${({$rotate:e})=>e&&`
transform: rotate($ {
        e
    }
    deg);
`}
`, Pm = v.button `
    color: inherit;
    cursor: pointer;
    font-size: inherit;
  
    &:focus-visible {
        outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }
`, Cx = ({
    $rotate: e,
    className: t,
    ...o
}) => a(Pm, { ...o,
    className: t,
    children: a(Rm, {
        $rotate: e
    })
});

function wx() {
    const e = hl();
    return f.exports.useCallback(t => Co.isExternalPage(t) ? { ...t.hyperlink,
        href: e.render(t)
    } : {
        id: t.uuid,
        type: k.Internal,
        pageUuid: t.uuid,
        href: e.render(t),
        target: Ce.Self
    }, [e])
}
const Bx = v($o)
`
    display: flex;
`, Fm = ({
    page: e,
    arrowRotate: t,
    hasChildren: o,
    onArrowCLick: r,
    onClick: i,
    onMouseEnter: n,
    children: l,
    depth: s,
    ...u
}) => {
    const c = wx(),
        h = f.exports.useMemo(() => c(e), [c, e]),
        m = f.exports.useCallback(g => {
            g.preventDefault(), g.stopPropagation(), r(e)
        }, [r, e]);
    return y(Bx, { ...u,
        onMouseEnter: n,
        onClick: i,
        hyperlink: h,
        description: e.name,
        "data-ats-canvas-view-element-href": h ? .href,
        "data-ats-canvas-view-element-target": h ? .target,
        "data-ats-canvas-view-element": "navbar-list-item-link",
        children: [a("div", {
            children: l
        }), o ? a(Cx, {
            $rotate: t,
            onClick: m
        }) : null]
    })
}, Sx = v(Fm)
`
    ${({$navbarTheme:e})=>uo(e)}
    ${({$navbarTheme:e})=>hm(e)}
    font-size: ${({depth:e})=>e>0?".9em":"1em"};
    margin-left: ${({depth:e})=>e}em;

    height: 3.5em;
    padding: 0 1.5em;
    display: flex;
    align-items: center;
  
    &:focus-visible {
        outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }

    > *:first-child {
        flex: 1 1 auto;
    }

    ${Pm} {
      padding: .25em 8px;
    }
`;

function $x(e) {
    const {
        entry: t,
        depth: o,
        dataAts: r
    } = e, {
        dispatch: i,
        onClick: n,
        MenuItemContent: l,
        Menu: s
    } = xi(), u = Un(), {
        page: c,
        children: h
    } = t, [m, g] = f.exports.useState(!1), p = f.exports.useCallback(() => i(Cs(c)), [i, c]), b = f.exports.useCallback($ => {
        n(c, $), i(wm())
    }, [i, n, c]), C = f.exports.useCallback(() => g(!m), [m]), w = h.length > 0, B = m && w, S = m ? Rr.Top : Rr.Bottom;
    return y("li", {
        "data-ats-canvas-view-element": r,
        children: [a(Sx, {
            depth: o,
            page: c,
            arrowRotate: S,
            hasChildren: w,
            $navbarTheme: u,
            onClick: b,
            onArrowCLick: C,
            onMouseEnter: p,
            children: a(l, {
                page: c,
                $color: u.$textColor,
                $size: u.$fontSize
            })
        }), B ? a(s, {
            depth: o + 1,
            pages: h
        }) : null]
    })
}
const Rx = v(Fm)
`
    padding: 0.625em 1em;
    ${({$navbarTheme:e})=>uo(e)}
    ${({$navbarTheme:e})=>hm(e)}
    
    &:focus-visible {
        outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
        outline-offset: -${fe}px;
    }

    ${Rm} {
        width: 0.8em;
        margin-left: 0.4em;
    }

    ${({theme:e})=>P`
@media $ {
    ze(e.globalDesign.contentWidth)
} {
    $ {
        ml
    }
}
`}
`, Px = e => {
        const {
            entry: t,
            depth: o,
            dataAts: r
        } = e, {
            state: {
                activePage: i
            },
            dispatch: n,
            onClick: l,
            MenuItemContent: s
        } = xi(), u = Un(), {
            Menu: c
        } = xi(), {
            page: h,
            children: m
        } = t, g = f.exports.useRef(null), [p, b] = f.exports.useState(!1), C = f.exports.useCallback(() => b(!0), []), w = f.exports.useCallback(() => b(!1), []), B = f.exports.useCallback(() => n(Cs(h)), [n, h]), S = f.exports.useCallback(A => {
            b(!1), l(h, A), n(wm())
        }, [n, l, h]), $ = f.exports.useCallback(A => {
            b(!p), p || n(Cs(A))
        }, [p, n]), L = m.length > 0, M = p && i && L, F = p ? o > 0 ? Rr.Right : Rr.Top : Rr.Bottom;
        return y("li", {
            onMouseEnter: C,
            onMouseLeave: w,
            ref: g,
            "data-ats-canvas-view-element": r,
            children: [a(Rx, {
                depth: o,
                page: h,
                arrowRotate: F,
                hasChildren: L,
                $navbarTheme: u,
                onClick: S,
                onMouseEnter: B,
                onArrowCLick: $,
                children: a(s, {
                    page: h,
                    $color: u.$textColor,
                    $size: u.$fontSize
                })
            }), M ? a(c, {
                depth: o + 1,
                pages: m,
                neighborRef: g
            }) : null]
        })
    }, Fx = .2, Ix = v.ul `
    ${({$depth:e,$textColor:t})=>e===0&&t&&t!==At&&` &
    > li: not(: first - child) {
        position: relative; &
        ::before {
            position: absolute;
            width: 100 % ;
            content: '';
            border - top: 1 px solid $ {
                t
            };
            opacity: $ {
                Fx
            }
        }


    }
`}
`, lc = new Map().set(W.Center, "center").set(W.Left, "flex-start").set(W.Right, "flex-end").set(W.Justify, "stretch"), kx = e => {
    var t, o;
    return e.direction === pt.Column ? {
        alignItems: lc.get((t = e.align) !== null && t !== void 0 ? t : W.Center),
        flexDirection: "column"
    } : {
        alignItems: "center",
        justifyContent: lc.get((o = e.align) !== null && o !== void 0 ? o : W.Center)
    }
}, Tx = ({
    $boxBackgroundColor: e,
    parentBackgroundColor: t,
    $$props: o
}) => {
    const r = o.$boxBackgroundColor === At ? t : e;
    return {
        background: r ? ? "#fff"
    }
}, Ex = v.ul.attrs(ve(["$depth"]))
`
    display: flex;
    flex-wrap: wrap;
    overflow: hidden;

    ${({$depth:e})=>e===0&&P`
$ {
    kx
}
$ {
    Ro
}
$ {
    Ii
}
`}

    ${({$depth:e})=>e>0&&P`
margin: 0 0.4e m;
flex - direction: column;
box - shadow: 7 px 8 px 10 px - 8 px #000000;
            ${Tx}
        `}
`,Lx= e => {
    const {
        className: t,
        pagesWithChildren: o,
        containerRef: r,
        onClick: i,
        dataAts: n,
        dataAttrs: l,
        MenuItemContent: s = fx,
        ...u
    } = e, [c, h] = f.exports.useReducer(rx, {}), [m, g] = f.exports.useState(!1);
    f.exports.useEffect(() => {
        g(Boolean(u.isMobileView && u.hasMobileView))
    }, [u.isMobileView, u.hasMobileView]);
    const p = f.exports.useMemo(() => ({
            dispatch: h,
            state: c,
            onClick: i,
            Menu: m ? $m : xx,
            MenuItem: m ? $x : Px,
            MenuContainer: m ? Ix : Ex,
            MenuItemContent: s
        }), [s, c, i, m]),
        b = nx(u),
        C = m ? bx : lx;
    return a(Bm.Provider, {
        value: b,
        children: a(Cm.Provider, {
            value: p,
            children: a(C, {
                className: t,
                containerRef: r,
                dataAts: n,
                dataAttrs: l,
                pages: o
            })
        })
    })
}, sc = new Map([
    [be.TopLeft, "top left"],
    [be.TopCenter, "top"],
    [be.TopRight, "top right"],
    [be.CenterLeft, "left"],
    [be.CenterCenter, "center"],
    [be.CenterRight, "right"],
    [be.BottomLeft, "bottom left"],
    [be.BottomCenter, "bottom"],
    [be.BottomRight, "bottom right"]
]);

function Mx(e, t, o) {
    if (o === Ir.Cover) return "cover";
    if (e && typeof t == "number") return `${e.width*t/100}px`
}

function Im({
    $backgroundImage: e,
    $backgroundImageResolution: t,
    $backgroundRepeat: o,
    $backgroundPosition: r,
    $backgroundSize: i,
    $opacity: n
}) {
    if (e && n > 0) {
        const l = {
            position: "absolute",
            content: '""',
            display: "block",
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            backgroundImage: `url(${e})`,
            backgroundSize: Mx(t, i, o),
            backgroundPosition: r ? sc.get(r) : sc.get(be.CenterCenter),
            backgroundRepeat: !o || o === Ir.Cover ? "no-repeat" : o,
            opacity: bm(n)
        };
        return P `
            ::before {
                ${Ad};
                ${l};
            }
        `
    }
    return {}
}
const Ox = v.div `
    ${Im}
`,
    km = P `
    ${({readOnly:e})=>e&&"pointer-events: none;"};
`,
    Ax = (e = "auto") => P `
    cursor: ${({cursor:t})=>t||e};
`,
    Wx = P `
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
`,
    Tm = (e, t = "absolute", o = tn.px) => `
    position: ${t};

    ${Object.entries(e).reduce((r,[i,n])=>n===void 0?r:r.concat(`${i}: ${n}${o};`),"")}
`,
    Dx = ({
        $height: e,
        $width: t
    }, o = tn.px) => `
        height: ${e?va(e,o):"auto"};
        width: ${t?va(t,o):"auto"};
    `,
    Vd = 99998,
    Nx = v.div `
    ${Tm({top:0,bottom:0,right:0,left:0},"fixed")};
    background: ${({$overlayColor:e})=>e};
    z-index: ${Vd};
`,
    dc = {
        [be.TopLeft]: `
        top: 0;
        left: 0;
    `,
        [be.TopCenter]: `
        top: 0;
        left: 50%;
        transform: translate(-50%);
    `,
        [be.TopRight]: `
        right: 0;
    `,
        [be.CenterLeft]: `
        top: 50%;
        transform: translateY(-50%);
    `,
        [be.CenterCenter]: `
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    `,
        [be.CenterRight]: `
        right: 0;
        top: 50%;
        transform: translateY(-50%);
    `,
        [be.BottomLeft]: `
        bottom: 0;
    `,
        [be.BottomCenter]: `
        bottom: 0;
        left: 50%;
        transform: translate(-50%);
    `,
        [be.BottomRight]: `
        bottom: 0;
        right: 0;
    `
    },
    Ux = v.div.attrs(e => ({
        style: {
            height: va(e.$height),
            width: va(e.$width)
        }
    }))
`
    position: fixed;
    ${({position:e})=>dc[e]};
    z-index: ${Vd+1};
    
    @media ${({theme:e})=>ze(e.globalDesign.contentWidth)} {
        ${dc[be.CenterCenter]};
    }
`, Vx = v.button `
    ${Tm({top:20,right:20})};
    ${Ax("pointer")};
    z-index: ${Vd+1};
`, Ho = v.div.attrs(ve())
`
  overflow: ${({$showOverflow:e})=>e?"visible":"hidden"};
  ${Ro}
  ${Dt}
`, Hx = v(Ho)({
    overflowY: "auto",
    overflowX: "hidden",
    height: "100%",
    whiteSpace: "nowrap"
}), jx = () => a("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 7.45 7.45",
    children: a("path", {
        d: "M4.82,3.72l2.4-2.4a.78.78,0,0,0,0-1.1.8.8,0,0,0-1.1,0l-2.4,2.4L1.32.22a.8.8,0,0,0-1.1, 0,.8.8,0,0,0,0,1.1l2.4,2.4L.22,6.12a.8.8,0,0,0,0,1.1.78.78,0,0,0,1.1,0l2.4-2.4,2.4,2.4a.78.78,0,0,0,1.1-1.1Z"
    })
}), uc = e => {
    switch (e.size) {
        case "x-small":
            return "8px";
        case "small":
            return "9px";
        default:
            return "8px"
    }
}, zx = v.span `
    display: inline-block;
    width: ${uc};
    height: ${uc};

    svg {
        ${Dx({$height:100,$width:100},tn.percent)};
        vertical-align: top;
        fill: ${({color:e})=>e||"#7990A1"};
    }
`, _x = {
    close: jx
}, Em = ({
    name: e,
    color: t,
    size: o
}) => {
    const r = _x[e];
    return a(zx, {
        color: t,
        size: o,
        children: a(r, {})
    })
};
var jt;
(function(e) {
    e.Small = "Small", e.Medium = "Medium", e.Large = "Large", e.FullScreen = "FullScreen", e.FullHeight = "FullHeight"
})(jt || (jt = {}));
const Gx = {
        [jt.Small]: {
            $width: 500,
            $height: 350
        },
        [jt.Medium]: {
            $width: 800,
            $height: 500
        },
        [jt.Large]: {
            $width: 1200,
            $height: 550
        },
        [jt.FullScreen]: {
            $width: "100%",
            $height: "100%"
        },
        [jt.FullHeight]: {
            $width: 500,
            $height: "100%"
        }
    },
    Zx = ({
        isOpen: e,
        children: t,
        onClose: o,
        isClosable: r = !0,
        onClick: i,
        position: n = be.CenterCenter,
        size: l = jt.Small,
        title: s,
        $overlayColor: u,
        $inlineMode: c,
        $boxBackgroundColor: h,
        $isBoxBorderEnabled: m,
        $boxBorderColorRight: g,
        $boxBorderColorLeft: p,
        $boxBorderColorBottom: b,
        $boxBorderColorTop: C,
        $boxBorderStyleBottom: w,
        $boxBorderStyleLeft: B,
        $boxBorderStyleRight: S,
        $boxBorderStyleTop: $,
        $boxBorderWidthBottom: L,
        $boxBorderWidthLeft: M,
        $boxBorderWidthRight: F,
        $boxBorderWidthTop: A,
        $boxBorderRadiusBottomLeft: z,
        $boxBorderRadiusBottomRight: _,
        $boxBorderRadiusTopLeft: Z,
        $boxBorderRadiusTopRight: G,
        $boxPaddingBottom: H,
        $boxPaddingLeft: te,
        $boxPaddingRight: oe,
        $boxPaddingTop: re,
        $isBoxShadowEnabled: Q,
        $isBoxPaddingEnabled: J,
        $isBoxRadiusEnabled: ee,
        $boxShadowBlurRadius: le,
        $boxShadowColor: ue,
        $boxShadowOffsetX: me,
        $boxShadowOffsetY: ie,
        $boxShadowOpacity: Y,
        $boxShadowSpreadRadius: ae,
        containerRef: X,
        className: ge,
        ...ce
    }) => {
        const de = ec(o),
            ne = ec(),
            Se = Uh(),
            Fe = typeof l == "string" ? Gx[l] : l;
        return gt(e, a(Nx, {
            className: ge,
            "data-ats-modal": "overlay",
            $overlayColor: u,
            onClick: ne,
            children: y(Ux, {
                role: "dialog",
                "aria-labelledby": s,
                $width: Se ? "100%" : Fe.$width,
                $height: Se ? "100%" : Fe.$height,
                position: n,
                ...ce,
                onClick: i,
                children: [gt(r, a(Vx, {
                    "data-ats-modal": "close-button",
                    onClick: de,
                    children: a(Em, {
                        name: "close"
                    })
                })), a(Hx, {
                    $inlineMode: c,
                    $boxBackgroundColor: h,
                    $isBoxBorderEnabled: m,
                    $boxBorderColorRight: g,
                    $boxBorderColorLeft: p,
                    $boxBorderColorBottom: b,
                    $boxBorderColorTop: C,
                    $boxBorderStyleBottom: w,
                    $boxBorderStyleLeft: B,
                    $boxBorderStyleRight: S,
                    $boxBorderStyleTop: $,
                    $boxBorderWidthBottom: L,
                    $boxBorderWidthLeft: M,
                    $boxBorderWidthRight: F,
                    $boxBorderWidthTop: A,
                    $boxBorderRadiusBottomLeft: z,
                    $boxBorderRadiusBottomRight: _,
                    $boxBorderRadiusTopLeft: Z,
                    $boxBorderRadiusTopRight: G,
                    $boxPaddingBottom: H,
                    $boxPaddingLeft: te,
                    $boxPaddingRight: oe,
                    $boxPaddingTop: re,
                    $isBoxShadowEnabled: Q,
                    $isBoxPaddingEnabled: J,
                    $isBoxRadiusEnabled: ee,
                    $boxShadowBlurRadius: le,
                    $boxShadowColor: ue,
                    $boxShadowOffsetX: me,
                    $boxShadowOffsetY: ie,
                    $boxShadowOpacity: Y,
                    $boxShadowSpreadRadius: ae,
                    ref: X,
                    children: t
                })]
            })
        }))
    },
    qx = {
        [yo.Small]: jt.Small,
        [yo.Medium]: jt.Medium,
        [yo.Large]: jt.Large,
        [yo.FullHeight]: jt.FullHeight,
        [yo.FullScreen]: jt.FullScreen
    },
    Jx = ({
        size: e,
        customHeightPercentage: t,
        customWidthPercentage: o
    }) => {
        const r = {
            $height: `${t}%`,
            $width: `${o}%`
        };
        return e === yo.Custom ? r : qx[e]
    };
var cc;
(function(e) {
    e.EaseInOut = "ease-in-out", e.EaseIn = "ease-in", e.EaseOut = "ease-out", e.Ease = "ease"
})(cc || (cc = {}));

function Yx(e, t) {
    const o = Object.keys(t),
        r = {};
    for (const i of o) r[e + i] = t[i];
    return r
}

function Xx(e) {
    return Yx("$", e)
}

function Kx(e) {
    return typeof e ? .data == "object" && "resolution" in e.data
}

function Lm(e) {
    if (Kx(e)) return e.data.resolution
}

function Qx(e, t) {
    return P `
        &&& ${e} {
            ${Od(t)}
        }
    `
}

function ev() {
    return [...sm.map(e => Qx(`${e.selector}, ${e.selector} .${sd}`, e.mobileFontSize)), P `
            &&& a {
              font-size: inherit;
            }
            &&& li {
              ${ml}
            }
        `]
}

function tv(e) {
    return [...sm.map(t => P `
                &&& ${t.selector} {
                    ${Qn(e,t.type)};
                    color: var(--${D.Two});
                }
            `), P `
            li {
                ${Qn(e,Ve.Paragraph)};
                color: var(--${D.Two});
            }
            a {
                ${Qn(e,Ve.Link)}
            }

            a:hover {
                ${Qn(e,Ve.HoverLink)}
            }

            a,
            a:visited {
                color: var(--${D.Three});
            }
        `]
}

function ov(e) {
    return P `
        color: var(--${D.Two});
        font-family: ${Oa[0].fontStack.join(", ")};

        ${tv(e)}

        &&& ${Mo[q.TopHeader].selector},
        &&& ${Mo[q.Header].selector},
        &&& ${Mo[q.Subheader].selector},
        &&& ${Mo[q.Paragraph].selector},
        &&& ${Mo[q.Disclaimer].selector},
        &&& a,
        li {
            ${gm};
            margin: 0;
            line-height: ${Si};
        }

        a:focus-visible {
            outline: ${fe}px solid ${({theme:t})=>t.globalDesign.colors.specialTwo};
            display: inline-block;
        }

        .${sd} {
            font-size: var(--font-size);
        }

        ol {
            list-style-type: decimal;
        }

        ul {
            list-style-type: disc;
        }

        && ul,
        && ol {
            list-style-position: inside;
            padding: 0 0 0 24px;

            ${Mo[q.Paragraph].selector} {
                display: initial;
            }
        }

        ul ul ul,
        ul ul ul ul ul ul {
            list-style-type: square;
        }

        ul ul,
        ul ul ul ul ul {
            list-style-type: circle;
        }

        ul,
        ul ul ul ul {
            list-style-type: disc;
        }

        ol ol ol,
        ol ol ol ol ol ol {
            list-style-type: lower-roman;
        }

        ol ol,
        ol ol ol ol ol {
            list-style-type: lower-alpha;
        }

        ol,
        ol ol ol ol {
            list-style-type: decimal;
        }

        &&& .${Gf} * {
            line-height: inherit;
        }

        li {
            color: var(--${D.Two});
            font-weight: normal;
            text-decoration: none;
            font-style: normal;
            list-style-position: outside;
        }

        @media ${({theme:t})=>ze(t.globalDesign.contentWidth)} {
            ${ev}
        }
    `
}
const rv = v.div.attrs(ve()).attrs(Pt("text"))
`
        position: relative;

        ${e=>ov(e.typography)}
        ${Ro};
        ${Dt}
        ${Ii}
        
        .text-color-gradient u {
            text-decoration-color: #000;
        }
`, nv = dt(rv), ws = v.div.attrs(ve())
`
    display: flex;
    position: relative;
    padding-top: ${({imagesVerticalSpacing:e})=>`
$ {
    e
}
px `};
    padding-bottom: ${({imagesVerticalSpacing:e})=>`
$ {
    e
}
px `};
    padding-left: ${({imagesHorizontalSpacing:e})=>`
$ {
    e
}
px `};
    padding-right: ${({imagesHorizontalSpacing:e})=>`
$ {
    e
}
px `};
    width: 100%;
    height: 100%;

    .gallery-hyperlink {
        width: 100%;
        height: 100%;
    }

    .gallery-hyperlink:focus-visible,
    .gallery-image-button:focus-visible {
        outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
        outline-offset: -${fe}px;
        ${Ct};
    }
`, iv = v.div.attrs(ve()).attrs(Ae("grid-gallery", "image"))
`
    overflow: hidden;
    display: block;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
    box-sizing: border-box;

    ${Ct};
    ${co};
    ${Po};
    
    .grid-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
`, Hd = x.createContext(() => null);

function bl({
    sourceSet: e,
    as: t,
    children: o,
    ...r
}) {
    return y(t ? ? "picture", { ...r,
        children: [(e ? ? []).map(n => {
            var l;
            return a("source", {
                srcSet: n.src,
                type: (l = n.type) !== null && l !== void 0 ? l : void 0
            }, n.id)
        }), o]
    })
}
const Mm = f.exports.createContext(null),
    Or = () => {
        const e = f.exports.useContext(Mm);
        if (e) return e;
        throw new Error("missing gallery data")
    },
    av = v.button.attrs(Ae("grid-gallery", "image-button"))
`
    background: none;
    outline: none;
    border: none;
    height: 100%;
    width: 100%;
    padding: 0;
`, jd = ({
    onClick: e,
    source: t,
    children: o,
    isActiveElement: r
}) => {
    var i, n;
    const {
        anchorDataAts: l,
        isEnableHyperLinkAction: s,
        galleryType: u
    } = Or(), c = (i = t.hyperlink) === null || i === void 0 ? void 0 : i.target, h = f.exports.useCallback(() => e(t.id), [e, t.id]);
    return !((n = t.hyperlink) === null || n === void 0) && n.href ? a($o, {
        hyperlink: t.hyperlink,
        isClickable: s,
        description: t.alt,
        emptyContainer: a("div", {
            className: "gallery-hyperlink"
        }),
        "data-ats-canvas-gallery-item-hyperlink-target": c,
        className: "gallery-hyperlink",
        tabIndex: r,
        ...Ae(`${u}-gallery-link`, "anchor"),
        ...l,
        children: o
    }) : a(av, {
        type: "button",
        className: "gallery-image-button",
        "data-ats-canvas-gallery-item-hyperlink-target": c,
        onClick: h,
        tabIndex: r,
        children: o
    })
}, lv = e => {
    var t;
    const {
        source: o,
        onClick: r
    } = e, i = Or(), {
        anchorDataAts: n,
        itemDataAts: l,
        isActive: s,
        ...u
    } = i, {
        getImageSource: c,
        getSourceSet: h,
        getImageAuthor: m
    } = u, g = o.source ? c(o) : void 0, p = f.exports.useCallback(() => r(o.id), [r, o.id]), b = x.useContext(Hd), C = (t = m(o)) !== null && t !== void 0 ? t : null, w = Fi();
    return y(ws, { ...u,
        onClick: Gt,
        children: [a(jd, {
            onClick: p,
            source: o,
            children: a(iv, { ...u,
                children: a(bl, {
                    sourceSet: h(o),
                    children: a("img", {
                        src: g,
                        alt: o.alt,
                        className: "grid-image",
                        ...l,
                        loading: w ? "lazy" : void 0,
                        decoding: w ? "async" : void 0
                    })
                })
            })
        }), C ? a(b, {
            name: C.name,
            url: C.url,
            Component: ws
        }) : null]
    })
}, zd = v.div.attrs(Ae("no-data", "wrapper"))
`
  background-color: #ffffff;
  border-radius: 4px;
  border: 3px solid transparent;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-shadow: 2px 2px 2px 2px rgba(0, 0, 0, 0.15), -2px -2px 3px 1px rgb(255, 255, 255);

  .source-thumbnail-no-data-icon {
    fill: #00BAFF;
    width: 80px;
    height: 80px;
    min-width: 80px;
    min-height: 80px;
  }
`, _d = e => a("svg", {
    className: e.classNameWrapper,
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 40 40",
    children: a("path", {
        d: "M10,23h10.4l2.9-2.8l2.9,2.8H30v-1l-3.4,0l-3.3-3.2L20,22l-10,0V23L10,23z M16.1,15.9v-0.5 c-1.4,0-2.5,1.1-2.5,2.5c0,1.4,1.1,2.5,2.5,2.5c1.4,0,2.5-1.1,2.5-2.5c0-1.4-1.1-2.5-2.5-2.5V15.9v0.5c0.8,0,1.5,0.7,1.5,1.5 c0,0.8-0.7,1.5-1.5,1.5c-0.8,0-1.5-0.7-1.5-1.5c0-0.8,0.7-1.5,1.5-1.5V15.9z M28.3,12.5V12H11.7c-0.6,0-1.1,0.3-1.5,0.7 c-0.4,0.4-0.7,0.9-0.7,1.5v11.6c0,0.6,0.3,1.1,0.7,1.5c0.4,0.4,0.9,0.7,1.5,0.7h16.6c0.6,0,1.1-0.3,1.5-0.7 c0.4-0.4,0.7-0.9,0.7-1.5V14.2c0-0.6-0.3-1.1-0.7-1.5c-0.4-0.4-0.9-0.7-1.5-0.7V12.5V13c0.3,0,0.6,0.1,0.8,0.4 c0.2,0.2,0.4,0.5,0.4,0.8v11.6c0,0.3-0.1,0.6-0.4,0.8c-0.2,0.2-0.5,0.4-0.8,0.4H11.7c-0.3,0-0.6-0.1-0.8-0.4 c-0.2-0.2-0.4-0.5-0.4-0.8V14.2c0-0.3,0.1-0.6,0.4-0.8c0.2-0.2,0.5-0.4,0.8-0.4h16.6V12.5z"
    })
}), sv = v.div.attrs(Ae("grid-gallery", "wrapper"))
`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  max-width: ${({theme:e})=>e.globalDesign.contentWidth}px;

  @media ${({theme:e})=>ze(e.globalDesign.contentWidth)} {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }

  .grid-nodata-wrapper {
    width: 100%;
    height: 100%;
  }
  
  .source-element {
    display: flex;
  }
`, dv = dt(sv), Om = f.exports.createContext(null), fl = Symbol("GalleryModalCancel");

function Gd() {
    const e = f.exports.useContext(Om);
    if (!e) throw new Error("Missing gallery modal context");
    return e
}
const uv = () => {
        const e = Or(),
            {
                sources: t,
                isPlaceholderAvailable: o,
                isModalEnabled: r,
                $width: i
            } = e,
            [n] = Gd(),
            l = f.exports.useCallback(async s => {
                const u = t.findIndex(h => h.id === s),
                    {
                        activeElement: c
                    } = document;
                try {
                    await n({
                        sources: t,
                        activeIndex: u,
                        activeElement: c
                    })
                } catch (h) {
                    if (h !== fl) throw h
                }
            }, [n, t]);
        return a(dv, { ...e,
            children: t.map(s => s.source ? a("div", {
                className: "source-element",
                style: {
                    width: i,
                    height: i
                },
                children: a(lv, {
                    source: s,
                    onClick: r && !s.hyperlink ? l : Gt
                }, s.id)
            }, s.id) : gt(o, y(ws, {
                style: {
                    width: i,
                    height: i
                },
                ...e,
                onClick: Gt,
                children: [a(zd, {
                    className: "grid-nodata-wrapper",
                    children: a(_d, {
                        classNameWrapper: "source-thumbnail-no-data-icon"
                    })
                }), ","]
            }, s.id)))
        })
    },
    cv = v.div.attrs(Ae("masonry-gallery", "wrapper"))
`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  max-width: ${({theme:e})=>e.globalDesign.contentWidth}px;

  @media ${({theme:e})=>ze(e.globalDesign.contentWidth)} {
    flex-wrap: wrap;
  }

  .masonry-nodata-wrapper {
    width: 350px;
    height: 250px;
  }
`, hv = dt(cv), mv = 3, bv = 300;

function fv(e, t = mv, o = bv) {
    const r = Array.from({
        length: t
    }, () => []);
    for (const i of e) gv(r, o).push(i);
    return r
}

function gv(e, t) {
    let o = [],
        r = Number.POSITIVE_INFINITY;
    for (const i of e) {
        const n = i.reduce((l, s) => {
            const {
                width: u,
                height: c
            } = pv(s);
            return l + t / (u / c)
        }, 0);
        n < r && (r = n, o = i)
    }
    return o
}

function pv(e) {
    if (e.source === null) return {
        width: 205,
        height: 205
    };
    if (dh(e.source)) {
        if (!e.source.data.resolution) throw new Error("Missing external image resolution");
        return e.source.data.resolution
    }
    if (Fr(e.source)) {
        if (!e.source.data.resolution) throw new Error("Missing storage image resolution");
        return e.source.data.resolution
    }
    throw new Error(`Unknown image type: ${e.source.type}`)
}
const yv = v.div.attrs(ve()).attrs(Ae("masonry-gallery", "image"))
`
    overflow: hidden;
    display: block;
    justify-content: center;
    align-items: center;
    
    ${Ct};
    ${co};
    ${Po};
    
    .masonry-image {
        width: 100%;
        height: auto;
        height: intrinsic;
        display: block;
    }
`, hc = v.div.attrs(ve())
`
    display: flex;
    position: relative;
    padding-top: ${({imagesVerticalSpacing:e})=>e?`
$ {
    e
}
px `:"0px"};
    padding-bottom: ${({imagesVerticalSpacing:e})=>e?`
$ {
    e
}
px `:"0px"};
    padding-left: ${({imagesHorizontalSpacing:e})=>e?`
$ {
    e
}
px `:"0px"};
    padding-right: ${({imagesHorizontalSpacing:e})=>e?`
$ {
    e
}
px `:"0px"};

    .gallery-hyperlink:focus-visible,
    .gallery-image-button:focus-visible {
        outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
        outline-offset: -${fe}px;
        ${Ct};
    }
`, xv = e => {
    var t;
    const {
        source: o,
        onClick: r
    } = e, i = Or(), {
        itemDataAts: n,
        isActive: l,
        ...s
    } = i, {
        getImageSource: u,
        getSourceSet: c,
        getImageAuthor: h
    } = s, m = o.source ? u(o) : void 0, g = x.useContext(Hd), p = (t = h(o)) !== null && t !== void 0 ? t : null, b = Fi(), C = f.exports.useCallback(() => r(o.id), [r, o.id]);
    return y(hc, { ...s,
        children: [a(jd, {
            onClick: C,
            source: o,
            children: a(yv, {
                $inlineMode: l,
                ...e,
                onClick: C,
                children: a(bl, {
                    sourceSet: c(o),
                    children: a("img", {
                        src: m,
                        alt: o.alt,
                        className: "masonry-image",
                        ...n,
                        loading: b ? "lazy" : void 0,
                        decoding: b ? "async" : void 0
                    })
                })
            })
        }), p ? a(g, {
            name: p.name,
            url: p.url,
            Component: hc
        }) : null]
    })
}, vv = v(({
    $isEnableHyperLinkAction: e,
    $imagesVerticalSpacing: t,
    $imagesHorizontalSpacing: o,
    $width: r,
    ...i
}) => a($o, { ...i
})).attrs(e => ({
    style: {
        width: e.$width === 0 ? "auto" : `${e.$width}px`
    }
})).attrs(Ae("masonry-gallery", "anchor"))
`
  ${({$isEnableHyperLinkAction:e})=>e?"":"cursor: default"};
  display: flex;
  position: relative;
  padding-top: ${({$imagesVerticalSpacing:e})=>e?`
$ {
    e
}
px `:0};
  padding-bottom: ${({$imagesVerticalSpacing:e})=>e?`
$ {
    e
}
px `:0};
  padding-left: ${({$imagesHorizontalSpacing:e})=>e?`
$ {
    e
}
px `:0};
  padding-right: ${({$imagesHorizontalSpacing:e})=>e?`
$ {
    e
}
px `:0};
`, Cv = () => {
    const [e] = Gd(), t = Or(), {
        sources: o,
        $width: r,
        imagesVerticalSpacing: i,
        isEnableHyperLinkAction: n,
        isPlaceholderAvailable: l,
        isModalEnabled: s
    } = t, u = f.exports.useCallback(async c => {
        const h = o.findIndex(g => g.id === c),
            {
                activeElement: m
            } = document;
        try {
            await e({
                sources: o,
                activeIndex: h,
                activeElement: m
            })
        } catch (g) {
            if (g !== fl) throw g
        }
    }, [e, o]);
    return a(hv, { ...t,
        children: fv(o).map((c, h) => a("div", {
            children: c.map(m => m.source ? a(xv, {
                source: m,
                onClick: s && !m.hyperlink ? u : Gt,
                ...t
            }, m.id) : gt(l, a(vv, {
                $isEnableHyperLinkAction: n,
                $imagesVerticalSpacing: i,
                $imagesHorizontalSpacing: i,
                $width: r,
                emptyContainer: a("div", {}),
                children: a(zd, {
                    className: "masonry-nodata-wrapper",
                    children: a(_d, {
                        classNameWrapper: "source-thumbnail-no-data-icon"
                    })
                })
            }, m.id)))
        }, h))
    })
}, wv = v.div `
    height: 100%;
    width: 100%;
    max-width: 100vw;
    display: inline-block;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    box-sizing: border-box;
    position: relative;

    .link {
        ${({$isEnableHyperLinkAction:e})=>e?"":"cursor: default"};
    }

    img {
        object-fit: cover;
        height: ${({$borderWidthTop:e,$borderWidthBottom:t,$imageDesignHeight:o})=>`
calc($ {
        o
    }
    px - $ {
        e + t
    }
    px)
`};
        width: 100%;
        max-width: 100vw;
        max-height: 100vh;

        @media ${({theme:e})=>ze(e.globalDesign.contentWidth)} {
            height: 100%;
            object-fit: contain;
        }
    }
    
     .gallery-image-button,
     .gallery-hyperlink {
        display: block;
        height: 100%;
    }
  
`, Bv = x.forwardRef((e, t) => {
    const {
        source: o,
        onClick: r,
        tabIndex: i
    } = e, n = Or(), {
        anchorDataAts: l,
        itemDataAts: s,
        slideshowHeight: u,
        $borderWidthTop: c,
        $borderWidthBottom: h,
        ...m
    } = n, {
        getImageSource: g,
        getSourceSet: p,
        isEnableHyperLinkAction: b
    } = m, C = o.source ? g(o) : void 0, w = Fi(), B = f.exports.useCallback(() => r(o.id), [r, o.id]);
    return a(wv, {
        ref: t,
        $isEnableHyperLinkAction: b,
        $imageDesignHeight: u,
        $borderWidthTop: c,
        $borderWidthBottom: h,
        children: a(jd, {
            onClick: B,
            source: o,
            isActiveElement: i,
            children: a(bl, {
                sourceSet: p(o),
                children: a("img", {
                    src: C,
                    loading: w ? "lazy" : void 0,
                    alt: o.alt,
                    ...s
                })
            })
        })
    })
}), Sv = v.div `
  scroll-behavior: smooth;
  display: inline-block;
  width: 100%;
  box-sizing: border-box;
  position: relative;
  white-space: nowrap;
  overflow: hidden;
  height: 600px;

  @media ${({theme:e})=>ze(e.globalDesign.contentWidth)} {
    height: 100vw;
  }

  .slideshow-nodata-wrapper {
    width: 100%;
    height: 100%;
  }
`, $v = dt(Sv);

function Rv(e) {
    const {
        $borderRadiusTopLeft: t,
        $borderRadiusTopRight: o,
        $borderRadiusBottomRight: r,
        $borderRadiusBottomLeft: i,
        $borderWidthTop: n,
        $borderWidthLeft: l,
        $borderWidthRight: s,
        $borderWidthBottom: u,
        $isBorderEnabled: c,
        $isRadiusEnabled: h
    } = e;
    if (!c) return Ct({
        $borderRadiusTopLeft: t,
        $borderRadiusTopRight: o,
        $borderRadiusBottomRight: r,
        $borderRadiusBottomLeft: i,
        $isRadiusEnabled: h
    });
    if (h) {
        const g = `calc(${t} - max(${n}, ${l}))`,
            p = `calc(${o} - max(${n}, ${s}))`,
            b = `calc(${r} - max(${u}, ${s}))`,
            C = `calc(${i} - max(${u}, ${l}))`;
        return P `border-radius:
            max(${g}, 0px) max(${p}, 0px)
            max(${b}, 0px) max(${C}, 0px);
        `
    }
    return ""
}
const mc = v.div.attrs(ve())
`
  width: ${({$imageDesignWidth:e})=>e};
  height: ${({$imageDesignHeight:e})=>e};
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  max-width: ${({theme:e})=>e.globalDesign.contentWidth}px;

  @media ${({theme:e})=>ze(e.globalDesign.contentWidth)} {
    height: auto;
    width: 100%;
  }

  .slideshow-wrapper {
    ${Ct};
    ${Po};
    ${co};
    width: 100%;
    height: 100%;
  }

  .prev,
  .next {
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: ${({isEnableSlideshowScroll:e})=>e?"pointer":"default"};
    position: absolute;
    background-color: black;
    top: 50%;
    transform: translateY(-50%);
    width: 33px;
    height: 33px;
    border-radius: 18px;
    border: 2px solid white;
    text-decoration: none;
    z-index: ${Qo.Element+1};
  }

  .next {
    right: 20px;
  }

  .prev {
    left: 20px;
  }

  .prev:focus-visible,
  .next:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    outline-offset: -${fe}px;
  }
  
  .slideshow-wrapper :focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    outline-offset: -${fe}px;
    ${Rv};
  }
`, Am = () => a("svg", {
    viewBox: "4 2 7.41 12",
    height: "10px",
    children: a("path", {
        d: "M11.41 3.41L6.83003 8L11.41 12.59L10 14L4.00003 8L10 2L11.41 3.41Z",
        fill: "#ffffff"
    })
}), Wm = () => a("svg", {
    viewBox: "4 2 7.41 12",
    height: "10px",
    children: a("path", {
        d: "M4.00003 12.59L8.58003 8L4.00003 3.41L5.41003 2L11.41 8L5.41003 14L4.00003 12.59Z",
        fill: "#ffffff"
    })
});

function Bs(e, t, o) {
    const r = t + e;
    return (o.length + r) % o.length
}
const Pv = {
        tabIndex: -1
    },
    Fv = () => {
        var e;
        const t = Or(),
            {
                sources: o,
                isPlaceholderAvailable: r,
                isEnableSlideshowScroll: i,
                slideshowWidth: n,
                slideshowHeight: l,
                isActive: s,
                isModalEnabled: u,
                getImageAuthor: c
            } = t,
            [h] = Gd(),
            [m, g] = x.useState(0),
            p = x.useRef([]),
            b = f.exports.useCallback(async F => {
                const A = o.findIndex(_ => _.id === F),
                    {
                        activeElement: z
                    } = document;
                try {
                    await h({
                        sources: o,
                        activeIndex: A,
                        activeElement: z
                    })
                } catch (_) {
                    if (_ !== fl) throw _
                }
            }, [h, o]),
            C = x.useMemo(() => r ? o : o.filter(F => Boolean(F.source)), [o, r]),
            w = x.useContext(Hd),
            B = C[m],
            S = (e = c(B)) !== null && e !== void 0 ? e : null,
            $ = x.useCallback(F => {
                var A;
                (A = p.current[F]) === null || A === void 0 || A.scrollIntoView({
                    behavior: "smooth",
                    block: "nearest",
                    inline: "start"
                }), g(F)
            }, [p]),
            L = x.useCallback(() => $(Bs(1, m, o)), [m, o, $]),
            M = x.useCallback(() => $(Bs(-1, m, o)), [m, o, $]);
        return y(mc, { ...t,
            $inlineMode: s,
            $imageDesignHeight: l,
            $imageDesignWidth: n,
            children: [gt(C.length >= 2, a("button", {
                type: "button",
                className: "prev",
                onClick: i ? M : void 0,
                ...Ae("slideshow-gallery", "prev"),
                children: a(Am, {})
            })), a($v, { ...t,
                className: "slideshow-wrapper",
                children: C.map((F, A) => F.source ? a(Bv, {
                    source: F,
                    ref: z => p.current[A] = z,
                    onClick: u && !F.hyperlink ? b : Gt,
                    ...A === m ? {} : Pv
                }, F.id) : gt(r, a(zd, {
                    className: "slideshow-nodata-wrapper",
                    children: a(_d, {
                        classNameWrapper: "source-thumbnail-no-data-icon"
                    })
                }, F.id)))
            }), S ? a(w, {
                name: S.name,
                url: S.url,
                Component: mc
            }) : null, gt(C.length >= 2, a("button", {
                type: "button",
                className: "next",
                onClick: i ? L : void 0,
                ...Ae("slideshow-gallery", "next"),
                children: a(Wm, {})
            }))]
        })
    },
    bc = {
        [Ko.Grid]: uv,
        [Ko.Masonry]: Cv,
        [Ko.Slideshow]: Fv
    };

function Iv(e) {
    const {
        $paddingRight: t,
        $paddingLeft: o,
        $paddingBottom: r,
        $paddingTop: i
    } = e, n = .1;
    return P `
        padding-left: ${(o*n).toFixed(2)}vw;
        padding-right: ${(t*n).toFixed(2)}vw;
        padding-top: ${(i*n).toFixed(2)}vh;
        padding-bottom: ${(r*n).toFixed(2)}vh;
    `
}

function kv({
    $isResponsive: e,
    theme: t
}) {
    return e ? `
      @media ${ze(t.globalDesign.contentWidth)} {
        width: 100%;
      }
    ` : ""
}
const Tv = v.div `
    display: flex;
    flex-direction: column;
    min-height: ${Nn}px;
    position: relative;
    ${Iv};
    ${Dt};
    width: ${({theme:e})=>e.globalDesign.isFullWidth?"100%":`
$ {
    e.globalDesign.contentWidth
}
px `};
    max-width: 100%;

    ${({$isEmpty:e})=>e?P` > * {
    visibility: visible!important;
}
`:""}
  
    ${kv}
`, Ev = dt(Tv), Lv = v.div.attrs(Ae("section-background", "video"))
`
    height: 100%;
    width: 100%;
    max-width: ${({$isFullWidth:e,theme:t})=>e?"100%":`
$ {
    t.globalDesign.contentWidth
}
px `};
    overflow: hidden;
    position: absolute;
    opacity: ${({$opacity:e})=>bm(e)};
    ${Ad};

    video {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translateX(-50%) translateY(-50%);
        object-fit: cover;
    }
`, Mv = v.div.attrs(Ae("section-background", "image"))
`
    width: ${({$isFullWidth:e})=>e?"100%":"auto"};
    max-width: 100%;
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    position: relative;

    ${Im}
`, Ov = v.div.attrs(ve())
`
    width: ${({$isFullWidth:e})=>e?"100%":"auto"};
    max-width: 100%;
    display: flex;
    justify-content: center;
    min-height: ${Nn}px;
    ${({$backgroundColor:e})=>e?`
background: $ {
    e
}
`:""};
    background-origin: border-box;
    position: relative;

    ${co};
    ${Ct};
    ${Po};
`, Av = v.video `
  ${Ad}
`, Dm = f.exports.createContext(null), Nm = () => f.exports.useContext(Dm);

function Wv() {
    const e = Nm();
    return f.exports.useMemo(() => e ? .backgroundColor === At ? void 0 : e ? .backgroundColor, [e])
}

function Dv() {
    const e = Nm();
    return e ? .elementId === Xt.Header
}
const Zd = v.section.attrs(Pt("section"))
`
    display: flex;
    justify-content: center;
    min-height: ${Nn}px;

    .bottom-spacer {
        height: ${e=>e.$bottomSpace}px;
    }
`;
Zd.defaultProps = {
    $bottomSpace: 0
};
const qd = v(Zd)
`
    position: sticky;
    top: 0;
    z-index: ${Qo.HeaderSticky};
`;
var ao;
(function(e) {
    e[e.None = 0] = "None", e[e.Visible = 1] = "Visible", e[e.Hidden = 2] = "Hidden"
})(ao || (ao = {}));
var Cr;
(function(e) {
    e[e.Up = 0] = "Up", e[e.Down = 1] = "Down"
})(Cr || (Cr = {}));

function Nv(e = {}) {
    var t;
    const {
        distance: o = 120,
        ratioScrollingUp: r = 1,
        ratioScrollingDown: i = 1.8
    } = e;
    let n = 0,
        l = Cr.Down,
        s = ao.None,
        u = 0,
        c = (t = e ? .height) !== null && t !== void 0 ? t : 0;
    return {
        setElementHeight(h) {
            c = h
        },
        processPosition(h) {
            const m = Math.abs(h - u),
                g = h >= n ? Cr.Down : Cr.Up,
                p = g === Cr.Down ? i : -r,
                b = h < c ? c * p : 0;
            return b && (s = ao.None), l !== g && (u = h, l = g), m > o + b && (u = h, s = g === Cr.Down ? ao.Hidden : ao.Visible), n = h, s
        }
    }
}
const Uv = v(qd)
`
    transition: transform 0.3s ease-in-out;
    ${({$state:e})=>e===ao.None&&{transition:"none"}}
    ${({$state:e})=>e===ao.Hidden&&{transform:"translateY(-100%)"}}
`, Vv = v(qd)
`
    --animate-duration: 0.5s;
    --z-index-duration: 0.1s var(--animate-duration);
    transition: opacity var(--animate-duration) ease-in-out, z-index var(--z-index-duration);
    ${({$state:e})=>e===ao.None&&{transition:"none"}}
    ${({$state:e})=>e===ao.Hidden?{opacity:0,zIndex:-1,pointerEvents:"none"}:{"--z-index-duration":"0s"}}
`;

function Hv({
    scrollingBehavior: e,
    bottomSpace: t,
    className: o,
    id: r,
    children: i
}) {
    const n = f.exports.useRef(),
        l = f.exports.useMemo(() => Nv(), []),
        [s, u] = f.exports.useState(ao.None);
    f.exports.useEffect(() => {
        var h;

        function m() {
            u(l.processPosition(window.scrollY))
        }
        return n.current && l.setElementHeight(n.current.clientHeight), (h = Er()) === null || h === void 0 || h.addEventListener("scroll", m), () => {
            var g;
            return (g = Er()) === null || g === void 0 ? void 0 : g.removeEventListener("scroll", m)
        }
    }, [l]);
    const c = e === Wo.Disappear ? Uv : Vv;
    return a(c, {
        ref: n,
        $bottomSpace: t,
        className: o,
        id: r,
        $state: s,
        children: i
    })
}

function jv(e) {
    switch (e.scrollingBehavior) {
        case Wo.Disappear:
        case Wo.Fade:
            return a(Hv, { ...e
            });
        case Wo.Fixed:
            return a(qd, {
                $bottomSpace: e.bottomSpace,
                className: e.className,
                id: e.id,
                children: e.children
            });
        case Wo.Normal:
        default:
            return a(Zd, {
                $bottomSpace: e.bottomSpace,
                className: e.className,
                id: e.id,
                children: e.children
            })
    }
}
const zv = v.iframe.attrs(ve()).attrs(({
    $isLazyLoadingEnabled: e
}) => ({
    allow: "autoplay encrypted-media fullscreen",
    allowFullScreen: !0,
    frameBorder: 0,
    loading: e ? "lazy" : "eager"
})).attrs(Pt("video"))
`
    width: ${({$width:e})=>e||"auto"};
    height: ${({$height:e})=>e||"auto"};
    pointer-events: ${({$enablePointerEvents:e})=>e?"auto":"none"};
    ${co};
    ${Ct};
    ${Po};
    max-width: 100%;
    max-height: 100%;

    ${({$isAdjustToWidth:e,theme:t})=>e&&`
@media $ {
    ze(t.globalDesign.contentWidth)
} {
    width: 100 % ;
    height: 100 % ;
}
`}
`;

function _v(e) {
    var t;
    const o = Fi();
    return a(zv, { ...e,
        $enablePointerEvents: (t = e.$enablePointerEvents) !== null && t !== void 0 ? t : !0,
        $isLazyLoadingEnabled: o
    })
}

function Gv(e) {
    switch (e) {
        case W.Left:
            return "flex-start";
        case W.Right:
            return "flex-end";
        case W.Center:
        default:
            return "center"
    }
}
const Zv = v.div.attrs(ve(["$align"]))
`
    display: flex;
    justify-content: ${({$align:e})=>Gv(e)};
    overflow: hidden;
    ${Ro}
    ${Dt}
    max-width: 100%;

    ${({$ratio:e,theme:t})=>`
@media $ {
    ze(t.globalDesign.contentWidth)
} {
    max - height: calc(100 vw / $ {
        e
    });
}
`}

    ${({$isAdjustToWidth:e,$ratio:t,theme:o})=>e&&`
@media $ {
    ze(o.globalDesign.contentWidth)
} {
    width: 100 vw;
    height: calc(100 vw / $ {
        t
    });
}
`}
`, qv = dt(Zv), Jv = v.div.attrs(ve())
`
      background: #000000;
      display: flex;
      ${({$isAdjustToWidth:e,theme:t})=>e&&P`
@media $ {
    ze(t.globalDesign.contentWidth)
} {
    width: 100 % ;
}
`}
    ${Ct};
`;

function Yv(e) {
    switch (e) {
        case W.Left:
            return P `text-align: left;
              margin-left: 0;`;
        case W.Right:
            return P `text-align: right;
              margin-right: 0;`;
        default:
            return P `text-align: center;`
    }
}

function Xv(e) {
    const {
        $direction: t,
        $width: o,
        $height: r
    } = e;
    switch (t) {
        case pt.Column:
            return P `width: 0;
              height: ${r}px;`;
        case pt.Row:
        default:
            return P `width: ${o}%;
              height: 0;`
    }
}

function Kv(e) {
    const {
        $direction: t
    } = e;
    return t === pt.Column ? P `
          border-right: ${e.$borderWidthTop}px ${e.$borderStyleTop} ${e.$borderColorTop};
          border-top: none;
        ` : P `
      border-top: ${e.$borderWidthTop}px ${e.$borderStyleTop} ${e.$borderColorTop};
      border-right: none;
    `
}
const Qv = v.hr.attrs(Pt("divider"))
`
  margin-block-start: 0;
  margin-block-end: 0;
  border-bottom: none;
  border-left: none;
  ${({$align:e})=>Yv(e)};
  ${Xv}
  ${Kv}
`;

function eC(e) {
    const {
        $direction: t
    } = e;
    return t === pt.Row ? P `display: flex;
          align-items: center;
          min-height: ${Nn}px;` : ""
}
const tC = v.div.attrs(ve()).attrs(Pt("divider-container"))
`
  overflow: hidden;
  ${eC}
  ${Ro}
  ${Dt}
`, oC = dt(tC), rC = v.div.attrs(ve()).attrs(Pt("timer"))
`
    ${Ro}
    ${Dt}
`, nC = v.div.attrs(ve())
`
  margin: 0 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  .clock-container {
    width: fit-content;
    background: ${({$backgroundColor:e})=>e};
    ${co};
    ${Ct};
  }
  .label-container {
    width: 100%;
    display: flex;
    justify-content: center;
  }
`, iC = dt(nC), aC = v.div.attrs(ve())
`
  width: 1.4em;
  text-align: center;
  box-sizing: content-box;
  ${uo};
  ${ki};
`, lC = v.div.attrs(ve())
`
  line-height: normal;
  max-width: 100%;
  ${uo}
`, Um = x.createContext(null);
class sC extends _0 {}
const Jd = () => {
        const e = f.exports.useContext(Um);
        if (e === null) throw new Error("Missing context ContentTranslationContext");
        return e
    },
    zt = e => {
        const t = Jd();
        return a(G0, {
            translationsService: t,
            children: a(Z0, { ...e
            })
        })
    },
    dC = Um.Provider;

function Yd() {
    return Jd().getIntl()
}
const K = {
    Elements: {
        Form: {
            Errors: {
                GeneralError: "Renderer.Elements.Form.Errors.GeneralError",
                Required: "Renderer.Elements.Form.Errors.Required",
                EmailInvalid: "Renderer.Elements.Form.Errors.EmailInvalid",
                PhoneInvalid: "Renderer.Elements.Form.Errors.PhoneInvalid",
                PhonePrefixInvalid: "Renderer.Elements.Form.Errors.PhonePrefixInvalid",
                UrlInvalid: "Renderer.Elements.Form.Errors.UrlInvalid",
                IpInvalid: "Renderer.Elements.Form.Errors.IpInvalid",
                DateRangeInvalid: "Renderer.Elements.Form.Errors.DateRangeInvalid",
                DateTimeFormatInvalid: "Renderer.Elements.Form.Errors.DateTimeFormatInvalid",
                ValueTooLong: "Renderer.Elements.Form.Errors.ValueTooLong",
                FormatInvalid: "Renderer.Elements.Form.Errors.FormatInvalid",
                CharactersNotAllowed: "Renderer.Elements.Form.Errors.CharactersNotAllowed",
                NumberFormat: "Renderer.Elements.Form.Errors.NumberFormat"
            },
            Recaptcha: {
                BadgeLabel: "Renderer.Elements.Form.Recaptcha.BadgeLabel"
            },
            NoConsentModal: {
                Heading: "Renderer.Elements.Form.NoConsentModal.Heading",
                Content: "Renderer.Elements.Form.NoConsentModal.Content",
                RejectButton: "Renderer.Elements.Form.NoConsentModal.RejectButton",
                ConfirmButton: "Renderer.Elements.Form.NoConsentModal.ConfirmButton"
            },
            InputDate: {
                Placeholder: "Renderer.Elements.Form.InputDate.Placeholder"
            },
            Select: {
                Placeholder: "Renderer.Elements.Form.Select.Placeholder"
            },
            Customs: {
                [Pe.Gender]: {
                    "Prefer not to say": "Renderer.Elements.Form.Customs.Genders.PreferNotToSay",
                    Male: "Renderer.Elements.Form.Customs.Genders.Male",
                    Female: "Renderer.Elements.Form.Customs.Genders.Female"
                },
                [Pe.Country]: {
                    Aruba: "Renderer.Elements.Form.Customs.Country.Aruba",
                    Afghanistan: "Renderer.Elements.Form.Customs.Country.Afghanistan",
                    Angola: "Renderer.Elements.Form.Customs.Country.Angola",
                    Anguilla: "Renderer.Elements.Form.Customs.Country.Anguilla",
                    "Aland Islands": "Renderer.Elements.Form.Customs.Country.AlandIslands",
                    Albania: "Renderer.Elements.Form.Customs.Country.Albania",
                    Andorra: "Renderer.Elements.Form.Customs.Country.Andorra",
                    "United Arab Emirates": "Renderer.Elements.Form.Customs.Country.UnitedArabEmirates",
                    Argentina: "Renderer.Elements.Form.Customs.Country.Argentina",
                    Armenia: "Renderer.Elements.Form.Customs.Country.Armenia",
                    "American Samoa": "Renderer.Elements.Form.Customs.Country.AmericanSamoa",
                    Antarctica: "Renderer.Elements.Form.Customs.Country.Antarctica",
                    "French Southern Territories": "Renderer.Elements.Form.Customs.Country.FrenchSouthernTerritories",
                    "Antigua and Barbuda": "Renderer.Elements.Form.Customs.Country.AntiguaandBarbuda",
                    Australia: "Renderer.Elements.Form.Customs.Country.Australia",
                    Austria: "Renderer.Elements.Form.Customs.Country.Austria",
                    Azerbaijan: "Renderer.Elements.Form.Customs.Country.Azerbaijan",
                    Burundi: "Renderer.Elements.Form.Customs.Country.Burundi",
                    Belgium: "Renderer.Elements.Form.Customs.Country.Belgium",
                    Benin: "Renderer.Elements.Form.Customs.Country.Benin",
                    "Burkina Faso": "Renderer.Elements.Form.Customs.Country.BurkinaFaso",
                    Bangladesh: "Renderer.Elements.Form.Customs.Country.Bangladesh",
                    Bulgaria: "Renderer.Elements.Form.Customs.Country.Bulgaria",
                    Bahrain: "Renderer.Elements.Form.Customs.Country.Bahrain",
                    Bahamas: "Renderer.Elements.Form.Customs.Country.Bahamas",
                    "Bosnia and Herzegovina": "Renderer.Elements.Form.Customs.Country.BosniaandHerzegovina",
                    "Saint Barth\xE9lemy": "Renderer.Elements.Form.Customs.Country.SaintBarth\xE9lemy",
                    Belarus: "Renderer.Elements.Form.Customs.Country.Belarus",
                    Belize: "Renderer.Elements.Form.Customs.Country.Belize",
                    Bermuda: "Renderer.Elements.Form.Customs.Country.Bermuda",
                    Bolivia: "Renderer.Elements.Form.Customs.Country.Bolivia",
                    Brazil: "Renderer.Elements.Form.Customs.Country.Brazil",
                    Barbados: "Renderer.Elements.Form.Customs.Country.Barbados",
                    "Brunei Darussalam": "Renderer.Elements.Form.Customs.Country.BruneiDarussalam",
                    Bhutan: "Renderer.Elements.Form.Customs.Country.Bhutan",
                    "Bouvet Island": "Renderer.Elements.Form.Customs.Country.BouvetIsland",
                    Botswana: "Renderer.Elements.Form.Customs.Country.Botswana",
                    "Central African Republic": "Renderer.Elements.Form.Customs.Country.CentralAfricanRepublic",
                    Canada: "Renderer.Elements.Form.Customs.Country.Canada",
                    Switzerland: "Renderer.Elements.Form.Customs.Country.Switzerland",
                    Chile: "Renderer.Elements.Form.Customs.Country.Chile",
                    China: "Renderer.Elements.Form.Customs.Country.China",
                    "Cote d'Ivoire": "Renderer.Elements.Form.Customs.Country.CotedIvoire",
                    Cameroon: "Renderer.Elements.Form.Customs.Country.Cameroon",
                    "Congo, the democratic republic of the": "Renderer.Elements.Form.Customs.Country.Congothedemocraticrepublicofthe",
                    Congo: "Renderer.Elements.Form.Customs.Country.Congo",
                    "Cook Islands": "Renderer.Elements.Form.Customs.Country.CookIslands",
                    Colombia: "Renderer.Elements.Form.Customs.Country.Colombia",
                    Comoros: "Renderer.Elements.Form.Customs.Country.Comoros",
                    "Cabo Verde": "Renderer.Elements.Form.Customs.Country.CapeVerde",
                    "Costa Rica": "Renderer.Elements.Form.Customs.Country.CostaRica",
                    Cuba: "Renderer.Elements.Form.Customs.Country.Cuba",
                    Curacao: "Renderer.Elements.Form.Customs.Country.Curacao",
                    "Christmas Island": "Renderer.Elements.Form.Customs.Country.ChristmasIsland",
                    "Cayman Islands": "Renderer.Elements.Form.Customs.Country.CaymanIslands",
                    Cyprus: "Renderer.Elements.Form.Customs.Country.Cyprus",
                    "Czech Republic": "Renderer.Elements.Form.Customs.Country.CzechRepublic",
                    Germany: "Renderer.Elements.Form.Customs.Country.Germany",
                    Djibouti: "Renderer.Elements.Form.Customs.Country.Djibouti",
                    Dominica: "Renderer.Elements.Form.Customs.Country.Dominica",
                    Denmark: "Renderer.Elements.Form.Customs.Country.Denmark",
                    "Dominican Republic": "Renderer.Elements.Form.Customs.Country.DominicanRepublic",
                    Algeria: "Renderer.Elements.Form.Customs.Country.Algeria",
                    Ecuador: "Renderer.Elements.Form.Customs.Country.Ecuador",
                    Egypt: "Renderer.Elements.Form.Customs.Country.Egypt",
                    Eritrea: "Renderer.Elements.Form.Customs.Country.Eritrea",
                    "Western Sahara": "Renderer.Elements.Form.Customs.Country.WesternSahara",
                    Spain: "Renderer.Elements.Form.Customs.Country.Spain",
                    Estonia: "Renderer.Elements.Form.Customs.Country.Estonia",
                    Ethiopia: "Renderer.Elements.Form.Customs.Country.Ethiopia",
                    Finland: "Renderer.Elements.Form.Customs.Country.Finland",
                    Fiji: "Renderer.Elements.Form.Customs.Country.Fiji",
                    "Falkland Islands (Malvinas)": "Renderer.Elements.Form.Customs.Country.FalklandIslandsMalvinas",
                    France: "Renderer.Elements.Form.Customs.Country.France",
                    "Faroe Islands": "Renderer.Elements.Form.Customs.Country.FaroeIslands",
                    "Micronesia, federated states of": "Renderer.Elements.Form.Customs.Country.Micronesiafederatedstatesof",
                    Gabon: "Renderer.Elements.Form.Customs.Country.Gabon",
                    "United Kingdom": "Renderer.Elements.Form.Customs.Country.UnitedKingdom",
                    Georgia: "Renderer.Elements.Form.Customs.Country.Georgia",
                    Guernsey: "Renderer.Elements.Form.Customs.Country.Guernsey",
                    Ghana: "Renderer.Elements.Form.Customs.Country.Ghana",
                    Gibraltar: "Renderer.Elements.Form.Customs.Country.Gibraltar",
                    Guinea: "Renderer.Elements.Form.Customs.Country.Guinea",
                    Guadeloupe: "Renderer.Elements.Form.Customs.Country.Guadeloupe",
                    Gambia: "Renderer.Elements.Form.Customs.Country.Gambia",
                    "Guinea-bissau": "Renderer.Elements.Form.Customs.Country.Guineabissau",
                    "Equatorial Guinea": "Renderer.Elements.Form.Customs.Country.EquatorialGuinea",
                    Greece: "Renderer.Elements.Form.Customs.Country.Greece",
                    Grenada: "Renderer.Elements.Form.Customs.Country.Grenada",
                    Greenland: "Renderer.Elements.Form.Customs.Country.Greenland",
                    Guatemala: "Renderer.Elements.Form.Customs.Country.Guatemala",
                    "French Guiana": "Renderer.Elements.Form.Customs.Country.FrenchGuiana",
                    Guam: "Renderer.Elements.Form.Customs.Country.Guam",
                    Guyana: "Renderer.Elements.Form.Customs.Country.Guyana",
                    "Hong Kong": "Renderer.Elements.Form.Customs.Country.HongKong",
                    "Heard Island and Mcdonald Islands": "Renderer.Elements.Form.Customs.Country.HeardIslandandMcdonaldIslands",
                    Honduras: "Renderer.Elements.Form.Customs.Country.Honduras",
                    Croatia: "Renderer.Elements.Form.Customs.Country.Croatia",
                    Haiti: "Renderer.Elements.Form.Customs.Country.Haiti",
                    Hungary: "Renderer.Elements.Form.Customs.Country.Hungary",
                    Indonesia: "Renderer.Elements.Form.Customs.Country.Indonesia",
                    "Isle of man": "Renderer.Elements.Form.Customs.Country.Isleofman",
                    India: "Renderer.Elements.Form.Customs.Country.India",
                    "British Indian Ocean Territory": "Renderer.Elements.Form.Customs.Country.BritishIndianOceanTerritory",
                    Ireland: "Renderer.Elements.Form.Customs.Country.Ireland",
                    "Iran, Islamic republic of": "Renderer.Elements.Form.Customs.Country.IranIslamicrepublicof",
                    Iraq: "Renderer.Elements.Form.Customs.Country.Iraq",
                    Iceland: "Renderer.Elements.Form.Customs.Country.Iceland",
                    Israel: "Renderer.Elements.Form.Customs.Country.Israel",
                    Italy: "Renderer.Elements.Form.Customs.Country.Italy",
                    Jamaica: "Renderer.Elements.Form.Customs.Country.Jamaica",
                    Jersey: "Renderer.Elements.Form.Customs.Country.Jersey",
                    Jordan: "Renderer.Elements.Form.Customs.Country.Jordan",
                    Japan: "Renderer.Elements.Form.Customs.Country.Japan",
                    Kazakhstan: "Renderer.Elements.Form.Customs.Country.Kazakhstan",
                    Kenya: "Renderer.Elements.Form.Customs.Country.Kenya",
                    Kyrgyzstan: "Renderer.Elements.Form.Customs.Country.Kyrgyzstan",
                    Cambodia: "Renderer.Elements.Form.Customs.Country.Cambodia",
                    Kiribati: "Renderer.Elements.Form.Customs.Country.Kiribati",
                    "Saint Kitts and Nevis": "Renderer.Elements.Form.Customs.Country.SaintKittsandNevis",
                    "Korea, republic of": "Renderer.Elements.Form.Customs.Country.Korearepublicof",
                    Kosovo: "Renderer.Elements.Form.Customs.Country.Kosovo",
                    Kuwait: "Renderer.Elements.Form.Customs.Country.Kuwait",
                    "Lao people's democratic republic": "Renderer.Elements.Form.Customs.Country.Laopeoplesdemocraticrepublic",
                    Lebanon: "Renderer.Elements.Form.Customs.Country.Lebanon",
                    Liberia: "Renderer.Elements.Form.Customs.Country.Liberia",
                    Libya: "Renderer.Elements.Form.Customs.Country.LibyanArabJamahiriya",
                    "Saint Lucia": "Renderer.Elements.Form.Customs.Country.SaintLucia",
                    Liechtenstein: "Renderer.Elements.Form.Customs.Country.Liechtenstein",
                    "Sri Lanka": "Renderer.Elements.Form.Customs.Country.SriLanka",
                    Lesotho: "Renderer.Elements.Form.Customs.Country.Lesotho",
                    Lithuania: "Renderer.Elements.Form.Customs.Country.Lithuania",
                    Luxembourg: "Renderer.Elements.Form.Customs.Country.Luxembourg",
                    Latvia: "Renderer.Elements.Form.Customs.Country.Latvia",
                    Macao: "Renderer.Elements.Form.Customs.Country.Macao",
                    "Saint Martin": "Renderer.Elements.Form.Customs.Country.SaintMartin",
                    Morocco: "Renderer.Elements.Form.Customs.Country.Morocco",
                    Monaco: "Renderer.Elements.Form.Customs.Country.Monaco",
                    "Moldova, republic of": "Renderer.Elements.Form.Customs.Country.Moldovarepublicof",
                    Madagascar: "Renderer.Elements.Form.Customs.Country.Madagascar",
                    Maldives: "Renderer.Elements.Form.Customs.Country.Maldives",
                    Mexico: "Renderer.Elements.Form.Customs.Country.Mexico",
                    "Marshall Islands": "Renderer.Elements.Form.Customs.Country.MarshallIslands",
                    Macedonia: "Renderer.Elements.Form.Customs.Country.Macedoniatheformeryugoslavrepublicof",
                    Mali: "Renderer.Elements.Form.Customs.Country.Mali",
                    Malta: "Renderer.Elements.Form.Customs.Country.Malta",
                    Myanmar: "Renderer.Elements.Form.Customs.Country.Myanmar",
                    Montenegro: "Renderer.Elements.Form.Customs.Country.Montenegro",
                    Mongolia: "Renderer.Elements.Form.Customs.Country.Mongolia",
                    "Northern Mariana Islands": "Renderer.Elements.Form.Customs.Country.NorthernMarianaIslands",
                    Mozambique: "Renderer.Elements.Form.Customs.Country.Mozambique",
                    Mauritania: "Renderer.Elements.Form.Customs.Country.Mauritania",
                    Montserrat: "Renderer.Elements.Form.Customs.Country.Montserrat",
                    Martinique: "Renderer.Elements.Form.Customs.Country.Martinique",
                    Mauritius: "Renderer.Elements.Form.Customs.Country.Mauritius",
                    Malawi: "Renderer.Elements.Form.Customs.Country.Malawi",
                    Malaysia: "Renderer.Elements.Form.Customs.Country.Malaysia",
                    Mayotte: "Renderer.Elements.Form.Customs.Country.Mayotte",
                    Namibia: "Renderer.Elements.Form.Customs.Country.Namibia",
                    "New Caledonia": "Renderer.Elements.Form.Customs.Country.NewCaledonia",
                    Niger: "Renderer.Elements.Form.Customs.Country.Niger",
                    "Norfolk Island": "Renderer.Elements.Form.Customs.Country.NorfolkIsland",
                    Nigeria: "Renderer.Elements.Form.Customs.Country.Nigeria",
                    Nicaragua: "Renderer.Elements.Form.Customs.Country.Nicaragua",
                    Niue: "Renderer.Elements.Form.Customs.Country.Niue",
                    Netherlands: "Renderer.Elements.Form.Customs.Country.Netherlands",
                    Norway: "Renderer.Elements.Form.Customs.Country.Norway",
                    Nepal: "Renderer.Elements.Form.Customs.Country.Nepal",
                    Nauru: "Renderer.Elements.Form.Customs.Country.Nauru",
                    "New Zealand": "Renderer.Elements.Form.Customs.Country.NewZealand",
                    Oman: "Renderer.Elements.Form.Customs.Country.Oman",
                    Pakistan: "Renderer.Elements.Form.Customs.Country.Pakistan",
                    Panama: "Renderer.Elements.Form.Customs.Country.Panama",
                    Peru: "Renderer.Elements.Form.Customs.Country.Peru",
                    Philippines: "Renderer.Elements.Form.Customs.Country.Philippines",
                    Palau: "Renderer.Elements.Form.Customs.Country.Palau",
                    "Papua New Guinea": "Renderer.Elements.Form.Customs.Country.PapuaNewGuinea",
                    Poland: "Renderer.Elements.Form.Customs.Country.Poland",
                    "Puerto Rico": "Renderer.Elements.Form.Customs.Country.PuertoRico",
                    "Korea, democratic people's republic of": "Renderer.Elements.Form.Customs.Country.Koreademocraticpeoplesrepublicof",
                    Portugal: "Renderer.Elements.Form.Customs.Country.Portugal",
                    Paraguay: "Renderer.Elements.Form.Customs.Country.Paraguay",
                    "Palestine, State of": "Renderer.Elements.Form.Customs.Country.Palestinianterritoryoccupied",
                    "French Polynesia": "Renderer.Elements.Form.Customs.Country.FrenchPolynesia",
                    Qatar: "Renderer.Elements.Form.Customs.Country.Qatar",
                    R\ u00E9union: "Renderer.Elements.Form.Customs.Country.R\xE9union",
                    Romania: "Renderer.Elements.Form.Customs.Country.Romania",
                    "Russian Federation": "Renderer.Elements.Form.Customs.Country.RussianFederation",
                    Rwanda: "Renderer.Elements.Form.Customs.Country.Rwanda",
                    "Saudi Arabia": "Renderer.Elements.Form.Customs.Country.SaudiArabia",
                    Sudan: "Renderer.Elements.Form.Customs.Country.Sudan",
                    Senegal: "Renderer.Elements.Form.Customs.Country.Senegal",
                    Singapore: "Renderer.Elements.Form.Customs.Country.Singapore",
                    "Svalbard and Jan Mayen": "Renderer.Elements.Form.Customs.Country.SvalbardandJanMayen",
                    "Solomon Islands": "Renderer.Elements.Form.Customs.Country.SolomonIslands",
                    "Sierra Leone": "Renderer.Elements.Form.Customs.Country.SierraLeone",
                    "El Salvador": "Renderer.Elements.Form.Customs.Country.ElSalvador",
                    "San Marino": "Renderer.Elements.Form.Customs.Country.SanMarino",
                    Somalia: "Renderer.Elements.Form.Customs.Country.Somalia",
                    "Saint Pierre and Miquelon": "Renderer.Elements.Form.Customs.Country.SaintPierreandMiquelon",
                    Serbia: "Renderer.Elements.Form.Customs.Country.Serbia",
                    "South Sudan": "Renderer.Elements.Form.Customs.Country.SouthSudan",
                    "Sao Tome and Principe": "Renderer.Elements.Form.Customs.Country.SaoTomeandPrincipe",
                    Suriname: "Renderer.Elements.Form.Customs.Country.Suriname",
                    Slovakia: "Renderer.Elements.Form.Customs.Country.Slovakia",
                    Slovenia: "Renderer.Elements.Form.Customs.Country.Slovenia",
                    Sweden: "Renderer.Elements.Form.Customs.Country.Sweden",
                    Swaziland: "Renderer.Elements.Form.Customs.Country.Swaziland",
                    "Sint Maarten": "Renderer.Elements.Form.Customs.Country.SintMaarten",
                    Seychelles: "Renderer.Elements.Form.Customs.Country.Seychelles",
                    "Syrian Arab Republic": "Renderer.Elements.Form.Customs.Country.SyrianArabRepublic",
                    "Turks and Caicos Islands": "Renderer.Elements.Form.Customs.Country.TurksandCaicosIslands",
                    Chad: "Renderer.Elements.Form.Customs.Country.Chad",
                    Togo: "Renderer.Elements.Form.Customs.Country.Togo",
                    Thailand: "Renderer.Elements.Form.Customs.Country.Thailand",
                    Tajikistan: "Renderer.Elements.Form.Customs.Country.Tajikistan",
                    Tokelau: "Renderer.Elements.Form.Customs.Country.Tokelau",
                    Turkmenistan: "Renderer.Elements.Form.Customs.Country.Turkmenistan",
                    "Timor-leste": "Renderer.Elements.Form.Customs.Country.Timorleste",
                    Tonga: "Renderer.Elements.Form.Customs.Country.Tonga",
                    "Trinidad and Tobago": "Renderer.Elements.Form.Customs.Country.TrinidadandTobago",
                    Tunisia: "Renderer.Elements.Form.Customs.Country.Tunisia",
                    Turkey: "Renderer.Elements.Form.Customs.Country.Turkey",
                    Tuvalu: "Renderer.Elements.Form.Customs.Country.Tuvalu",
                    Taiwan: "Renderer.Elements.Form.Customs.Country.Taiwan",
                    "Tanzania, United Republic Of": "Renderer.Elements.Form.Customs.Country.TanzaniaUnitedRepublicOf",
                    Uganda: "Renderer.Elements.Form.Customs.Country.Uganda",
                    Ukraine: "Renderer.Elements.Form.Customs.Country.Ukraine",
                    "United States Minor Outlying Islands": "Renderer.Elements.Form.Customs.Country.UnitedStatesMinorOutlyingIslands",
                    Uruguay: "Renderer.Elements.Form.Customs.Country.Uruguay",
                    "United States": "Renderer.Elements.Form.Customs.Country.UnitedStates",
                    Uzbekistan: "Renderer.Elements.Form.Customs.Country.Uzbekistan",
                    "Vatican City State": "Renderer.Elements.Form.Customs.Country.VaticanCityState",
                    "Saint Vincent and the Grenadines": "Renderer.Elements.Form.Customs.Country.SaintVincentandtheGrenadines",
                    "Venezuela, Bolivarian Republic Of": "Renderer.Elements.Form.Customs.Country.VenezuelaBolivarianRepublicOf",
                    "Virgin Islands, British": "Renderer.Elements.Form.Customs.Country.VirginIslandsBritish",
                    "Virgin Islands, U.S.": "Renderer.Elements.Form.Customs.Country.VirginIslandsUS",
                    Vietnam: "Renderer.Elements.Form.Customs.Country.Vietnam",
                    Vanuatu: "Renderer.Elements.Form.Customs.Country.Vanuatu",
                    "Wallis and Futuna": "Renderer.Elements.Form.Customs.Country.WallisandFutuna",
                    Samoa: "Renderer.Elements.Form.Customs.Country.Samoa",
                    Yemen: "Renderer.Elements.Form.Customs.Country.Yemen",
                    "South Africa": "Renderer.Elements.Form.Customs.Country.SouthAfrica",
                    Zambia: "Renderer.Elements.Form.Customs.Country.Zambia",
                    Zimbabwe: "Renderer.Elements.Form.Customs.Country.Zimbabwe",
                    "Bonaire, Sint Eustatius and Saba": "Renderer.Elements.Form.Customs.Country.CaribbeanNetherlands",
                    "South Georgia and the South Sandwich Islands": "Renderer.Elements.Form.Customs.Country.SouthGeorgiaandtheSouthSandwichIslands",
                    "Cocos (Keeling) Islands": "Renderer.Elements.Form.Customs.Country.CocosKeelingIslands",
                    Pitcairn: "Renderer.Elements.Form.Customs.Country.Pitcairn",
                    "Saint Helena, Ascension and Tristan da Cunha": "Renderer.Elements.Form.Customs.Country.SaintHelena"
                }
            }
        },
        SubscriptionForm: {
            Errors: {
                AlreadySubscribed: "Renderer.Elements.SubscriptionForm.Errors.AlreadySubscribed",
                GeneralError: "Renderer.Elements.SubscriptionForm.Errors.GeneralError",
                WrongPhoneNumber: "Renderer.Elements.SubscriptionForm.Errors.WrongPhoneNumber"
            }
        },
        ContactForm: {
            Errors: {
                MessageTooLong: "Renderer.Elements.ContactForm.Errors.MessageTooLong",
                GenericError: "Renderer.Elements.ContactForm.Errors.GenericError"
            }
        },
        WebinarForm: {
            NotAvailableInfo: "Renderer.Elements.WebinarForm.NotAvailableInfo"
        },
        OrderForm: {
            Presentation: {
                MissingProducts: "Renderer.Elements.OrderForm.Presentation.MissingProducts"
            }
        },
        Timer: {
            Days: "Renderer.Elements.Timer.Days",
            Hours: "Renderer.Elements.Timer.Hours",
            Minutes: "Renderer.Elements.Timer.Minutes",
            Seconds: "Renderer.Elements.Timer.Seconds"
        }
    }
};
var Ss;
(function(e) {
    e.Renderer = "WBE.Renderer"
})(Ss || (Ss = {}));
Ss.Renderer;
const uC = e => {
        const {
            clockValue: t,
            label: o,
            textColor: r,
            fontFamily: i,
            fontSize: n,
            isBold: l,
            isItalic: s,
            isUnderline: u,
            borderRadiusBottomLeft: c,
            borderRadiusBottomRight: h,
            borderRadiusTopLeft: m,
            borderRadiusTopRight: g,
            isRadiusEnabled: p,
            borderStyleBottom: b,
            borderStyleLeft: C,
            borderStyleRight: w,
            borderStyleTop: B,
            borderWidthBottom: S,
            borderWidthLeft: $,
            borderWidthRight: L,
            borderWidthTop: M,
            borderColorTop: F,
            borderColorRight: A,
            borderColorLeft: z,
            borderColorBottom: _,
            paddingRight: Z,
            paddingLeft: G,
            paddingBottom: H,
            paddingTop: te,
            isBorderEnabled: oe,
            backgroundColor: re,
            clockTextColor: Q,
            clockFontFamily: J,
            clockFontSize: ee,
            isClockBold: le,
            isClockItalic: ue,
            isClockUnderline: me,
            isActive: ie,
            isPaddingEnabled: Y,
            isLabelsVisible: ae
        } = e;
        return y(iC, {
            globalClassName: I.Timer,
            $inlineMode: ie,
            $backgroundColor: re,
            $borderRadiusTopRight: g,
            $borderRadiusTopLeft: m,
            $borderRadiusBottomRight: h,
            $borderRadiusBottomLeft: c,
            $isRadiusEnabled: p,
            $isBorderEnabled: oe,
            $borderStyleBottom: b,
            $borderStyleLeft: C,
            $borderStyleRight: w,
            $borderStyleTop: B,
            $borderWidthBottom: S,
            $borderWidthLeft: $,
            $borderWidthRight: L,
            $borderWidthTop: M,
            $borderColorTop: F,
            $borderColorRight: A,
            $borderColorLeft: z,
            $borderColorBottom: _,
            children: [a("div", {
                className: "clock-container",
                children: a(aC, {
                    $inlineMode: ie,
                    $isPaddingEnabled: Y,
                    $paddingRight: Z,
                    $paddingLeft: G,
                    $paddingBottom: H,
                    $paddingTop: te,
                    $backgroundColor: re,
                    $textColor: Q,
                    $fontFamily: J,
                    $fontSize: ee,
                    $isBold: le,
                    $isItalic: ue,
                    $isUnderline: me,
                    children: t
                })
            }), ae ? a("div", {
                className: "label-container",
                children: a(lC, {
                    $textColor: r,
                    $fontFamily: i,
                    $fontSize: n,
                    $isBold: l,
                    $isItalic: s,
                    $isUnderline: u,
                    $isLabelsVisible: ae,
                    children: o ? a(zt, {
                        id: o
                    }) : null
                })
            }) : null]
        })
    },
    cC = v.div `
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
`;

function hC(e) {
    const {
        textColor: t,
        fontFamily: o,
        fontSize: r,
        isBold: i,
        isItalic: n,
        isUnderline: l,
        isRadiusLocked: s,
        isBorderEnabled: u,
        borderRadiusBottomLeft: c,
        borderRadiusBottomRight: h,
        borderRadiusTopLeft: m,
        borderRadiusTopRight: g,
        isRadiusEnabled: p,
        borderStyleBottom: b,
        borderStyleLeft: C,
        borderStyleRight: w,
        borderStyleTop: B,
        borderWidthBottom: S,
        borderWidthLeft: $,
        borderWidthRight: L,
        borderWidthTop: M,
        borderColorTop: F,
        borderColorRight: A,
        borderColorLeft: z,
        borderColorBottom: _,
        paddingRight: Z,
        paddingLeft: G,
        paddingBottom: H,
        paddingTop: te,
        isPaddingEnabled: oe,
        backgroundColor: re,
        clockTextColor: Q,
        clockFontFamily: J,
        clockFontSize: ee,
        isClockBold: le,
        isClockItalic: ue,
        isClockUnderline: me,
        isActive: ie,
        isLabelsVisible: Y
    } = e, ae = X => X <= 9 ? `0${X}` : X.toString();
    return a(cC, {
        children: e.items.map(X => a(uC, {
            clockValue: ae(X.value),
            label: X.label,
            textColor: t,
            fontFamily: o,
            fontSize: r,
            isBold: i,
            isItalic: n,
            isUnderline: l,
            isRadiusLocked: s,
            borderRadiusBottomLeft: c,
            borderRadiusBottomRight: h,
            borderRadiusTopLeft: m,
            borderRadiusTopRight: g,
            isRadiusEnabled: p,
            isBorderEnabled: u,
            borderStyleBottom: b,
            borderStyleLeft: C,
            borderStyleRight: w,
            borderStyleTop: B,
            borderWidthBottom: S,
            borderWidthLeft: $,
            borderWidthRight: L,
            borderWidthTop: M,
            borderColorTop: F,
            borderColorRight: A,
            borderColorLeft: z,
            borderColorBottom: _,
            isPaddingEnabled: oe,
            paddingRight: Z,
            paddingLeft: G,
            paddingBottom: H,
            paddingTop: te,
            backgroundColor: re,
            clockTextColor: Q,
            clockFontFamily: J,
            clockFontSize: ee,
            isClockBold: le,
            isClockItalic: ue,
            isClockUnderline: me,
            isActive: ie,
            isLabelsVisible: Y
        }, X.label))
    })
}
const fc = [{
    label: K.Elements.Timer.Days,
    field: Rt.Days
}, {
    label: K.Elements.Timer.Hours,
    field: Rt.Hours
}, {
    label: K.Elements.Timer.Minutes,
    field: Rt.Minutes
}, {
    label: K.Elements.Timer.Seconds,
    field: Rt.Seconds
}];

function Vm(e) {
    const {
        fields: t,
        seconds: o,
        labels: r = fc,
        countdownService: i,
        ...n
    } = e, {
        isEnabled: l
    } = n, [s, u] = f.exports.useState(o), c = b => {
        var C, w, B, S;
        return (S = (w = (C = r.find($ => $.field === b)) === null || C === void 0 ? void 0 : C.label) !== null && w !== void 0 ? w : (B = fc.find($ => $.field === b)) === null || B === void 0 ? void 0 : B.label) !== null && S !== void 0 ? S : "unknown"
    }, h = f.exports.useCallback(() => {
        u(b => Math.max(0, b - 1))
    }, []), m = f.exports.useMemo(() => Q2(s, t), [s, t]), g = yy();
    f.exports.useEffect(() => {
        if (!(!l || !g)) return i.register(h)
    }, [l, i, h, g]), f.exports.useEffect(() => {
        u(o)
    }, [o]);
    const p = [{
        value: m.days,
        field: Rt.Days
    }, {
        value: m.hours,
        field: Rt.Hours
    }, {
        value: m.minutes,
        field: Rt.Minutes
    }, {
        value: m.seconds,
        field: Rt.Seconds
    }].filter(b => t.includes(b.field)).map(b => ({ ...b,
        label: c(b.field)
    }));
    return a(hC, {
        items: p,
        ...n
    })
}
const mC = 1e3;

function bC(e) {
    const {
        date: t,
        timeZoneId: o,
        isEnabled: r,
        fields: i,
        countdownService: n,
        ...l
    } = e, s = f.exports.useMemo(() => {
        const u = q0(o),
            c = new Date(new Date(t).toLocaleString("en-US", {
                timeZone: "UTC"
            })),
            h = new Date(new Date().toLocaleString("en-US", {
                timeZone: u ? u.name : "UTC"
            })),
            m = (c.getTime() - h.getTime()) / mC;
        return Math.max(m, 0)
    }, [t, o]);
    return a(Vm, {
        seconds: s,
        isEnabled: r,
        fields: i,
        countdownService: n,
        ...l
    })
}

function fC(e) {
    const {
        type: t,
        seconds: o,
        date: r,
        timeZoneId: i,
        fields: n,
        countdownService: l,
        isCountdownEnabled: s,
        ...u
    } = e;
    return t === qr.Evergreen ? a(Vm, {
        seconds: o,
        isEnabled: s,
        fields: n,
        countdownService: l,
        ...u
    }) : a(bC, {
        date: r,
        timeZoneId: i,
        countdownService: l,
        isEnabled: s,
        fields: n,
        ...u
    })
}
const gC = v(Ho).attrs(Pt("gallery"))
`
    overflow: hidden;
    display: flex;
    justify-content: center;
    max-width: ${({theme:e})=>`
$ {
    e.globalDesign.contentWidth
}
px `};

    ${Dt}
    .placeholder {
        width: 23%;
        height: 100px;
        text-transform: uppercase;
        background: gray;
        color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        user-select: none;
        font-size: large;
    }
`, pC = v.div.attrs(Ae("grid-gallery", "modal"))
`
  position: fixed;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  z-index: ${Qo.GalleryModal};

  .close-button {
    position: absolute;
    background-color: #000000;
    border-radius: 18px;
    border: 2px solid #ffffff;
    cursor: pointer;
    display: flex;
    padding: 10px;
    justify-content: center;
    align-items: center;
    right: 13px;
    top: 13px;
    z-index: ${Qo.GalleryModal+1};

    &:focus-visible {
      outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }
  }

  .image-wrapper {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  .modal-image {
    width: auto;
    max-width: 100vw;
    height: auto;
    max-height: 100vh;
    margin-bottom: 0;
  }

  .prev,
  .next {
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: ${({isEnableSlideshowScroll:e})=>e?"pointer":"default"};
    position: absolute;
    background-color: black;
    top: 50%;
    width: 33px;
    height: 33px;
    transform: translateY(-50%);
    border-radius: 20px;
    border: 2px solid white;
    text-decoration: none;
    z-index: ${Qo.GalleryModal+1};
    
    &:focus-visible {
      outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }
  }

  .next {
    right: 45px;
  }

  .prev {
    left: 45px;
  }
`, yC = v.div `
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  background-color: rgb(32 39 48 / 80%);
`, la = {
    TAB_KEY: "Tab",
    RIGHT_ARROW_KEY: "ArrowRight",
    LEFT_ARROW_KEY: "ArrowLeft",
    ESCAPE_KEY: "Escape"
}, xC = "a[href], button, textarea, input, select", vC = ({
    elementRef: e,
    enabled: t = !0
}) => {
    const o = f.exports.useCallback(r => {
        const {
            key: i
        } = r;
        if (i !== la.TAB_KEY || !e.current) return;
        const n = Array.from(e.current.querySelectorAll(xC));
        if (n.length) {
            const l = n.indexOf(document.activeElement),
                s = r.shiftKey ? 0 : n.length - 1;
            (l === -1 || l === s) && (n[r.shiftKey ? n.length - 1 : 0].focus(), r.preventDefault())
        }
    }, [e]);
    f.exports.useEffect(() => {
        if (!(!t || !e.current)) return document.addEventListener("keydown", o), () => {
            document.removeEventListener("keydown", o)
        }
    }, [o, t, e])
}, es = {
    isOpen: !1,
    sources: [],
    activeIndex: 0,
    onReject: Gt,
    onResolve: Gt,
    activeElement: null
}, CC = ({
    children: e
}) => {
    var t;
    const [o, r] = f.exports.useState(es), {
        onReject: i,
        onResolve: n,
        isOpen: l,
        sources: s,
        activeIndex: u,
        activeElement: c
    } = o, h = f.exports.useRef(null);
    vC({
        elementRef: h,
        enabled: l
    });
    const m = s[u],
        g = f.exports.useCallback(() => {
            i(fl), r(es), c instanceof HTMLElement && c.focus()
        }, [i, c]),
        p = f.exports.useCallback(S => new Promise(($, L) => {
            r({ ...es,
                ...S,
                isOpen: !0,
                onReject: L,
                onResolve: $
            })
        }), []),
        b = f.exports.useCallback(S => {
            r($ => ({ ...$,
                activeIndex: Bs(S, $.activeIndex, s)
            }))
        }, [s]);
    f.exports.useEffect(() => {
        function S($) {
            $.key === la.ESCAPE_KEY ? (g(), n()) : $.key === la.RIGHT_ARROW_KEY ? b(1) : $.key === la.LEFT_ARROW_KEY && b(-1)
        }
        return document.addEventListener("keyup", S), () => document.removeEventListener("keyup", S)
    }, [g, b, n]);
    const C = f.exports.useCallback(() => b(-1), [b]),
        w = f.exports.useCallback(() => b(1), [b]),
        B = f.exports.useMemo(() => [p, g], [g, p]);
    return y(Om.Provider, {
        value: B,
        children: [l ? y(pC, {
            ref: h,
            children: [a(yC, {
                onClick: g
            }), a("button", {
                onClick: g,
                className: "close-button",
                type: "button",
                ...Ae("grid-gallery", "modal-button-close"),
                children: a(Em, {
                    name: "close",
                    color: "#FFFFFF",
                    size: "small"
                })
            }), a("button", {
                type: "button",
                className: "prev",
                onClick: C,
                ...Ae("slideshow-gallery", "prev"),
                children: a(Am, {})
            }), a("div", {
                className: "image-wrapper",
                children: a("img", {
                    src: (t = m.source) === null || t === void 0 ? void 0 : t.data.src,
                    alt: m.alt,
                    className: "modal-image"
                })
            }), a("button", {
                type: "button",
                className: "next",
                onClick: w,
                ...Ae("slideshow-gallery", "next"),
                children: a(Wm, {})
            })]
        }) : null, e]
    })
}, wC = f.exports.memo(e => {
    var t;
    const {
        galleryType: o
    } = e, r = (t = bc[o]) !== null && t !== void 0 ? t : bc[Ko.Grid];
    return a(Mm.Provider, {
        value: e,
        children: a(CC, {
            children: a(r, {})
        })
    })
}), Xd = e => {
    switch (e) {
        case "number":
            return "number";
        case "datetime":
            return "datetime-local";
        case "date":
            return "date"
    }
    return "text"
}, Ti = v.span `
  pointer-events: none;
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
`, BC = v.input `
  &:focus + ${Ti} {
    display: none;
  }
  
  :not(:focus) {
    color: ${({value:e})=>!e&&"transparent!important"};
  }
`, SC = ({
    placeholder: e,
    ...t
}) => y(ir, {
    children: [a(BC, { ...t
    }), t.value ? null : a(Ti, {
        className: e ? "hasInInputPlaceholder" : void 0,
        children: e || a(zt, {
            id: K.Elements.Form.InputDate.Placeholder
        })
    })]
}), $C = v.input ``, RC = ({
    onChange: e,
    name: t,
    requiredMarker: o,
    value: r = [""],
    readOnly: i,
    onFocus: n,
    onBlur: l,
    valueType: s,
    min: u,
    max: c,
    ...h
}) => {
    const m = x.useCallback(S => {
            e([S.target.value])
        }, [e]),
        g = x.useCallback(() => {
            n(t)
        }, [n, t]),
        p = x.useCallback(() => {
            l(t)
        }, [l, t]),
        b = Xd(s),
        w = ["date", "datetime-local"].includes(b) ? SC : $C,
        B = h.placeholder ? `${h.placeholder} ${o||""}` : void 0;
    return a(w, {
        name: t,
        placeholder: B,
        value: r[0],
        min: u,
        max: c,
        onFocus: g,
        onBlur: i ? void 0 : p,
        onChange: m,
        readOnly: i,
        type: b,
        "data-ats-form-field": t,
        "data-ats-form-field-type": "input"
    })
}, PC = v.div `
  display: flex;
  margin-top: 2px;
  
  &:focus-visible .checkbox {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }

  &> label {
    line-height: 1.1;
  }
`, FC = ({
    onChange: e,
    label: t,
    readOnly: o,
    index: r,
    value: i,
    onFocus: n,
    name: l
}) => {
    const s = x.useCallback(() => {
            e([t])
        }, [e, t]),
        u = x.useCallback(() => {
            n(l)
        }, [n, l]),
        c = x.useCallback(m => {
            !o && m.key === Tr.SpaceBar && e([t])
        }, [t, e, o]),
        h = r === 0 && o ? !0 : i.includes(t);
    return y(PC, {
        onClick: o ? void 0 : s,
        onKeyDown: c,
        tabIndex: 0,
        onFocus: u,
        children: [a("input", {
            name: l,
            id: t,
            value: t,
            type: "radio",
            checked: h,
            onChange: nh,
            "data-ats-form-field": l,
            "data-ats-form-field-type": "radio"
        }), y("label", {
            children: [a("div", {
                className: "checkbox rounded",
                children: a("div", {
                    className: "checkbox-checked rounded"
                })
            }), t]
        })]
    })
}, IC = ({
    onChange: e,
    name: t,
    readOnly: o,
    formFieldId: r,
    value: i,
    onFocus: n,
    defaultValues: l,
    mappedValues: s
}) => a(ir, {
    children: l.map((u, c) => a(FC, {
        readOnly: o,
        name: t,
        onChange: e,
        label: s ? s[c] : u,
        index: c,
        value: i,
        onFocus: n
    }, r + u))
}), Hm = v.div `
  margin-top: 2px;
  
  &:focus-visible .checkbox {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
  
  &> label {
    line-height: 1.1;
  }
`, Kd = () => a("svg", {
    width: "100",
    height: "73",
    viewBox: "0 0 100 73",
    xmlns: "http://www.w3.org/2000/svg",
    children: a("path", {
        d: "m87.41982, 0.48292l-48.55452, 48.55452l-26.41012, -26.40993l-11.83019, 11.83019l38.2403, 38.2403l60.3847, -60.3847l-11.83019, -11.83038z"
    })
}), jm = ({
    onChange: e,
    label: t,
    readOnly: o,
    isChecked: r,
    onFocus: i,
    onBlur: n,
    htmlLabel: l,
    name: s,
    value: u
}) => {
    const c = x.useCallback(() => {
            i(s)
        }, [i, s]),
        h = x.useCallback(() => {
            n(s)
        }, [n, s]),
        m = x.useCallback(g => {
            !o && g.key === Tr.SpaceBar && e()
        }, [e, o]);
    return y(Hm, {
        "data-ats-form-control": "checkbox",
        onClick: o ? void 0 : e,
        onKeyDown: m,
        tabIndex: 0,
        onFocus: c,
        onBlur: o ? void 0 : h,
        children: [a("input", {
            id: u,
            value: u,
            type: "checkbox",
            onChange: nh,
            checked: r,
            "data-ats-form-field": s,
            "data-ats-form-field-type": "checkbox"
        }), y("label", {
            children: [a("div", {
                className: "checkbox",
                children: r ? a(Kd, {}) : null
            }), l ? a("span", {
                dangerouslySetInnerHTML: {
                    __html: u
                },
                "data-ats-form-control-checkbox-label": u
            }) : a("span", {
                "data-ats-form-control-checkbox-label": u,
                children: t
            })]
        })]
    })
}, kC = ({
    defaultValues: e,
    onChange: t,
    readOnly: o,
    value: r,
    onFocus: i,
    onBlur: n,
    name: l,
    mappedValues: s
}) => {
    const u = f.exports.useCallback(c => {
        const h = r.includes(c) ? r.filter(m => m !== c) : [...r, c];
        t(h)
    }, [t, r]);
    return a(ir, {
        children: e.map((c, h) => {
            const m = h === 0 && o ? !0 : r.includes(c);
            return a(TC, {
                readOnly: o,
                onChange: u,
                name: l,
                label: s ? s[h] : c,
                value: c,
                isChecked: m,
                onFocus: i,
                onBlur: n
            }, l + c)
        })
    })
};

function TC({
    onChange: e,
    ...t
}) {
    const o = f.exports.useCallback(() => e(t.value), [e, t.value]);
    return a(jm, { ...t,
        onChange: o
    })
}
const EC = v.textarea `
    ${({readOnly:e})=>e&&"resize: none"};
`,
    LC = ({
        onChange: e,
        requiredMarker: t,
        placeholder: o,
        name: r,
        value: i = [""],
        readOnly: n,
        onFocus: l,
        onBlur: s
    }) => {
        const u = x.useCallback(m => {
                e([m.target.value])
            }, [e]),
            c = x.useCallback(() => {
                l(r)
            }, [l, r]),
            h = x.useCallback(() => {
                s(r)
            }, [s, r]);
        return a("div", {
            className: "text_wrapper",
            children: a(EC, {
                name: r,
                placeholder: o ? `${o} ${t||""}` : void 0,
                value: i[0],
                onChange: u,
                readOnly: n,
                onFocus: c,
                onBlur: n ? void 0 : h,
                "data-ats-form-field": r,
                "data-ats-form-field-type": "textarea",
                rows: 2
            })
        })
    },
    zm = () => a("svg", {
        viewBox: "0 0 24 24",
        "aria-hidden": "true",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: a("path", {
            d: "M7.41 7.84 12 12.42l4.59-4.58L18 9.25l-6 6-6-6 1.41-1.41Z",
            fill: "currentColor"
        })
    }),
    MC = (e, t) => e ? Array.from(t.target.options).reduce((r, i) => !i.selected || i.disabled ? r : [...r, i.value], []) : [t.target.value],
    OC = v.select `
    ${km};
    padding-right: 20px;
`,
    AC = v.div `
    display: inline-flex;
    pointer-events: none;
    width: 20px;
    height: 21px;
    position: absolute;
    right: 4px;
`,
    gc = ({
        onChange: e,
        requiredMarker: t,
        defaultValues: o,
        readOnly: r,
        placeholder: i,
        multiple: n = !1,
        formFieldId: l,
        name: s,
        onFocus: u,
        onBlur: c,
        mappedValues: h
    }) => {
        const m = Yd(),
            g = x.useCallback(C => {
                e(MC(n, C))
            }, [e, n]),
            p = x.useCallback(() => {
                u(s)
            }, [u, s]),
            b = x.useCallback(() => {
                c(s)
            }, [c, s]);
        return y("div", {
            className: "select_wrapper",
            children: [y(OC, {
                readOnly: r,
                multiple: n,
                onChange: g,
                onFocus: p,
                onBlur: r ? void 0 : b,
                "data-ats-form-field": s,
                "data-ats-form-field-type": "select",
                children: [i ? a("option", {
                    disabled: !0,
                    value: "",
                    selected: !0,
                    "data-ats-form-select-field": "custom-placeholder",
                    children: `${i} ${t||""}`
                }) : a("option", {
                    disabled: !0,
                    value: "",
                    selected: !0,
                    "data-ats-form-select-field": "placeholder",
                    children: m.translateString(K.Elements.Form.Select.Placeholder)
                }), o.map((C, w) => a("option", {
                    value: C,
                    "data-ats-form-select-option": C,
                    children: h ? h[w] : C
                }, l + C))]
            }), a(AC, {
                children: a(zm, {})
            })]
        })
    },
    sa = P `
    ${e=>uo({$textColor:e.labelTextColor,$fontFamily:e.labelFontFamily,$fontSize:e.labelFontSize,$isBold:e.labelIsBold,$isItalic:e.labelIsItalic,$isUnderline:e.labelIsUnderline})}
`,
    WC = v.label `
    display: inline-block;
    margin-bottom: 5px;
    line-height: 1.1;
    ${sa};
`,
    Kn = P `
  font-family: ${({fieldFontFamily:e})=>e};
  font-size: ${({fieldFontSize:e})=>e}px;
  font-weight: ${({fieldIsBold:e})=>e?"bold":"normal"};
  font-style: ${({fieldIsItalic:e})=>e?"italic":"normal"};
  text-decoration: ${({fieldIsUnderline:e})=>e?"underline":"none"};
  color: ${({fieldTextColor:e})=>e};
`,
    pc = P `
  ${({fieldShadowOffsetX:e,fieldShadowOffsetY:t,fieldShadowBlurRadius:o,fieldShadowSpreadRadius:r,fieldShadowColor:i,isFieldShadowEnabled:n})=>n?`
box - shadow:
    $ {
        e
    }
px
$ {
    t
}
px
$ {
    o
}
px
$ {
    r
}
px
$ {
    i
};
`:null}
`, yc = P `
  ${({fieldPaddingTop:e,fieldPaddingLeft:t,fieldPaddingRight:o,fieldPaddingBottom:r})=>`
padding: $ {
    e
}
px $ {
    o
}
px $ {
    r
}
px $ {
    t
}
px;
`}
`, DC = P `
  ${({fieldBorderWidthTop:e,fieldBorderWidthLeft:t,fieldBorderWidthRight:o,fieldBorderWidthBottom:r})=>`
border - top - width: $ {
    e
}
px;
border - left - width: $ {
    t
}
px;
border - right - width: $ {
    o
}
px;
border - bottom - width: $ {
    r
}
px;
`}
`, xc = P `
  ${({fieldBorderColorTop:e,fieldBorderColorLeft:t,fieldBorderColorRight:o,fieldBorderColorBottom:r})=>`
border - top - color: $ {
    e
};
border - left - color: $ {
    t
};
border - right - color: $ {
    o
};
border - bottom - color: $ {
    r
};
`}`, NC = P `
  ${({fieldBorderStyleTop:e,fieldBorderStyleLeft:t,fieldBorderStyleRight:o,fieldBorderStyleBottom:r})=>`
border - top - style: $ {
    e
};
border - left - style: $ {
    t
};
border - right - style: $ {
    o
};
border - bottom - style: $ {
    r
};
`}`, UC = P `
  ${({fieldBorderRadiusTopLeft:e,fieldBorderRadiusTopRight:t,fieldBorderRadiusBottomLeft:o,fieldBorderRadiusBottomRight:r,isFieldBorderRadiusEnabled:i})=>i?`
border - radius: $ {
    e
}
px
$ {
    t
}
px
$ {
    o
}
px
$ {
    r
}
px;
`:"-webkit-border-radius: initial;"}`, Jt = {
    small: 4,
    medium: 9,
    large: 19
}, ts = {
    small: 10,
    medium: 15,
    large: 20
}, VC = P `
  ${({fieldBorderRadiusTopLeft:e,fieldBorderRadiusTopRight:t,fieldBorderRadiusBottomLeft:o,fieldBorderRadiusBottomRight:r,isFieldBorderRadiusEnabled:i,fieldPaddingTop:n})=>i?e>Jt.large||t>Jt.large||o>Jt.large||r>Jt.large?n<ts.large?"padding: 10px 20px;":"padding: inherit 10px;":e>Jt.medium||t>Jt.medium||o>Jt.medium||r>Jt.medium?n<ts.medium?"padding: 8px 15px;":"padding: inherit 8px;":e>Jt.small||t>Jt.small||o>Jt.small||r>Jt.small?n<ts.small?"padding: 5px 10px;":"padding: inherit 5px;":"":""}
`, oa = 10, _m = .3, HC = {
    [be.TopLeft]: "flex-start",
    [be.CenterCenter]: "center"
};

function os(e) {
    return e > oa ? Math.round((e - oa) * _m + oa) : oa
}
const Gm = v.div `
    ${Kn};  
    width: ${({fieldWidth:e})=>e}%;
    margin: 5px auto 2px;

    @media (max-width: 900px) {
        width: 100%;
    }
  
    ${Ti} {
      ${Kn};
      ${yc};
      
      &.hasInInputPlaceholder {
        ${sa};
      }
    }

    input[type='text'],
    .text_wrapper,
    .select_wrapper,
    input[type='date'],
    input[type='datetime-local'],
    input[type='number'] {
        -webkit-appearance: none;
        ${Kn};
        ${pc};
        ${yc};
        ${DC};
        ${xc};
        ${NC};
        ${UC};
        &::placeholder {
            ${sa};     
            opacity: 1;
        }

        ${({isFieldBorderEnabled:e})=>e?"":"border:none;"}
        display: block;
        width: 100%;
        background-color: ${({fieldBackgroundColor:e})=>e};
    }

    select, option, textarea{
      ${Kn};
    }

    .select_wrapper, .text_wrapper{
        ${VC};
    }
    
    .select_wrapper {
        display: flex;
        position: relative;
        align-items: center;
    }

    select, textarea {
        border: none;
        display: block;
        width: 100%;
        background-color: ${({fieldBackgroundColor:e})=>e};
        appearance: none;
        overflow: auto;

        &::placeholder {
            ${sa};
        }
    }
    textarea {
      min-height: 60px;
      -webkit-appearance: none;
      max-width: 100%;
      min-width: 100%;
    }
    
    a {
        color: inherit;
        font-weight: ${({consentLinkIsBold:e})=>e?"bold":"normal"};
        font-style: ${({consentLinkIsItalic:e})=>e?"italic":"normal"};
        text-decoration: ${({consentLinkIsUnderline:e})=>e?"underline":"none"};
    }
  
   a: hover {
        color: inherit;
        font-weight: ${({consentLinkHoverIsBold:e})=>e?"bold":"normal"};
        font-style: ${({consentLinkHoverIsItalic:e})=>e?"italic":"normal"};
        text-decoration: ${({consentLinkHoverIsUnderline:e})=>e?"underline":"none"};
   }
   
    input[type='radio'],
    input[type='checkbox'] {
        display: none;

        & + label {
            ${Kn};
            display: flex;
            margin: 0 5px;
            align-items: ${({align:e})=>HC[e]};
            white-space: normal;

        & .checkbox {
                flex: none;
                width: ${({fieldFontSize:e})=>os(e)}px;
                height: ${({fieldFontSize:e})=>os(e)}px;
                margin-top: ${({fieldFontSize:e,align:t})=>t===be.TopLeft?(e-os(e))/2:0}px;
                background-color: ${({fieldBackgroundColor:e})=>e};
                border-width: 1px;
                border-style: solid;

                ${({isFieldBorderEnabled:e})=>e?xc:"border:none;"}
                margin-right: ${({fieldFontSize:e})=>Math.round(e*_m)}px;
                position: relative;
                ${pc};
              

                svg {
                    width: 100%;
                    height: 100%;
                    fill: ${({fieldTextColor:e})=>e};
                    position: absolute;
                    padding: 1px;
                }
            }

            & .rounded {
                border-radius: 100%;
            }
        }
     
        &:checked + label .checkbox .checkbox-checked {
            background-color: ${({fieldTextColor:e})=>e};
            position: absolute;
            top: 2px;
            bottom: 2px;
            left: 2px;
            right: 2px;

            & .rounded {
                border-radius: 100%;
            }
        }
   }
   
  select, option, textarea, a, input {
     line-height: 1.2;
     box-sizing: border-box;
    &:focus-visible {
      outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }
  }
}
`,
    Zm = v.div `
    min-height: 13px;
    color: ${({$fieldErrorColor:e})=>e};
    font-size: 13px;
    margin: 3px auto 12px;
    font-family: ${({$fieldFontFamily:e})=>e};
`;

function vc(e) {
    if ("is" in e) return rs(e.is);
    if ("truthy" in e) return rs(e.truthy);
    if ("falsy" in e) return !rs(e.falsy);
    throw new Error("Failed to resolve boolean from props")
}

function rs(e) {
    return typeof e == "function" ? e() : e
}

function jC(e) {
    throw new Error("<Else/> should be rendered inside <If/> component")
}

function zC(e) {
    throw new Error("<ElseIf/> should be rendered inside <If/> component")
}

function qm(e) {
    return Ym(e, jC)
}

function Jm(e) {
    return Ym(e, zC)
}

function Ym(e, t) {
    return e ? .type === t
}

function Xm(e) {
    return x.Children.toArray(e).filter(o => qm(o) || Jm(o))
}

function _C(e, t = Xm(e)) {
    return x.Children.toArray(e).filter(r => !t.some(i => i.type === r.type))
}

function Km(e) {
    const t = Xm(e.children);
    if (vc(e)) return ns(_C(e.children, t));
    for (const o of t) {
        if (Jm(o)) {
            if (vc(o.props)) return ns(o.props.children);
            continue
        }
        if (qm(o)) return ns(o.props.children)
    }
    return null
}

function ns(e) {
    return a(ir, {
        children: e
    })
}
var In;
(function(e) {
    e[e.Vertical = 0] = "Vertical", e[e.Horizontal = 1] = "Horizontal"
})(In || (In = {}));
const GC = v.div `
    position: relative;
`;

function Qd(e) {
    return y(Gm, {
        fieldFontFamily: e.fieldFontFamily,
        fieldFontSize: e.fieldFontSize,
        fieldIsBold: e.fieldIsBold,
        fieldIsItalic: e.fieldIsItalic,
        fieldIsUnderline: e.fieldIsUnderline,
        fieldTextColor: e.fieldTextColor,
        fieldWidth: e.fieldWidth,
        fieldPaddingTop: e.fieldPaddingTop,
        fieldPaddingLeft: e.fieldPaddingLeft,
        fieldPaddingRight: e.fieldPaddingRight,
        fieldPaddingBottom: e.fieldPaddingBottom,
        fieldBorderRadiusTopLeft: e.fieldBorderRadiusTopLeft,
        fieldBorderRadiusTopRight: e.fieldBorderRadiusTopRight,
        fieldBorderRadiusBottomLeft: e.fieldBorderRadiusBottomLeft,
        fieldBorderRadiusBottomRight: e.fieldBorderRadiusBottomRight,
        isFieldBorderRadiusEnabled: e.isFieldBorderRadiusEnabled,
        labelFontFamily: e.labelFontFamily,
        labelFontSize: e.labelFontSize,
        labelIsBold: e.labelIsBold,
        labelIsItalic: e.labelIsItalic,
        labelIsUnderline: e.labelIsUnderline,
        labelTextColor: e.labelTextColor,
        fieldBorderColorTop: e.fieldBorderColorTop,
        fieldBorderColorLeft: e.fieldBorderColorLeft,
        fieldBorderColorRight: e.fieldBorderColorRight,
        fieldBorderColorBottom: e.fieldBorderColorBottom,
        fieldBorderStyleTop: e.fieldBorderStyleTop,
        fieldBorderStyleLeft: e.fieldBorderStyleLeft,
        fieldBorderStyleRight: e.fieldBorderStyleRight,
        fieldBorderStyleBottom: e.fieldBorderStyleBottom,
        isFieldBorderEnabled: e.isFieldBorderEnabled,
        fieldBorderWidthTop: e.fieldBorderWidthTop,
        fieldBorderWidthLeft: e.fieldBorderWidthLeft,
        fieldBorderWidthRight: e.fieldBorderWidthRight,
        fieldBorderWidthBottom: e.fieldBorderWidthBottom,
        fieldBackgroundColor: e.fieldBackgroundColor,
        fieldShadowColor: e.fieldShadowColor,
        fieldShadowBlurRadius: e.fieldShadowBlurRadius,
        fieldShadowOffsetX: e.fieldShadowOffsetX,
        fieldShadowOffsetY: e.fieldShadowOffsetY,
        fieldShadowOpacity: e.fieldShadowOpacity,
        fieldShadowSpreadRadius: e.fieldShadowSpreadRadius,
        isFieldShadowEnabled: e.isFieldShadowEnabled,
        isFieldPaddingLocked: e.isFieldPaddingLocked,
        consentLinkIsBold: e.consentLinkIsBold,
        consentLinkIsItalic: e.consentLinkIsItalic,
        consentLinkIsUnderline: e.consentLinkIsUnderline,
        consentLinkHoverIsBold: e.consentLinkHoverIsBold,
        consentLinkHoverIsItalic: e.consentLinkHoverIsItalic,
        consentLinkHoverIsUnderline: e.consentLinkHoverIsUnderline,
        align: e.align,
        children: [e.label ? a(WC, {
            labelFontFamily: e.labelFontFamily,
            labelFontSize: e.labelFontSize,
            labelIsBold: e.labelIsBold,
            labelIsItalic: e.labelIsItalic,
            labelIsUnderline: e.labelIsUnderline,
            labelTextColor: e.labelTextColor,
            children: `${e.label} ${e.requiredMarker||""}`
        }) : null, a(GC, {
            children: e.children
        }), a(Km, {
            is: e.orientation === In.Vertical || !!e.fieldErrorMessage,
            children: a(Zm, {
                $fieldErrorColor: e.fieldErrorColor,
                $fieldFontFamily: e.fieldFontFamily,
                "data-ats-form-field-error": e.name,
                children: e.fieldErrorMessage ? a(zt, {
                    id: e.fieldErrorMessage
                }) : null
            })
        })]
    })
}
const ZC = v.div `
  display: flex;
  flex-direction: column;
  width: ${({fieldWidth:e})=>e}%;
  margin: auto;
  align-items: ${({$align:e})=>ux.get(e)};
  
  @media (max-width: 900px) {
    width: 100%;
  }
`,
    qC = v.div `
  width: 150px;
  position: relative;
  top: 5px;
  z-index: 1;
  white-space: normal;
  word-break: break-word;
`,
    JC = v.div `
  width: 10px;
  height: 10px;
  margin: auto;
  transform: rotate(-45deg);
  background-color: #000;
  border-top: solid 1px ${({$borderColor:e})=>e};
  border-right: solid 1px ${({$borderColor:e})=>e};
`,
    YC = v.div `
  position: absolute;
  width: 100%;
  text-align: center;
  top: 5px;
`,
    XC = v.div `
  position: absolute;
  border: white;
  color: #fff;
  padding: 10px;
  width: 100%;
  background-color: #000;
  top: 10px;
  text-align: center;
  border-radius: 3px;
  font-size: 14px;
  border: solid 1px ${({$borderColor:e})=>e};
`,
    KC = v.div `
  width: 80px;
  height: ${({$buttonFontSize:e})=>e}px;

  svg {
    width: ${({$buttonFontSize:e})=>e}px;
    height: ${({$buttonFontSize:e})=>e}px;
    fill: ${({$textSuccessColor:e})=>e};
  }
`;

function QC({
    message: e,
    backgroundColor: t,
    borderColor: o,
    textColor: r
}) {
    return y(qC, {
        children: [a(XC, {
            $textColor: r,
            $backgroundColor: t,
            $borderColor: o,
            children: e
        }), a(YC, {
            children: a(JC, {
                $backgroundColor: t,
                $borderColor: o
            })
        })]
    })
}

function ew(e) {
    const {
        onChange: t
    } = e, o = x.useCallback(() => {
        const i = e.value.includes(e.formFieldId) ? e.value.filter(n => n !== e.formFieldId) : [...e.value, e.formFieldId];
        t(i)
    }, [t, e.formFieldId, e.value]), r = e.value.includes(e.formFieldId);
    return a(Qd, {
        fieldBorderRadiusTopLeft: e.fieldBorderRadiusTopLeft,
        fieldBorderRadiusTopRight: e.fieldBorderRadiusTopRight,
        fieldBorderRadiusBottomLeft: e.fieldBorderRadiusBottomLeft,
        fieldBorderRadiusBottomRight: e.fieldBorderRadiusBottomRight,
        isFieldBorderRadiusEnabled: e.isFieldBorderRadiusEnabled,
        labelFontFamily: e.labelFontFamily,
        labelFontSize: e.labelFontSize,
        labelIsBold: e.labelIsBold,
        labelIsItalic: e.labelIsItalic,
        labelIsUnderline: e.labelIsUnderline,
        labelTextColor: e.labelTextColor,
        fieldTextColor: e.fieldTextColor,
        fieldFontFamily: e.fieldFontFamily,
        fieldFontSize: e.fieldFontSize,
        fieldIsBold: e.fieldIsBold,
        fieldIsItalic: e.fieldIsItalic,
        fieldIsUnderline: e.fieldIsUnderline,
        fieldWidth: e.fieldWidth,
        fieldPaddingTop: e.fieldPaddingTop,
        fieldPaddingLeft: e.fieldPaddingLeft,
        fieldPaddingRight: e.fieldPaddingRight,
        fieldPaddingBottom: e.fieldPaddingBottom,
        fieldBorderColorTop: e.fieldBorderColorTop,
        fieldBorderColorLeft: e.fieldBorderColorLeft,
        fieldBorderColorRight: e.fieldBorderColorRight,
        fieldBorderColorBottom: e.fieldBorderColorBottom,
        fieldBorderStyleTop: e.fieldBorderStyleTop,
        fieldBorderStyleLeft: e.fieldBorderStyleLeft,
        fieldBorderStyleRight: e.fieldBorderStyleRight,
        fieldBorderStyleBottom: e.fieldBorderStyleBottom,
        isFieldBorderEnabled: e.isFieldBorderEnabled,
        fieldBorderWidthTop: e.fieldBorderWidthTop,
        fieldBorderWidthLeft: e.fieldBorderWidthLeft,
        fieldBorderWidthRight: e.fieldBorderWidthRight,
        fieldBorderWidthBottom: e.fieldBorderWidthBottom,
        fieldBackgroundColor: e.fieldBackgroundColor,
        fieldShadowColor: e.fieldShadowColor,
        fieldShadowBlurRadius: e.fieldShadowBlurRadius,
        fieldShadowOffsetX: e.fieldShadowOffsetX,
        fieldShadowOffsetY: e.fieldShadowOffsetY,
        fieldShadowOpacity: e.fieldShadowOpacity,
        fieldShadowSpreadRadius: e.fieldShadowSpreadRadius,
        isFieldShadowEnabled: e.isFieldShadowEnabled,
        isFieldPaddingLocked: e.isFieldPaddingLocked,
        fieldErrorColor: e.fieldErrorColor,
        fieldErrorMessage: e.fieldErrorMessage,
        consentLinkIsBold: e.consentLinkIsBold,
        consentLinkIsItalic: e.consentLinkIsItalic,
        consentLinkIsUnderline: e.consentLinkIsUnderline,
        consentLinkHoverIsBold: e.consentLinkHoverIsBold,
        consentLinkHoverIsItalic: e.consentLinkHoverIsItalic,
        consentLinkHoverIsUnderline: e.consentLinkHoverIsUnderline,
        align: be.TopLeft,
        orientation: e.orientation,
        name: e.name,
        children: a(jm, {
            name: e.name,
            onFocus: e.onFocus,
            onBlur: e.onBlur,
            isChecked: r,
            value: e.label,
            label: e.label,
            onChange: o,
            readOnly: e.readOnly,
            htmlLabel: !0
        })
    })
}
var Do;
(function(e) {
    e.Gdpr = "gdpr", e.Field = "field"
})(Do || (Do = {}));
const is = "#FFFFFF",
    Cc = "#2ec761";

function tw(e) {
    return e.latestVersionContent !== void 0
}
const ow = (e, t) => {
    const o = [];
    return e.required && o.push(q2(() => K.Elements.Form.Errors.Required)), tw(e) || (e.name === "email" && o.push(N2(() => K.Elements.Form.Errors.EmailInvalid)), e.valueType === "phone" && t && o.push(j2(() => K.Elements.Form.Errors.PhoneInvalid)), e.valueType === "url" && t && o.push(W2({
        protocol: "",
        allowEmpty: !0
    }, () => K.Elements.Form.Errors.UrlInvalid)), e.valueType === "ip" && t && o.push(G2(() => K.Elements.Form.Errors.IpInvalid)), (e.valueType === Pe.Date || e.valueType === Pe.Datetime && t) && o.push(J2(e.min, e.max, () => K.Elements.Form.Errors.DateRangeInvalid))), A2(...o)
};

function kn(e, t) {
    const o = ow(e, t),
        r = o ? .(t);
    return r ? {
        fieldName: e.name,
        message: r
    } : null
}
const wc = ({
        required: e,
        type: t,
        text: o
    }) => {
        const r = t === rn.Asterix ? "*" : o;
        return e ? r : void 0
    },
    rw = v.form.attrs({
        noValidate: !0
    })
`
    ${nw}
`;

function nw(e) {
    return e.$orientation === In.Vertical ? "" : P `
        display: flex;
        align-items: center;
        
        > *:not(:last-child) {
            margin-right: 10px;
        }
    `
}
const iw = dt(rw);

function aw(e) {
    return a(Qd, {
        fieldBorderRadiusTopLeft: e.fieldBorderRadiusTopLeft,
        fieldBorderRadiusTopRight: e.fieldBorderRadiusTopRight,
        fieldBorderRadiusBottomLeft: e.fieldBorderRadiusBottomLeft,
        fieldBorderRadiusBottomRight: e.fieldBorderRadiusBottomRight,
        isFieldBorderRadiusEnabled: e.isFieldBorderRadiusEnabled,
        labelFontFamily: e.labelFontFamily,
        labelFontSize: e.labelFontSize,
        labelIsBold: e.labelIsBold,
        labelIsItalic: e.labelIsItalic,
        labelIsUnderline: e.labelIsUnderline,
        labelTextColor: e.labelTextColor,
        fieldTextColor: e.fieldTextColor,
        fieldFontFamily: e.fieldFontFamily,
        fieldFontSize: e.fieldFontSize,
        fieldIsBold: e.fieldIsBold,
        fieldIsItalic: e.fieldIsItalic,
        fieldIsUnderline: e.fieldIsUnderline,
        fieldWidth: e.fieldWidth,
        fieldPaddingTop: e.fieldPaddingTop,
        fieldPaddingLeft: e.fieldPaddingLeft,
        fieldPaddingRight: e.fieldPaddingRight,
        fieldPaddingBottom: e.fieldPaddingBottom,
        fieldBorderColorTop: e.fieldBorderColorTop,
        fieldBorderColorLeft: e.fieldBorderColorLeft,
        fieldBorderColorRight: e.fieldBorderColorRight,
        fieldBorderColorBottom: e.fieldBorderColorBottom,
        fieldBorderStyleTop: e.fieldBorderStyleTop,
        fieldBorderStyleLeft: e.fieldBorderStyleLeft,
        fieldBorderStyleRight: e.fieldBorderStyleRight,
        fieldBorderStyleBottom: e.fieldBorderStyleBottom,
        isFieldBorderEnabled: e.isFieldBorderEnabled,
        fieldBorderWidthTop: e.fieldBorderWidthTop,
        fieldBorderWidthLeft: e.fieldBorderWidthLeft,
        fieldBorderWidthRight: e.fieldBorderWidthRight,
        fieldBorderWidthBottom: e.fieldBorderWidthBottom,
        fieldBackgroundColor: e.fieldBackgroundColor,
        fieldShadowColor: e.fieldShadowColor,
        fieldShadowBlurRadius: e.fieldShadowBlurRadius,
        fieldShadowOffsetX: e.fieldShadowOffsetX,
        fieldShadowOffsetY: e.fieldShadowOffsetY,
        fieldShadowOpacity: e.fieldShadowOpacity,
        fieldShadowSpreadRadius: e.fieldShadowSpreadRadius,
        isFieldShadowEnabled: e.isFieldShadowEnabled,
        isFieldPaddingLocked: e.isFieldPaddingLocked,
        fieldErrorColor: e.fieldErrorColor,
        consentLinkIsBold: e.consentLinkIsBold,
        consentLinkIsItalic: e.consentLinkIsItalic,
        consentLinkIsUnderline: e.consentLinkIsUnderline,
        consentLinkHoverIsBold: e.consentLinkHoverIsBold,
        consentLinkHoverIsItalic: e.consentLinkHoverIsItalic,
        consentLinkHoverIsUnderline: e.consentLinkHoverIsUnderline,
        align: be.TopLeft,
        orientation: e.orientation,
        name: "reCaptchaBadge",
        children: a(zt, {
            id: K.Elements.Form.Recaptcha.BadgeLabel,
            values: {
                privacyLink: (...t) => x.createElement("a", {
                    href: "https://policies.google.com/privacy",
                    target: "_blank",
                    rel: "noreferrer nofollow noopener"
                }, ...t),
                termsLink: (...t) => x.createElement("a", {
                    href: "https://policies.google.com/terms",
                    target: "_blank",
                    rel: "noreferrer nofollow noopener"
                }, ...t)
            }
        })
    })
}

function lw(e) {
    return a(Gm, {
        fieldFontFamily: e.fieldFontFamily,
        fieldFontSize: e.fieldFontSize,
        fieldIsBold: e.fieldIsBold,
        fieldIsItalic: e.fieldIsItalic,
        fieldIsUnderline: e.fieldIsUnderline,
        fieldTextColor: e.fieldTextColor,
        fieldWidth: e.fieldWidth,
        fieldPaddingTop: e.fieldPaddingTop,
        fieldPaddingLeft: e.fieldPaddingLeft,
        fieldPaddingRight: e.fieldPaddingRight,
        fieldPaddingBottom: e.fieldPaddingBottom,
        fieldBorderRadiusTopLeft: e.fieldBorderRadiusTopLeft,
        fieldBorderRadiusTopRight: e.fieldBorderRadiusTopRight,
        fieldBorderRadiusBottomLeft: e.fieldBorderRadiusBottomLeft,
        fieldBorderRadiusBottomRight: e.fieldBorderRadiusBottomRight,
        isFieldBorderRadiusEnabled: e.isFieldBorderRadiusEnabled,
        labelFontFamily: e.labelFontFamily,
        labelFontSize: e.labelFontSize,
        labelIsBold: e.labelIsBold,
        labelIsItalic: e.labelIsItalic,
        labelIsUnderline: e.labelIsUnderline,
        labelTextColor: e.labelTextColor,
        fieldBorderColorTop: e.fieldBorderColorTop,
        fieldBorderColorLeft: e.fieldBorderColorLeft,
        fieldBorderColorRight: e.fieldBorderColorRight,
        fieldBorderColorBottom: e.fieldBorderColorBottom,
        fieldBorderStyleTop: e.fieldBorderStyleTop,
        fieldBorderStyleLeft: e.fieldBorderStyleLeft,
        fieldBorderStyleRight: e.fieldBorderStyleRight,
        fieldBorderStyleBottom: e.fieldBorderStyleBottom,
        isFieldBorderEnabled: e.isFieldBorderEnabled,
        fieldBorderWidthTop: e.fieldBorderWidthTop,
        fieldBorderWidthLeft: e.fieldBorderWidthLeft,
        fieldBorderWidthRight: e.fieldBorderWidthRight,
        fieldBorderWidthBottom: e.fieldBorderWidthBottom,
        fieldBackgroundColor: e.fieldBackgroundColor,
        fieldShadowColor: e.fieldShadowColor,
        fieldShadowBlurRadius: e.fieldShadowBlurRadius,
        fieldShadowOffsetX: e.fieldShadowOffsetX,
        fieldShadowOffsetY: e.fieldShadowOffsetY,
        fieldShadowOpacity: e.fieldShadowOpacity,
        fieldShadowSpreadRadius: e.fieldShadowSpreadRadius,
        isFieldShadowEnabled: e.isFieldShadowEnabled,
        isFieldPaddingLocked: e.isFieldPaddingLocked,
        consentLinkIsBold: e.consentLinkIsBold,
        consentLinkIsItalic: e.consentLinkIsItalic,
        consentLinkIsUnderline: e.consentLinkIsUnderline,
        consentLinkHoverIsBold: e.consentLinkHoverIsBold,
        consentLinkHoverIsItalic: e.consentLinkHoverIsItalic,
        consentLinkHoverIsUnderline: e.consentLinkHoverIsUnderline,
        align: e.align,
        children: a(Zm, {
            $fieldErrorColor: e.fieldErrorColor,
            $fieldFontFamily: e.fieldFontFamily,
            children: a(zt, {
                id: e.errorMessage
            })
        })
    })
}
const Qm = (e, t) => {
        const o = t.getIntl();
        return { ...e,
            mappedValues: e.defaultValues.map(r => o.translateString(K.Elements.Form.Customs[e.valueType][r]))
        }
    },
    sw = (e, t) => {
        if (e.mappedValues) {
            const o = e.defaultValues.map((r, i) => ({
                value: r,
                mappedValue: e.mappedValues[i]
            })).sort((r, i) => r.mappedValue.localeCompare(i.mappedValue, t));
            return { ...e,
                mappedValues: o.map(r => r.mappedValue),
                defaultValues: o.map(r => r.value)
            }
        }
        return e
    },
    dw = (e, t) => {
        const o = t.getLocale(),
            r = Qm(e, t);
        return sw(r, o)
    },
    uw = new Map([
        [Pe.Country, dw],
        [Pe.Gender, Qm]
    ]);

function Bc(e, t) {
    return { ...e,
        id: `${t}-${e.id}`,
        originId: e.id,
        fieldType: t
    }
}
const cw = {
        text: RC,
        textarea: LC,
        checkbox: kC,
        radio: IC,
        single_select: gc,
        multi_select: e => a(gc, { ...e,
            multiple: !0
        })
    },
    hw = [Je.Checkbox, Je.Radio];

function eb(e) {
    return e.format === "text" || e.format === "textarea" ? e.defaultValues : []
}
const as = (e, t) => {
    var o;
    const r = e.fieldType === Do.Field;
    return ((o = t[e.id]) === null || o === void 0 ? void 0 : o.map(i => i.trim())) || (r ? eb(e) : [])
};

function mw({
    formFields: e,
    message: t,
    successViewMethod: o,
    isSubmitted: r,
    onSubmit: i,
    isSubmitting: n = !1,
    readOnly: l = !1,
    fieldTextColor: s,
    fieldFontFamily: u,
    fieldFontSize: c,
    fieldIsBold: h,
    fieldIsItalic: m,
    fieldIsUnderline: g,
    labelPlacement: p,
    requiredInputMarkerType: b,
    requiredInputMarkerText: C,
    labelFontFamily: w,
    labelFontSize: B,
    labelIsBold: S,
    labelIsItalic: $,
    labelIsUnderline: L,
    labelTextColor: M,
    fieldPaddingTop: F,
    fieldPaddingLeft: A,
    fieldPaddingRight: z,
    fieldPaddingBottom: _,
    fieldWidth: Z,
    fieldBorderRadiusTopLeft: G,
    fieldBorderRadiusTopRight: H,
    fieldBorderRadiusBottomLeft: te,
    fieldBorderRadiusBottomRight: oe,
    isFieldBorderRadiusEnabled: re,
    fieldBorderColorTop: Q,
    fieldBorderColorLeft: J,
    fieldBorderColorRight: ee,
    fieldBorderColorBottom: le,
    fieldBorderStyleTop: ue,
    fieldBorderStyleLeft: me,
    fieldBorderStyleRight: ie,
    fieldBorderStyleBottom: Y,
    isFieldBorderEnabled: ae,
    fieldBorderWidthTop: X,
    fieldBorderWidthLeft: ge,
    fieldBorderWidthRight: ce,
    fieldBorderWidthBottom: de,
    fieldBackgroundColor: ne,
    fieldShadowColor: Se,
    fieldShadowBlurRadius: Fe,
    fieldShadowOffsetX: $e,
    fieldShadowOffsetY: Ie,
    fieldShadowOpacity: xe,
    fieldShadowSpreadRadius: ke,
    fieldErrorColor: Le,
    isFieldShadowEnabled: We,
    buttonBackgroundColor: Ke,
    buttonBackgroundHoverColor: at,
    buttonBorderColorBottom: wt,
    buttonBorderColorLeft: ht,
    buttonBorderColorRight: Bt,
    buttonBorderColorTop: tt,
    buttonBorderEnabled: mt,
    buttonBorderRadiusBottomLeft: yt,
    buttonBorderRadiusBottomRight: xt,
    buttonBorderRadiusTopLeft: Ft,
    buttonBorderRadiusTopRight: vt,
    isButtonRadiusEnabled: St,
    buttonBorderStyleBottom: Ut,
    buttonBorderStyleLeft: Vt,
    buttonBorderStyleRight: eo,
    buttonBorderStyleTop: Fo,
    buttonBorderWidthBottom: mo,
    buttonBorderWidthLeft: Io,
    buttonBorderWidthRight: qt,
    buttonBorderWidthTop: dr,
    buttonFontColor: ur,
    buttonFontColorHover: cr,
    buttonFontFamily: bo,
    buttonFontSize: ko,
    buttonInternalPaddingBottom: hr,
    buttonInternalPaddingLeft: Fl,
    buttonInternalPaddingRight: Il,
    buttonInternalPaddingTop: kl,
    buttonShadowBlurRadius: Tl,
    buttonShadowColor: El,
    buttonShadowOffsetX: Ll,
    buttonShadowOffsetY: Ai,
    buttonShadowOpacity: Wi,
    buttonShadowSpreadRadius: Ml,
    isButtonFontBold: Ol,
    isButtonFontItalic: Al,
    isButtonFontUnderLine: Vn,
    isButtonShadowEnabled: Wl,
    buttonAlign: Hn,
    buttonText: Dl,
    isFieldPaddingLocked: Ar,
    areGDPRSEnabled: Nl,
    isRecaptchaEnabled: Ul,
    consentFontFamily: zo,
    consentFontSize: _o,
    consentLinkIsBold: jn,
    consentLinkIsItalic: zn,
    consentLinkIsUnderline: _n,
    consentLinkHoverIsBold: Gn,
    consentLinkHoverIsItalic: Zn,
    consentLinkHoverIsUnderline: qn,
    formFieldErrors: mr = Ku,
    onBeforeValidate: Di = Gt,
    formRef: Vl,
    isActive: Hl,
    className: Tu,
    ...br
}) {
    const [Ht, Ni] = x.useState({}), [to, fr] = x.useState(mr), [Wr, Ui] = x.useState(mr), Vi = Nl ? br.gdprFormFields : Ku, Hi = Jd(), ji = x.useMemo(() => e.map(U => {
        const it = uw.get(U.valueType);
        return it ? it(U, Hi) : U
    }), [e, Hi]), To = x.useMemo(() => [...ji.map(U => Bc(U, Do.Field)), ...Vi.map(U => Bc(U, Do.Gdpr))], [ji, Vi]), zi = x.useCallback((U, it) => It => {
        Ni({ ...Ht,
            [U]: It
        }), Ui(Wr.filter(lt => lt.fieldName !== it))
    }, [Ht, Wr]), _i = x.useCallback(U => {
        fr(to.filter(it => it.fieldName !== U))
    }, [to]), Gi = x.useCallback(U => {
        const it = To.find(kt => kt.name === U),
            It = as(it, Ht),
            lt = kn(it, It[0]);
        if (lt) fr([...to, lt]);
        else {
            const kt = Wr.find(Tt => Tt.fieldName === U);
            kt && fr([...to, kt])
        }
    }, [To, to, Wr, Ht]), jl = x.useCallback(U => {
        if (U.preventDefault(), l) return;
        Di();
        const it = To.reduce((lt, kt) => {
            const Tt = as(kt, Ht),
                Dr = kn(kt, Tt[0]);
            return Dr ? [...lt, Dr] : lt
        }, []);
        if (fr(it), it.length > 0) return;
        const It = To.map(lt => ({
            id: lt.originId,
            fieldType: lt.fieldType,
            name: lt.name,
            value: as(lt, Ht)
        }));
        i(It)
    }, [l, Di, To, Ht, i]), zl = l ? "auto" : "pointer", Zi = n || to.filter(U => U.fieldName).length > 0;
    return x.useEffect(() => {
        r && Object.keys(Ht).length && Ni({})
    }, [r, Ht]), x.useEffect(() => {
        fr(mr), Ui(mr)
    }, [mr]), y(iw, {
        onSubmit: jl,
        ref: Vl,
        $orientation: br.orientation,
        globalClassName: I.Form,
        children: [To.filter(U => U.fieldType === Do.Field).map(U => {
            var it, It;
            const lt = cw[U.format],
                kt = wc({
                    required: U.required,
                    type: b,
                    text: C
                }),
                Tt = to.find(Dr => Dr.fieldName === U.name);
            return a(Qd, {
                fieldBorderRadiusTopLeft: G,
                fieldBorderRadiusTopRight: H,
                fieldBorderRadiusBottomLeft: te,
                fieldBorderRadiusBottomRight: oe,
                isFieldBorderRadiusEnabled: re,
                labelFontFamily: w,
                labelFontSize: B,
                labelIsBold: S,
                labelIsItalic: $,
                labelIsUnderline: L,
                labelTextColor: M,
                fieldTextColor: s,
                fieldFontFamily: u,
                fieldFontSize: c,
                fieldIsBold: h,
                fieldIsItalic: m,
                fieldIsUnderline: g,
                requiredMarker: kt,
                fieldWidth: Z,
                fieldPaddingTop: F,
                fieldPaddingLeft: A,
                fieldPaddingRight: z,
                fieldPaddingBottom: _,
                fieldBorderColorTop: Tt ? Le : Q,
                fieldBorderColorLeft: Tt ? Le : J,
                fieldBorderColorRight: Tt ? Le : ee,
                fieldBorderColorBottom: Tt ? Le : le,
                fieldBorderStyleTop: ue,
                fieldBorderStyleLeft: me,
                fieldBorderStyleRight: ie,
                fieldBorderStyleBottom: Y,
                isFieldBorderEnabled: ae,
                fieldBorderWidthTop: X,
                fieldBorderWidthLeft: ge,
                fieldBorderWidthRight: ce,
                fieldBorderWidthBottom: de,
                fieldBackgroundColor: ne,
                fieldShadowColor: Se,
                fieldShadowBlurRadius: Fe,
                fieldShadowOffsetX: $e,
                fieldShadowOffsetY: Ie,
                fieldShadowOpacity: xe,
                fieldShadowSpreadRadius: ke,
                isFieldShadowEnabled: We,
                fieldErrorColor: Le,
                label: p === Yo.AboveInput || hw.includes(U.format) ? U.label : void 0,
                isFieldPaddingLocked: Ar,
                fieldErrorMessage: Tt ? Tt.message : "",
                align: be.CenterCenter,
                orientation: br.orientation,
                name: U.name,
                children: a(lt, {
                    requiredMarker: p === Yo.InInput ? kt : void 0,
                    placeholder: p === Yo.InInput ? U.label : void 0,
                    onChange: zi(U.id, U.name),
                    onFocus: _i,
                    onBlur: Gi,
                    name: U.name,
                    value: Ht[U.id] || eb(U),
                    readOnly: l,
                    defaultValues: U.defaultValues,
                    formFieldId: U.id,
                    min: (it = U.min) !== null && it !== void 0 ? it : void 0,
                    max: (It = U.max) !== null && It !== void 0 ? It : void 0,
                    mappedValues: U.mappedValues,
                    valueType: U.valueType
                })
            }, U.id)
        }), To.filter(({
            fieldType: U
        }) => U === Do.Gdpr).map((U, it) => {
            const It = wc({
                    required: U.required,
                    type: b,
                    text: C
                }),
                lt = to.find(Tt => Tt.fieldName === U.name),
                kt = `${U.latestVersionContent}${It?` ${It}`:""}`;
            return a(ew, {
                name: U.name,
                label: kt,
                fieldErrorColor: Le,
                fieldErrorMessage: lt ? lt.message : "",
                fieldBorderRadiusTopLeft: G,
                fieldBorderRadiusTopRight: H,
                fieldBorderRadiusBottomLeft: te,
                fieldBorderRadiusBottomRight: oe,
                isFieldBorderRadiusEnabled: re,
                labelFontFamily: zo,
                labelFontSize: _o,
                labelIsBold: S,
                labelIsItalic: $,
                labelIsUnderline: L,
                labelTextColor: M,
                fieldTextColor: s,
                fieldFontFamily: zo,
                fieldFontSize: _o,
                fieldIsBold: h,
                fieldIsItalic: m,
                fieldIsUnderline: g,
                fieldWidth: Z,
                fieldPaddingTop: F,
                fieldPaddingLeft: A,
                fieldPaddingRight: z,
                fieldPaddingBottom: _,
                fieldBorderColorTop: Q,
                fieldBorderColorLeft: J,
                fieldBorderColorRight: ee,
                fieldBorderColorBottom: le,
                fieldBorderStyleTop: ue,
                fieldBorderStyleLeft: me,
                fieldBorderStyleRight: ie,
                fieldBorderStyleBottom: Y,
                isFieldBorderEnabled: ae,
                fieldBorderWidthTop: X,
                fieldBorderWidthLeft: ge,
                fieldBorderWidthRight: ce,
                fieldBorderWidthBottom: de,
                fieldBackgroundColor: ne,
                fieldShadowColor: Se,
                fieldShadowBlurRadius: Fe,
                fieldShadowOffsetX: $e,
                fieldShadowOffsetY: Ie,
                fieldShadowOpacity: xe,
                fieldShadowSpreadRadius: ke,
                isFieldShadowEnabled: We,
                isFieldPaddingLocked: Ar,
                onChange: zi(U.id, U.name),
                readOnly: l,
                formFieldId: U.id,
                onFocus: _i,
                onBlur: Gi,
                value: it === 0 && l ? [U.id] : Ht[U.id] || [],
                consentLinkIsBold: jn,
                consentLinkIsItalic: zn,
                consentLinkIsUnderline: _n,
                consentLinkHoverIsBold: Gn,
                consentLinkHoverIsItalic: Zn,
                consentLinkHoverIsUnderline: qn,
                orientation: br.orientation
            }, U.id)
        }), a(Km, {
            is: Ul,
            children: a(aw, {
                fieldErrorColor: Le,
                fieldBorderRadiusTopLeft: G,
                fieldBorderRadiusTopRight: H,
                fieldBorderRadiusBottomLeft: te,
                fieldBorderRadiusBottomRight: oe,
                isFieldBorderRadiusEnabled: re,
                labelFontFamily: zo,
                labelFontSize: _o,
                labelIsBold: S,
                labelIsItalic: $,
                labelIsUnderline: L,
                labelTextColor: M,
                fieldTextColor: s,
                fieldFontFamily: zo,
                fieldFontSize: _o,
                fieldIsBold: h,
                fieldIsItalic: m,
                fieldIsUnderline: g,
                fieldWidth: Z,
                fieldPaddingTop: F,
                fieldPaddingLeft: A,
                fieldPaddingRight: z,
                fieldPaddingBottom: _,
                fieldBorderColorTop: Q,
                fieldBorderColorLeft: J,
                fieldBorderColorRight: ee,
                fieldBorderColorBottom: le,
                fieldBorderStyleTop: ue,
                fieldBorderStyleLeft: me,
                fieldBorderStyleRight: ie,
                fieldBorderStyleBottom: Y,
                isFieldBorderEnabled: ae,
                fieldBorderWidthTop: X,
                fieldBorderWidthLeft: ge,
                fieldBorderWidthRight: ce,
                fieldBorderWidthBottom: de,
                fieldBackgroundColor: ne,
                fieldShadowColor: Se,
                fieldShadowBlurRadius: Fe,
                fieldShadowOffsetX: $e,
                fieldShadowOffsetY: Ie,
                fieldShadowOpacity: xe,
                fieldShadowSpreadRadius: ke,
                isFieldShadowEnabled: We,
                isFieldPaddingLocked: Ar,
                consentLinkIsBold: jn,
                consentLinkIsItalic: zn,
                consentLinkIsUnderline: _n,
                consentLinkHoverIsBold: Gn,
                consentLinkHoverIsItalic: Zn,
                consentLinkHoverIsUnderline: qn,
                orientation: br.orientation
            })
        }), to.filter(U => !U.fieldName).map(U => a(lw, {
            fieldErrorColor: Le,
            fieldBorderRadiusTopLeft: G,
            fieldBorderRadiusTopRight: H,
            fieldBorderRadiusBottomLeft: te,
            fieldBorderRadiusBottomRight: oe,
            isFieldBorderRadiusEnabled: re,
            labelFontFamily: zo,
            labelFontSize: _o,
            labelIsBold: S,
            labelIsItalic: $,
            labelIsUnderline: L,
            labelTextColor: M,
            fieldTextColor: s,
            fieldFontFamily: zo,
            fieldFontSize: _o,
            fieldIsBold: h,
            fieldIsItalic: m,
            fieldIsUnderline: g,
            fieldWidth: Z,
            fieldPaddingTop: F,
            fieldPaddingLeft: A,
            fieldPaddingRight: z,
            fieldPaddingBottom: _,
            fieldBorderColorTop: Q,
            fieldBorderColorLeft: J,
            fieldBorderColorRight: ee,
            fieldBorderColorBottom: le,
            fieldBorderStyleTop: ue,
            fieldBorderStyleLeft: me,
            fieldBorderStyleRight: ie,
            fieldBorderStyleBottom: Y,
            isFieldBorderEnabled: ae,
            fieldBorderWidthTop: X,
            fieldBorderWidthLeft: ge,
            fieldBorderWidthRight: ce,
            fieldBorderWidthBottom: de,
            fieldBackgroundColor: ne,
            fieldShadowColor: Se,
            fieldShadowBlurRadius: Fe,
            fieldShadowOffsetX: $e,
            fieldShadowOffsetY: Ie,
            fieldShadowOpacity: xe,
            fieldShadowSpreadRadius: ke,
            isFieldShadowEnabled: We,
            isFieldPaddingLocked: Ar,
            consentLinkIsBold: jn,
            consentLinkIsItalic: zn,
            consentLinkIsUnderline: _n,
            consentLinkHoverIsBold: Gn,
            consentLinkHoverIsItalic: Zn,
            consentLinkHoverIsUnderline: qn,
            errorMessage: U.message,
            align: be.TopLeft
        }, U.message)), y(ZC, {
            fieldWidth: Z,
            $align: Hn,
            children: [a(xm, {
                $inlineMode: Hl,
                $backgroundColor: r ? Cc : Ke,
                $borderColorBottom: wt,
                $borderColorLeft: ht,
                $borderColorRight: Bt,
                $borderColorTop: tt,
                $shadowColor: El,
                $textColor: r ? is : ur,
                $paddingRight: Il,
                $paddingLeft: Fl,
                $paddingBottom: hr,
                $paddingTop: kl,
                $fontFamily: bo,
                $align: Hn,
                $borderRadiusBottomLeft: yt,
                $borderRadiusBottomRight: xt,
                $borderRadiusTopLeft: Ft,
                $borderRadiusTopRight: vt,
                $isRadiusEnabled: St,
                $borderStyleBottom: Ut,
                $borderStyleLeft: Vt,
                $borderStyleRight: eo,
                $borderStyleTop: Fo,
                $borderWidthBottom: mo,
                $borderWidthLeft: Io,
                $borderWidthRight: qt,
                $borderWidthTop: dr,
                $boxBorderRadiusBottomLeft: yt,
                $boxBorderRadiusBottomRight: xt,
                $boxBorderRadiusTopLeft: Ft,
                $boxBorderRadiusTopRight: vt,
                $fontSize: ko,
                $isBold: Ol,
                $isBorderEnabled: mt,
                $isItalic: Al,
                $isShadowEnabled: Wl,
                $isUnderline: Vn,
                $shadowBlurRadius: Tl,
                $shadowOffsetX: Ll,
                $shadowOffsetY: Ai,
                $shadowOpacity: Wi,
                $shadowSpreadRadius: Ml,
                $backgroundColorHover: r ? Cc : at,
                $textColorHover: r ? is : cr,
                $boxBorderStyleBottom: "none",
                $boxBorderStyleLeft: "none",
                $boxBorderStyleRight: "none",
                $boxBorderStyleTop: "none",
                $boxBorderWidthBottom: 0,
                $boxBorderWidthLeft: 0,
                $boxBorderWidthRight: 0,
                $boxBorderWidthTop: 0,
                $boxPaddingBottom: 0,
                $boxPaddingLeft: 0,
                $boxPaddingRight: 0,
                $boxPaddingTop: 0,
                $boxShadowBlurRadius: 0,
                $boxShadowColor: "transparent",
                $boxShadowOffsetX: 0,
                $boxShadowOffsetY: 0,
                $boxShadowOpacity: 0,
                $boxShadowSpreadRadius: 0,
                $boxBackgroundColor: "transparent",
                $isBoxBorderEnabled: !1,
                $isBoxShadowEnabled: !1,
                $isBoxPaddingEnabled: !1,
                $isBoxRadiusEnabled: !1,
                $boxBorderColorRight: "transparent",
                $boxBorderColorLeft: "transparent",
                $boxBorderColorBottom: "transparent",
                $boxBorderColorTop: "transparent",
                $cursor: zl,
                $disabled: Zi,
                children: a("button", {
                    type: "submit",
                    value: "Submit",
                    disabled: Zi,
                    children: a("span", {
                        children: r ? a(KC, {
                            $buttonFontSize: ko,
                            $textSuccessColor: is,
                            children: a(Kd, {})
                        }) : Dl
                    })
                })
            }), r && o === So.ShowMessage && t ? a(QC, {
                backgroundColor: s,
                borderColor: ne,
                textColor: ne,
                message: t
            }) : null]
        })]
    })
}
const bw = v.div.attrs(Ae("cookie-banner", "container"))
`
    background: #FFFFFF;
    padding: 20px;
    margin-top: 30px;
    display: flex;
    ${({$isRounded:e})=>e?"border-radius: 8px;":""}
    align-items: center;

    @media (max-width: 600px) {
        & {
            flex-flow: column;
        }
      
        && .controls {
            margin: 15px 0 0 0;
        }
    }

    .cookie-content {
        flex: 1;
        font-weight: 400;
        font-family: Roboto, Helvetica, Arial, sans-serif;
        font-size: 13px;
        letter-spacing: 0.025em;
        line-height: 1.2em;
    }

    button {
        background: rgb(32, 39, 48);
        border-radius: 5px;
        box-shadow: rgb(0 0 0 / 15%) 2px 2px 5px 1px, rgb(255 255 255) -2px -2px 3px 1px;
        height: 35px;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
        color: rgb(254, 255, 255);
        padding: 0 25px;
        margin: 0 15px;

        :hover {
            background: rgb(0, 186, 255);
        }
    }

    a {
        cursor: pointer;

        :hover {
            color: #2f79ea;
        }
    }

    .controls {
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 15px;

        > *:not(:last-child) {
            margin-right: 25px;
        }
    }
    
    a, .decline {
        text-decoration: none;
        
        :hover {
            text-decoration: underline;
        }
    }

    a, .decline,
    :is(a, .decline):hover {
        color: #00BAFF;
    }
`;
var Tn;
(function(e) {
    class t {
        constructor(i) {
            Object.defineProperty(this, "content", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: i
            })
        }
    }
    e.Text = t;
    class o {
        constructor(i, n, l) {
            Object.defineProperty(this, "name", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: void 0
            }), Object.defineProperty(this, "arg", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: void 0
            }), Object.defineProperty(this, "content", {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: void 0
            }), this.name = i, this.arg = n, this.content = l
        }
    }
    e.Decoration = o
})(Tn || (Tn = {}));
class ra extends Error {
    constructor(t, o) {
        super(`${o} at ${t}`), Object.defineProperty(this, "charIndex", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.charIndex = t
    }
}
class fw {
    constructor() {
        Object.defineProperty(this, "name", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "arg", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "content", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        })
    }
    withName(t) {
        return this.name = t, this
    }
    withArg(t) {
        return this.arg = t, this
    }
    withContent(t) {
        return this.content = t, this
    }
    withChild(t) {
        return this.content || (this.content = []), this.content.push(t), this
    }
    build() {
        return new Tn.Decoration(this.name, this.arg, this.content)
    }
}
class Sc {
    constructor(t, o) {
        Object.defineProperty(this, "lastIndex", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "content", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
}
class gw {
    constructor(t, o) {
        Object.defineProperty(this, "lastIndex", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "decoration", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
}
class Lt {
    parse(t) {
        return this.parseInternal(t).content
    }
    parseDecoration(t, o, r, i) {
        const n = this.parseInternal(t, i + 1, o),
            l = new fw().withName(o).withArg(r).withContent(n.content).build();
        return new gw(n.lastIndex, l)
    }
    parseInternal(t, o = 0, r = null) {
        let i = !1,
            n = !1,
            l = !1,
            s = !1,
            u = -1,
            c = null,
            h = null,
            m = o;
        const g = [];
        for (let b = o; b < t.length; b++) {
            const C = t[b];
            if (!l && C === Lt.BlockStart) {
                if (i || n || s) throw new ra(b, "Unexpected block start character");
                const w = t.substring(m, b);
                w.length > 0 && g.push(new Tn.Text(w)), t[b + 1] === Lt.BlockClose ? (s = !0, b++) : (i = !0, h = null), u = b
            } else if (i && C === Lt.ArgValue) c = t.substring(u + 1, b), i = !1, n = !0, u = b;
            else if (n && b === u + 1 && C === Lt.ArgEscape) l = !0, u = b;
            else if (l && n && C === Lt.ArgEscape) {
                if (t[b + 1] !== Lt.BlockEnd) throw new ra(b, "Invalid end sequence");
                l = !1, h = t.substring(u + 1, b)
            } else if (!l && (n || i || s) && C === Lt.BlockEnd) {
                if (s && r !== null) {
                    const B = t.substring(u + 1, b);
                    if (c === null && B === r) return new Sc(b, g);
                    if (c === B) throw new ra(b, "Unexpected bbcode close tag")
                } else i ? c = t.substring(u + 1, b) : n && h === null && (h = t.substring(u + 1, b));
                n = i = !1, u = -1;
                const w = this.parseDecoration(t, c, h, b);
                b = w.lastIndex + 1, m = b, g.push(w.decoration), c = h = null
            }
        }
        if (i || n || l || s) throw new ra(t.length, "Unexpected end of string");
        const p = t.substring(m);
        return p.length > 0 && g.push(new Tn.Text(p)), new Sc(t.length, g)
    }
}
Object.defineProperty(Lt, "BlockStart", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: "["
});
Object.defineProperty(Lt, "BlockEnd", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: "]"
});
Object.defineProperty(Lt, "ArgValue", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: "="
});
Object.defineProperty(Lt, "ArgEscape", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: '"'
});
Object.defineProperty(Lt, "BlockClose", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: "/"
});

function $c(e, t) {
    try {
        return e.parse(t)
    } catch (o) {
        console.warn(o)
    }
    return null
}
const pw = ["http:", "https:"];

function $s(e) {
    return a(ir, {
        children: e.content.map((t, o) => {
            var r;
            if (t instanceof Tn.Text) return a("span", {
                children: t.content
            }, `${o}:text`);
            const i = a($s, {
                    content: t.content,
                    isClickable: e.isClickable
                }, `${o}:parsed`),
                n = (r = t.arg) === null || r === void 0 ? void 0 : r.toLowerCase();
            return t.name.toLowerCase() === "url" && n !== void 0 && pw.some(l => n.startsWith(l)) ? a("a", {
                href: n,
                rel: "noopener",
                target: "_blank",
                onClick: e.isClickable ? void 0 : Wd,
                children: i
            }, `${o}:anchor`) : i
        })
    })
}

function yw(e) {
    var t, o;
    const {
        onConfirm: r,
        onReject: i
    } = e, n = f.exports.useCallback(m => {
        m.preventDefault(), r ? .()
    }, [r]), l = f.exports.useCallback(m => {
        m.preventDefault(), i ? .()
    }, [i]), s = f.exports.useMemo(() => new Lt, []), u = f.exports.useMemo(() => $c(s, e.title), [s, e.title]), c = f.exports.useMemo(() => $c(s, e.message), [s, e.message]), h = (t = e.isClickable) !== null && t !== void 0 ? t : !0;
    return y(bw, {
        $isRounded: (o = e.isRounded) !== null && o !== void 0 ? o : !1,
        children: [y("div", {
            className: "cookie-content",
            children: [a("strong", {
                "data-ats-cookie-banner": "title",
                children: u ? a($s, {
                    content: u,
                    isClickable: h
                }) : e.title
            }), a("div", {
                "data-ats-cookie-banner": "message",
                children: c ? a($s, {
                    content: c,
                    isClickable: h
                }) : e.message
            })]
        }), y("div", {
            className: "controls",
            children: [a("a", {
                className: "decline",
                onClick: l,
                href: "#",
                "data-ats-cookie-banner": "decline",
                children: e.decline
            }), a("button", {
                onClick: n,
                type: "button",
                "data-ats-cookie-banner": "confirm",
                children: e.button
            })]
        })]
    })
}

function xw({
    $isAdjustToWidth: e,
    theme: t,
    width: o,
    height: r
}) {
    if (e) {
        const i = o && r ? Number(o) / Number(r) : 1;
        return P `
            @media ${ze(t.globalDesign.contentWidth)} {
                align-self: flex-start;
                width: 100%;
                min-width: 100%;
                height: auto;
                ${i?`aspect-ratio: ${i}`:null};
            }
        `
    }
    return ""
}
const vw = v.img.attrs(e => ({
    loading: e.$isLazyLoadingEnabled ? "lazy" : void 0,
    decoding: e.$isLazyLoadingEnabled ? "async" : void 0
}))
`
    width: ${({width:e})=>e}px;
    height: ${({height:e})=>e}px;
    vertical-align: middle;
    ${({$isStretched:e})=>e&&"width: 100%; height: 100%;"};

    &:focus-visible {
        outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }

    ${xw};
`, Cw = v.div.attrs(ve(["$opacity", "$align"]))
`
    position: relative;
    width: 100%;
    height: auto;
    display: flex;
    justify-content: ${({$align:e})=>e?Nd.get(e):void 0};
    ${({$hasOverflow:e})=>!e&&"overflow: hidden;"}
    
    img {
        opacity: calc(${({$opacity:e})=>e}/100);
    }

    ${Ro}
    ${Dt}
`, ww = dt(Cw), Bw = v($o).attrs(ve(["$align"]))
`
  display: flex;
  justify-content: ${({$align:e})=>e?Nd.get(e):void 0};
  overflow: hidden;
  ${co};
  ${Ct};
  ${ki};
  ${Po};
  ${({$isStretched:e})=>e&&"width: 100%; height: 100%;"};

  &:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }

  ${({$isAdjustToWidth:e,theme:t})=>e&&`
@media $ {
    ze(t.globalDesign.contentWidth)
} {
    width: 100 % ;
}
`}
`, Sw = v.picture `
    ${({$isStretched:e})=>e&&"width: 100%; height: 100%;"};
`, $w = ({
    sourceSet: e,
    ...t
}) => {
    const o = Fi();
    return a(bl, {
        as: Sw,
        sourceSet: e,
        $isStretched: t.$isStretched,
        children: a(vw, {
            $isLazyLoadingEnabled: o,
            ...t
        })
    })
}, Rw = v.div.attrs(ve())
`
    max-width: 100%;
    min-height: ${({$fontSize:e,$hasAvatar:t})=>t?`
calc($ {
    e
}* 3 + 6 px)
`:"auto"};
    display: flex;
    align-items: center;
    padding: 3px;
    
    &, .auth-link {
        ${e=>{var t,o;return Lr((o=(t=e.$$props)===null||t===void 0?void 0:t.$color)!==null&&o!==void 0?o:e.$color)}}
    }
    
    .auth-link {
        ${e=>cm({$isBold:e.$isBold,$isUnderline:e.$isUnderline,$isItalic:e.$isItalic})}
        line-height: 1.55em;
    }
    
    .auth-link:hover {
        ${e=>{var t,o;return Lr((o=(t=e.$$props)===null||t===void 0?void 0:t.$hoverColor)!==null&&o!==void 0?o:e.$hoverColor)}}
    }

  .auth-link:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
`;

function Pw(e) {
    const t = f.exports.useMemo(() => ({ ...j.createDefaultHyperlink(k.Internal),
            type: k.Internal,
            target: Ce.Self,
            href: e.loginPageId,
            pageUuid: e.loginPageId
        }), [e.loginPageId]),
        o = f.exports.useMemo(() => ({ ...j.createDefaultHyperlink(k.Internal),
            type: k.Internal,
            target: Ce.Self,
            href: e.registerPageId,
            pageUuid: e.registerPageId
        }), [e.registerPageId]);
    return y(Rw, {
        $hasAvatar: e.displayMode === vo.Avatar || e.displayMode === vo.AvatarAndName,
        $fontSize: e.fontSize,
        $hoverColor: e.hoverColor,
        $inlineMode: e.isEditMode,
        $color: e.color,
        $isUnderline: e.isUnderline,
        $isItalic: e.isItalic,
        $isBold: e.isBold,
        children: [a($o, {
            hyperlink: t,
            className: "auth-link",
            "data-ats-member-link": "login",
            children: e.loginText
        }), "\xA0/\xA0", a($o, {
            hyperlink: o,
            className: "auth-link",
            "data-ats-member-link": "register",
            children: e.registerText
        })]
    })
}
const Fw = v.div.attrs(ve(["$align"]))
`
    ${e=>um({$fontFamily:e.$fontFamily,$fontSize:e.$fontSize,$textColor:e.$color})}  
    display: flex;
    justify-content: ${({$align:e})=>e?Nd.get(e):void 0};
    align-items: center;
    ${e=>e.$isEditMode?"cursor: default;pointer-events: none;":""}

    ${({theme:e})=>P`
@media $ {
    ze(e.globalDesign.contentWidth)
} {
    $ {
        ml
    }
}
`}
`, Iw = dt(Fw), tb = v.div `
  border: solid #000;
  border-width: 0 3px 3px 0;
  display: inline-block;
  padding: 3px;
  transform: rotate(${e=>e.$isOpen?-135:45}deg);
`, ob = P `
  box-shadow: 0 0 7px 1px #ccc7c7;
`, kw = P `
  :hover {
    ${ob}
  }
`, Tw = v.div `
  display: flex;
  justify-content: center;
  align-items: center;
  max-width: 100%;
  cursor: pointer;
  padding: 3px;
  
  :focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }

  ${tb} {
    margin-left: 10px;
  }

  img {
    margin-right: 10px;
    border-radius: 50%;
    width: ${e=>e.$fontSize*3}px;
  }

  ${e=>e.$isEditMode?"":kw}
  ${e=>e.$isOpen?ob:""}
  .member-last-name,
  .member-first-name,
  .member-info-wrapper,
  .member-email {
    ${Wx};
    line-height: 1.85em;
  }

  .member-info-wrapper {
    display: inline-flex;
    flex-wrap: wrap;
    line-height: 1.85em;
  }
  
  .member-info-wrapper, .member-email {
    ${e=>Lr(e.$textColor)}
  }
`, Ew = v.div `
  box-shadow: 0 4px 7px 1px #ccc7c7;
  border-top: none;
  background: ${e=>e.$palette[0]};
  font-family: ${e=>e.$fontFamily};
  color: ${e=>e.$palette[1]};

  > * {
    padding: 10px;
    cursor: pointer;

    :hover {
      color: ${e=>e.$palette[2]};
    }
    :focus-visible {
      outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
    }
  }
`;

function Lw() {
    const e = f.exports.useContext(Hh);
    if (e === null) throw new Error("Missing PaletteColorsContext");
    return e
}

function Mw(e) {
    const t = Lw();
    return a(Ew, {
        style: {
            width: e.width
        },
        $palette: t,
        $fontFamily: e.fontFamily,
        children: a("div", {
            onClick: e.onLogoutClick,
            role: "button",
            tabIndex: 0,
            "data-ats": "logout-button",
            children: "Logout"
        })
    })
}

function Ow(e) {
    var t;
    const [o, r] = f.exports.useState(!1), i = f.exports.useCallback(() => r(l => !l), []), n = f.exports.useRef(null);
    return f.exports.useEffect(() => {
        if (!o) return;

        function l(s) {
            var u;
            !((u = n.current) === null || u === void 0) && u.contains(s.target) || r(!1)
        }
        return document.addEventListener("click", l), () => document.removeEventListener("click", l)
    }, [o]), y(Tw, {
        $fontSize: e.fontSize,
        onClick: i,
        $isEditMode: e.isEditMode,
        $isOpen: o,
        ref: n,
        $textColor: e.color,
        children: [gt(e.displayMode === vo.Avatar || e.displayMode === vo.AvatarAndName, e.avatar), e.displayMode === vo.Name || e.displayMode === vo.AvatarAndName ? gt(!!e.firstName, y("div", {
            className: "member-info-wrapper",
            "data-ats": "member-name",
            children: [y("span", {
                className: "member-first-name",
                children: [e.firstName, "\xA0"]
            }), gt(!!e.lastName, a("span", {
                className: "member-last-name",
                children: e.lastName
            }))]
        }), a("span", {
            className: "member-email",
            "data-ats": "member-email",
            children: e.email
        })) : null, a(tb, {
            $isOpen: o
        }), a(Ud, {
            neighborRef: n,
            matchingPointsOrder: [pe.FromBottomAlignCenter],
            isOpen: o,
            distanceToFence: 0,
            children: a(Mw, {
                onLogoutClick: e.onLogoutClick,
                width: (t = n ? .current) === null || t === void 0 ? void 0 : t.clientWidth,
                fontFamily: e.fontFamily
            })
        })]
    })
}

function Aw(e) {
    var t, o, r, i;
    const n = { ...e,
        color: (o = (t = e.$$props) === null || t === void 0 ? void 0 : t.color) !== null && o !== void 0 ? o : e.color,
        hoverColor: (i = (r = e.$$props) === null || r === void 0 ? void 0 : r.hoverColor) !== null && i !== void 0 ? i : e.color
    };
    return a(Iw, {
        globalClassName: I.MemberProfile,
        $fontFamily: n.fontFamily,
        $fontSize: n.fontSize,
        $color: n.color,
        $inlineMode: n.isEditMode,
        $isEditMode: n.isEditMode,
        $align: n.align,
        children: n.isMember ? a(Ow, { ...n
        }) : a(Pw, { ...n
        })
    })
}

function Ww(e) {
    return a("img", {
        src: `https://www.gravatar.com/avatar/${e.hash}`,
        alt: "avatar"
    })
}

function Dw(e) {
    const t = f.exports.useMemo(() => J0.exports(e.email.toLowerCase().trim()), [e.email]);
    return a(Ww, {
        hash: t
    })
}

function Nw(e) {
    var t, o, r, i;
    const [n, l] = f.exports.useState(""), [s, u] = f.exports.useState(""), {
        onSubmit: c,
        onFocus: h,
        error: m
    } = e, g = f.exports.useCallback(b => {
        c({
            email: n,
            password: s
        }, b)
    }, [n, c, s]), p = (t = m ? .find(b => b.type === _t.Global)) === null || t === void 0 ? void 0 : t.message;
    return y(vm, { ...e.buttonProps,
        globalClassName: I.RegisterForm,
        $labelFontFamily: e.fontFamily,
        $labelFontSize: e.fontSize,
        $color: e.color,
        $isLabelBold: e.isBold,
        $isLabelItalic: e.isItalic,
        $isLabelUnderline: e.isUnderline,
        $isEditMode: e.isInteractionEnabled,
        $inlineMode: !e.isInteractionEnabled,
        onSubmit: g,
        isInteractionEnabled: e.isInteractionEnabled,
        className: e.className,
        $isSubmitDisabled: (o = e.isSubmitting) !== null && o !== void 0 ? o : !1,
        children: [a("div", {
            className: "global-error",
            children: p ? ? null
        }), y("div", {
            className: "content",
            children: [y("div", {
                children: [a("div", {
                    className: "label-container",
                    children: e.emailLabelContent
                }), a(yi, {
                    isInteractionEnabled: e.isInteractionEnabled,
                    onChange: l,
                    value: n,
                    type: "email",
                    autocomplete: "email",
                    shouldShowHHorizontalMargin: !1,
                    color: e.color,
                    error: (r = m ? .find(b => b.type === _t.Email)) === null || r === void 0 ? void 0 : r.message,
                    globalError: !!p,
                    onFocus: h
                })]
            }), y("div", {
                children: [a("div", {
                    className: "label-container",
                    children: e.passwordLabelContent
                }), a(yi, {
                    isInteractionEnabled: e.isInteractionEnabled,
                    onChange: u,
                    value: s,
                    type: "password",
                    autocomplete: "new-password",
                    shouldShowHHorizontalMargin: !1,
                    color: e.color,
                    error: (i = m ? .find(b => b.type === _t.Password)) === null || i === void 0 ? void 0 : i.message,
                    globalError: !!p,
                    onFocus: h
                })]
            }), y("button", {
                type: "submit",
                ...Ae("register-form", "submit"),
                children: [a("span", {
                    className: "button-text",
                    children: e.submitButtonContent
                }), gt(!!e.isSubmitting, a(pm, {
                    center: !1,
                    size: er.Medium
                }))]
            })]
        })]
    })
}
const Uw = v.section `
  background: #FFF;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  
  img {
    width: ${e=>e.$logoWidth}px;
    height: ${e=>e.$logoHeight}px;
  }
`,
    Vw = "https://us-wbe.gr-cdn.com/public/js/assets/gr_logo.669fd08a.png",
    Rc = 620,
    Pc = 96;

function Hw(e) {
    return a(Uw, {
        $logoWidth: Rc / 2,
        $logoHeight: Pc / 2,
        children: a("a", {
            href: e.href,
            target: "_blank",
            rel: "nofollow",
            children: a("img", {
                src: Vw,
                alt: "GetResponse",
                width: Rc,
                height: Pc
            })
        })
    })
}

function jw() {
    return y("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 16 16",
        children: [a("path", {
            fill: "currentColor",
            d: "M11.293 3.293L12 2.586 13.414 4l-.707.707-1.414-1.414zm-6.586 9.414L4 13.414 2.586 12l.707-.707 1.414 1.414zm8-8l-8 8-1.414-1.414 8-8 1.414 1.414z"
        }), a("path", {
            fill: "currentColor",
            d: "M4.707 3.293L4 2.586 2.586 4l.707.707 1.414-1.414zm6.586 9.414l.707.707L13.414 12l-.707-.707-1.414 1.414zm-8-8l8 8 1.414-1.414-8-8-1.414 1.414z"
        })]
    })
}

function zw() {
    return y("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 16 16",
        fill: "none",
        children: [a("circle", {
            cx: "8",
            cy: "8",
            r: "6.5",
            stroke: "currentColor"
        }), a("path", {
            strokeLinecap: "round",
            d: "M11 5l-6 6m0-6l6 6",
            stroke: "currentColor"
        })]
    })
}
const _w = v.button `
    background: ${e=>e.$bgColor};
    width: ${e=>e.$size}px;
    height: ${e=>e.$size}px;
    display: flex;
    justify-content: center;
    align-items: center;
    border: none;
    outline: none;
    padding: 0;
    margin: 0;
    cursor: ${e=>e.disabled?"default":"pointer"};
    color: ${e=>e.$color};
    position: ${e=>e.$static?"static":"absolute"};
    right: 10px;
    top: 10px;
    z-index: 99997;

    svg {
        width: ${e=>e.$size}px;
        height: ${e=>e.$size}px;
    }
`;

function Gw(e) {
    var t, o, r, i, n;
    return a(_w, {
        $size: (t = e.size) !== null && t !== void 0 ? t : 20,
        $color: (o = e.color) !== null && o !== void 0 ? o : "#000000",
        $bgColor: (r = e.backgroundColor) !== null && r !== void 0 ? r : "transparent",
        $static: (i = e.staticPosition) !== null && i !== void 0 ? i : !0,
        "data-ats-popup": "close",
        disabled: e.interactive === void 0 ? (n = e.staticPosition) !== null && n !== void 0 ? n : !1 : !e.interactive,
        onClick: e.onClick,
        children: e.children
    })
}

function pr(e) {
    return t => a(Gw, { ...t,
        children: a(e, {})
    })
}

function Zw() {
    return a("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 16 16",
        children: a("path", {
            stroke: "currentColor",
            strokeLinecap: "round",
            d: "M12 4l-8 8m0-8l8 8"
        })
    })
}

function qw() {
    return y("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 16 16",
        fill: "none",
        children: [a("path", {
            strokeLinecap: "round",
            d: "M11 5l-6 6m0-6l6 6",
            stroke: "currentColor"
        }), a("path", {
            d: "M2 2h12v12H2z",
            stroke: "currentColor"
        })]
    })
}

function Jw() {
    return a("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 16 16",
        children: a("path", {
            fill: "currentColor",
            d: "M7.005 8.006c-.894-.806-1.658-1.559-2.49-2.224-.481-.384-.776-.834-.606-1.384.132-.43.437-.903.805-1.14.435-.281.956-.1 1.338.315.61.661 1.225 1.318 1.848 1.966.147.153.332.268.564.451.227-.3.434-.528.59-.789.253-.425.455-.881.71-1.306.449-.75 1.368-1.102 1.94-.769.7.408.862 1.495.299 2.281-.288.402-.66.742-.982 1.12-.319.373-.621.76-1 1.226.38.403.705.76 1.043 1.103.313.318.686.588.952.94.507.668.285 1.645-.43 2.117-.79.523-1.502.341-2.026-.512-.26-.421-.517-.845-.796-1.252-.069-.1-.222-.14-.359-.22-1.13.867-1.835 2.251-3.144 2.96a.929.929 0 01-1.208-.293 3.411 3.411 0 01-.044-.065c-.523-.802-.473-1.015.232-1.711.895-.882 1.762-1.791 2.764-2.814z"
        })
    })
}

function Yw() {
    return a("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 16 16",
        children: a("path", {
            fillRule: "evenodd",
            fill: "currentColor",
            d: "M3 1a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V3a2 2 0 00-2-2H3zm1.96 3.96a1 1 0 011.414 0l1.813 1.812L10 4.96a1 1 0 111.414 1.414L9.6 8.187 11.414 10A1 1 0 1110 11.414L8.187 9.6l-1.813 1.813A1 1 0 014.96 10l1.812-1.813L4.96 6.374a1 1 0 010-1.414z",
            clipRule: "evenodd"
        })
    })
}

function Xw() {
    return a("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 16 16",
        children: a("path", {
            fillRule: "evenodd",
            fill: "currentColor",
            d: "M8 15A7 7 0 108 1a7 7 0 000 14zM5.139 5.14a1 1 0 011.414 0l1.62 1.618L9.79 5.14a1 1 0 111.414 1.414l-1.619 1.62 1.62 1.618a1 1 0 01-1.415 1.414L8.172 9.586l-1.619 1.62A1 1 0 015.14 9.79l1.62-1.619-1.62-1.619a1 1 0 010-1.414z",
            clipRule: "evenodd"
        })
    })
}
fo.Simple + "", pr(jw), fo.SimpleLight + "", pr(Zw), fo.Rounded + "", pr(zw), fo.Square + "", pr(qw), fo.Comic + "", pr(Jw), fo.ComicRounded + "", pr(Xw), fo.ComicSquare + "", pr(Yw);
const Kw = v.div.attrs(ve()).attrs(Pt("buy-button"))
`
  min-height: ${Nn}px;
  ${Ro};
  ${Dt};
  .content-container > * { 
    margin-left: auto;
    margin-right: auto;
  }
`, Qw = dt(Kw), e3 = v.div.attrs(ve())
`
    ${uo}
    ${fm}
    
    display: inline-block;
    background: ${e=>e.$backgroundColor};
`, t3 = v(Ho)
`
    display: flex;
    justify-content: ${e=>{switch(e.$align){case W.Left:return"flex-start";case W.Right:return"flex-end"}return"center"}};
    align-items: center;
`, o3 = x.forwardRef((e, t) => {
    var o;
    const {
        code: r,
        ...i
    } = e;
    return a(t3, { ...i,
        ref: t,
        children: a(e3, { ...i,
            children: (o = r ? ? e.fallbackContent) !== null && o !== void 0 ? o : "[PROMO CODE]"
        })
    })
});

function r3(e) {
    switch (e) {
        case W.Left:
            return "flex-start";
        case W.Right:
            return "flex-end";
        case W.Center:
        default:
            return "center"
    }
}

function n3(e) {
    const t = Mo[e];
    return Od(t.mobileFontSize)
}
const Fc = v.div.attrs(ve(["$lineHeight", "$type", "$align"]))
`
    display: flex;
    justify-content: ${({$align:e})=>r3(e)};
    background-color: ${e=>e.$backgroundColor};
    line-height: ${e=>e.$lineHeight};
    
    > span {        
        ${uo}
    }
    
    ${({theme:e,$type:t})=>t===null?"":P`
@media $ {
    ze(e.globalDesign.contentWidth)
} {
    $ {
        n3(t)
    }
}
`}
`, i3 = v.div `
    display: flex;
    flex-direction: column;
    justify-content: center;
`;

function a3({
    className: e
}) {
    return y("svg", {
        className: e,
        width: "240",
        height: "150",
        viewBox: "0 0 240 150",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [a("filter", {
            id: "shadow",
            x: "0",
            y: "0",
            width: "200%",
            height: "200%",
            children: a("feDropShadow", {
                dx: "3",
                dy: "3",
                stdDeviation: "1",
                floodColor: "#c6c9cf",
                floodOpacity: "1"
            })
        }), a("rect", {
            x: "58.5155",
            y: "29.0723",
            width: "119.168",
            height: "87.7256",
            rx: "8",
            fill: "white",
            filter: "url(#shadow)"
        }), a("g", {
            filter: "url(#filter0_i_5550_104989)",
            children: a("path", {
                d: "M144.683 46H177.683V109C177.683 113.418 174.101 117 169.683 117H144.683V46Z",
                fill: "#E9EEF5"
            })
        }), a("path", {
            d: "M58.6831 46H144.683V117H67.6831C62.7125 117 58.6831 112.971 58.6831 108V46Z",
            fill: "#B1D5F1"
        }), a("circle", {
            cx: "68.4213",
            cy: "37.8491",
            r: "2",
            fill: "#F62F36"
        }), a("circle", {
            cx: "75.4764",
            cy: "37.8491",
            r: "2",
            fill: "#F8CA4E"
        }), a("circle", {
            cx: "82.5317",
            cy: "37.8491",
            r: "2",
            fill: "#00C662"
        }), a("rect", {
            width: "21.0707",
            height: "3.90466",
            rx: "1.95233",
            transform: "matrix(1 -4.54369e-08 -0.00287852 0.999996 151.376 85.7168)",
            fill: "#7990A1"
        }), a("rect", {
            width: "21.0707",
            height: "3.90466",
            rx: "1.95233",
            transform: "matrix(1 -8.3924e-08 -0.00287874 0.999996 151.366 93.5259)",
            fill: "#7990A1"
        }), a("rect", {
            width: "21.0707",
            height: "3.90466",
            rx: "1.95233",
            transform: "matrix(1 -8.48804e-08 -0.00287874 0.999996 151.355 101.335)",
            fill: "#7990A1"
        }), a("g", {
            filter: "url(#filter1_i_5550_104989)",
            children: a("path", {
                d: "M113.751 100.232C111.025 98.7258 112.432 95.9796 113.751 94.7394C115.421 93.0563 117.444 87.3867 117.444 87.3867C120.785 85.8807 121.137 83.4888 121.489 81.8943C122.984 77.1106 119.291 76.4019 119.291 76.4019C119.291 76.4019 122.192 68.429 119.818 62.4051C116.74 54.4322 104.078 51.5088 101.879 58.8616C86.8426 55.3181 90.0083 76.2247 90.0083 76.2247C90.0083 76.2247 86.315 76.9334 87.8099 81.7171C88.1617 83.4002 88.5134 85.7921 91.8549 87.2095C91.8549 87.2095 93.8774 92.9677 95.5482 94.5622C96.8672 95.8911 98.2742 98.6373 95.5482 100.055C90.0083 103.155 73.4766 103.864 73.4766 116.798H135.734C135.734 103.864 119.291 103.155 113.751 100.232Z",
                fill: "white"
            })
        }), a("mask", {
            id: "mask0_5550_104989",
            style: {
                maskType: "alpha"
            },
            maskUnits: "userSpaceOnUse",
            x: "151",
            y: "54",
            width: "22",
            height: "22",
            children: a("ellipse", {
                cx: "161.895",
                cy: "65.0845",
                rx: "10.3713",
                ry: "10.4483",
                fill: "#B1D5F1"
            })
        }), y("g", {
            mask: "url(#mask0_5550_104989)",
            children: [a("ellipse", {
                cx: "161.895",
                cy: "65.0845",
                rx: "10.3713",
                ry: "10.4483",
                fill: "#ABBCC9"
            }), a("g", {
                filter: "url(#filter2_i_5550_104989)",
                children: a("path", {
                    d: "M164.695 71.2148C163.892 70.7707 164.307 69.961 164.695 69.5953C165.188 69.099 165.784 67.4273 165.784 67.4273C166.77 66.9832 166.873 66.2779 166.977 65.8078C167.418 64.3973 166.329 64.1883 166.329 64.1883C166.329 64.1883 167.185 61.8374 166.485 60.0612C165.577 57.7104 161.843 56.8484 161.195 59.0164C156.761 57.9716 157.695 64.136 157.695 64.136C157.695 64.136 156.606 64.345 157.047 65.7555C157.15 66.2518 157.254 66.9571 158.239 67.375C158.239 67.375 158.836 69.0729 159.328 69.543C159.717 69.9348 160.132 70.7446 159.328 71.1625C157.695 72.0767 152.82 72.2857 152.82 76.0993H171.178C171.178 72.2857 166.329 72.0767 164.695 71.2148Z",
                    fill: "white"
                })
            })]
        }), a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M202.957 102.503C202.957 101.858 202.434 101.335 201.789 101.335C201.144 101.335 200.621 101.858 200.621 102.503L200.621 104.865H198.294C197.644 104.865 197.118 105.392 197.118 106.042C197.118 106.692 197.644 107.218 198.294 107.218H200.621L200.621 109.58C200.621 110.225 201.144 110.748 201.789 110.748C202.434 110.748 202.957 110.225 202.957 109.58V107.218H205.284C205.934 107.218 206.461 106.692 206.461 106.042C206.461 105.392 205.934 104.865 205.284 104.865H202.957V102.503Z",
            fill: "#7990A1"
        }), a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M193.614 82.1787C193.614 81.5336 193.091 81.0107 192.446 81.0107C191.801 81.0107 191.278 81.5336 191.278 82.1787L191.278 84.5406H188.951C188.301 84.5406 187.774 85.0673 187.774 85.7172C187.774 86.367 188.301 86.8938 188.951 86.8938H191.278L191.278 89.2556C191.278 89.9007 191.801 90.4236 192.446 90.4236C193.091 90.4236 193.614 89.9007 193.614 89.2556V86.8938H195.941C196.591 86.8938 197.118 86.367 197.118 85.7172C197.118 85.0673 196.591 84.5406 195.941 84.5406H193.614V82.1787Z",
            fill: "#7990A1"
        }), a("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M188.942 122.097C188.942 121.452 188.419 120.929 187.774 120.929C187.129 120.929 186.606 121.452 186.606 122.097L186.606 124.459H184.279C183.629 124.459 183.102 124.986 183.102 125.636C183.102 126.285 183.629 126.812 184.279 126.812H186.606L186.606 129.174C186.606 129.819 187.129 130.342 187.774 130.342C188.419 130.342 188.942 129.819 188.942 129.174V126.812H191.269C191.919 126.812 192.446 126.285 192.446 125.636C192.446 124.986 191.919 124.459 191.269 124.459H188.942V122.097Z",
            fill: "#7990A1"
        }), a("path", {
            d: "M58.6831 37C58.6831 32.5817 62.2648 29 66.6831 29H169.683C174.101 29 177.683 32.5817 177.683 37V46H58.6831V37Z",
            fill: "white"
        }), a("circle", {
            cx: "67.4213",
            cy: "38.5771",
            r: "2",
            fill: "#F62F36"
        }), a("circle", {
            cx: "74.4764",
            cy: "38.5771",
            r: "2",
            fill: "#F8CA4E"
        }), a("circle", {
            cx: "81.5317",
            cy: "38.5771",
            r: "2",
            fill: "#00C662"
        }), a("rect", {
            x: "55.5",
            y: "113.5",
            width: "10.9213",
            height: "14.2716",
            fill: "#F8CA4E",
            filter: "url(#shadow)"
        }), a("circle", {
            cx: "60.9607",
            cy: "96.3233",
            r: "25.1768",
            fill: "#C4C4C4"
        }), a("circle", {
            cx: "60.9607",
            cy: "96.3233",
            r: "25.1768",
            fill: "url(#paint0_linear_5550_104989)"
        }), a("g", {
            filter: "url(#filter3_i_5550_104989)",
            children: a("circle", {
                cx: "60.9607",
                cy: "96.3235",
                r: "11.2893",
                fill: "url(#paint1_linear_5550_104989)"
            })
        }), a("circle", {
            cx: "60.9607",
            cy: "96.3235",
            r: "9.78934",
            stroke: "#7990A1",
            strokeWidth: "3"
        }), a("rect", {
            x: "44.4448",
            y: "125.636",
            width: "33.0317",
            height: "4.27161",
            rx: "2.1358",
            fill: "#F8CA4E",
            filter: "url(#shadow)"
        }), a("circle", {
            cx: "58.6875",
            cy: "94.0503",
            r: "3.18748",
            fill: "white"
        }), y("defs", {
            children: [y("filter", {
                id: "filter0_i_5550_104989",
                x: "144.683",
                y: "46",
                width: "34",
                height: "72",
                filterUnits: "userSpaceOnUse",
                colorInterpolationFilters: "sRGB",
                children: [a("feFlood", {
                    floodOpacity: "0",
                    result: "BackgroundImageFix"
                }), a("feBlend", {
                    mode: "normal",
                    in: "SourceGraphic",
                    in2: "BackgroundImageFix",
                    result: "shape"
                }), a("feColorMatrix", { in: "SourceAlpha",
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                    result: "hardAlpha"
                }), a("feOffset", {
                    dx: "1",
                    dy: "1"
                }), a("feGaussianBlur", {
                    stdDeviation: "0.5"
                }), a("feComposite", {
                    in2: "hardAlpha",
                    operator: "arithmetic",
                    k2: "-1",
                    k3: "1"
                }), a("feColorMatrix", {
                    type: "matrix",
                    values: "0 0 0 0 0.12549 0 0 0 0 0.152941 0 0 0 0 0.188235 0 0 0 0.16 0"
                }), a("feBlend", {
                    mode: "normal",
                    in2: "shape",
                    result: "effect1_innerShadow_5550_104989"
                })]
            }), y("filter", {
                id: "filter1_i_5550_104989",
                x: "73.4766",
                y: "54.6362",
                width: "62.2578",
                height: "62.1616",
                filterUnits: "userSpaceOnUse",
                colorInterpolationFilters: "sRGB",
                children: [a("feFlood", {
                    floodOpacity: "0",
                    result: "BackgroundImageFix"
                }), a("feBlend", {
                    mode: "normal",
                    in: "SourceGraphic",
                    in2: "BackgroundImageFix",
                    result: "shape"
                }), a("feColorMatrix", { in: "SourceAlpha",
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                    result: "hardAlpha"
                }), a("feOffset", {
                    dx: "1",
                    dy: "1"
                }), a("feComposite", {
                    in2: "hardAlpha",
                    operator: "arithmetic",
                    k2: "-1",
                    k3: "1"
                }), a("feColorMatrix", {
                    type: "matrix",
                    values: "0 0 0 0 0.12549 0 0 0 0 0.152941 0 0 0 0 0.188235 0 0 0 0.2 0"
                }), a("feBlend", {
                    mode: "normal",
                    in2: "shape",
                    result: "effect1_innerShadow_5550_104989"
                })]
            }), y("filter", {
                id: "filter2_i_5550_104989",
                x: "152.82",
                y: "57.7705",
                width: "18.3572",
                height: "18.3286",
                filterUnits: "userSpaceOnUse",
                colorInterpolationFilters: "sRGB",
                children: [a("feFlood", {
                    floodOpacity: "0",
                    result: "BackgroundImageFix"
                }), a("feBlend", {
                    mode: "normal",
                    in: "SourceGraphic",
                    in2: "BackgroundImageFix",
                    result: "shape"
                }), a("feColorMatrix", { in: "SourceAlpha",
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                    result: "hardAlpha"
                }), a("feOffset", {
                    dx: "1",
                    dy: "1"
                }), a("feComposite", {
                    in2: "hardAlpha",
                    operator: "arithmetic",
                    k2: "-1",
                    k3: "1"
                }), a("feColorMatrix", {
                    type: "matrix",
                    values: "0 0 0 0 0.12549 0 0 0 0 0.152941 0 0 0 0 0.188235 0 0 0 0.2 0"
                }), a("feBlend", {
                    mode: "normal",
                    in2: "shape",
                    result: "effect1_innerShadow_5550_104989"
                })]
            }), y("filter", {
                id: "filter3_i_5550_104989",
                x: "49.6714",
                y: "85.0342",
                width: "22.5786",
                height: "22.5786",
                filterUnits: "userSpaceOnUse",
                colorInterpolationFilters: "sRGB",
                children: [a("feFlood", {
                    floodOpacity: "0",
                    result: "BackgroundImageFix"
                }), a("feBlend", {
                    mode: "normal",
                    in: "SourceGraphic",
                    in2: "BackgroundImageFix",
                    result: "shape"
                }), a("feColorMatrix", { in: "SourceAlpha",
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                    result: "hardAlpha"
                }), a("feOffset", {
                    dx: "1",
                    dy: "1"
                }), a("feComposite", {
                    in2: "hardAlpha",
                    operator: "arithmetic",
                    k2: "-1",
                    k3: "1"
                }), a("feColorMatrix", {
                    type: "matrix",
                    values: "0 0 0 0 0.12549 0 0 0 0 0.152941 0 0 0 0 0.188235 0 0 0 0.2 0"
                }), a("feBlend", {
                    mode: "normal",
                    in2: "shape",
                    result: "effect1_innerShadow_5550_104989"
                })]
            }), y("linearGradient", {
                id: "paint0_linear_5550_104989",
                x1: "42.5354",
                y1: "70.9957",
                x2: "73.0789",
                y2: "113.096",
                gradientUnits: "userSpaceOnUse",
                children: [a("stop", {
                    stopColor: "#FFF007"
                }), a("stop", {
                    offset: "1",
                    stopColor: "#FFCD07"
                })]
            }), y("linearGradient", {
                id: "paint1_linear_5550_104989",
                x1: "71.6587",
                y1: "104.387",
                x2: "27.6998",
                y2: "78.1742",
                gradientUnits: "userSpaceOnUse",
                children: [a("stop", {
                    stopColor: "#AED8FF"
                }), a("stop", {
                    offset: "1",
                    stopColor: "#EFF7FF"
                })]
            })]
        })]
    })
}
const l3 = v.div `
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    padding: 40px 40px 86px;
    border: 2px solid ${({errorColor:e})=>e};
    background-color: #f2f4f7;
    font-family: Roboto, Arial, sans-serif;
    font-size: 16px;
`;

function s3(e) {
    return a(l3, {
        errorColor: e.errorColor,
        "data-ats-wb-element": "webinar-not-available",
        children: e.children
    })
}

function d3(e) {
    switch (e.$alignment) {
        case W.Right:
            return P `
              text-align: right;
            `;
        case W.Justify:
            return P `
              text-align: justify;
            `;
        case W.Center:
            return P `
              text-align: center;
            `;
        case W.Left:
        default:
            return P `
              text-align: left;
            `
    }
}

function u3(e) {
    const t = [];
    return e.$isStrikethrough && t.push("line-through"), e.$isUnderline && t.push("underline"), t.length > 0 ? `text-decoration: ${t.join(" ")}` : "text-decoration: none"
}
const da = v.div.attrs(ve(["$lineHeight", "$alignment"]))
`
  background-color: ${({$backgroundColor:e})=>e};
  line-height: ${({$lineHeight:e})=>e};
  margin-bottom: 10px;
  ${uo};
  ${d3};
  ${u3}
`, c3 = v.div `
  width: 100%;
  display: flex;
  flex-direction: column;
  padding: 15px 25px;
`;
var ii;
(function(e) {
    e[e.Small = 150] = "Small", e[e.Medium = 250] = "Medium", e[e.Large = 350] = "Large"
})(ii || (ii = {}));

function Ic({
    $imageSize: e
}) {
    switch (e) {
        case Yt.Small:
            return ii.Small;
        case Yt.Large:
            return ii.Large;
        case Yt.Medium:
        default:
            return ii.Medium
    }
}
const rb = v.img.attrs(ve(["$imageSize", "$imageAlign"]))
`
  display: flex;
  width: ${Ic}px;
  height: ${Ic}px;
  object-fit: contain;

  ${Po}
  ${co}
  ${Ct}

  ${({theme:e,$imageStretchOnMobile:t})=>t&&P`
@media $ {
    ze(e.globalDesign.contentWidth)
} {
    width: 100 % ;
}
`}
`;

function h3(e) {
    const {
        $layout: t,
        $imageStretchOnMobile: o
    } = e;
    switch (t) {
        case Ot.Right:
            return o ? P `
                  flex-direction: column-reverse;
                  justify-content: flex-end;
                ` : P `
                  flex-direction: row-reverse;
                  justify-content: flex-end;
                `;
        case Ot.Top:
            return P `
              flex-direction: column;
              justify-content: flex-start;
              flex-wrap: wrap;
            `;
        case Ot.Bottom:
            return P `
              flex-direction: column-reverse;
              justify-content: flex-end;
              flex-wrap: wrap;
            `;
        case Ot.Left:
        default:
            return P `
              flex-direction: row;
              justify-content: flex-start;
            `
    }
}

function m3(e) {
    return `${(100/e.$columns).toFixed(2)}%`
}

function b3(e) {
    switch (e) {
        case W.Left:
            return "flex-start";
        case W.Right:
            return "flex-end";
        case W.Center:
        default:
            return "center"
    }
}
const f3 = v.div.attrs(ve(["$layout", "$columns", "$imageAlign", "$imageStretchOnMobile"]))
`
  display: flex;
  ${({$contentGap:e})=>e?`
gap: $ {
    e
}
`:null};
  flex: 1 1 ${m3};

  ${({theme:e,$imageStretchOnMobile:t})=>t&&P`
@media $ {
    ze(e.globalDesign.contentWidth)
} {
    width: 100 % ;
    flex - wrap: wrap;
}
`}

  ${h3}
  
  ${rb} {
    align-self: ${({$imageAlign:e})=>b3(e)};
  }
`;

function g3(e) {
    switch (e) {
        case W.Left:
            return "flex-start";
        case W.Right:
            return "flex-end";
        case W.Center:
        default:
            return "center"
    }
}
const p3 = v($o).attrs(ve(["$align"])).attrs(Pt("button"))
`
  ${uo};
  ${fm};
  line-height: 1;
  background: ${({$backgroundColor:e})=>e};
  align-self: ${({$align:e})=>g3(e)};

  &:hover {
    background: ${({$backgroundColorHover:e})=>e};
    color: ${({$textColorHover:e})=>e};
  }

  &:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
`;
v(da)
`
    margin: 20px 0;
`;

function y3(e) {
    switch (e.$layout) {
        case Ot.Right:
            return P `
              flex-direction: column;
            `;
        case Ot.Top:
            return P `
              flex-direction: row;
            `;
        case Ot.Bottom:
            return P `
              flex-direction: row;
            `;
        case Ot.Left:
        default:
            return P `
              flex-direction: column;
            `
    }
}
const x3 = v.div.attrs(ve(["$layout"]))
`
  display: flex;
  flex-wrap: wrap;
  gap: ${({$productGap:e})=>e};
  justify-content: center;
  ${y3}
  ${({theme:e,$keepLayoutOnMobile:t})=>t&&P`
@media $ {
    ze(e.globalDesign.contentWidth)
} {
    flex - wrap: nowrap;
}
`}
`, v3 = e => {
    var t;
    const {
        contentGap: o,
        layout: r,
        inlineMode: i = !1,
        product: n,
        price: l,
        isEditMode: s,
        columns: u,
        isImageVisible: c,
        isProductNameVisible: h,
        isDescriptionVisible: m,
        isPriceVisible: g,
        isButtonVisible: p
    } = e, {
        name: b,
        description: C,
        image: w
    } = n;
    return y(f3, {
        $contentGap: o,
        $layout: r,
        $imageStretchOnMobile: n.imageStretchOnMobile,
        $columns: u,
        $imageAlign: n.imageAlign,
        $inlineMode: i,
        children: [c ? a(rb, {
            src: w,
            alt: b,
            $inlineMode: i,
            $imageSize: n.imageSize,
            $imageStretchOnMobile: n.imageStretchOnMobile,
            $isBorderEnabled: n.imageIsBorderEnabled,
            $borderWidthTop: n.imageBorderWidthTop,
            $borderWidthBottom: n.imageBorderWidthBottom,
            $borderWidthLeft: n.imageBorderWidthLeft,
            $borderWidthRight: n.imageBorderWidthRight,
            $borderStyleTop: n.imageBorderStyleTop,
            $borderStyleLeft: n.imageBorderStyleLeft,
            $borderStyleRight: n.imageBorderStyleRight,
            $borderStyleBottom: n.imageBorderStyleBottom,
            $borderColorTop: n.imageBorderColorTop,
            $borderColorLeft: n.imageBorderColorLeft,
            $borderColorRight: n.imageBorderColorRight,
            $borderColorBottom: n.imageBorderColorBottom,
            $isRadiusEnabled: n.imageIsRadiusEnabled,
            $borderRadiusTopLeft: n.imageBorderRadiusTopLeft,
            $borderRadiusTopRight: n.imageBorderRadiusTopRight,
            $borderRadiusBottomLeft: n.imageBorderRadiusBottomLeft,
            $borderRadiusBottomRight: n.imageBorderRadiusBottomRight,
            $isShadowEnabled: n.imageIsShadowEnabled,
            $shadowOffsetX: n.imageShadowOffsetX,
            $shadowOffsetY: n.imageShadowOffsetY,
            $shadowSpreadRadius: n.imageShadowSpreadRadius,
            $shadowBlurRadius: n.imageShadowBlurRadius,
            $shadowColor: n.imageShadowColor
        }) : null, y(c3, {
            children: [h ? a(da, {
                $inlineMode: i,
                $fontSize: n.productNameFontSize,
                $fontFamily: n.productNameFontFamily,
                $isBold: n.productNameFontStyleIsBold,
                $isItalic: n.productNameFontStyleIsItalic,
                $isUnderline: n.productNameFontStyleIsUnderline,
                $textColor: n.productNameFontColor,
                $backgroundColor: n.productNameBackgroundColor,
                $alignment: n.productNameAlignment,
                $lineHeight: n.productNameLineHeight,
                children: b
            }) : null, m ? a(da, {
                $inlineMode: i,
                $fontSize: n.descriptionFontSize,
                $fontFamily: n.descriptionFontFamily,
                $isBold: n.descriptionFontStyleIsBold,
                $isItalic: n.descriptionFontStyleIsItalic,
                $isUnderline: n.descriptionFontStyleIsUnderline,
                $textColor: n.descriptionFontColor,
                $backgroundColor: n.descriptionBackgroundColor,
                $alignment: n.descriptionAlignment,
                $lineHeight: n.descriptionLineHeight,
                children: C
            }) : null, g ? a(da, {
                $inlineMode: i,
                $fontSize: n.priceFontSize,
                $fontFamily: n.priceFontFamily,
                $isBold: n.priceFontStyleIsBold,
                $isItalic: n.priceFontStyleIsItalic,
                $isUnderline: n.priceFontStyleIsUnderline,
                $isStrikethrough: n.priceFontStyleIsStrikethrough,
                $textColor: n.priceTextColor,
                $backgroundColor: n.priceBackgroundColor,
                $alignment: n.priceAlignment,
                children: l
            }) : null, p ? a(p3, {
                $backgroundColor: n.buttonBackgroundColor,
                $borderColorBottom: n.buttonBorderColorBottom,
                $borderColorLeft: n.buttonBorderColorLeft,
                $borderColorRight: n.buttonBorderColorRight,
                $borderColorTop: n.buttonBorderColorTop,
                $shadowColor: n.buttonShadowColor,
                $textColor: n.buttonTextColor,
                $paddingRight: n.buttonPaddingRight,
                $paddingLeft: n.buttonPaddingLeft,
                $paddingBottom: n.buttonPaddingBottom,
                $paddingTop: n.buttonPaddingTop,
                $fontFamily: n.buttonFontFamily,
                $align: n.buttonAlign,
                $borderRadiusBottomLeft: n.buttonBorderRadiusBottomLeft,
                $borderRadiusBottomRight: n.buttonBorderRadiusBottomRight,
                $borderRadiusTopLeft: n.buttonBorderRadiusTopLeft,
                $borderRadiusTopRight: n.buttonBorderRadiusTopRight,
                $isRadiusEnabled: n.buttonIsRadiusEnabled,
                $borderStyleBottom: n.buttonBorderStyleBottom,
                $borderStyleLeft: n.buttonBorderStyleLeft,
                $borderStyleRight: n.buttonBorderStyleRight,
                $borderStyleTop: n.buttonBorderStyleTop,
                $borderWidthBottom: n.buttonBorderWidthBottom,
                $borderWidthLeft: n.buttonBorderWidthLeft,
                $borderWidthRight: n.buttonBorderWidthRight,
                $borderWidthTop: n.buttonBorderWidthTop,
                $isItalic: n.buttonIsItalic,
                $isUnderline: n.buttonIsUnderline,
                $isSubscript: n.buttonIsSubscript,
                $isSuperscript: n.buttonIsSuperscript,
                $isStrikethrough: n.buttonIsStrikethrough,
                $isShadowEnabled: n.buttonIsShadowEnabled,
                $shadowBlurRadius: n.buttonShadowBlurRadius,
                $shadowOffsetX: n.buttonShadowOffsetX,
                $shadowOffsetY: n.buttonShadowOffsetY,
                $shadowOpacity: n.buttonShadowOpacity,
                $shadowSpreadRadius: n.buttonShadowSpreadRadius,
                $backgroundColorHover: n.buttonBackgroundColorHover,
                $textColorHover: n.buttonTextColorHover,
                $fontSize: n.buttonFontSize,
                $isBold: n.buttonIsBold,
                $isBorderEnabled: n.buttonIsBorderEnabled,
                isClickable: s,
                hyperlink: n.buttonHyperlink,
                description: (t = n.buttonButtonText) !== null && t !== void 0 ? t : void 0,
                emptyContainer: a("button", {
                    type: "button"
                }),
                children: n.buttonButtonText
            }) : null]
        })]
    })
}, C3 = dt(v(Ho).attrs(Pt("product-box"))
    ``), nb = v.header `
    font-family: 'Roboto-Bold', 'Roboto Bold', 'Roboto', sans-serif;
    font-weight: 700;
    font-style: normal;
    font-size: 20px;
    padding-bottom: 20px;
    word-wrap: break-word;
`, ib = v.div `
    background-color: rgba(245, 247, 250, 1);
    border: none;
    border-radius: 7px;
    box-shadow: 2px 2px 10px rgb(227 227 227);
    width: 501px;
    padding: 45px 52px 37px 25px;
    margin: 9px;
    height: min-content;
`, w3 = v.button `
    text-transform: uppercase;
    width: 240px;
    height: 46px;
    background-color: black;
    color: white;
    border-radius: 4px;
`, B3 = v.div `
    display: flex;
    justify-content: space-between;
    flex-wrap: nowrap;
    width: 100%;
    font-family: 'Roboto-Bold', 'Roboto Bold', 'Roboto', sans-serif;
    font-weight: 700;
    font-style: normal;
    font-size: 14px;
    line-height: 30px;
`, S3 = v.div `
    display: flex;
    flex-wrap: nowrap;
    width: 100%;
    justify-content: space-between;
    line-height: 25px;
`;

function $3(e) {
    return f.exports.useMemo(() => e.map(t => ({
        id: t.id,
        label: "",
        required: t.required,
        min: "",
        max: "",
        defaultValues: [t.latestVersionContent],
        format: Je.Checkbox,
        name: t.name,
        valueType: Pe.String
    })), [e])
}
const R3 = v.div `
  min-height: 13px;
  color: rgb(255, 0, 0);
  font-size: 13px;
  font-family: Roboto, Arial, sans-serif;
`,
    P3 = v.div `
  display: flex;
  flex-direction: column;
  gap: 5px;
`,
    ab = x.createContext(null);

function jo() {
    const e = f.exports.useContext(ab);
    if (e === null) throw new Error("Missing form field context");
    return e
}
const F3 = ({
        children: e
    }) => {
        const {
            name: t,
            isFieldValid: o,
            getFieldError: r
        } = jo(), i = x.useMemo(() => {
            var n;
            return (n = r()) === null || n === void 0 ? void 0 : n.message
        }, [r]);
        return y(P3, {
            children: [e, !o() && i ? a(R3, {
                "data-ats-form-field-error": t,
                children: a(zt, {
                    id: i
                })
            }) : null]
        })
    },
    lb = v.input `
  position: relative;
  width: 100%;
  height: 40px;
  background-color: rgba(255, 255, 255, 1);
  box-sizing: border-box;
  border: 1px solid ${({$hasError:e})=>e?"rgb(255, 0, 0)":"rgba(204, 204, 204, 1)"};
  border-radius: 7px;
  box-shadow: 2px 2px 10px 0 rgb(227 227 227) inset;
  font-family: 'Roboto-Regular', 'Roboto', sans-serif;
  font-weight: 400;
  margin: 5px auto 2px;

  @media (max-width: 900px) {
    width: 100%;
  }
  
  &:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
`,
    sb = x.createContext(null);

function Ei() {
    const e = f.exports.useContext(sb);
    if (e === null) throw new Error("Missing order form values context");
    return e
}
const nr = v.label `
  display: inline-block;
  font-family: Roboto-Regular, Roboto, serif;
  font-size: 14px;
  font-weight: 400;
  color: rgb(51, 51, 51);
  ${({$isRequired:e})=>e&&P`::after {
    content: '*';
    margin - left: 5 px;
}
`}
`, kc = ({
    readOnly: e
}) => {
    var t;
    const {
        setError: o
    } = Ei(), r = jo(), {
        name: i,
        min: n,
        max: l,
        valueType: s,
        clearFieldError: u,
        isFieldValid: c,
        setFieldValue: h,
        getFieldValue: m,
        defaultValues: g,
        label: p,
        required: b
    } = r, C = (t = x.useMemo(() => m(), [m])[0]) !== null && t !== void 0 ? t : g[0], w = Xd(s), B = x.useCallback(L => {
        h(L.target.value)
    }, [h]), S = x.useCallback(() => {
        const L = kn(r, C);
        L && o(L)
    }, [r, C, o]), $ = x.useCallback(() => {
        u()
    }, [u]);
    return y(f.exports.Fragment, {
        children: [a(nr, {
            $isRequired: b,
            children: p
        }), a(lb, {
            name: i,
            value: C,
            min: n ? ? void 0,
            max: l ? ? void 0,
            readOnly: e,
            onFocus: e ? void 0 : $,
            onBlur: e ? void 0 : S,
            onChange: B,
            type: w,
            "data-ats-form-field": i,
            "data-ats-form-field-type": "input",
            $hasError: !c()
        })]
    })
}, I3 = v(lb)
`
  &:focus + ${Ti} {
    display: none;
  }

  :not(:focus) {
    color: ${({value:e})=>!e&&"transparent!important"};
  }
`, k3 = v.div `
    position: relative;
`, T3 = ({
    readOnly: e
}) => {
    var t;
    const {
        setError: o
    } = Ei(), r = jo(), {
        name: i,
        min: n,
        max: l,
        valueType: s,
        clearFieldError: u,
        isFieldValid: c,
        setFieldValue: h,
        getFieldValue: m,
        defaultValues: g,
        label: p,
        required: b
    } = r, C = (t = x.useMemo(() => m(), [m])[0]) !== null && t !== void 0 ? t : g[0], w = Xd(s), B = x.useCallback(L => {
        h(L.target.value)
    }, [h]), S = x.useCallback(() => {
        const L = kn(r, C);
        L && o(L)
    }, [r, C, o]), $ = x.useCallback(() => {
        u()
    }, [u]);
    return y(f.exports.Fragment, {
        children: [a(nr, {
            $isRequired: b,
            children: p
        }), y(k3, {
            children: [a(I3, {
                name: i,
                value: C,
                min: n ? ? void 0,
                max: l ? ? void 0,
                readOnly: e,
                onFocus: e ? void 0 : $,
                onBlur: e ? void 0 : S,
                onChange: B,
                type: w,
                "data-ats-form-field": i,
                "data-ats-form-field-type": "date-input",
                $hasError: !c()
            }), C ? null : a(Ti, {
                children: a(zt, {
                    id: K.Elements.Form.InputDate.Placeholder
                })
            })]
        })]
    })
}, E3 = v.textarea `
  -webkit-appearance: none;
  ${({readOnly:e})=>e&&"resize: none"};
  position: relative;
  max-width: 100%;
  min-width: 100%;
  min-height: 40px;
  background-color: rgba(255, 255, 255, 1);
  box-sizing: border-box;
  border: 1px solid ${({$hasError:e})=>e?"rgb(255, 0, 0)":"rgba(204, 204, 204, 1)"};
  border-radius: 7px;
  box-shadow: 2px 2px 10px 0 rgb(227 227 227) inset;
  font-family: 'Roboto-Regular', 'Roboto', sans-serif;
  font-weight: 400;
  margin: 5px auto 2px;

  @media (max-width: 900px) {
    width: 100%;
  }

  &:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
`, L3 = ({
    readOnly: e
}) => {
    var t;
    const {
        setError: o
    } = Ei(), r = jo(), {
        name: i,
        getFieldValue: n,
        setFieldValue: l,
        clearFieldError: s,
        isFieldValid: u,
        defaultValues: c,
        required: h,
        label: m
    } = r, g = (t = x.useMemo(() => n(), [n])[0]) !== null && t !== void 0 ? t : c[0], p = x.useCallback(w => {
        l(w.target.value)
    }, [l]), b = x.useCallback(() => {
        const w = kn(r, g);
        w && o(w)
    }, [r, o, g]), C = x.useCallback(() => {
        s()
    }, [s]);
    return y(f.exports.Fragment, {
        children: [a(nr, {
            $isRequired: h,
            children: m
        }), a(E3, {
            readOnly: e,
            $hasError: !u(),
            name: i,
            value: g,
            onFocus: e ? void 0 : C,
            onBlur: e ? void 0 : b,
            onChange: p,
            "data-ats-form-field": i,
            "data-ats-form-field-type": "textarea"
        })]
    })
}, db = v.input `
  display: none;

  & + label {
    display: flex;
    margin: 0 5px;
    align-items: flex-start;
    white-space: normal;

    & .checkbox {
      flex: none;
      width: 10px;
      height: 10px;
      margin-top: 2px;
      background-color: white;
      border-width: 1px;
      border-style: solid;
      margin-right: 3px;
      position: relative;

      svg {
        width: 100%;
        height: 100%;
        fill: rgb(255, 0, 0);
        position: absolute;
        padding: 1px;
      }
    }

    & .rounded {
      border-radius: 100%;
    }
  }

  &:checked + label .checkbox .checkbox-checked {
    background-color: blue;
    position: absolute;
    top: 2px;
    bottom: 2px;
    left: 2px;
    right: 2px;

    & .rounded {
      border-radius: 100%;
    }
  }
  &:focus-visible .checkbox {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
`, M3 = ({
    label: e,
    readOnly: t,
    index: o,
    isHtmlContent: r = !1
}) => {
    const {
        name: i,
        getFieldValue: n,
        setFieldValue: l,
        label: s,
        required: u
    } = jo(), c = x.useMemo(() => n(), [n]), h = o === 0 && t ? !0 : c.includes(e), m = f.exports.useCallback(() => {
        const p = c.includes(e) ? c.filter(b => b !== e) : [...c, e];
        l(p)
    }, [c, e, l]), g = x.useCallback(p => {
        p.key === Tr.SpaceBar && m()
    }, [m]);
    return y(Hm, {
        "data-ats-form-control": "checkbox",
        onClick: t ? void 0 : m,
        onKeyDown: t ? void 0 : g,
        children: [a(db, {
            id: e,
            value: e,
            type: "checkbox",
            checked: h,
            "data-ats-form-field": i,
            "data-ats-form-field-type": "checkbox",
            onChange: Gt
        }), y("label", {
            children: [a("div", {
                className: "checkbox",
                children: h ? a(Kd, {}) : null
            }), r ? a(nr, {
                $isRequired: Boolean(u && !s),
                "data-ats-form-control-checkbox-label": e,
                dangerouslySetInnerHTML: {
                    __html: e
                }
            }) : a(nr, {
                $isRequired: Boolean(u && !s),
                "data-ats-form-control-checkbox-label": e,
                children: e
            })]
        })]
    })
}, O3 = ({
    readOnly: e,
    isHtmlContent: t
}) => {
    const {
        id: o,
        defaultValues: r,
        label: i,
        required: n
    } = jo();
    return y(ir, {
        children: [i ? a(nr, {
            $isRequired: n,
            children: i
        }) : null, r.map((l, s) => a(M3, {
            readOnly: e,
            label: l,
            index: s,
            isHtmlContent: t
        }, `${l}-${o}`))]
    })
}, A3 = v.div `
  display: flex;
  margin-top: 5px;
  
  &:focus-visible .checkbox {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
`, W3 = e => {
    const {
        label: t,
        readOnly: o,
        index: r
    } = e, i = jo(), {
        name: n,
        getFieldValue: l,
        setFieldValue: s
    } = i, u = x.useMemo(() => l(), [l]), c = r === 0 && o ? !0 : u.includes(t), h = x.useCallback(() => {
        s(t)
    }, [s, t]), m = x.useCallback(g => {
        g.key === Tr.SpaceBar && h()
    }, [h]);
    return y(A3, {
        onClick: o ? void 0 : h,
        onKeyDown: o ? void 0 : m,
        children: [a(db, {
            name: n,
            id: t,
            value: t,
            type: "radio",
            checked: c,
            "data-ats-form-field": n,
            "data-ats-form-field-type": "radio"
        }), y("label", {
            children: [a("div", {
                className: "checkbox rounded",
                children: a("div", {
                    className: "checkbox-checked rounded"
                })
            }), t]
        })]
    })
}, D3 = ({
    readOnly: e
}) => {
    const {
        id: t,
        defaultValues: o,
        label: r,
        required: i
    } = jo();
    return y(ir, {
        children: [r ? a(nr, {
            $isRequired: i,
            children: r
        }) : null, o.map((n, l) => a(W3, {
            readOnly: e,
            label: n,
            index: l
        }, `${n}-${t}`))]
    })
}, N3 = v.div `
  select {
    border: none;
    display: block;
    width: 100%;
    background-color: rgba(255, 255, 255, 1);
    appearance: none;
    overflow: auto;
  }

  display: flex;
  position: relative;
  align-items: center;
  width: 100%;
  background-color: rgba(255, 255, 255, 1);
  box-sizing: border-box;
  border: 1px solid ${({$hasError:e})=>e?"rgb(255, 0, 0)":"rgba(204, 204, 204, 1)"};
  border-radius: 7px;
  box-shadow: 2px 2px 10px 0 rgb(227 227 227) inset;
  font-family: 'Roboto-Regular', 'Roboto', sans-serif;
  font-weight: 400;
  margin: 5px auto 2px;
  padding: 12px 5px;

  @media (max-width: 900px) {
    width: 100%;
  }

  &:focus-visible {
    outline: ${fe}px solid ${({theme:e})=>e.globalDesign.colors.specialTwo};
  }
`, U3 = v.select `
    ${km};
    padding-right: 20px;
`, V3 = v.div `
  display: inline-flex;
  pointer-events: none;
  width: 20px;
  height: 21px;
  position: absolute;
  right: 4px;
`, H3 = (e, t = !1) => t ? Array.from(e.target.options).reduce((r, i) => !i.selected || i.disabled ? r : [...r, i.value], []) : [e.target.value], Tc = ({
    readOnly: e,
    multiple: t
}) => {
    const {
        setError: o
    } = Ei(), r = jo(), {
        id: i,
        name: n,
        defaultValues: l,
        getFieldValue: s,
        setFieldValue: u,
        clearFieldError: c,
        isFieldValid: h,
        required: m,
        label: g
    } = r, p = x.useMemo(() => s(), [s]), b = x.useCallback(B => {
        u(H3(B, t))
    }, [u, t]), C = x.useCallback(() => {
        const B = kn(r, p[0]);
        B && o(B)
    }, [r, o, p]), w = x.useCallback(() => {
        c()
    }, [c]);
    return y(f.exports.Fragment, {
        children: [a(nr, {
            $isRequired: m,
            children: g
        }), y(N3, {
            $hasError: !h(),
            children: [y(U3, {
                readOnly: e,
                multiple: t,
                onChange: b,
                onFocus: e ? void 0 : w,
                onBlur: e ? void 0 : C,
                "data-ats-form-field": n,
                "data-ats-form-field-type": "select",
                value: p,
                children: [y("option", {
                    disabled: !0,
                    value: "",
                    selected: !0,
                    "data-ats-form-select-field": "placeholder",
                    children: [" ", "Select value", " "]
                }), l.map(B => a("option", {
                    value: B,
                    "data-ats-form-select-option": B,
                    children: B
                }, `${B}-${i}`))]
            }), a(V3, {
                children: a(zm, {})
            })]
        })]
    })
};

function j3(e, t) {
    switch (e) {
        case Je.Text:
            return t === Pe.Date || t === Pe.Datetime ? T3 : kc;
        case Je.Textarea:
            return L3;
        case Je.Checkbox:
            return O3;
        case Je.Radio:
            return D3;
        case Je.Single_select:
            return Tc;
        case Je.Multi_select:
            return o => a(Tc, { ...o,
                multiple: !0
            });
        default:
            return kc
    }
}
const ub = ({
        field: e,
        readOnly: t,
        isHtmlContent: o
    }) => {
        const {
            isValid: r,
            clearError: i,
            getValue: n,
            setValue: l,
            getError: s
        } = Ei(), u = j3(e.format, e.valueType), c = x.useMemo(() => ({ ...e,
            clearFieldError() {
                i(e.name)
            },
            isFieldValid() {
                return r(e.name)
            },
            getFieldValue() {
                var h;
                return (h = n(e.id)) !== null && h !== void 0 ? h : []
            },
            setFieldValue(h) {
                l(e.id, h)
            },
            getFieldError() {
                return s(e.name)
            }
        }), [i, e, s, n, r, l]);
        return a(ab.Provider, {
            value: c,
            children: a(F3, {
                children: a(u, {
                    readOnly: t,
                    isHtmlContent: o
                })
            })
        })
    },
    cb = v.div `
  display: flex;
  flex-direction: column;
  gap: 20px;
`,
    z3 = v.div `
  padding: 20px 0;
`,
    _3 = e => {
        const {
            headingLabel: t,
            totalPriceLabel: o,
            products: r,
            storeCurrency: i,
            readOnly: n,
            consentFields: l
        } = e, s = Yd(), u = $3(l), c = f.exports.useMemo(() => {
            const g = r.map(p => Number(p.price)).reduce((p, b) => p + b, 0);
            return s.formatCurrency(g, i)
        }, [r, i, s]), h = f.exports.useMemo(() => {
            var g;
            return (g = r ? .map(p => ({ ...p,
                price: s.formatCurrency(p.price, i)
            }), [])) !== null && g !== void 0 ? g : []
        }, [r, i, s]), m = f.exports.useCallback(() => {
            console.log("elko")
        }, []);
        return y(ib, {
            children: [a(nb, {
                children: t
            }), h.map(g => y(S3, {
                children: [a("div", {
                    children: g.name
                }), a("div", {
                    children: g.price
                })]
            }, g.id)), a("hr", {}), y(B3, {
                children: [a("div", {
                    children: o
                }), a("div", {
                    children: c
                })]
            }), a(z3, {
                children: a(cb, {
                    children: u.map(g => a(ub, {
                        field: g,
                        readOnly: n,
                        isHtmlContent: !0
                    }, g.id))
                })
            }), a(w3, {
                onClick: m,
                children: "Place Order"
            })]
        })
    },
    G3 = v.div `
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    width: 100%;
    padding: 22px 35px 40px 35px;
    background-color: rgba(245, 247, 250, 1);
    border: none;
    border-radius: 7px;
    box-shadow: 2px 2px 10px rgb(227 227 227);
`,
    Z3 = x.createContext(null);

function Ec({
    headerLabel: e,
    fields: t,
    readOnly: o
}) {
    return y(ib, {
        children: [a(nb, {
            children: e
        }), a(cb, {
            children: t.map(r => a(ub, {
                field: r,
                readOnly: o
            }, r.id))
        })]
    })
}

function q3(e) {
    const {
        billingDetailsFields: t,
        billingDetailsHeadingLabel: o,
        contactInformationFields: r,
        contactInformationHeadingLabel: i,
        readOnly: n = !1,
        headingLabel: l,
        totalPriceLabel: s,
        products: u,
        storeCurrency: c,
        consentFields: h,
        hasConsentFields: m
    } = e, g = x.useMemo(() => r.reduce((S, $) => ({ ...S,
        [$.id]: $.format === "text" || $.format === "textarea" ? $.defaultValues : []
    }), {}), [r]), [p, b] = x.useState(g), [C, w] = x.useState([]), B = x.useMemo(() => ({
        getValue(S) {
            return p[S]
        },
        setValue(S, $) {
            b({ ...p,
                [S]: typeof $ == "string" ? [$] : $
            })
        },
        getError(S) {
            return C.find($ => $.fieldName === S)
        },
        setError(S) {
            w([...C, S])
        },
        clearError(S) {
            C.find(L => L.fieldName === S) && w(C.filter(L => L.fieldName !== S))
        },
        isValid(S) {
            return !C.some($ => $.fieldName === S)
        }
    }), [p, C]);
    return a(sb.Provider, {
        value: B,
        children: a(Z3.Provider, {
            value: e,
            children: y(G3, {
                children: [y("div", {
                    children: [a(Ec, {
                        fields: r,
                        headerLabel: i,
                        readOnly: n
                    }), a(Ec, {
                        fields: t,
                        headerLabel: o,
                        readOnly: n
                    })]
                }), a(_3, {
                    headingLabel: l,
                    totalPriceLabel: s,
                    products: u,
                    hasConsentFields: m,
                    storeCurrency: c,
                    consentFields: h,
                    readOnly: n
                })]
            })
        })
    })
}
const J3 = () => a("div", {
        style: {
            height: "100px"
        },
        children: "Confirmation page element"
    }),
    eu = x.createContext(null);

function ar() {
    const e = f.exports.useContext(eu);
    if (e === null) throw new Error("Missing ShowDepsProvider");
    return e
}
const Y3 = x.memo(e => {
    const t = f.exports.useMemo(() => {
        var o, r, i;
        return {
            content: e.content,
            flags: e.flags,
            owner: e.owner,
            handlers: (o = e.handlers) !== null && o !== void 0 ? o : {},
            cookieConsent: e.cookieConsent,
            rootContainer: {
                node: (r = e.rootContainer) !== null && r !== void 0 ? r : typeof document > "u" ? null : document.body
            },
            referenceResolver: (i = e.referenceResolver) !== null && i !== void 0 ? i : new Wn(e.content.settings)
        }
    }, [e.content, e.cookieConsent, e.flags, e.handlers, e.owner, e.rootContainer, e.referenceResolver]);
    return a(eu.Provider, {
        value: t,
        children: e.children
    })
});

function gl() {
    return ar().content
}

function Li(e) {
    const t = gl();
    return f.exports.useMemo(() => e(t), [t])
}

function X3(e) {
    const t = e.theming[De.Palette],
        o = t.availablePalettes.find(r => r.uuid === t.selectedPaletteUUID);
    if (!o) throw new Error("Missing selected palette");
    return o
}

function K3() {
    return Li(X3)
}

function hb() {
    return K3().colors
}

function Ge(e) {
    const t = hb();
    return f.exports.useMemo(() => {
        const o = {};
        for (const r in e) {
            if (!e.hasOwnProperty(r)) continue;
            const i = e[r];
            if (!eB(i)) {
                o[r] = i;
                continue
            }
            o[r] = mb(t, i)
        }
        return o
    }, [t, e])
}

function Q3(e) {
    const t = hb();
    return e === null ? null : typeof e == "string" ? e : mb(t, e)
}

function eB(e) {
    return typeof e == "object" && typeof e ? .origin == "string" && Object.values(O).includes(e.origin)
}

function tB(e) {
    return e.origin === O.Custom
}

function oB(e) {
    return e.origin === O.Palette
}

function mb(e, t) {
    if (tB(t)) return t.value;
    if (oB(t)) {
        const o = e.find(r => r.name === t.name);
        if (!o) throw new Error(`Unknown palette color: ${t.name}`);
        return o.value
    }
    throw new Error(`Unknown color: ${JSON.stringify(t)}`)
}

function bb() {
    const e = Li(t => t.settings);
    return f.exports.useMemo(() => gi.fromJson(e), [e])
}

function rB(e) {
    return Li(t => {
        var o;
        return (o = t.pages.find(r => e(r))) !== null && o !== void 0 ? o : null
    })
}

function nB(e, t) {
    return Li(o => t ? t(o.theming[e]) : o.theming[e])
}

function no(e, t) {
    return Li(o => {
        const r = t(o.theming);
        return { ...e,
            ...Object.entries(e).reduce((i, [n, l]) => {
                var s;
                return l === null && (i[n] = (s = r[n]) !== null && s !== void 0 ? s : l), i
            }, {})
        }
    })
}
var Lc;
(function(e) {
    e[e.genericValidation = 1003] = "genericValidation"
})(Lc || (Lc = {}));
class tu {
    constructor(t, o) {
        Object.defineProperty(this, "url", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "chatId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.chatId = t, this.url = new URL("/sendContactForm", o ? "https://us-central1-grchatbeta.cloudfunctions.net" : "https://us-central1-grchat-d3548.cloudfunctions.net")
    }
    static browserPartialPayload(t) {
        return {
            c: encodeURIComponent(t),
            language: window.navigator.language,
            platform: window.navigator.platform,
            pageHref: window.location.href,
            pageTitle: document.title,
            timeZoneName: Intl.DateTimeFormat().resolvedOptions().timeZone,
            timeZoneOffsetMin: new Date().getTimezoneOffset()
        }
    }
    async send(t) {
        if (!this.chatId) throw new Error("Missing chatId");
        const o = await fetch(this.url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                data: { ...tu.browserPartialPayload(this.chatId),
                    ...t
                }
            })
        });
        if (o.ok) return o.json();
        throw new Error("[Contact Form] Invalid response")
    }
}
var Mc;
(function(e) {
    e.Browser = "browser", e.Memory = "memory"
})(Mc || (Mc = {}));

function ou(e) {
    const {
        flags: t
    } = ar();
    if (!(e in t)) throw new Error(`Unknown runtime flag: ${e}`);
    return t[e]
}

function iB() {
    const e = ou("isGrChatsBeta"),
        {
            analytics: {
                chats: {
                    id: t
                }
            }
        } = bb();
    return f.exports.useMemo(() => new tu(t, e), [t, e])
}

function aB(e) {
    const {
        owner: t
    } = ar();
    return f.exports.useMemo(() => e(t), [t])
}

function lB(e) {
    const {
        href: t,
        type: o
    } = e ? ? {};
    switch (o) {
        case k.Email:
            return `mailto:${t}`;
        case k.Phone:
            return `tel:${t}`;
        case k.Protocol:
        case k.Web:
        case k.LandingPage:
        default:
            return t
    }
}

function sB(e, t) {
    return e.replace(/{{(.*?)}}/g, (o, r) => t[r] ? String(t[r]) : "")
}

function fb() {
    return ar().handlers
}

function ho(e) {
    const {
        useElementClick: t
    } = fb();
    return t ? .(e)
}

function dB() {}

function gb() {
    var e;
    return (e = fb().dispatch) !== null && e !== void 0 ? e : dB
}
class Mi {}

function uB() {
    return !1
}

function cB(e) {
    let t = null;
    return () => {
        if (t !== null) return t;
        try {
            return t = localStorage.getItem(e) !== null
        } catch (o) {
            console.warn(o)
        }
        return !1
    }
}
const hB = cB("logStats");
class mB {
    constructor() {
        Object.defineProperty(this, "listeners", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: new Map
        }), Object.defineProperty(this, "isLoggingEnabled", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: hB()
        }), this.dispatch = this.dispatch.bind(this)
    }
    dispatch(t) {
        var o;
        const r = this.listeners.get(t.constructor);
        if (this.isLoggingEnabled && (console.groupCollapsed(`%cCRS dispatcher event %c${t.constructor.name}`, "color: violet;", "color: white;"), console.log(t), console.log(`Listeners (${(o=r?.length)!==null&&o!==void 0?o:0}):`, r), console.groupEnd()), r !== void 0)
            for (const i of r) i(t)
    }
    register(t, o) {
        this.listeners.has(t) || this.listeners.set(t, []), this.listeners.get(t).push(o)
    }
}
var ut;
(function(e) {
    e[e.None = 0] = "None", e[e.Rejected = 1] = "Rejected", e[e.Accepted = 2] = "Accepted"
})(ut || (ut = {}));

function ru() {
    const e = ou("isCookieBannerEnabled"),
        t = bb(),
        o = pl(),
        [r, i] = f.exports.useState(e && t.cookieBanner.isEnabled ? o.state : ut.Accepted);
    return f.exports.useEffect(() => o.subscribe(i), [o]), r
}

function pb() {
    return ru() === ut.Accepted
}

function pl() {
    return ar().cookieConsent
}

function bB() {
    return ar().rootContainer
}

function fB() {
    return bB().node
}
const gB = "data-element-id";

function qe(e) {
    const {
        flags: t
    } = ar();
    return f.exports.useMemo(() => {
        const o = {};
        return t.isDataElementIdEnabled && (o[gB] = e.toString()), o
    }, [e, t])
}
class pB {
    static injectHead(t, o) {
        const r = document.createElement("script");
        return o && (r.onload = o), r.async = !0, r.src = t, document.head.appendChild(r), () => document.head.removeChild(r)
    }
    static injectHeadRaw(t) {
        const o = document.createElement("script");
        return o.textContent = t, document.head.appendChild(o), () => document.head.removeChild(o)
    }
}
var Rs;
(function(e) {
    e.GetResponsePoweredByBadge = "https://www.getresponse.com/features/website-builder"
})(Rs || (Rs = {}));

function yB() {
    const [e, t] = aB(o => {
        var r;
        return [(r = o.hasBadge) !== null && r !== void 0 ? r : o.isTrial || o.isFreemium, o.grBadgeUrl]
    });
    return e ? a(Hw, {
        href: t ? ? Rs.GetResponsePoweredByBadge
    }) : null
}
class xB extends Mi {
    constructor(t) {
        super(), Object.defineProperty(this, "pageId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        })
    }
}
class vB extends Mi {
    constructor(t) {
        super(), Object.defineProperty(this, "pageId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        })
    }
}
class CB extends Mi {
    constructor(t, o, r) {
        super(), Object.defineProperty(this, "pageId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "hyperlink", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "description", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.pageId = t, this.hyperlink = o, this.description = r
    }
}

function wB({
    pageId: e,
    dispatch: t
}) {
    const o = fB(),
        r = Md();
    return f.exports.useEffect(() => {
        if (!o || !r) {
            console.warn("Anchor stats are disabled due to missing `rootNode` or `hyperlinkService`", "root:", o, "service:", r);
            return
        }

        function i(n) {
            var l, s;
            let u = null,
                c = n.target;
            if (!!o.contains(c)) {
                do {
                    if (u = (l = c ? .getAttribute) === null || l === void 0 ? void 0 : l.call(c, "data-hyperlink-id"), u) break;
                    c = c ? .parentNode
                } while (c && c !== document.body && c !== o);
                if (u) {
                    const h = r.getRegisteredData(u);
                    if (!h) {
                        console.warn("Got `linkId` (", u, ") without registered data");
                        return
                    }
                    t(new CB(e, h, (s = h.description) !== null && s !== void 0 ? s : c.textContent))
                }
            }
        }
        return o.addEventListener("click", i, !0), () => o.removeEventListener("click", i, !0)
    }, [t, r, e, o]), null
}

function Xe(e, t) {
    return Object.assign(x.memo(e), t)
}
const BB = v.div `
  position: relative;
`,
    yb = "page-body",
    xb = Xe(e => {
        const {
            onClick: t
        } = e, o = ou("isExternalLinksEnabled"), r = f.exports.useMemo(() => new j, [e.pageUuid]), i = f.exports.useMemo(() => ({
            allowedHyperlinkTypes: o ? rm : [k.Internal, k.Anchor],
            allowedTargets: o ? nm : [Ce.Self]
        }), [o]), n = gb(), l = qe(e.elementId), s = f.exports.useCallback(u => {
            n(new vB(e.pageUuid)), t ? .(u)
        }, [n, t, e.pageUuid]);
        return f.exports.useEffect(() => {
            n(new xB(e.pageUuid))
        }, [n, e.pageUuid]), a(im.Provider, {
            value: i,
            children: y(om.Provider, {
                value: r,
                children: [a(wB, {
                    pageId: e.pageUuid,
                    dispatch: n
                }), y(BB, {
                    id: yb,
                    role: "presentation",
                    onClick: s,
                    className: e.className,
                    ...l,
                    children: [e.children, a(yB, {})]
                })]
            })
        })
    }, {
        loadTranslation: !1
    }),
    SB = Xe(e => {
        const {
            buttonText: t,
            hyperlink: o,
            boxBorderColorRight: r,
            boxBorderColorLeft: i,
            boxBorderColorBottom: n,
            boxBackgroundColor: l,
            align: s,
            boxBorderColorTop: u,
            boxBorderRadiusBottomLeft: c,
            boxBorderRadiusBottomRight: h,
            boxBorderRadiusTopLeft: m,
            boxBorderRadiusTopRight: g,
            boxBorderStyleBottom: p,
            boxBorderStyleLeft: b,
            boxBorderStyleRight: C,
            boxBorderStyleTop: w,
            boxBorderWidthBottom: B,
            boxBorderWidthLeft: S,
            boxBorderWidthRight: $,
            boxBorderWidthTop: L,
            boxPaddingBottom: M,
            boxPaddingLeft: F,
            boxPaddingRight: A,
            boxPaddingTop: z,
            boxShadowBlurRadius: _,
            isBoxRadiusEnabled: Z,
            isBoxPaddingEnabled: G,
            boxShadowColor: H,
            boxShadowOffsetX: te,
            boxShadowOffsetY: oe,
            boxShadowOpacity: re,
            boxShadowSpreadRadius: Q,
            isBoxBorderEnabled: J,
            isBoxShadowEnabled: ee,
            elementPosition: le,
            className: ue,
            backgroundColor: me,
            backgroundColorHover: ie,
            borderColorBottom: Y,
            borderColorLeft: ae,
            borderColorRight: X,
            borderColorTop: ge,
            shadowColor: ce,
            textColor: de,
            textColorHover: ne,
            paddingRight: Se,
            paddingLeft: Fe,
            paddingBottom: $e,
            paddingTop: Ie,
            fontFamily: xe,
            borderRadiusBottomLeft: ke,
            borderRadiusBottomRight: Le,
            borderRadiusTopLeft: We,
            borderRadiusTopRight: Ke,
            isRadiusEnabled: at,
            borderStyleBottom: wt,
            borderStyleLeft: ht,
            borderStyleRight: Bt,
            borderStyleTop: tt,
            borderWidthBottom: mt,
            borderWidthLeft: yt,
            borderWidthRight: xt,
            borderWidthTop: Ft,
            fontSize: vt,
            isBold: St,
            isBorderEnabled: Ut,
            isItalic: Vt,
            isShadowEnabled: eo,
            isUnderline: Fo,
            shadowBlurRadius: mo,
            shadowOffsetX: Io,
            shadowOffsetY: qt,
            shadowOpacity: dr,
            shadowSpreadRadius: ur
        } = Ge(no(e, ko => {
            var hr;
            return (hr = ko[De.Button].customProperties) !== null && hr !== void 0 ? hr : ko[De.Button].defaultProperties
        })), cr = qe(e.elementId), bo = o && lB(o) ? "pointer" : "auto";
        return a(xm, {
            globalClassName: I.Button,
            $backgroundColor: me,
            $backgroundColorHover: ie,
            $borderColorBottom: Y,
            $borderColorLeft: ae,
            $borderColorRight: X,
            $borderColorTop: ge,
            $shadowColor: ce,
            $textColor: de,
            $textColorHover: ne,
            $boxBorderColorRight: r,
            $boxBorderColorLeft: i,
            $boxBorderColorBottom: n,
            $boxBackgroundColor: l,
            $paddingRight: Se,
            $paddingLeft: Fe,
            $paddingBottom: $e,
            $paddingTop: Ie,
            $fontFamily: xe,
            $align: s,
            $borderRadiusBottomLeft: ke,
            $borderRadiusBottomRight: Le,
            $borderRadiusTopLeft: We,
            $borderRadiusTopRight: Ke,
            $isRadiusEnabled: at,
            $borderStyleBottom: wt,
            $borderStyleLeft: ht,
            $borderStyleRight: Bt,
            $borderStyleTop: tt,
            $borderWidthBottom: mt,
            $borderWidthLeft: yt,
            $borderWidthRight: xt,
            $borderWidthTop: Ft,
            $boxBorderColorTop: u,
            $boxBorderRadiusBottomLeft: c,
            $boxBorderRadiusBottomRight: h,
            $boxBorderRadiusTopLeft: m,
            $boxBorderRadiusTopRight: g,
            $boxBorderStyleBottom: p,
            $boxBorderStyleLeft: b,
            $boxBorderStyleRight: C,
            $boxBorderStyleTop: w,
            $boxBorderWidthBottom: B,
            $boxBorderWidthLeft: S,
            $boxBorderWidthRight: $,
            $boxBorderWidthTop: L,
            $boxPaddingBottom: M,
            $boxPaddingLeft: F,
            $boxPaddingRight: A,
            $boxPaddingTop: z,
            $boxShadowBlurRadius: _,
            $boxShadowColor: H,
            $boxShadowOffsetX: te,
            $boxShadowOffsetY: oe,
            $boxShadowOpacity: re,
            $boxShadowSpreadRadius: Q,
            $fontSize: vt,
            $isBold: St,
            $isBorderEnabled: Ut,
            $isBoxBorderEnabled: J,
            $isBoxShadowEnabled: ee,
            $isItalic: Vt,
            $isShadowEnabled: eo,
            $isBoxRadiusEnabled: Z,
            $isBoxPaddingEnabled: G,
            $isUnderline: Fo,
            $shadowBlurRadius: mo,
            $shadowOffsetX: Io,
            $shadowOffsetY: qt,
            $shadowOpacity: dr,
            $shadowSpreadRadius: ur,
            onClick: ho(e),
            $cursor: bo,
            $position: le,
            className: ue,
            ...cr,
            children: a($o, {
                hyperlink: o,
                description: t,
                emptyContainer: a("button", {
                    type: "button"
                }),
                children: a("span", {
                    children: t
                })
            })
        })
    }, {
        loadTranslation: !1
    });

function Oi({
    theme: e
}) {
    var t;
    return ze((t = e.globalDesign) === null || t === void 0 ? void 0 : t.contentWidth)
}
const $B = v.div `
    display: flex;

    @media ${Oi} {
        display: block;
    }
`,
    RB = Xe(({
        children: e,
        className: t,
        elementId: o
    }) => {
        const r = qe(o);
        return a($B, {
            className: t,
            ...r,
            children: e
        })
    }, {
        loadTranslation: !1
    }),
    PB = v.div `
    width: ${({$width:e})=>e}%;

    @media ${Oi} {
        width: auto;
    }

    ${Dt}

    .content-wrapper {
        max-width: 100%;
    }
`,
    FB = Xe(({
        elementId: e,
        children: t,
        elementPosition: o,
        width: r,
        className: i
    }) => {
        const n = qe(e);
        return a(PB, {
            $width: r,
            $position: o,
            className: i,
            ...n,
            children: a("div", {
                className: "content-wrapper",
                children: t
            })
        })
    }, {
        loadTranslation: !1
    });

function IB(e) {
    const {
        backgroundVideo: t,
        isFullWidth: o,
        borderStyleRight: r,
        borderStyleLeft: i,
        borderStyleBottom: n,
        borderRadiusTopRight: l,
        borderRadiusTopLeft: s,
        borderRadiusBottomRight: u,
        borderRadiusBottomLeft: c,
        isRadiusEnabled: h,
        borderColorTop: m,
        borderColorRight: g,
        borderColorLeft: p,
        borderColorBottom: b,
        borderStyleTop: C,
        borderWidthBottom: w,
        borderWidthLeft: B,
        borderWidthRight: S,
        borderWidthTop: $,
        isBorderEnabled: L,
        $opacity: M
    } = e;
    return a(Lv, {
        $borderStyleRight: r,
        $borderStyleLeft: i,
        $borderStyleBottom: n,
        $borderRadiusTopRight: l,
        $borderRadiusTopLeft: s,
        $borderRadiusBottomRight: u,
        $borderRadiusBottomLeft: c,
        $isRadiusEnabled: h,
        $borderColorTop: m,
        $borderColorRight: g,
        $borderColorLeft: p,
        $borderColorBottom: b,
        $borderStyleTop: C,
        $borderWidthBottom: w,
        $borderWidthLeft: B,
        $borderWidthRight: S,
        $borderWidthTop: $,
        $isBorderEnabled: L,
        $isFullWidth: o,
        $opacity: M,
        children: a(Av, {
            src: t,
            autoPlay: !0,
            muted: !0,
            loop: !0,
            $borderRadiusTopRight: l,
            $borderRadiusTopLeft: s,
            $borderRadiusBottomRight: u,
            $borderRadiusBottomLeft: c,
            $isRadiusEnabled: h,
            $borderWidthBottom: w,
            $borderWidthLeft: B,
            $borderWidthRight: S,
            $borderWidthTop: $,
            $isBorderEnabled: L,
            playsInline: !0
        })
    })
}
class kB extends Error {
    constructor(t) {
        super(`Unknown source type: ${t}`)
    }
}

function yl(e) {
    if (dh(e)) return e.data.src;
    if (Fr(e)) {
        const {
            src: t
        } = e.data;
        if (t.startsWith("/")) return `https://m.gr-cdn-3.com${t}`;
        const o = new URL(t);
        return !o.pathname.startsWith("/user") && o.host === "multimedia.getresponse.com" ? (o.protocol = "https:", o.host = "m.gr-cdn-3.com", o.toString()) : t
    }
    throw new kB(e.type)
}

function nu(e) {
    var t;
    return e && Fr(e) ? (t = e.data.fallback) !== null && t !== void 0 ? t : [] : []
}

function vb(e) {
    const t = f.exports.useMemo(() => e ? yl(e) : void 0, [e]);
    return Cy(t, nu(e))
}
const TB = Xe(e => {
    const {
        children: t,
        backgroundImage: o,
        backgroundVideo: r,
        backgroundColor: i,
        isFullWidth: n,
        borderStyleRight: l,
        borderStyleLeft: s,
        borderStyleBottom: u,
        borderRadiusTopRight: c,
        borderRadiusTopLeft: h,
        borderRadiusBottomRight: m,
        borderRadiusBottomLeft: g,
        isRadiusEnabled: p,
        borderColorTop: b,
        borderColorRight: C,
        borderColorLeft: w,
        borderColorBottom: B,
        borderStyleTop: S,
        borderWidthBottom: $,
        borderWidthLeft: L,
        borderWidthRight: M,
        borderWidthTop: F,
        isBorderEnabled: A,
        shadowOffsetX: z,
        shadowOffsetY: _,
        shadowBlurRadius: Z,
        shadowSpreadRadius: G,
        shadowColor: H,
        shadowOpacity: te,
        isShadowEnabled: oe,
        paddingBottom: re,
        paddingTop: Q,
        paddingRight: J,
        paddingLeft: ee,
        bottomSpace: le,
        elementPosition: ue,
        className: me,
        elementId: ie,
        backgroundOpacity: Y,
        isBackgroundMediaEnabled: ae,
        scrollingBehavior: X,
        backgroundRepeat: ge,
        backgroundSize: ce,
        backgroundPosition: de
    } = Ge(e), ne = vb(ae ? o : null), Se = ae && r ? yl(r) : "", Fe = Lm(o), $e = f.exports.useMemo(() => ({
        elementId: ie,
        backgroundColor: i
    }), [ie, i]), Ie = qe(e.elementId);
    return a(Dm.Provider, {
        value: $e,
        children: a(jv, {
            bottomSpace: le,
            className: me,
            id: ie,
            scrollingBehavior: X,
            children: y(Ov, {
                $backgroundColor: i,
                $backgroundImage: ne,
                $isFullWidth: n,
                $borderStyleRight: l,
                $borderStyleLeft: s,
                $borderStyleBottom: u,
                $borderRadiusTopRight: c,
                $borderRadiusTopLeft: h,
                $borderRadiusBottomRight: m,
                $borderRadiusBottomLeft: g,
                $isRadiusEnabled: p,
                $borderColorTop: b,
                $borderColorRight: C,
                $borderColorLeft: w,
                $borderColorBottom: B,
                $borderStyleTop: S,
                $borderWidthBottom: $,
                $borderWidthLeft: L,
                $borderWidthRight: M,
                $borderWidthTop: F,
                $isBorderEnabled: A,
                $shadowOffsetX: z,
                $shadowOffsetY: _,
                $shadowBlurRadius: Z,
                $shadowSpreadRadius: G,
                $shadowColor: H,
                $shadowOpacity: te,
                $isShadowEnabled: oe,
                ...Ie,
                children: [Se ? a(IB, {
                    borderStyleRight: l,
                    borderStyleLeft: s,
                    borderStyleBottom: u,
                    borderRadiusTopRight: c,
                    borderRadiusTopLeft: h,
                    borderRadiusBottomRight: m,
                    borderRadiusBottomLeft: g,
                    isRadiusEnabled: p,
                    borderColorTop: b,
                    borderColorRight: C,
                    borderColorLeft: w,
                    borderColorBottom: B,
                    borderStyleTop: S,
                    borderWidthBottom: $,
                    borderWidthLeft: L,
                    borderWidthRight: M,
                    borderWidthTop: F,
                    isBorderEnabled: A,
                    backgroundVideo: Se,
                    isFullWidth: n,
                    $opacity: Y
                }) : null, y(Mv, {
                    $isFullWidth: n,
                    $backgroundImage: ne,
                    $borderRadiusTopRight: c,
                    $borderRadiusTopLeft: h,
                    $borderRadiusBottomRight: m,
                    $borderRadiusBottomLeft: g,
                    $isRadiusEnabled: p,
                    $borderWidthBottom: $,
                    $borderWidthLeft: L,
                    $borderWidthRight: M,
                    $borderWidthTop: F,
                    $isBorderEnabled: A,
                    $opacity: Y,
                    $backgroundRepeat: ge,
                    $backgroundPosition: de,
                    $backgroundSize: ce,
                    $backgroundImageResolution: Fe,
                    children: [a(Ev, {
                        globalClassName: I.Section,
                        $paddingTop: Q,
                        $paddingBottom: re,
                        $paddingLeft: ee,
                        $paddingRight: J,
                        $isResponsive: !0,
                        $position: ue,
                        children: t
                    }), a("div", {
                        className: "bottom-spacer"
                    })]
                })]
            })
        })
    })
}, {
    loadTranslation: !1
});

function EB() {
    const e = Dn();
    if (e === null) throw new Error("Missing INavigationService implementation");
    return e
}
class LB {
    constructor(t) {
        Object.defineProperty(this, "scripts", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "callbacks", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: []
        }), Object.defineProperty(this, "isDisposed", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: !1
        }), this.dispose = this.dispose.bind(this)
    }
    replace(t, o) {
        if (this.isDisposed) throw new Error("HTMLScriptsLoader was destroyed!");
        o.parentNode ? o.parentNode.replaceChild(t, o) : (console.warn("Found detached script tag", o), document.head.appendChild(t), this.callbacks.push(() => document.head.removeChild(t)))
    }
    copy(t) {
        const o = Object.assign(document.createElement("script"), {
            async: !1
        });
        return t.getAttributeNames().forEach(r => o.setAttribute(r, t.getAttribute(r))), t.textContent && (o.textContent = t.textContent), o
    }
    async process() {
        const [t, o] = pi(this.scripts, r => Boolean(r.src));
        await Promise.all(t.map(r => {
            const i = this.copy(r),
                n = i.defer || i.async ? i : new Promise(l => i.onload = i.onerror = () => l(i));
            return this.replace(i, r), n
        })), o.forEach(r => this.replace(this.copy(r), r))
    }
    dispose() {
        this.isDisposed || (this.callbacks.forEach(t => t()), this.isDisposed = !0)
    }
}

function Cb(e, t) {
    const o = EB();
    f.exports.useEffect(() => {
        if (!o.isClientSideNavigation || e.current === null) return;
        const r = new LB(Array.from(e.current.querySelectorAll("script")));
        return r.process().catch(i => {
            console.warn(i), r.dispose()
        }), r.dispose
    }, [e, o.isClientSideNavigation, t])
}
const MB = Xe(({
        elementPosition: e,
        ...t
    }) => {
        const o = f.exports.useRef(null),
            r = qe(t.elementId);
        return Cb(o, t.content), a(ox, {
            onClick: ho(t),
            $position: e,
            className: t.className,
            ref: o,
            ...r,
            children: a("div", {
                dangerouslySetInnerHTML: {
                    __html: t.content
                }
            })
        })
    }, {
        loadTranslation: !1
    }),
    OB = Xe(e => {
        const {
            align: t,
            direction: o,
            width: r,
            height: i,
            borderStyleTop: n,
            borderStyleRight: l,
            borderStyleBottom: s,
            borderStyleLeft: u,
            borderColorTop: c,
            borderColorRight: h,
            borderColorBottom: m,
            borderColorLeft: g,
            borderWidthTop: p,
            borderWidthRight: b,
            borderWidthBottom: C,
            borderWidthLeft: w,
            boxBackgroundColor: B,
            isBoxBorderEnabled: S,
            isBoxShadowEnabled: $,
            boxBorderColorRight: L,
            boxBorderColorLeft: M,
            boxBorderColorBottom: F,
            boxBorderColorTop: A,
            boxBorderStyleBottom: z,
            boxBorderStyleLeft: _,
            boxBorderStyleRight: Z,
            boxBorderStyleTop: G,
            boxBorderWidthBottom: H,
            boxBorderWidthLeft: te,
            boxBorderWidthRight: oe,
            boxBorderWidthTop: re,
            boxBorderRadiusBottomLeft: Q,
            boxBorderRadiusBottomRight: J,
            boxBorderRadiusTopLeft: ee,
            boxBorderRadiusTopRight: le,
            boxPaddingBottom: ue,
            boxPaddingLeft: me,
            boxPaddingRight: ie,
            boxPaddingTop: Y,
            boxShadowBlurRadius: ae,
            boxShadowSpreadRadius: X,
            boxShadowColor: ge,
            boxShadowOpacity: ce,
            boxShadowOffsetX: de,
            boxShadowOffsetY: ne,
            isBoxRadiusEnabled: Se,
            isBoxPaddingEnabled: Fe,
            elementPosition: $e,
            className: Ie
        } = Ge(e), xe = qe(e.elementId);
        return a(oC, {
            globalClassName: I.Divider,
            $direction: o,
            $boxBackgroundColor: B,
            $isBoxBorderEnabled: S,
            $boxBorderColorRight: L,
            $boxBorderColorLeft: M,
            $boxBorderColorBottom: F,
            $boxBorderColorTop: A,
            $boxBorderStyleBottom: z,
            $boxBorderStyleLeft: _,
            $boxBorderStyleRight: Z,
            $boxBorderStyleTop: G,
            $boxBorderWidthBottom: H,
            $boxBorderWidthLeft: te,
            $boxBorderWidthRight: oe,
            $boxBorderWidthTop: re,
            $boxBorderRadiusBottomLeft: Q,
            $boxBorderRadiusBottomRight: J,
            $boxBorderRadiusTopLeft: ee,
            $boxBorderRadiusTopRight: le,
            $boxPaddingBottom: ue,
            $boxPaddingLeft: me,
            $boxPaddingRight: ie,
            $boxPaddingTop: Y,
            $isBoxShadowEnabled: $,
            $isBoxRadiusEnabled: Se,
            $isBoxPaddingEnabled: Fe,
            $boxShadowBlurRadius: ae,
            $boxShadowColor: ge,
            $boxShadowOffsetX: de,
            $boxShadowOffsetY: ne,
            $boxShadowOpacity: ce,
            $boxShadowSpreadRadius: X,
            $position: $e,
            className: Ie,
            onClick: ho(e),
            ...xe,
            children: a(Qv, {
                $align: t,
                $direction: o,
                $width: r,
                $height: i,
                $borderStyleTop: n,
                $borderStyleRight: l,
                $borderStyleBottom: s,
                $borderStyleLeft: u,
                $borderColorTop: c,
                $borderColorRight: h,
                $borderColorBottom: m,
                $borderColorLeft: g,
                $borderWidthTop: p,
                $borderWidthRight: b,
                $borderWidthBottom: C,
                $borderWidthLeft: w,
                $isBorderEnabled: !0
            })
        })
    }, {
        loadTranslation: !1
    });

function AB(e) {
    if (e.source === null) throw new Error("Image without source rendering attempt");
    return yl(e.source)
}

function WB() {
    return null
}

function DB(e) {
    return e.source ? nu(e.source) : []
}
const NB = Xe(e => {
        const {
            boxBorderColorTop: t,
            boxBorderRadiusBottomLeft: o,
            boxBorderRadiusBottomRight: r,
            boxBorderRadiusTopLeft: i,
            boxBorderRadiusTopRight: n,
            boxBorderStyleBottom: l,
            boxBorderStyleLeft: s,
            boxBorderStyleRight: u,
            boxBorderStyleTop: c,
            boxBorderWidthBottom: h,
            boxBorderWidthLeft: m,
            boxBorderWidthRight: g,
            boxBorderWidthTop: p,
            boxPaddingBottom: b,
            boxPaddingLeft: C,
            boxPaddingRight: w,
            boxPaddingTop: B,
            boxShadowBlurRadius: S,
            boxShadowColor: $,
            boxShadowOffsetX: L,
            boxShadowOffsetY: M,
            boxShadowOpacity: F,
            boxShadowSpreadRadius: A,
            boxBorderColorRight: z,
            boxBorderColorLeft: _,
            boxBorderColorBottom: Z,
            boxBackgroundColor: G,
            isBoxShadowEnabled: H,
            isBoxBorderEnabled: te,
            sources: oe,
            imagesVerticalSpacing: re,
            imagesHorizontalSpacing: Q,
            slideshowWidth: J,
            slideshowHeight: ee,
            galleryType: le,
            borderColorTop: ue,
            borderColorRight: me,
            borderColorLeft: ie,
            borderColorBottom: Y,
            shadowColor: ae,
            isShadowEnabled: X,
            shadowBlurRadius: ge,
            shadowOffsetX: ce,
            shadowOffsetY: de,
            shadowOpacity: ne,
            shadowSpreadRadius: Se,
            borderStyleBottom: Fe,
            borderStyleLeft: $e,
            borderStyleRight: Ie,
            borderStyleTop: xe,
            borderWidthBottom: ke,
            borderWidthLeft: Le,
            borderWidthRight: We,
            borderWidthTop: Ke,
            isBorderEnabled: at,
            borderRadiusBottomLeft: wt,
            borderRadiusBottomRight: ht,
            borderRadiusTopLeft: Bt,
            borderRadiusTopRight: tt,
            isRadiusEnabled: mt,
            isBoxRadiusEnabled: yt,
            isBoxPaddingEnabled: xt,
            width: Ft,
            height: vt,
            elementPosition: St,
            className: Ut
        } = Ge(e), Vt = qe(e.elementId), eo = ho(e);
        return oe.length === 0 ? null : a(gC, {
            $boxBackgroundColor: G,
            $isBoxBorderEnabled: te,
            $boxBorderColorRight: z,
            $boxBorderColorLeft: _,
            $boxShadowColor: $,
            $boxBorderColorBottom: Z,
            $boxBorderColorTop: t,
            $boxBorderStyleBottom: l,
            $boxBorderStyleLeft: s,
            $boxBorderStyleRight: u,
            $boxBorderStyleTop: c,
            $boxBorderWidthBottom: h,
            $boxBorderWidthLeft: m,
            $boxBorderWidthRight: g,
            $boxBorderWidthTop: p,
            $boxBorderRadiusBottomLeft: o,
            $boxBorderRadiusBottomRight: r,
            $boxBorderRadiusTopLeft: i,
            $boxBorderRadiusTopRight: n,
            $boxPaddingBottom: b,
            $boxPaddingLeft: C,
            $boxPaddingRight: w,
            $boxPaddingTop: B,
            $isBoxShadowEnabled: H,
            $isBoxRadiusEnabled: yt,
            $isBoxPaddingEnabled: xt,
            $boxShadowBlurRadius: S,
            $boxShadowOffsetX: L,
            $boxShadowOffsetY: M,
            $boxShadowOpacity: F,
            $boxShadowSpreadRadius: A,
            "data-ats-canvas-view-element": I.Gallery,
            $position: St,
            className: Ut,
            onClick: eo,
            ...Vt,
            children: a(wC, {
                getImageAuthor: WB,
                getImageSource: AB,
                getSourceSet: DB,
                isEnableHyperLinkAction: !0,
                isModalEnabled: !0,
                isPlaceholderAvailable: !1,
                isEnableSlideshowScroll: !0,
                galleryType: le,
                sources: oe,
                slideshowWidth: J,
                slideshowHeight: ee,
                $width: Ft,
                $height: vt,
                imagesHorizontalSpacing: Q,
                imagesVerticalSpacing: re,
                $isBorderEnabled: at,
                $borderColorTop: ue,
                $borderColorRight: me,
                $borderColorLeft: ie,
                $borderColorBottom: Y,
                $borderStyleBottom: Fe,
                $borderStyleLeft: $e,
                $borderStyleRight: Ie,
                $borderStyleTop: xe,
                $borderWidthTop: Ke,
                $borderWidthBottom: ke,
                $borderWidthLeft: Le,
                $borderWidthRight: We,
                $isShadowEnabled: X,
                $shadowColor: ae,
                $shadowBlurRadius: ge,
                $shadowOffsetX: ce,
                $shadowOffsetY: de,
                $shadowOpacity: ne,
                $shadowSpreadRadius: Se,
                $borderRadiusBottomLeft: wt,
                $borderRadiusBottomRight: ht,
                $borderRadiusTopLeft: Bt,
                $borderRadiusTopRight: tt,
                $isRadiusEnabled: mt
            })
        })
    }, {
        loadTranslation: !1
    }),
    UB = Xe(e => {
        const {
            hyperlink: t,
            align: o,
            width: r,
            height: i,
            isAdjustToWidth: n,
            borderStyleRight: l,
            borderStyleLeft: s,
            borderStyleBottom: u,
            borderColorTop: c,
            borderColorRight: h,
            borderColorLeft: m,
            borderColorBottom: g,
            borderStyleTop: p,
            borderWidthBottom: b,
            borderWidthLeft: C,
            borderWidthRight: w,
            borderWidthTop: B,
            paddingTop: S,
            paddingBottom: $,
            paddingLeft: L,
            paddingRight: M,
            shadowOffsetX: F,
            shadowOffsetY: A,
            shadowSpreadRadius: z,
            shadowBlurRadius: _,
            shadowColor: Z,
            shadowOpacity: G,
            isShadowEnabled: H,
            borderRadiusTopLeft: te,
            borderRadiusBottomLeft: oe,
            borderRadiusTopRight: re,
            borderRadiusBottomRight: Q,
            isBorderEnabled: J,
            boxBorderColorTop: ee,
            boxBorderRadiusBottomLeft: le,
            boxBorderRadiusBottomRight: ue,
            boxBorderRadiusTopLeft: me,
            boxBorderRadiusTopRight: ie,
            boxBorderStyleBottom: Y,
            boxBorderStyleLeft: ae,
            boxBorderStyleRight: X,
            boxBorderStyleTop: ge,
            boxBorderWidthBottom: ce,
            boxBorderWidthLeft: de,
            boxBorderWidthRight: ne,
            boxBorderWidthTop: Se,
            boxPaddingBottom: Fe,
            boxPaddingLeft: $e,
            boxPaddingRight: Ie,
            boxPaddingTop: xe,
            boxShadowBlurRadius: ke,
            boxShadowColor: Le,
            boxShadowOffsetX: We,
            boxShadowOffsetY: Ke,
            boxShadowOpacity: at,
            boxShadowSpreadRadius: wt,
            boxBorderColorRight: ht,
            boxBorderColorLeft: Bt,
            boxBorderColorBottom: tt,
            boxBackgroundColor: mt,
            isBoxShadowEnabled: yt,
            isBoxBorderEnabled: xt,
            isBoxRadiusEnabled: Ft,
            isBoxPaddingEnabled: vt,
            elementPosition: St,
            className: Ut,
            opacity: Vt,
            isRadiusEnabled: eo
        } = Ge(e), Fo = qe(e.elementId), mo = e.src ? yl(e.src) : null, Io = ho(e);
        return mo === null ? null : a(ww, {
            globalClassName: I.Image,
            $align: o,
            $isBoxRadiusEnabled: Ft,
            $isBoxPaddingEnabled: vt,
            $boxBorderColorTop: ee,
            $boxBorderRadiusBottomLeft: le,
            $boxBorderRadiusBottomRight: ue,
            $boxBorderRadiusTopLeft: me,
            $boxBorderRadiusTopRight: ie,
            $boxBorderStyleBottom: Y,
            $boxBorderStyleLeft: ae,
            $boxBorderStyleRight: X,
            $boxBorderStyleTop: ge,
            $boxBorderWidthBottom: ce,
            $boxBorderWidthLeft: de,
            $boxBorderWidthRight: ne,
            $boxBorderWidthTop: Se,
            $boxPaddingBottom: Fe,
            $boxPaddingLeft: $e,
            $boxPaddingRight: Ie,
            $boxPaddingTop: xe,
            $boxShadowBlurRadius: ke,
            $boxShadowColor: Le,
            $boxShadowOffsetX: We,
            $boxShadowOffsetY: Ke,
            $boxShadowOpacity: at,
            $boxShadowSpreadRadius: wt,
            $boxBorderColorRight: ht,
            $boxBorderColorLeft: Bt,
            $boxBorderColorBottom: tt,
            $boxBackgroundColor: mt,
            $isBoxShadowEnabled: yt,
            $isBoxBorderEnabled: xt,
            onClick: Io,
            $position: St,
            className: Ut,
            $opacity: Vt,
            ...Fo,
            children: a(Bw, {
                hyperlink: t,
                description: e.alt,
                $isAdjustToWidth: n,
                $align: o,
                $borderStyleRight: l,
                $borderStyleLeft: s,
                $borderStyleBottom: u,
                $borderColorTop: c,
                $borderColorRight: h,
                $borderColorLeft: m,
                $borderColorBottom: g,
                $borderStyleTop: p,
                $borderWidthBottom: b,
                $borderWidthLeft: C,
                $borderWidthRight: w,
                $borderWidthTop: B,
                $paddingTop: S,
                $paddingBottom: $,
                $paddingLeft: L,
                $paddingRight: M,
                $shadowOffsetX: F,
                $shadowOffsetY: A,
                $shadowSpreadRadius: z,
                $shadowBlurRadius: _,
                $shadowColor: Z,
                $shadowOpacity: G,
                $isShadowEnabled: H,
                $borderRadiusTopLeft: te,
                $borderRadiusBottomLeft: oe,
                $borderRadiusTopRight: re,
                $borderRadiusBottomRight: Q,
                $isRadiusEnabled: eo,
                $isBorderEnabled: J,
                children: a($w, {
                    loading: "lazy",
                    decoding: "async",
                    alt: e.alt,
                    src: mo,
                    sourceSet: nu(e.src),
                    width: r,
                    height: i,
                    $isAdjustToWidth: n
                })
            })
        })
    }, {
        loadTranslation: !1
    });
class VB {
    get basicUrl() {
        return this.url.host ? new URL(this.url.pathname, this.url.href).toString() : this.url.pathname
    }
    get searchParams() {
        return this.url.searchParams
    }
}
class HB extends VB {
    get url() {
        if (typeof window > "u") throw new Error("BrowserPageUrlService is supported only on client side");
        return new URL(window.location.href)
    }
}
const wb = f.exports.createContext(new HB);

function jB() {
    const e = f.exports.useContext(wb);
    if (!e) throw new Error("Missing PageUrl context");
    return e
}
const zB = e => {
        const {
            type: t,
            iconsSize: o,
            customIconsSize: r,
            variant: i,
            action: n,
            fontFamily: l,
            fontSize: s,
            isBold: u,
            isItalic: c,
            isUnderline: h,
            labelColor: m,
            label: g,
            alt: p,
            elementId: b,
            iconsColor: C
        } = e, {
            basicUrl: w
        } = jB(), B = f.exports.useMemo(() => e.hyperlink ? { ...e.hyperlink,
            href: sB(e.hyperlink.href, {
                PAGE_URL: w
            })
        } : null, [e.hyperlink, w]), S = M2[i], $ = S.iconsSet[t], L = Q3(S.color);
        return a(Qh, {
            $iconsSize: o,
            $customIconsSize: r,
            $color: C ? ? L,
            children: y(mm, {
                hyperlink: B,
                $cursor: B ? .href ? "pointer" : "default",
                $labelColor: m,
                $fontFamily: l,
                $fontSize: s,
                $isBold: u,
                $isItalic: c,
                $isUnderline: h,
                children: [a($, {
                    alt: p ? ? void 0,
                    id: `${b}-${t}`
                }), n === Xo.Share ? a(yr, {
                    children: g
                }) : null]
            })
        })
    },
    _B = Xe(e => {
        const {
            align: t,
            boxPaddingTop: o,
            boxPaddingRight: r,
            boxPaddingLeft: i,
            boxPaddingBottom: n,
            boxBackgroundColor: l,
            direction: s,
            [e.action]: {
                medias: u
            },
            action: c,
            fontFamily: h,
            fontSize: m,
            isBold: g,
            isItalic: p,
            isUnderline: b,
            labelColor: C,
            elementId: w,
            iconsSpacing: B,
            iconsSize: S,
            customIconsSize: $,
            iconsVariant: L,
            iconsColor: M,
            boxBorderRadiusTopLeft: F,
            boxBorderRadiusTopRight: A,
            boxBorderRadiusBottomLeft: z,
            boxBorderRadiusBottomRight: _,
            boxShadowOffsetX: Z,
            boxShadowOffsetY: G,
            boxShadowBlurRadius: H,
            boxShadowSpreadRadius: te,
            boxShadowColor: oe,
            boxShadowOpacity: re,
            isBoxShadowEnabled: Q,
            boxBorderColorTop: J,
            boxBorderColorLeft: ee,
            boxBorderColorRight: le,
            boxBorderColorBottom: ue,
            boxBorderStyleTop: me,
            boxBorderStyleLeft: ie,
            boxBorderStyleRight: Y,
            boxBorderStyleBottom: ae,
            boxBorderWidthTop: X,
            boxBorderWidthLeft: ge,
            boxBorderWidthRight: ce,
            boxBorderWidthBottom: de,
            isBoxBorderEnabled: ne,
            isBoxPaddingEnabled: Se,
            isBoxRadiusEnabled: Fe,
            elementPosition: $e,
            className: Ie
        } = Ge(e), xe = qe(e.elementId);
        return a(Oy, {
            globalClassName: I.SocialMedia,
            onClick: ho(e),
            $align: t,
            $direction: s,
            $spacing: B,
            $boxPaddingTop: o,
            $boxPaddingBottom: n,
            $boxPaddingLeft: i,
            $boxPaddingRight: r,
            $boxBackgroundColor: l,
            $boxBorderRadiusTopLeft: F,
            $boxBorderRadiusTopRight: A,
            $boxBorderRadiusBottomLeft: z,
            $boxBorderRadiusBottomRight: _,
            $boxShadowOffsetX: Z,
            $boxShadowOffsetY: G,
            $boxShadowBlurRadius: H,
            $boxShadowSpreadRadius: te,
            $boxShadowColor: oe,
            $boxShadowOpacity: re,
            $isBoxShadowEnabled: Q,
            $boxBorderColorTop: J,
            $boxBorderColorLeft: ee,
            $boxBorderColorRight: le,
            $boxBorderColorBottom: ue,
            $boxBorderStyleTop: me,
            $boxBorderStyleLeft: ie,
            $boxBorderStyleRight: Y,
            $boxBorderStyleBottom: ae,
            $boxBorderWidthTop: X,
            $boxBorderWidthLeft: ge,
            $boxBorderWidthRight: ce,
            $boxBorderWidthBottom: de,
            $isBoxBorderEnabled: ne,
            $position: $e,
            className: Ie,
            $isBoxPaddingEnabled: Se,
            $isBoxRadiusEnabled: Fe,
            ...xe,
            children: u.filter(ke => ke.isEnabled).map(ke => a(zB, {
                action: c,
                type: ke.type,
                iconsSize: S,
                customIconsSize: $,
                variant: L,
                fontFamily: h,
                fontSize: m,
                isBold: g,
                isItalic: p,
                isUnderline: b,
                labelColor: C,
                label: ke.data.label,
                hyperlink: ke.data.hyperlink,
                alt: ke.data.alt,
                elementId: w,
                iconsColor: M
            }, ke.type))
        })
    }, {
        loadTranslation: !1
    }),
    GB = v(Ho)
`
    height: ${({space:e})=>e}px;
`, ZB = Xe(e => {
    const {
        boxBackgroundColor: t,
        isBoxBorderEnabled: o,
        boxBorderColorRight: r,
        boxBorderColorLeft: i,
        boxBorderColorBottom: n,
        boxBorderColorTop: l,
        boxBorderStyleBottom: s,
        boxBorderStyleLeft: u,
        boxBorderStyleRight: c,
        boxBorderStyleTop: h,
        boxBorderWidthBottom: m,
        boxBorderWidthLeft: g,
        boxBorderWidthRight: p,
        boxBorderWidthTop: b,
        boxBorderRadiusBottomLeft: C,
        boxBorderRadiusBottomRight: w,
        boxBorderRadiusTopLeft: B,
        boxBorderRadiusTopRight: S,
        boxPaddingBottom: $,
        boxPaddingLeft: L,
        boxPaddingRight: M,
        boxPaddingTop: F,
        isBoxShadowEnabled: A,
        boxShadowBlurRadius: z,
        boxShadowColor: _,
        boxShadowOffsetX: Z,
        boxShadowOffsetY: G,
        boxShadowOpacity: H,
        boxShadowSpreadRadius: te,
        space: oe,
        isBoxRadiusEnabled: re,
        isBoxPaddingEnabled: Q,
        className: J
    } = Ge(e), ee = qe(e.elementId);
    return a(GB, {
        $boxBackgroundColor: t,
        $isBoxBorderEnabled: o,
        $boxBorderColorRight: r,
        $boxBorderColorLeft: i,
        $boxBorderColorBottom: n,
        $boxBorderColorTop: l,
        $boxBorderStyleBottom: s,
        $boxBorderStyleLeft: u,
        $boxBorderStyleRight: c,
        $boxBorderStyleTop: h,
        $boxBorderWidthBottom: m,
        $boxBorderWidthLeft: g,
        $boxBorderWidthRight: p,
        $boxBorderWidthTop: b,
        $boxBorderRadiusBottomLeft: C,
        $boxBorderRadiusBottomRight: w,
        $boxBorderRadiusTopLeft: B,
        $boxBorderRadiusTopRight: S,
        $boxPaddingBottom: $,
        $boxPaddingLeft: L,
        $boxPaddingRight: M,
        $boxPaddingTop: F,
        $isBoxShadowEnabled: A,
        $isBoxRadiusEnabled: re,
        $isBoxPaddingEnabled: Q,
        $boxShadowBlurRadius: z,
        $boxShadowColor: _,
        $boxShadowOffsetX: Z,
        $boxShadowOffsetY: G,
        $boxShadowOpacity: H,
        $boxShadowSpreadRadius: te,
        space: oe,
        className: J,
        onClick: ho(e),
        ...ee
    })
}, {
    loadTranslation: !1
}), Bb = "text-color", qB = "text-color-gradient";

function JB(e) {
    return Object.fromEntries(Object.entries(e).map(([t, o]) => [t.replace(/-([a-z])/g, r => r[1].toUpperCase()), o]))
}
const et = new Y0(e => e, e => e, (e, t, o) => (console.warn(`Unknown ${e} with type "${t.type}"`), o ? .()));
et.addNodeRenderer(Re.Doc, e => e());
et.addNodeRenderer(Re.Paragraph, (e, t, o) => t.content ? a("p", {
    children: e()
}, o) : y("p", {
    children: [e(), a("br", {})]
}, o));
et.addNodeRenderer(Re.Text, e => e());
et.addNodeRenderer(Re.BulletList, (e, t, o) => a("ul", {
    children: e()
}, o));
et.addNodeRenderer(Re.OrderedList, (e, t, o) => a("ol", {
    children: e()
}, o));
et.addNodeRenderer(Re.ListItem, (e, {
    attrs: t
}, o) => {
    const r = {
        fontWeight: t.isBold ? "bold" : void 0,
        fontStyle: t.isItalic ? "italic" : void 0,
        fontFamily: t.fontFamily ? t.fontFamily : void 0,
        color: t.color ? t.color : void 0,
        ["--font-size"]: t.fontSize ? `${t.fontSize}px` : void 0
    };
    return a("li", {
        style: r,
        children: e()
    }, o)
});
et.addNodeRenderer("hardBreak", (e, t, o) => a("p", {
    children: a("br", {})
}, o));
for (let e = 0, t = fs.length; e < t; e++) {
    const o = fs[e];
    et.addNodeRenderer(`block-type-${o.id}`, (r, i, n) => i.content ? x.createElement(o.tagName, {
        className: o.className,
        key: `block-type-${o.id}-${n}`
    }, r()) : a("p", {
        children: a("br", {})
    }, `block-type-${o.id}-${n}`))
}

function Wt(e, t) {
    return `${e}-${t}`
}
et.addMarkRenderer(se.Strong, (e, t, o) => a("strong", {
    children: e()
}, Wt(se.Strong, o)));
et.addMarkRenderer(se.Italic, (e, t, o) => a("em", {
    children: e()
}, Wt(se.Italic, o)));
et.addMarkRenderer(se.Underline, (e, t, o) => a("u", {
    children: e()
}, Wt(se.Underline, o)));
et.addMarkRenderer(se.Strikethrough, (e, t, o) => a("s", {
    children: e()
}, Wt(se.Strikethrough, o)));
et.addMarkRenderer(se.TextIndex, (e, t, o) => t.attrs.type === X0.Subscript ? a("sub", {
    children: e()
}, Wt(`${se.TextIndex}-sub`, o)) : a("sup", {
    children: e()
}, Wt(`${se.TextIndex}-sup`, o)));
et.addMarkRenderer(se.FontFamily, (e, t, o) => a("span", {
    style: {
        fontFamily: t.attrs.fontFamily
    },
    children: e()
}, Wt(se.FontFamily, o)));
et.addMarkRenderer(se.FontSize, (e, t, o) => {
    const r = {
        "--font-size": `${t.attrs.size}px`
    };
    return a("span", {
        className: sd,
        style: r,
        children: e()
    }, Wt(se.FontSize, o))
});
et.addMarkRenderer(se.BackgroundColor, (e, t, o) => a("span", {
    style: {
        backgroundColor: t.attrs.color
    },
    children: e()
}, Wt(se.BackgroundColor, o)));
et.addMarkRenderer(se.TextColor, (e, t, o) => a("span", {
    className: [Bb, dm(t.attrs.color) ? qB : null].filter(Boolean).join(" "),
    style: JB(Lr(t.attrs.color)),
    children: e()
}, Wt(se.TextColor, o)));
et.addMarkRenderer(se.Hyperlink, (e, t, o) => a($o, {
    hyperlink: j.createTextHyperlink(t.attrs),
    children: e()
}, Wt(se.Hyperlink, `${t.attrs.uniqueId}-${o}`)));
et.addMarkRenderer(se.LetterSpacing, (e, t, o) => a("span", {
    style: {
        letterSpacing: t.attrs.spacing
    },
    children: e()
}, Wt(se.LetterSpacing, o)));
et.addMarkRenderer(se.LineHeight, (e, t, o) => a("div", {
    style: {
        lineHeight: t.attrs.lineHeight
    },
    className: th,
    children: e()
}, Wt(se.LineHeight, o)));
et.addMarkRenderer(se.Alignment, (e, t, o) => {
    let r;
    switch (t.attrs.align) {
        case Ji.End:
            r = "right";
            break;
        case Ji.Center:
            r = "center";
            break;
        case Ji.Justify:
            r = "justify";
            break;
        case Ji.Start:
        default:
            r = "left";
            break
    }
    return a("div", {
        style: {
            textAlign: r
        },
        children: e()
    }, Wt(se.Alignment, o))
});
const YB = v(nv)
`
  .${Bb} a {
      color: inherit;
  }
  
  white-space: pre-wrap;
  overflow: hidden;
  overflow-wrap: break-word;
`, XB = v.div `
    position: relative;
`, KB = Xe(e => {
    const t = Ed(),
        o = f.exports.useMemo(() => e.content.content ? et.render(e.content) : null, [e.content]),
        {
            boxPaddingTop: r,
            boxPaddingRight: i,
            boxPaddingLeft: n,
            boxPaddingBottom: l,
            boxBackgroundColor: s,
            boxBorderRadiusTopLeft: u,
            boxBorderRadiusTopRight: c,
            boxBorderRadiusBottomLeft: h,
            boxBorderRadiusBottomRight: m,
            boxShadowOffsetX: g,
            boxShadowOffsetY: p,
            boxShadowBlurRadius: b,
            boxShadowSpreadRadius: C,
            boxShadowColor: w,
            boxShadowOpacity: B,
            isBoxShadowEnabled: S,
            boxBorderColorTop: $,
            boxBorderColorLeft: L,
            boxBorderColorRight: M,
            boxBorderColorBottom: F,
            boxBorderStyleTop: A,
            boxBorderStyleLeft: z,
            boxBorderStyleRight: _,
            boxBorderStyleBottom: Z,
            boxBorderWidthTop: G,
            boxBorderWidthLeft: H,
            boxBorderWidthRight: te,
            boxBorderWidthBottom: oe,
            isBoxBorderEnabled: re,
            isBoxRadiusEnabled: Q,
            isBoxPaddingEnabled: J,
            elementPosition: ee,
            className: le,
            backgroundImage: ue,
            backgroundOpacity: me,
            isBackgroundMediaEnabled: ie,
            backgroundRepeat: Y,
            backgroundSize: ae,
            backgroundPosition: X
        } = Ge(e),
        ge = vb(ie ? ue : null),
        ce = Lm(ue),
        de = qe(e.elementId);
    return a(YB, {
        typography: t,
        onClick: ho(e),
        $boxPaddingTop: r,
        $boxPaddingBottom: l,
        $boxPaddingLeft: n,
        $boxPaddingRight: i,
        $boxBackgroundColor: s,
        $boxBorderRadiusTopLeft: u,
        $boxBorderRadiusTopRight: c,
        $boxBorderRadiusBottomLeft: h,
        $boxBorderRadiusBottomRight: m,
        $boxShadowOffsetX: g,
        $boxShadowOffsetY: p,
        $boxShadowBlurRadius: b,
        $boxShadowSpreadRadius: C,
        $boxShadowColor: w,
        $boxShadowOpacity: B,
        $isBoxShadowEnabled: S,
        $isBoxRadiusEnabled: Q,
        $isBoxPaddingEnabled: J,
        $boxBorderColorTop: $,
        $boxBorderColorLeft: L,
        $boxBorderColorRight: M,
        $boxBorderColorBottom: F,
        $boxBorderStyleTop: A,
        $boxBorderStyleLeft: z,
        $boxBorderStyleRight: _,
        $boxBorderStyleBottom: Z,
        $boxBorderWidthTop: G,
        $boxBorderWidthLeft: H,
        $boxBorderWidthRight: te,
        $boxBorderWidthBottom: oe,
        $isBoxBorderEnabled: re,
        $position: ee,
        className: le,
        ...de,
        children: a(Ox, {
            $backgroundImage: ge,
            $opacity: me,
            $borderWidthTop: G,
            $borderWidthLeft: H,
            $borderWidthRight: te,
            $borderWidthBottom: oe,
            $isBorderEnabled: re,
            $borderRadiusTopLeft: u,
            $borderRadiusTopRight: c,
            $borderRadiusBottomLeft: h,
            $borderRadiusBottomRight: m,
            $isRadiusEnabled: Q,
            $backgroundRepeat: Y,
            $backgroundPosition: X,
            $backgroundSize: ae,
            $backgroundImageResolution: ce,
            children: a(XB, {
                children: o
            })
        })
    })
}, {
    loadTranslation: !1
}), Oc = {
    labelFontSize: [8, 10, 12, 13, 14, 16, 18, 20, 22, 24, 26, 28, 32],
    clockFontSize: [18, 20, 22, 24, 26, 28, 32, 36, 40, 44, 48, 52, 64, 72]
};
class xl {
    constructor() {
        Object.defineProperty(this, "listeners", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: []
        }), Object.defineProperty(this, "intervalId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: null
        })
    }
    register(t) {
        return this.listeners.push(t), this.intervalId === null && (this.intervalId = window.setInterval(() => this.tick(), xl.TickEveryMs)), () => {
            this.listeners = this.listeners.filter(o => o !== t), this.listeners.length === 0 && (this.intervalId !== null && clearInterval(this.intervalId), this.intervalId = null)
        }
    }
    tick() {
        for (const t of this.listeners) t()
    }
}
Object.defineProperty(xl, "TickEveryMs", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: 1e3
});

function Ac(e, t) {
    const {
        paragraph: o
    } = e, r = o.fontSize < t[0] ? t[0] : t[t.length - 1];
    return t.includes(o.fontSize) ? o.fontSize : r
}
let ls = null;
const QB = Xe(e => {
        ls === null && (ls = new xl);
        const {
            isBoxBorderEnabled: t,
            isBoxShadowEnabled: o,
            isRadiusLocked: r,
            isBorderEnabled: i,
            boxBackgroundColor: n,
            boxBorderColorRight: l,
            boxBorderColorLeft: s,
            boxBorderColorBottom: u,
            boxBorderColorTop: c,
            boxBorderStyleBottom: h,
            boxBorderStyleLeft: m,
            boxBorderStyleRight: g,
            boxBorderStyleTop: p,
            boxBorderWidthBottom: b,
            boxBorderWidthLeft: C,
            boxBorderWidthRight: w,
            boxBorderWidthTop: B,
            boxBorderRadiusBottomLeft: S,
            boxBorderRadiusBottomRight: $,
            boxBorderRadiusTopLeft: L,
            boxBorderRadiusTopRight: M,
            boxPaddingBottom: F,
            boxPaddingLeft: A,
            boxPaddingRight: z,
            boxPaddingTop: _,
            boxShadowBlurRadius: Z,
            boxShadowColor: G,
            boxShadowOffsetX: H,
            boxShadowOffsetY: te,
            boxShadowOpacity: oe,
            boxShadowSpreadRadius: re,
            textColor: Q,
            fontFamily: J,
            fontSize: ee,
            isBold: le,
            isItalic: ue,
            isUnderline: me,
            isBoxRadiusEnabled: ie,
            isBoxPaddingEnabled: Y,
            borderColorTop: ae,
            borderColorRight: X,
            borderColorLeft: ge,
            borderColorBottom: ce,
            borderRadiusBottomLeft: de,
            borderRadiusBottomRight: ne,
            borderRadiusTopLeft: Se,
            borderRadiusTopRight: Fe,
            isRadiusEnabled: $e,
            borderStyleBottom: Ie,
            borderStyleLeft: xe,
            borderStyleRight: ke,
            borderStyleTop: Le,
            borderWidthBottom: We,
            borderWidthLeft: Ke,
            borderWidthRight: at,
            borderWidthTop: wt,
            paddingRight: ht,
            paddingLeft: Bt,
            paddingBottom: tt,
            paddingTop: mt,
            isPaddingEnabled: yt,
            backgroundColor: xt,
            clockTextColor: Ft,
            clockFontFamily: vt,
            clockFontSize: St,
            isClockBold: Ut,
            isClockItalic: Vt,
            isClockUnderline: eo,
            type: Fo,
            fields: mo,
            evergreen: Io,
            fixedDate: qt,
            elementPosition: dr,
            className: ur,
            isLabelsVisible: cr
        } = Ge(e), bo = Ed(), ko = qe(e.elementId);
        return a(rC, {
            $boxBackgroundColor: n,
            $isBoxBorderEnabled: t,
            $boxBorderColorRight: l,
            $boxBorderColorLeft: s,
            $boxBorderColorBottom: u,
            $boxBorderColorTop: c,
            $boxBorderStyleBottom: h,
            $boxBorderStyleLeft: m,
            $boxBorderStyleRight: g,
            $boxBorderStyleTop: p,
            $boxBorderWidthBottom: b,
            $boxBorderWidthLeft: C,
            $boxBorderWidthRight: w,
            $boxBorderWidthTop: B,
            $boxBorderRadiusBottomLeft: S,
            $boxBorderRadiusBottomRight: $,
            $boxBorderRadiusTopLeft: L,
            $boxBorderRadiusTopRight: M,
            $boxPaddingBottom: F,
            $boxPaddingLeft: A,
            $boxPaddingRight: z,
            $boxPaddingTop: _,
            $isBoxShadowEnabled: o,
            $isBoxRadiusEnabled: ie,
            $isBoxPaddingEnabled: Y,
            $boxShadowBlurRadius: Z,
            $boxShadowColor: G,
            $boxShadowOffsetX: H,
            $boxShadowOffsetY: te,
            $boxShadowOpacity: oe,
            $boxShadowSpreadRadius: re,
            $position: dr,
            className: ur,
            onClick: ho(e),
            ...ko,
            children: a(fC, {
                type: Fo,
                fields: mo,
                isCountdownEnabled: !0,
                seconds: Io.seconds,
                date: qt ? .date,
                countdownService: ls,
                timeZoneId: qt ? .id,
                textColor: Q,
                fontFamily: J ? ? bo.paragraph.fontFamily,
                fontSize: ee ? ? Ac(bo, Oc.labelFontSize),
                isBold: le,
                isItalic: ue,
                isUnderline: me,
                isRadiusLocked: r,
                borderRadiusBottomLeft: de,
                borderRadiusBottomRight: ne,
                borderRadiusTopLeft: Se,
                borderRadiusTopRight: Fe,
                isRadiusEnabled: $e,
                isBorderEnabled: i,
                borderStyleBottom: Ie,
                borderStyleLeft: xe,
                borderStyleRight: ke,
                borderStyleTop: Le,
                borderWidthBottom: We,
                borderWidthLeft: Ke,
                borderWidthRight: at,
                borderWidthTop: wt,
                borderColorTop: ae,
                borderColorRight: X,
                borderColorLeft: ge,
                borderColorBottom: ce,
                isPaddingEnabled: yt,
                paddingRight: ht,
                paddingLeft: Bt,
                paddingBottom: tt,
                paddingTop: mt,
                backgroundColor: xt,
                clockTextColor: Ft,
                clockFontFamily: vt ? ? bo.paragraph.fontFamily,
                clockFontSize: St ? ? Ac(bo, Oc.clockFontSize),
                isClockBold: Ut,
                isClockItalic: Vt,
                isClockUnderline: eo,
                isLabelsVisible: cr
            })
        })
    }, {
        loadTranslation: !0
    }),
    eS = v.div `
  max-width: 100%;
  display: flex;

  ${({$isAdjustToWidth:e})=>e&&P`
@media $ {
    Oi
} {
    width: 100 % ;
}
`}
`, tS = v.div `
  width: ${e=>e.$width}px;
  max-width: 100%;
  height: ${e=>e.$height}px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #FFF;
  background: #0e0e0e;
  border: 1px solid #2b5fd4;
  font-family: var(--common-font-family);
  flex-flow: column;

  @media ${Oi} {
    height: 100%;
  }
`, iu = {
    NoConsent: {
        Text: "Please accept third-party cookies to play this video",
        Button: "I Accept"
    }
}, oS = v.button `
  display: block;
  color: white;
  cursor: pointer;
  padding: 12px;
  background: #2b5fd4;
  margin: 15px;
  font-family: var(--common-font-family);
  transition: .2s background-color;
  
  :hover {
    background: #4777e4;
  }
`;

function Sb() {
    const e = pl(),
        t = f.exports.useCallback(o => {
            o.preventDefault(), e.acceptCookies()
        }, [e]);
    return a(oS, {
        onClick: t,
        children: iu.NoConsent.Button
    })
}

function rS(e) {
    return y(tS, {
        "data-ats-video": "no-consent",
        $width: e.width,
        $height: e.height,
        children: [iu.NoConsent.Text, a(Sb, {})]
    })
}
const nS = v.div `
  position: relative;
  height: 100%;

  .cookie-overlay {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
    z-index: 1000;
  }
`,
    iS = v.dialog.attrs({
        open: !0
    })
`
  position: fixed;
  top: 50%;
  transform: translateY(-50%);
  z-index: 9999999;
  width: 650px;
  max-width: 100%;
  max-height: 85%;
  border-radius: 8px;
  text-align: left;
  overflow-wrap: break-word;
  overflow-y: auto;
  background: rgb(255, 255, 255);
  padding: 50px 100px;
  border: none;
  color: rgb(138, 145, 152);
  font-size: 16px;
  font-family: var(--common-font-family);
  left: 0;
  right: 0;
  margin: auto;
`, aS = v.div `
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  z-index: 3000;
  background-color: rgba(32, 39, 48, 0.9);
`, lS = v.div `
  display: flex;
  justify-content: flex-end;
  margin-top: 15px;
  
  > *:not(:last-child) {
    margin-right: 15px;
  }
`;

function Ia({
    onClose: e = Gt,
    children: t
}) {
    var o;
    const r = f.exports.useRef((o = Er()) === null || o === void 0 ? void 0 : o.document.createElement("div")),
        i = f.exports.useCallback(n => n.stopPropagation(), []);
    return f.exports.useEffect(() => {
        const {
            current: n
        } = r;
        if (n !== void 0) return document.body.appendChild(n), () => {
            var l;
            return void((l = n.parentNode) === null || l === void 0 ? void 0 : l.removeChild(n))
        }
    }, []), r.current === void 0 ? null : ih.createPortal(a(aS, {
        onClick: e,
        children: a(iS, {
            onClick: i,
            children: t
        })
    }), r.current)
}
Ia.Controls = lS;

function sS(e) {
    const [t, o] = f.exports.useState(!1), r = f.exports.useCallback(() => o(!0), []), i = f.exports.useCallback(() => o(!1), []);
    return y(nS, {
        children: [a("div", {
            className: "cookie-overlay",
            onClick: r
        }), gt(t, y(Ia, {
            onClose: i,
            children: [iu.NoConsent.Text, a(Ia.Controls, {
                children: a(Sb, {})
            })]
        })), e.children]
    })
}

function dS({
    provider: e,
    ...t
}) {
    const o = ru();
    if (o === ut.Rejected || e.getProviderType() !== io.YouTube && o !== ut.Accepted) return a(rS, {
        width: t.$width,
        height: t.$height
    });
    let r = e.getFullEmbeddedVideoUrl();
    if (o !== ut.Accepted) {
        const n = $r.getProvider(e.toVideoSource());
        n.setBaseUrl(e.getBaseUrl().replace(".youtube.", ".youtube-nocookie.")), n.setEmbeddedVideoUrl(e.getEmbeddedVideoUrl().replace(".youtube.", ".youtube-nocookie.")), r = n.getFullEmbeddedVideoUrlWithoutAutoPlay()
    }
    const i = a(_v, { ...t,
        src: r
    });
    return o === ut.Accepted ? i : a(sS, {
        children: i
    })
}
const uS = Xe(e => {
        const {
            source: t,
            isBoxBorderEnabled: o,
            isBoxShadowEnabled: r,
            isRadiusLocked: i,
            isBorderEnabled: n,
            isShadowEnabled: l,
            align: s,
            isAdjustToWidth: u,
            width: c,
            height: h,
            ratio: m,
            boxBackgroundColor: g,
            boxBorderColorRight: p,
            boxBorderColorLeft: b,
            boxBorderColorBottom: C,
            boxBorderColorTop: w,
            boxBorderStyleBottom: B,
            boxBorderStyleLeft: S,
            boxBorderStyleRight: $,
            boxBorderStyleTop: L,
            boxBorderWidthBottom: M,
            boxBorderWidthLeft: F,
            boxBorderWidthRight: A,
            boxBorderWidthTop: z,
            boxBorderRadiusBottomLeft: _,
            boxBorderRadiusBottomRight: Z,
            boxBorderRadiusTopLeft: G,
            boxBorderRadiusTopRight: H,
            boxPaddingBottom: te,
            boxPaddingLeft: oe,
            boxPaddingRight: re,
            boxPaddingTop: Q,
            boxShadowBlurRadius: J,
            boxShadowColor: ee,
            boxShadowOffsetX: le,
            boxShadowOffsetY: ue,
            boxShadowOpacity: me,
            boxShadowSpreadRadius: ie,
            borderRadiusBottomLeft: Y,
            borderRadiusBottomRight: ae,
            borderRadiusTopLeft: X,
            borderRadiusTopRight: ge,
            isRadiusEnabled: ce,
            borderStyleBottom: de,
            borderStyleLeft: ne,
            borderStyleRight: Se,
            borderStyleTop: Fe,
            borderWidthBottom: $e,
            borderWidthLeft: Ie,
            borderWidthRight: xe,
            borderWidthTop: ke,
            borderColorTop: Le,
            borderColorRight: We,
            borderColorLeft: Ke,
            borderColorBottom: at,
            isBoxRadiusEnabled: wt,
            isBoxPaddingEnabled: ht,
            shadowColor: Bt,
            shadowBlurRadius: tt,
            shadowOffsetX: mt,
            shadowOffsetY: yt,
            shadowOpacity: xt,
            shadowSpreadRadius: Ft,
            elementPosition: vt,
            className: St
        } = Ge(e), Ut = qe(e.elementId), Vt = f.exports.useMemo(() => $r.getProvider(t), [t]);
        return a(qv, {
            globalClassName: I.Video,
            $align: s,
            $boxBackgroundColor: g,
            $isBoxBorderEnabled: o,
            $boxBorderColorRight: p,
            $boxBorderColorLeft: b,
            $boxBorderColorBottom: C,
            $boxBorderColorTop: w,
            $boxBorderStyleBottom: B,
            $boxBorderStyleLeft: S,
            $boxBorderStyleRight: $,
            $boxBorderStyleTop: L,
            $boxBorderWidthBottom: M,
            $boxBorderWidthLeft: F,
            $boxBorderWidthRight: A,
            $boxBorderWidthTop: z,
            $boxBorderRadiusBottomLeft: _,
            $boxBorderRadiusBottomRight: Z,
            $boxBorderRadiusTopLeft: G,
            $boxBorderRadiusTopRight: H,
            $boxPaddingBottom: te,
            $boxPaddingLeft: oe,
            $boxPaddingRight: re,
            $boxPaddingTop: Q,
            $isBoxShadowEnabled: r,
            $isBoxRadiusEnabled: wt,
            $isBoxPaddingEnabled: ht,
            $boxShadowBlurRadius: J,
            $boxShadowColor: ee,
            $boxShadowOffsetX: le,
            $boxShadowOffsetY: ue,
            $boxShadowOpacity: me,
            $boxShadowSpreadRadius: ie,
            $isAdjustToWidth: u,
            $ratio: m,
            $position: vt,
            className: St,
            onClick: ho(e),
            ...Ut,
            children: a(Jv, {
                $isAdjustToWidth: u,
                $borderStyleRight: Se,
                $borderStyleLeft: ne,
                $borderStyleBottom: de,
                $borderRadiusTopRight: ge,
                $borderRadiusTopLeft: X,
                $borderRadiusBottomRight: ae,
                $borderRadiusBottomLeft: Y,
                $isRadiusEnabled: ce,
                $borderColorTop: Le,
                $borderColorRight: We,
                $borderColorLeft: Ke,
                $borderColorBottom: at,
                $borderStyleTop: Fe,
                $borderWidthBottom: $e,
                $borderWidthLeft: Ie,
                $borderWidthRight: xe,
                $borderWidthTop: ke,
                $isBorderEnabled: n,
                children: a(eS, {
                    $isAdjustToWidth: u,
                    children: a(dS, {
                        enableLazyLoading: !0,
                        $isRadiusLocked: i,
                        $borderRadiusBottomLeft: Y,
                        $borderRadiusBottomRight: ae,
                        $borderRadiusTopLeft: X,
                        $borderRadiusTopRight: ge,
                        $isRadiusEnabled: ce,
                        $isBorderEnabled: n,
                        $borderStyleBottom: de,
                        $borderStyleLeft: ne,
                        $borderStyleRight: Se,
                        $borderStyleTop: Fe,
                        $borderWidthBottom: $e,
                        $borderWidthLeft: Ie,
                        $borderWidthRight: xe,
                        $borderWidthTop: ke,
                        $borderColorTop: Le,
                        $borderColorRight: We,
                        $borderColorLeft: Ke,
                        $borderColorBottom: at,
                        $isShadowEnabled: l,
                        $shadowColor: Bt,
                        $shadowBlurRadius: tt,
                        $shadowOffsetX: mt,
                        $shadowOffsetY: yt,
                        $shadowOpacity: xt,
                        $shadowSpreadRadius: Ft,
                        $width: c,
                        $height: h,
                        $isAdjustToWidth: u,
                        provider: Vt
                    })
                })
            })
        })
    }, {
        loadTranslation: !1
    }),
    cS = rr.map(({
        name: e
    }) => e),
    Wc = e => {
        var t;
        return ((t = e.value) === null || t === void 0 ? void 0 : t.filter(Boolean).length) > 0
    },
    Gr = (e, t) => {
        var o;
        return (o = e.find(r => r.name === t)) === null || o === void 0 ? void 0 : o.value[0]
    },
    hS = (e, t, o, r, i, n, l) => {
        const [s, u] = pi(e, ({
            fieldType: p
        }) => p === Do.Gdpr), [c, h] = pi(u, ({
            name: p
        }) => cS.includes(p)), m = h.filter(Wc).map(({
            fieldType: p,
            ...b
        }) => b), g = s.filter(Wc).map(tr);
        return {
            campaignId: o,
            name: Gr(c, or.Name),
            email: Gr(c, or.Email),
            dayOfCycle: r,
            customFields: m,
            consents: g,
            doubleOptIn: i,
            pageId: n,
            formId: l
        }
    };

function mS(e) {
    return {
        name: Gr(e, xo.Name),
        email: Gr(e, xo.Email),
        message: Gr(e, xo.Message),
        phoneNumber: Gr(e, xo.Phone)
    }
}

function bS(e, t) {
    var o;
    const r = (o = gl().pages.find(i => i.uuid === t)) === null || o === void 0 ? void 0 : o.content;
    if (!r) throw new Error(`Invalid pageId: ${t}`);
    return fS(r, e)
}

function fS(e, t) {
    const o = e.elements.filter(r => r.type === I.Lightbox);
    if (o.length === 0) return null;
    for (const r of o)
        if ($b(e, r.id).includes(t)) return r.id;
    return null
}

function $b(e, t) {
    const o = e.relations.find(i => i.elementId === t);
    if (!o) return [];
    const r = [];
    for (const i of o.children) r.push(i, ...$b(e, i));
    return r
}
class au extends Mi {
    constructor(t, o, r) {
        super(), Object.defineProperty(this, "type", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "elementId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        }), Object.defineProperty(this, "pageId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        })
    }
    get isContact() {
        return this.type === I.ContactForm
    }
}
class Rb extends au {}
class Pb extends au {}
class Fb extends Mi {
    constructor(t, o) {
        super(), Object.defineProperty(this, "elementId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "pageId", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
}
class Ib extends au {}

function lu({
    elementId: e,
    pageId: t,
    formType: o
}) {
    const r = bS(e, t),
        i = gb(),
        n = r !== null;
    return f.exports.useMemo(() => ({
        viewForm() {
            i(new Rb(o, e, t))
        },
        clickForm() {
            i(new Pb(o, e, t))
        },
        formLead() {
            if (n) return i(new Fb(r, t));
            i(new Ib(o, e, t))
        }
    }), [i, e, o, n, r, t])
}

function su(e, t) {
    const o = hl(),
        r = Dn(),
        i = rB(n => n.type === we.PopupSubmit);
    return f.exports.useCallback(n => {
        var l;
        if (t === So.Redirect) {
            const s = e ? o.render(e) : "",
                u = (l = e ? .target) !== null && l !== void 0 ? l : Ce.Self;
            if (e ? .type === k.Internal && u === Ce.Self) {
                if (r === null) throw new Error("Missing ISpaNavigationService");
                r.navigate(s)
            } else u === Ce.Self || !n ? window.location.assign(s) : n.location.assign(s);
            return
        }
        if (t === So.NavigateToSubmitPage) {
            if (i === null) throw new Error("Missing popup success page");
            if (r === null) throw new Error("Missing ISpaNavigationService");
            r.navigate(i.url)
        }
    }, [t, e, o, r, i])
}

function du(e, t) {
    return t === So.Redirect && !!e && e.target === Ce.Blank
}

function kb(e) {
    const {
        custom: t,
        predefined: o
    } = e[De.Typography];
    return {
        fontFamily: t ? .paragraph ? t.paragraph.fontFamily : o.paragraph.fontFamily,
        fontSize: t ? .paragraph ? t.paragraph.fontSize : o.paragraph.fontSize
    }
}

function gS(e) {
    const {
        custom: t,
        predefined: o
    } = e[De.Typography];
    return {
        isBold: t ? .link ? t.link.isBold : o.link.isBold,
        isItalic: t ? .link ? t.link.isItalic : o.link.isItalic,
        isUnderline: t ? .link ? t.link.isUnderline : o.link.isUnderline
    }
}

function pS(e) {
    const {
        custom: t,
        predefined: o
    } = e[De.Typography];
    return {
        isBold: t ? .["hover-link"] ? t["hover-link"].isBold : o["hover-link"].isBold,
        isItalic: t ? .["hover-link"] ? t["hover-link"].isItalic : o["hover-link"].isItalic,
        isUnderline: t ? .["hover-link"] ? t["hover-link"].isUnderline : o["hover-link"].isUnderline
    }
}

function yS(e) {
    const {
        custom: t,
        predefined: o
    } = e[De.Typography];
    return {
        fontSize: t ? .meta ? t.meta.fontSize : o.meta.fontSize,
        fontFamily: t ? .meta ? t.meta.fontFamily : o.meta.fontFamily
    }
}

function xS(e) {
    const t = kb(e);
    return ug(t)
}

function vS(e) {
    const t = kb(e);
    return dg(t)
}

function CS(e) {
    const t = gS(e);
    return hg(t)
}

function wS(e) {
    const t = pS(e);
    return mg(t)
}

function BS(e) {
    const t = yS(e);
    return bg(t)
}

function SS() {
    const e = nB(De.Popup);
    return e ? .displayType === ui.Bar ? In.Horizontal : In.Vertical
}
const uu = Xe(e => {
        const [t, o] = x.useState(!1), {
            boxBackgroundColor: r,
            isBoxBorderEnabled: i,
            isBoxShadowEnabled: n,
            boxBorderColorRight: l,
            boxBorderColorLeft: s,
            boxBorderColorBottom: u,
            boxBorderColorTop: c,
            boxBorderStyleBottom: h,
            boxBorderStyleLeft: m,
            boxBorderStyleRight: g,
            boxBorderStyleTop: p,
            boxBorderWidthBottom: b,
            boxBorderWidthLeft: C,
            boxBorderWidthRight: w,
            boxBorderWidthTop: B,
            boxBorderRadiusBottomLeft: S,
            boxBorderRadiusBottomRight: $,
            boxBorderRadiusTopLeft: L,
            boxBorderRadiusTopRight: M,
            boxPaddingBottom: F,
            boxPaddingLeft: A,
            boxPaddingRight: z,
            boxPaddingTop: _,
            boxShadowBlurRadius: Z,
            boxShadowSpreadRadius: G,
            boxShadowColor: H,
            boxShadowOpacity: te,
            boxShadowOffsetX: oe,
            boxShadowOffsetY: re,
            fieldsById: Q,
            fieldsIds: J,
            successViewMethod: ee,
            message: le,
            subscriptionListId: ue,
            fieldTextColor: me,
            fieldIsBold: ie,
            fieldIsItalic: Y,
            fieldIsUnderline: ae,
            fieldPaddingTop: X,
            fieldPaddingLeft: ge,
            fieldPaddingRight: ce,
            fieldPaddingBottom: de,
            fieldWidth: ne,
            labelIsBold: Se,
            labelIsItalic: Fe,
            labelIsUnderline: $e,
            labelPlacement: Ie,
            labelTextColor: xe,
            requiredInputMarkerType: ke,
            requiredInputMarkerText: Le,
            fieldBorderRadiusTopLeft: We,
            fieldBorderRadiusTopRight: Ke,
            fieldBorderRadiusBottomLeft: at,
            fieldBorderRadiusBottomRight: wt,
            isFieldBorderRadiusEnabled: ht,
            isBoxRadiusEnabled: Bt,
            isBoxPaddingEnabled: tt,
            fieldBackgroundColor: mt,
            fieldShadowColor: yt,
            fieldShadowBlurRadius: xt,
            fieldShadowOffsetX: Ft,
            fieldShadowOffsetY: vt,
            fieldShadowOpacity: St,
            fieldShadowSpreadRadius: Ut,
            isFieldShadowEnabled: Vt,
            fieldBorderColorTop: eo,
            fieldBorderColorLeft: Fo,
            fieldBorderColorRight: mo,
            fieldBorderColorBottom: Io,
            fieldBorderStyleTop: qt,
            fieldBorderStyleLeft: dr,
            fieldBorderStyleRight: ur,
            fieldBorderStyleBottom: cr,
            isFieldBorderEnabled: bo,
            fieldBorderWidthTop: ko,
            fieldBorderWidthLeft: hr,
            fieldBorderWidthRight: Fl,
            fieldBorderWidthBottom: Il,
            isFieldPaddingLocked: kl,
            fieldErrorColor: Tl,
            elementPosition: El,
            areGDPRSEnabled: Ll,
            gdprFieldsById: Ai,
            gdprFieldsIds: Wi,
            isRecaptchaEnabled: Ml,
            className: Ol,
            onSubmit: Al,
            isSubmitted: Vn,
            isSubmitting: Wl,
            setIsSubmitted: Hn,
            formErrors: Dl,
            onBeforeValidate: Ar,
            formRef: Nl,
            dataAts: Ul = "form"
        } = Ge(e), {
            fieldFontFamily: zo,
            fieldFontSize: _o
        } = no(e, vS), {
            labelFontFamily: jn,
            labelFontSize: zn
        } = no(e, xS), {
            consentLinkIsBold: _n,
            consentLinkIsItalic: Gn,
            consentLinkIsUnderline: Zn
        } = no(e, CS), {
            consentLinkHoverIsBold: qn,
            consentLinkHoverIsItalic: mr,
            consentLinkHoverIsUnderline: Di
        } = no(e, wS), {
            consentFontFamily: Vl,
            consentFontSize: Hl
        } = no(e, BS), {
            buttonBackgroundColor: Tu,
            buttonBackgroundHoverColor: br,
            buttonBorderColorBottom: Ht,
            buttonBorderColorLeft: Ni,
            buttonBorderColorRight: to,
            buttonBorderColorTop: fr,
            buttonBorderEnabled: Wr,
            buttonBorderRadiusBottomLeft: Ui,
            buttonBorderRadiusBottomRight: Vi,
            buttonBorderRadiusTopLeft: Hi,
            buttonBorderRadiusTopRight: ji,
            isButtonRadiusEnabled: To,
            buttonBorderStyleBottom: zi,
            buttonBorderStyleLeft: _i,
            buttonBorderStyleRight: Gi,
            buttonBorderStyleTop: jl,
            buttonBorderWidthBottom: zl,
            buttonBorderWidthLeft: Zi,
            buttonBorderWidthRight: U,
            buttonBorderWidthTop: it,
            buttonFontColor: It,
            buttonFontColorHover: lt,
            buttonFontFamily: kt,
            buttonFontSize: Tt,
            buttonInternalPaddingBottom: Dr,
            buttonInternalPaddingLeft: m0,
            buttonInternalPaddingRight: b0,
            buttonInternalPaddingTop: f0,
            buttonShadowBlurRadius: g0,
            buttonShadowColor: p0,
            buttonShadowOffsetX: y0,
            buttonShadowOffsetY: x0,
            buttonShadowOpacity: v0,
            buttonShadowSpreadRadius: C0,
            isButtonButtonRadiusLocked: w0,
            isButtonFontBold: B0,
            isButtonFontItalic: S0,
            isButtonFontUnderLine: $0,
            isButtonInternalPaddingLocked: R0,
            isButtonShadowEnabled: P0,
            buttonAlign: F0,
            buttonText: I0
        } = Ge(no(e, Nr => {
            var _l;
            return cg((_l = Nr[De.Button].customProperties) !== null && _l !== void 0 ? _l : Nr[De.Button].defaultProperties)
        })), k0 = qe(e.elementId), T0 = f.exports.useMemo(() => Qu(Object.values(Q), J, Nr => Nr.id), [Q, J]), E0 = f.exports.useMemo(() => Qu(Object.values(Ai), Wi, Nr => Nr.id), [Ai, Wi]), L0 = SS();
        return x.useEffect(() => {
            Vn && !t && (o(!0), setTimeout(() => {
                Hn(!1), o(!1)
            }, 8e3))
        }, [ue, Vn, t, Hn]), y(Ho, {
            $boxBackgroundColor: r,
            $isBoxBorderEnabled: i,
            $boxBorderColorRight: l,
            $boxBorderColorLeft: s,
            $boxBorderColorBottom: u,
            $boxBorderColorTop: c,
            $boxBorderStyleBottom: h,
            $boxBorderStyleLeft: m,
            $boxBorderStyleRight: g,
            $boxBorderStyleTop: p,
            $boxBorderWidthBottom: b,
            $boxBorderWidthLeft: C,
            $boxBorderWidthRight: w,
            $boxBorderWidthTop: B,
            $boxBorderRadiusBottomLeft: S,
            $boxBorderRadiusBottomRight: $,
            $boxBorderRadiusTopLeft: L,
            $boxBorderRadiusTopRight: M,
            $boxPaddingBottom: F,
            $boxPaddingLeft: A,
            $boxPaddingRight: z,
            $boxPaddingTop: _,
            $isBoxShadowEnabled: n,
            $isBoxRadiusEnabled: Bt,
            $isBoxPaddingEnabled: tt,
            $boxShadowBlurRadius: Z,
            $boxShadowColor: H,
            $boxShadowOffsetX: oe,
            $boxShadowOffsetY: re,
            $boxShadowOpacity: te,
            $boxShadowSpreadRadius: G,
            $position: El,
            className: Ol,
            $showOverflow: !0,
            "data-ats-wb-element": Ul,
            ...k0,
            children: [e.children, a(mw, {
                formFields: T0,
                successViewMethod: ee,
                message: le,
                isSubmitted: Vn,
                isSubmitting: Wl,
                onSubmit: Al,
                fieldTextColor: me,
                fieldFontFamily: zo,
                fieldFontSize: _o,
                fieldIsBold: ie,
                fieldIsItalic: Y,
                fieldIsUnderline: ae,
                fieldPaddingTop: X,
                fieldPaddingLeft: ge,
                fieldPaddingRight: ce,
                fieldPaddingBottom: de,
                fieldWidth: ne,
                fieldBorderRadiusTopLeft: We,
                fieldBorderRadiusTopRight: Ke,
                fieldBorderRadiusBottomLeft: at,
                fieldBorderRadiusBottomRight: wt,
                isFieldBorderRadiusEnabled: ht,
                fieldBackgroundColor: mt,
                fieldShadowColor: yt,
                fieldShadowBlurRadius: xt,
                fieldShadowOffsetX: Ft,
                fieldShadowOffsetY: vt,
                fieldShadowOpacity: St,
                fieldShadowSpreadRadius: Ut,
                isFieldShadowEnabled: Vt,
                fieldBorderColorTop: eo,
                fieldBorderColorLeft: Fo,
                fieldBorderColorRight: mo,
                fieldBorderColorBottom: Io,
                fieldBorderStyleTop: qt,
                fieldBorderStyleLeft: dr,
                fieldBorderStyleRight: ur,
                fieldBorderStyleBottom: cr,
                isFieldBorderEnabled: bo,
                fieldBorderWidthTop: ko,
                fieldBorderWidthLeft: hr,
                fieldBorderWidthRight: Fl,
                fieldBorderWidthBottom: Il,
                buttonBackgroundColor: Tu,
                buttonBackgroundHoverColor: br,
                buttonBorderColorBottom: Ht,
                buttonBorderColorLeft: Ni,
                buttonBorderColorRight: to,
                buttonBorderColorTop: fr,
                buttonBorderEnabled: Wr,
                buttonBorderRadiusBottomLeft: Ui,
                buttonBorderRadiusBottomRight: Vi,
                buttonBorderRadiusTopLeft: Hi,
                buttonBorderRadiusTopRight: ji,
                isButtonRadiusEnabled: To,
                buttonBorderStyleBottom: zi,
                buttonBorderStyleLeft: _i,
                buttonBorderStyleRight: Gi,
                buttonBorderStyleTop: jl,
                buttonBorderWidthBottom: zl,
                buttonBorderWidthLeft: Zi,
                buttonBorderWidthRight: U,
                buttonBorderWidthTop: it,
                buttonFontColor: It,
                buttonFontColorHover: lt,
                buttonFontFamily: kt,
                buttonFontSize: Tt,
                buttonInternalPaddingBottom: Dr,
                buttonInternalPaddingLeft: m0,
                buttonInternalPaddingRight: b0,
                buttonInternalPaddingTop: f0,
                buttonShadowBlurRadius: g0,
                buttonShadowColor: p0,
                buttonShadowOffsetX: y0,
                buttonShadowOffsetY: x0,
                buttonShadowOpacity: v0,
                buttonShadowSpreadRadius: C0,
                isButtonButtonRadiusLocked: w0,
                isButtonFontBold: B0,
                isButtonFontItalic: S0,
                isButtonFontUnderLine: $0,
                isButtonInternalPaddingLocked: R0,
                isButtonShadowEnabled: P0,
                buttonAlign: F0,
                buttonText: I0,
                labelFontFamily: jn,
                labelFontSize: zn,
                labelIsBold: Se,
                labelIsItalic: Fe,
                labelIsUnderline: $e,
                labelTextColor: xe,
                labelPlacement: Ie,
                requiredInputMarkerType: ke,
                requiredInputMarkerText: Le,
                isFieldPaddingLocked: kl,
                fieldErrorColor: Tl,
                areGDPRSEnabled: Ll,
                gdprFormFields: E0,
                formFieldErrors: Dl,
                isRecaptchaEnabled: Ml,
                consentFontFamily: Vl,
                consentFontSize: Hl,
                consentLinkIsBold: _n,
                consentLinkIsItalic: Gn,
                consentLinkIsUnderline: Zn,
                consentLinkHoverIsBold: qn,
                consentLinkHoverIsItalic: mr,
                consentLinkHoverIsUnderline: Di,
                onBeforeValidate: Ar,
                formRef: Nl,
                orientation: L0
            })]
        })
    }, {
        loadTranslation: !0
    }),
    $S = v.h3 `
    font-family: source-sans-basic, "Source Sans Pro", helvetica, arial, sans-serif;
    padding: 0px;
    margin: 0px 0px 30px;
    color: rgb(36, 40, 44);
    font-weight: 400;
    font-size: 26px;
    line-height: 1.3;
    letter-spacing: 0.04em;
    text-align: center;
`,
    RS = v.div `
    display: flex;
    justify-content: flex-end;
    margin-top: 27px;
`,
    Dc = v.button `
    text-align: center;
    min-width: 80px;
    height: 45px;
    line-height: 45px;
    cursor: pointer;
    color: ${e=>e.variant==="primary"?"white":"rgb(0, 186, 255)"};
    box-shadow: ${e=>e.variant==="primary"?"rgba(32, 39, 48, 0.2) 4px 4px 9.4px 0.6px, rgb(255, 255, 255) -4px -4px 9.4px 0.6px":"none"};
    font-size: 14px;
    padding: 0px 25px;
    background: ${e=>e.variant==="primary"?"linear-gradient(135deg, rgb(0, 174, 255) 0%, rgb(41, 202, 255) 100%) 0% 0% / 100% 100%, 0% 0% / cover":"transparent"};
    border-radius: 9px;
    font-weight: 700;

    &:hover {
        text-decoration: ${e=>e.variant==="primary"?"none":"underline"};
    }
`,
    PS = Xe(e => {
        const {
            successViewMethod: t,
            hyperlink: o,
            elementId: r,
            pageUuid: i
        } = e, n = lu({
            elementId: r,
            pageId: i,
            formType: I.ContactForm
        }), l = pl(), s = pb(), u = iB(), [c, h] = x.useState(!1), [m, g] = x.useState(!1), [p, b] = x.useState(!1), [C, w] = x.useState([]), [B, S] = x.useState([]), $ = x.useRef(null);
        x.useEffect(() => {
            n.viewForm()
        }, [n]);
        const L = su(o, t),
            M = x.useCallback(() => {
                b(!1)
            }, []),
            F = x.useCallback(Z => {
                b(!0), w(Z)
            }, []),
            A = x.useCallback(Z => {
                let G = null;
                du(o, t) && (G = window.open()), (async () => {
                    var H;
                    g(!0);
                    try {
                        await u.send(mS(Z)), h(!0), L(G), n.formLead(), (H = $.current) === null || H === void 0 || H.reset()
                    } catch {
                        S([{
                            fieldName: "",
                            message: K.Elements.ContactForm.Errors.GenericError
                        }]), G ? .close()
                    } finally {
                        g(!1)
                    }
                })()
            }, [o, t, u, L, n]),
            z = x.useCallback(async () => {
                l.acceptCookies(), await A(C)
            }, [l, A, C]),
            _ = x.useCallback(() => {
                n.clickForm()
            }, [n]);
        return y(ir, {
            children: [a(uu, {
                setIsSubmitted: h,
                isSubmitted: c,
                isSubmitting: m,
                formErrors: B,
                onSubmit: s ? A : F,
                onBeforeValidate: _,
                formRef: $,
                dataAts: "contact-form",
                ...e
            }), gt(!s && p, y(Ia, {
                onClose: M,
                children: [a($S, {
                    children: a(zt, {
                        id: K.Elements.Form.NoConsentModal.Heading
                    })
                }), a(zt, {
                    id: K.Elements.Form.NoConsentModal.Content
                }), y(RS, {
                    children: [a(Dc, {
                        onClick: M,
                        children: a(zt, {
                            id: K.Elements.Form.NoConsentModal.RejectButton
                        })
                    }), a(Dc, {
                        variant: "primary",
                        onClick: z,
                        children: a(zt, {
                            id: K.Elements.Form.NoConsentModal.ConfirmButton
                        })
                    })]
                })]
            }))]
        })
    }, {
        loadTranslation: !0
    });
class cu extends Error {}
const Tb = Xe(e => {
    const {
        gdprFieldsIds: t,
        subscriptionListId: o,
        successViewMethod: r,
        hyperlink: i,
        autoresponderDay: n,
        doubleOptIn: l,
        pageUuid: s,
        elementId: u,
        onSubmit: c
    } = e, h = lu({
        elementId: u,
        pageId: s,
        formType: I.Form
    }), [m, g] = f.exports.useState([]), [p, b] = x.useState(!1), [C, w] = x.useState(!1), B = x.useRef(null), {
        referenceResolver: S
    } = ar();
    x.useEffect(() => {
        h.viewForm()
    }, [h]);
    const $ = su(i, r),
        L = x.useCallback(F => {
            let A = null;
            const z = S.getValue(o);
            if (!z) throw new Error("Missing Subscription list id");
            du(i, r) && (A = window.open()), (async () => {
                var _, Z, G;
                w(!0);
                try {
                    const H = await c(hS(F, t, z, (_ = S.getValue(n)) !== null && _ !== void 0 ? _ : 0, (Z = S.getValue(l)) !== null && Z !== void 0 ? Z : !1, s, u));
                    if (H instanceof cu) throw g(H.getErrors()), H;
                    b(!0), $(A), h.formLead(), (G = B.current) === null || G === void 0 || G.reset()
                } catch (H) {
                    console.error(H), A ? .close()
                } finally {
                    w(!1)
                }
            })()
        }, [i, r, c, t, o, n, l, $, h, s, u, S]),
        M = x.useCallback(() => {
            h.clickForm()
        }, [h]);
    return a(uu, {
        setIsSubmitted: b,
        isSubmitted: p,
        isSubmitting: C,
        onBeforeValidate: M,
        formRef: B,
        ...e,
        formErrors: m,
        onSubmit: L,
        dataAts: "form"
    })
}, {
    loadTranslation: !0
});

function FS(e) {
    const t = [...e.matchAll(/<\w*[^>]*?id=['"]([a-z]+[\w\-:.]*)['"][^>]*>/mig)].map(([, r]) => r);
    let o = e;
    return t.forEach(r => {
        r && (o = o.replace(new RegExp(`['"]${r}['"]`, "g"), `'${r}-${(Math.random()*1e6).toFixed(0)}'`))
    }), o
}

function IS(e) {
    return `
        <script type="text/javascript">
            try {
                window.localStorage; // we need to check if localStorage is available (editor preview data: page problem)
            } catch (e) {
                const value = new Proxy({}, { 
                    get() {
                        return () => undefined;
                    },
                });
                
                Object.defineProperty(window, 'localStorage', {
                    value,
                });
            }
        <\/script>
        ${e}
    `
}
const kS = Xe(e => {
        const {
            elementPosition: t,
            boxBorderColorRight: o,
            boxBorderColorLeft: r,
            boxBorderColorBottom: i,
            boxBackgroundColor: n,
            boxBorderColorTop: l,
            boxBorderRadiusBottomLeft: s,
            boxBorderRadiusBottomRight: u,
            boxBorderRadiusTopLeft: c,
            boxBorderRadiusTopRight: h,
            boxBorderStyleBottom: m,
            boxBorderStyleLeft: g,
            boxBorderStyleRight: p,
            boxBorderStyleTop: b,
            boxBorderWidthBottom: C,
            boxBorderWidthLeft: w,
            boxBorderWidthRight: B,
            boxBorderWidthTop: S,
            boxPaddingBottom: $,
            boxPaddingLeft: L,
            boxPaddingRight: M,
            boxPaddingTop: F,
            boxShadowBlurRadius: A,
            boxShadowColor: z,
            boxShadowOffsetX: _,
            boxShadowOffsetY: Z,
            boxShadowOpacity: G,
            boxShadowSpreadRadius: H,
            isBoxBorderEnabled: te,
            isBoxShadowEnabled: oe,
            isBoxPaddingEnabled: re,
            isBoxRadiusEnabled: Q
        } = Ge(e), J = f.exports.useRef(null);
        Cb(J, e.content);
        const ee = f.exports.useMemo(() => IS(FS(e.content)), [e.content]),
            le = qe(e.elementId);
        return a(Qw, {
            onClick: ho(e),
            className: e.className,
            ref: J,
            $position: t,
            $boxBorderColorRight: o,
            $boxBorderColorLeft: r,
            $boxBorderColorBottom: i,
            $boxBorderColorTop: l,
            $boxBackgroundColor: n,
            $boxBorderRadiusBottomLeft: s,
            $boxBorderRadiusBottomRight: u,
            $boxBorderRadiusTopLeft: c,
            $boxBorderRadiusTopRight: h,
            $boxBorderStyleBottom: m,
            $boxBorderStyleLeft: g,
            $boxBorderStyleRight: p,
            $boxBorderStyleTop: b,
            $boxBorderWidthBottom: C,
            $boxBorderWidthLeft: w,
            $boxBorderWidthRight: B,
            $boxBorderWidthTop: S,
            $boxPaddingBottom: $,
            $boxPaddingLeft: L,
            $boxPaddingRight: M,
            $boxPaddingTop: F,
            $boxShadowBlurRadius: A,
            $boxShadowColor: z,
            $boxShadowOffsetX: _,
            $boxShadowOffsetY: Z,
            $boxShadowOpacity: G,
            $boxShadowSpreadRadius: H,
            $isBoxBorderEnabled: te,
            $isBoxShadowEnabled: oe,
            $isBoxPaddingEnabled: re,
            $isBoxRadiusEnabled: Q,
            ...le,
            children: a("div", {
                className: "content-container",
                dangerouslySetInnerHTML: {
                    __html: ee
                }
            })
        })
    }, {
        loadTranslation: !1
    }),
    TS = Xe(e => {
        var t, o, r;
        const i = Xx(Ge(e)),
            n = Ed(),
            l = qe(e.elementId);
        return a(o3, { ...i,
            $fontFamily: (t = i.$fontFamily) !== null && t !== void 0 ? t : n.paragraph.fontFamily,
            $fontSize: (o = i.$fontSize) !== null && o !== void 0 ? o : n.paragraph.fontSize,
            code: (r = e.remoteCode) !== null && r !== void 0 ? r : null,
            ...l
        })
    }, {
        loadTranslation: !1,
        async loadData({
            api: e,
            properties: t,
            entityId: o
        }) {
            if (t.codeId === null) return;
            const r = await e.promoCodes.getById(o, t.codeId);
            if (r.ok) return {
                remoteCode: (await r.json()).code
            }
        }
    });
class hu extends Error {}

function ES(e) {
    const t = dd[e ? ? q.Subheader];
    return o => {
        const {
            predefined: r,
            custom: i
        } = o[De.Typography];
        return (i ? ? r)[t]
    }
}

function LS(e) {
    const t = dd[e ? ? q.Paragraph];
    return o => {
        const {
            predefined: r,
            custom: i
        } = o[De.Typography], {
            fontFamily: n,
            fontSize: l,
            isBold: s,
            isItalic: u,
            isUnderline: c
        } = (i ? ? r)[t];
        return {
            dateFontFamily: n,
            dateFontSize: l,
            isDateBold: s,
            isDateItalic: u,
            isDateUnderline: c
        }
    }
}
const MS = rr.map(({
        name: e
    }) => e),
    Nc = e => {
        var t;
        return ((t = e.value) === null || t === void 0 ? void 0 : t.filter(Boolean).length) > 0
    },
    Uc = (e, t) => {
        var o;
        return (o = e.find(r => r.name === t)) === null || o === void 0 ? void 0 : o.value[0]
    },
    OS = (e, t, o, r, i) => {
        const [n, l] = pi(e, ({
            fieldType: m
        }) => m === Do.Gdpr), [s, u] = pi(l, ({
            name: m
        }) => MS.includes(m)), c = u.filter(Nc).map(({
            fieldType: m,
            ...g
        }) => g), h = n.filter(Nc).map(({
            id: m
        }) => {
            const {
                id: g,
                versionId: p
            } = o.find(({
                id: b
            }) => b === m);
            return {
                id: g,
                versionId: p
            }
        });
        return {
            name: Uc(s, or.Name),
            email: Uc(s, or.Email),
            customFields: c,
            consents: h,
            pageId: r,
            formId: i
        }
    },
    Eb = Xe(e => {
        var t;
        const {
            webinarId: o,
            gdprFieldsIds: r,
            gdprFields: i,
            successViewMethod: n,
            hyperlink: l,
            pageUuid: s,
            elementId: u,
            onSubmit: c,
            textColor: h,
            dateTextColor: m,
            backgroundColor: g,
            dateBackgroundColor: p,
            startsAtDate: b,
            fieldErrorColor: C,
            type: w,
            dateType: B
        } = Ge(e), {
            fontFamily: S,
            fontSize: $,
            isBold: L,
            isItalic: M,
            isUnderline: F
        } = no(e, ES(w)), {
            dateFontFamily: A,
            dateFontSize: z,
            isDateBold: _,
            isDateItalic: Z,
            isDateUnderline: G
        } = no(e, LS(B)), H = lu({
            elementId: u,
            pageId: s,
            formType: I.Webinar
        }), [te, oe] = f.exports.useState([]), [re, Q] = x.useState(!1), [J, ee] = x.useState(!1), le = x.useRef(null), [ue, me] = x.useState(!1);
        x.useEffect(() => {
            H.viewForm()
        }, [H]), x.useEffect(() => {
            me(b ? new Date(b).getTime() < new Date().getTime() : !1)
        }, [b]);
        const ie = su(l, n),
            Y = x.useCallback(ge => {
                let ce = null;
                du(l, n) && (ce = window.open()), (async () => {
                    var de;
                    ee(!0);
                    try {
                        const ne = await c(OS(ge, r, i, s, u));
                        if (ne instanceof hu) throw oe(ne.getErrors()), ne;
                        Q(!0), ie(ce), H.formLead(), (de = le.current) === null || de === void 0 || de.reset()
                    } catch (ne) {
                        console.error(ne), ce ? .close()
                    } finally {
                        ee(!1)
                    }
                })()
            }, [l, n, c, r, ie, H, s, u, i]),
            ae = x.useCallback(() => {
                H.clickForm()
            }, [H]);
        if (o === null) return null;
        if (ue) return y(s3, {
            errorColor: C,
            children: [a(a3, {}), e.notAvailableInfo]
        });
        const X = (t = e.webinarDate) !== null && t !== void 0 ? t : b;
        return a(uu, {
            setIsSubmitted: Q,
            isSubmitted: re,
            isSubmitting: J,
            onBeforeValidate: ae,
            formRef: le,
            subscriptionListId: "",
            name: "",
            ...e,
            formErrors: te,
            onSubmit: Y,
            dataAts: "webinar",
            children: y(i3, {
                children: [a(Fc, {
                    $fontFamily: S,
                    $fontSize: $,
                    $isBold: L,
                    $isItalic: M,
                    $isUnderline: F,
                    $textColor: h,
                    $backgroundColor: g,
                    $align: e.align,
                    $lineHeight: e.lineHeight,
                    $type: e.type,
                    "data-ats-wb-element": "webinar-title",
                    children: a("span", {
                        children: e.webinarName
                    })
                }), X ? a(Fc, {
                    $fontFamily: A,
                    $fontSize: z,
                    $isBold: _,
                    $isItalic: Z,
                    $isUnderline: G,
                    $textColor: m,
                    $backgroundColor: p,
                    $align: e.dateAlign,
                    $lineHeight: e.dateLineHeight,
                    $type: e.dateType,
                    "data-ats-wb-element": "webinar-date",
                    children: a("span", {
                        children: X
                    })
                }) : null]
            })
        })
    }, {
        loadTranslation: !0
    });

function ss(e, t, o) {
    return no(e, r => {
        const i = dd[o ? ? q.Paragraph],
            {
                custom: n,
                predefined: l
            } = r[De.Typography],
            s = (n ? ? l)[i];
        return Nh(t, s)
    })
}
const AS = e => {
    const {
        contentGap: t,
        layout: o,
        columns: r,
        isImageVisible: i,
        isProductNameVisible: n,
        isDescriptionVisible: l,
        isPriceVisible: s,
        isButtonVisible: u
    } = e, c = ss(e.product, A1, e.product.productNameType), h = ss(c, M1, e.product.descriptionType), m = ss(h, O1, e.product.priceType), g = no(m, C => {
        const {
            customProperties: w,
            defaultProperties: B
        } = C[De.Button];
        return Nh(L1, w ? ? B)
    }), p = Ge(g), {
        price: b
    } = e.product;
    return a(v3, {
        contentGap: t,
        layout: o,
        price: b,
        product: p,
        columns: r,
        isImageVisible: i,
        isProductNameVisible: n,
        isDescriptionVisible: l,
        isPriceVisible: s,
        isButtonVisible: u
    })
};

function WS(e, t, o) {
    return e.href ? e : o ? { ...e,
        href: o
    } : { ...j.createSpecialPageHyperlink(),
        pageType: we.Order,
        href: `?${new URLSearchParams({product:t})}`
    }
}
const DS = Xe(e => {
    const t = Yd(),
        {
            elementPosition: o,
            boxBorderColorRight: r,
            boxBorderColorLeft: i,
            boxBorderColorBottom: n,
            boxBackgroundColor: l,
            boxBorderColorTop: s,
            boxBorderRadiusBottomLeft: u,
            boxBorderRadiusBottomRight: c,
            boxBorderRadiusTopLeft: h,
            boxBorderRadiusTopRight: m,
            boxBorderStyleBottom: g,
            boxBorderStyleLeft: p,
            boxBorderStyleRight: b,
            boxBorderStyleTop: C,
            boxBorderWidthBottom: w,
            boxBorderWidthLeft: B,
            boxBorderWidthRight: S,
            boxBorderWidthTop: $,
            boxPaddingBottom: L,
            boxPaddingLeft: M,
            boxPaddingRight: F,
            boxPaddingTop: A,
            boxShadowBlurRadius: z,
            boxShadowColor: _,
            boxShadowOffsetX: Z,
            boxShadowOffsetY: G,
            boxShadowOpacity: H,
            boxShadowSpreadRadius: te,
            isBoxBorderEnabled: oe,
            isBoxShadowEnabled: re,
            isBoxPaddingEnabled: Q,
            isBoxRadiusEnabled: J,
            isImageVisible: ee,
            isProductNameVisible: le,
            isDescriptionVisible: ue,
            isPriceVisible: me,
            isButtonVisible: ie,
            products: Y,
            storeCurrency: ae,
            contentGap: X,
            layout: ge,
            productGap: ce,
            externalProducts: de,
            keepLayoutOnMobile: ne,
            columns: Se
        } = Ge(e),
        Fe = qe(e.elementId),
        $e = f.exports.useMemo(() => new pd(e.propertyStyles, Y.map(({
            id: xe
        }) => xe)), [e.propertyStyles, Y]),
        Ie = f.exports.useMemo(() => {
            var xe;
            return (xe = Y ? .reduce((ke, Le) => {
                const We = de ? .find(Ke => Ke.id === Le.id);
                if (We) {
                    const Ke = $e.getProperties(Le.id);
                    return [...ke, { ...Le,
                        ...We,
                        ...Ke,
                        price: t.formatCurrency(We.price, ae),
                        buttonHyperlink: WS(Ke.buttonHyperlink, Le.id, We.url)
                    }]
                }
                return ke
            }, [])) !== null && xe !== void 0 ? xe : []
        }, [Y, de, $e, t, ae]);
    return Ie.length === 0 ? null : a(C3, {
        $boxBackgroundColor: l,
        $isBoxBorderEnabled: oe,
        $boxBorderColorRight: r,
        $boxBorderColorLeft: i,
        $boxBorderColorBottom: n,
        $boxBorderColorTop: s,
        $boxBorderStyleBottom: g,
        $boxBorderStyleLeft: p,
        $boxBorderStyleRight: b,
        $boxBorderStyleTop: C,
        $boxBorderWidthBottom: w,
        $boxBorderWidthLeft: B,
        $boxBorderWidthRight: S,
        $boxBorderWidthTop: $,
        $boxBorderRadiusBottomLeft: u,
        $boxBorderRadiusBottomRight: c,
        $boxBorderRadiusTopLeft: h,
        $boxBorderRadiusTopRight: m,
        $boxPaddingBottom: L,
        $boxPaddingLeft: M,
        $boxPaddingRight: F,
        $boxPaddingTop: A,
        $isBoxShadowEnabled: re,
        $isBoxPaddingEnabled: Q,
        $isBoxRadiusEnabled: J,
        $boxShadowBlurRadius: z,
        $boxShadowColor: _,
        $boxShadowOffsetX: Z,
        $boxShadowOffsetY: G,
        $boxShadowOpacity: H,
        $boxShadowSpreadRadius: te,
        $position: o,
        className: e.className,
        ...Fe,
        children: a(x3, {
            $productGap: ce,
            $layout: ge,
            $keepLayoutOnMobile: ne,
            children: Ie.map(xe => a(AS, {
                contentGap: X ? ? 0,
                layout: ge,
                columns: Math.min(Se, Y.length),
                product: xe,
                isImageVisible: ee,
                isProductNameVisible: le,
                isDescriptionVisible: ue,
                isPriceVisible: me,
                isButtonVisible: ie
            }, xe.id))
        })
    })
}, {
    loadTranslation: !1,
    async loadData({
        api: e,
        properties: t,
        referenceResolver: o
    }) {
        var r, i, n, l;
        if (!e.productBox) throw new Error("Missing ProductBoxApi");
        const s = o.getValue(t.storeId);
        if (!s) return;
        const u = (i = (r = t.products) === null || r === void 0 ? void 0 : r.map(({
                id: h
            }) => h)) !== null && i !== void 0 ? i : [],
            c = await e.productBox.getProducts(s, u);
        if (c.ok) return {
            externalProducts: (l = (n = await c.json()) === null || n === void 0 ? void 0 : n.products) !== null && l !== void 0 ? l : []
        }
    }
});

function NS() {
    return a("div", {
        children: a(zt, {
            id: K.Elements.OrderForm.Presentation.MissingProducts
        })
    })
}
var En;
(function(e) {
    e[e.Always = 0] = "Always", e[e.UntilLocationChanged = 1] = "UntilLocationChanged"
})(En || (En = {}));
const US = Xe(e => e.products.length ? a(q3, { ...e
    }) : a(NS, {}), {
        loadTranslation: !0,
        cache: En.UntilLocationChanged,
        async loadData({
            api: e,
            referenceResolver: t,
            pageUrl: o
        }) {
            if (!e.productBox) throw new Error("Missing ProductBoxApi");
            const r = t.getValue(vf);
            if (!r) throw new Error("Missing storeId in settings");
            const i = o.searchParams.getAll("product"),
                n = await e.productBox.getProducts(r, i);
            if (n.ok) {
                const l = await n.json();
                return {
                    products: l.products,
                    storeCurrency: l.currency
                }
            }
            return {
                products: [],
                storeCurrency: null
            }
        }
    }),
    VS = Xe(() => a(J3, {}), {
        loadTranslation: !1
    });
class Ln {
    static resolveByType(t) {
        var o;
        return (o = this.componentsMap.get(t)) !== null && o !== void 0 ? o : null
    }
    resolveByType(t) {
        return Promise.resolve(this.getSync(t))
    }
    hasResolved() {
        return !0
    }
    getSync(t) {
        return Ln.resolveByType(t)
    }
    isKnown(t) {
        return Ln.componentsMap.has(t)
    }
}
Object.defineProperty(Ln, "componentsMap", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: new Map([
        [Jo.Body, xb],
        [Jo.Section, TB],
        [Jo.Column, FB],
        [I.ColumnGroup, RB],
        [I.Button, SB],
        [I.CustomHtml, MB],
        [I.Divider, OB],
        [I.Gallery, NB],
        [I.Image, UB],
        [I.SocialMedia, _B],
        [I.Spacer, ZB],
        [I.Text, KB],
        [I.Timer, QB],
        [I.Video, uS],
        [I.ContactForm, PS],
        [I.Form, Tb],
        [I.BuyButton, kS],
        [I.PromoCode, TS],
        [I.Webinar, Eb],
        [I.ProductBox, DS],
        [I.OrderForm, US],
        [I.ConfirmationPage, VS]
    ])
});
const Lb = "mobile-hide",
    HS = K0 `
    ${Jy}

    body.readonly {
        &, & iframe {
          pointer-events: none;
          user-select: none;
        }
    }
    
    :root, :host {
        --${D.One}: ${({theme:e})=>e.globalDesign.colors.background};
        --${D.Two}: ${({theme:e})=>e.globalDesign.colors.text};
        --${D.Three}: ${({theme:e})=>e.globalDesign.colors.buttonBackground};
        --${D.Four}: ${({theme:e})=>e.globalDesign.colors.specialOne};
        --${D.Five}: ${({theme:e})=>e.globalDesign.colors.specialTwo};
        --common-font-family: Roboto, Helvetica, Arial, sans-serif;
        --${Fd}: ${({topHeaderFontSize:e})=>e};
        --${Id}: ${({headerFontSize:e})=>e};
        --${kd}: ${({subheaderFontSize:e})=>e};
        --${Td}: ${({paragraphFontSize:e})=>e};
        --${qh}: ${({verticalSpacingRatio:e})=>e/100};
        --${Jh}: ${({horizontalSpacingRatio:e})=>e/100};
        --${Zh}: ${e=>e.windowWidthRatio};
    }
    
    @media ${Oi} {
        .${Lb} {
            display: none;
        }
    }
`;

function Vc(e, t) {
    return e === null || e > t.globalDesign.contentWidth ? 1 : e / t.globalDesign.contentWidth
}
const jS = x.memo(() => {
    const e = oh(),
        [t, o] = f.exports.useState(() => {
            var i, n;
            return Vc((n = (i = Er()) === null || i === void 0 ? void 0 : i.innerWidth) !== null && n !== void 0 ? n : null, e)
        }),
        r = gl().theming[De.Mobile];
    return f.exports.useEffect(() => {
        const i = Er();
        if (!i) return;

        function n() {
            var l;
            o(Vc((l = i ? .innerWidth) !== null && l !== void 0 ? l : null, e))
        }
        return i.addEventListener("resize", n, {
            passive: !0
        }), () => {
            i.removeEventListener("resize", n)
        }
    }, [e]), a(HS, { ...r,
        windowWidthRatio: t
    })
});
class zS extends cu {
    constructor(t, o = {}) {
        super("Form validation errors"), Object.defineProperty(this, "errors", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "errorsCodeMap", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    getErrors() {
        return this.errors.map(({
            code: t,
            fieldName: o
        }) => {
            var r;
            return {
                fieldName: o,
                message: (r = this.errorsCodeMap[t]) !== null && r !== void 0 ? r : K.Elements.SubscriptionForm.Errors.GeneralError
            }
        })
    }
}
class Hc extends cu {
    getErrors() {
        return [{
            fieldName: "",
            message: K.Elements.SubscriptionForm.Errors.GeneralError
        }]
    }
}
class _S {}
class GS extends hu {
    constructor(t, o = {}) {
        super("WebinarForm validation errors"), Object.defineProperty(this, "errors", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }), Object.defineProperty(this, "errorsCodeMap", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        })
    }
    getErrors() {
        return this.errors.map(({
            code: t,
            fieldName: o
        }) => {
            var r;
            return {
                fieldName: o,
                message: (r = this.errorsCodeMap[t]) !== null && r !== void 0 ? r : K.Elements.Form.Errors.GeneralError
            }
        })
    }
}
class jc extends hu {
    getErrors() {
        return [{
            fieldName: "",
            message: K.Elements.Form.Errors.GeneralError
        }]
    }
}
class ZS {}

function qS(e) {
    return e.asyncData
}

function JS(e) {
    return qS(e).data
}
const mu = x.createContext(null);

function bu() {
    return f.exports.useContext(mu)
}
class YS extends Error {
    constructor(t) {
        super(`Unknown source type: ${t}`)
    }
}

function XS(e) {
    return e.type === Ye.External
}

function KS(e) {
    return e.type === Ye.Storage
}

function zc(e) {
    if (XS(e)) return e.data.src;
    if (KS(e)) {
        const {
            src: t
        } = e.data;
        if (t.startsWith("/")) return `https://m.gr-cdn-3.com${t}`;
        const o = new URL(t);
        return !o.pathname.startsWith("/user") && o.host === "multimedia.getresponse.com" ? (o.protocol = "https:", o.host = "m.gr-cdn-3.com", o.toString()) : t
    }
    throw new YS(e.type)
}

function QS(e) {
    if (e.socialImage) return zc(e.socialImage);
    const t = Fn.fromJson(e.content),
        o = t.getElementChildrenSubtree(t.elements.getByElementId(Kr)).find(r => r.type === I.Image);
    return o ? .properties.src ? zc(o.properties.src) : null
}
const Mb = x.createContext(null);

function e4() {
    const e = f.exports.useContext(Mb);
    if (e === null) throw new Error("Missing SSR Result Context");
    return e
}
var ei = (e => (e.Start = "[hc", e.End = "hc]", e))(ei || {});

function t4(e) {
    const t = document.createElement("script");
    for (const r of e.getAttributeNames()) t.setAttribute(r, e.getAttribute(r));
    const o = e.textContent;
    return o !== null && (t.textContent = o), t
}
const o4 = x.memo(({
    page: e
}) => {
    const t = e4(),
        o = f.exports.useRef(null),
        r = f.exports.useRef(null),
        i = f.exports.useRef(!0);
    return f.exports.useEffect(() => {
        if (e.headContent === null) return;
        const n = new DOMParser;
        if (o.current === null || r.current === null)
            for (const l of Array.from(document.head.childNodes)) l instanceof Comment && (l.data === ei.Start ? o.current = l : l.data === ei.End && (r.current = l));
        if (o.current === null && r.current === null && (o.current = document.createComment(ei.Start), r.current = document.createComment(ei.End), document.head.append(o.current, r.current)), o.current === null || r.current === null) {
            console.warn("Failed to resolve custom head boundaries");
            return
        }
        if (!i.current) {
            const l = `i${Math.random()}`,
                s = n.parseFromString(`<div id="${l}">${e.headContent}</div>`, "text/html"),
                u = Array.from(s.getElementById(l).childNodes);
            for (let c = 0; c < u.length; c++) {
                const h = u[c];
                h instanceof HTMLScriptElement && (u[c] = t4(h))
            }
            o.current.after(...u)
        }
        return () => {
            let l = null;
            for (;
                (l = o.current.nextSibling) !== r.current;) l.parentNode.removeChild(l)
        }
    }, [e.headContent]), f.exports.useEffect(() => {
        i.current = !1
    }, []), e.headContent !== null && (t.headContent = e.headContent), null
});
var fu = (e => (e.Browser = "browser", e.Memory = "memory", e))(fu || {});

function r4(e) {
    return e.member
}

function Ob(e) {
    return r4(e).isLoggedIn
}

function lr(e) {
    return e.sitemap.sitemap
}

function vl(e) {
    return lr(e).theming
}

function Cl(e) {
    return s4(vl(e)).colors
}

function n4(e) {
    return vl(e)[De.CustomCode].hasClassesAndIds ? ? !1
}

function Ab(e, t) {
    return Co.findPage(lr(e), t)
}

function wl(e, t) {
    return lr(e).pages.find(o => o.type === t) ? ? null
}

function i4(e) {
    return wl(e, we.EnterPassword)
}

function Wb(e) {
    return wl(e, we.Login)
}

function a4(e, t) {
    return lr(e).pages.find(o => o.uuid === t) ? ? null
}

function Db(e, t) {
    return !!a4(e, t) ? .content
}

function l4(e) {
    return wl(e, we.NotFound)
}

function Nb(e) {
    const {
        customProperties: t,
        defaultProperties: o
    } = vl(e)[De.Button];
    return t ? ? o
}

function s4(e) {
    const {
        [De.Palette]: t
    } = e, {
        selectedPaletteUUID: o
    } = t;
    return t.availablePalettes.find(r => r.uuid === o)
}

function d4(e) {
    return lr(e).webfonts
}

function u4(e) {
    const t = lr(e),
        o = Ob(e),
        r = [...t.pages.filter(l => l.type === we.Internal ? l.access.type === Bo.Members ? o : !0 : !1), ...t.externalPages].filter(l => l.isHidden === !1 && l.status === kr.Active),
        i = t.pagePositions.map(l => r.find(s => s.uuid === l)).filter(l => l && l.status === kr.Active && l.isHidden === !1);

    function n(l) {
        const s = i.filter(u => u.parentId === l.uuid).map(n);
        return {
            page: l,
            children: s
        }
    }
    return i.filter(l => !l.parentId).map(n)
}

function c4(e) {
    return lr(e).settings
}

function gu(e) {
    return gi.fromJson(c4(e))
}

function Nt(e) {
    return e.runtime
}

function h4(e) {
    return Nt(e).endpoints.statistics
}

function m4(e) {
    return Nt(e).flags.isStatisticsEnabled && gu(e).analytics.stats.isCookieEnabled
}

function b4(e) {
    return Nt(e).flags.navigationMode === fu.Memory
}

function Ub(e) {
    return Nt(e).initialPagePath
}

function f4(e) {
    return Nt(e).origin
}

function g4(e) {
    return Nt(e).flags.isCookieBannerEnabled
}

function p4(e) {
    return Nt(e).flags
}

function Vb(e) {
    return Nt(e).account.isFreemium
}

function y4(e) {
    return Nt(e).account.isTrial
}

function x4(e) {
    return Nt(e).account.hasBadge
}

function v4(e) {
    return Nt(e).account.grBadgeUrl
}

function C4(e) {
    return Nt(e).flags.isForcingDisabledPages
}

function Hb(e) {
    return Nt(e).flags
}

function w4(e) {
    return Nt(e).websiteId
}

function B4({
    page: e
}) {
    const t = QS(e),
        o = je(Vb);
    return y(x.Fragment, {
        children: [y(so, {
            children: [a("title", {
                children: e.title
            }), a("meta", {
                property: "og:title",
                content: e.title
            }), a("meta", {
                property: "og:type",
                content: "website"
            }), t ? a("meta", {
                property: "og:image",
                content: t
            }) : null, e.description ? [a("meta", {
                property: "description",
                content: e.description
            }, "description"), a("meta", {
                property: "og:description",
                content: e.description
            }, "og:description")] : null, e.isSearchEnginesOn ? null : a("meta", {
                name: "robots",
                content: "noindex, nofollow"
            })]
        }), gt(!o, a(o4, {
            page: e
        }))]
    })
}
const Bl = x.createContext(null);

function pu() {
    return f.exports.useContext(Bl)
}

function Sl(e) {
    const t = f.exports.useContext(Bl);
    return f.exports.useCallback(o => {
        o.stopPropagation(), t.pageClick(e, o)
    }, [t, e])
}

function S4(e, t) {
    const o = f.exports.useContext(Bl);
    return f.exports.useCallback(r => {
        let i, n = r.target;
        if (!!document.body.contains(n)) {
            do {
                if (i = n ? .getAttribute ? .("data-hyperlink-id"), i) break;
                n = n ? .parentNode
            } while (n && n !== document.body);
            if (i) {
                const l = t.getRegisteredData(i);
                o.hyperlinkClick(e, { ...l,
                    description: l ? .description ? ? n.textContent
                })
            }
        }
    }, [t, e, o])
}
const $4 = f.exports.createContext(void 0);
class yu extends f.exports.PureComponent {
    static getDerivedStateFromError() {
        return {
            hasError: !0
        }
    }
    state = {
        hasError: !1,
        sentryEventId: null
    };
    componentDidCatch(t, o) {
        const {
            onComponentError: r
        } = this.props;
        r(), {
            FRONT_DIRECT_STORAGE_HOST: "multimedia.getresponse.com",
            FRONT_GETRESPONSE_STORAGE_CDN: "m.gr-cdn-3.com",
            FRONT_WBE_STORAGE_CDN: "us-wbe-img.gr-cdn.com",
            FRONT_AUTH_ENABLED: "true",
            FRONT_BANDWIDTH_ORIGINS: "us-wbe-img.gr-cdn.com,multimedia.getresponse.com,m.gr-cdn-3.com,us-wbe.gr-cdn.com,https://wbe-stats-collector.local.gr-dev.me,iframegrchatbeta.web.app,i.getresponse.chat",
            FRONT_DATA_OBFUSCATION_KEY: "Th!sISup3rS3cr3-|-Str1nG",
            BASE_URL: "https://us-wbe.gr-cdn.com/public/js/",
            MODE: "production",
            DEV: !1,
            PROD: !0
        }.FRONT_CLIENT_SENTRY === "true" && Q0(i => {
            i.setExtras(o);
            const n = ef(t);
            this.setState({
                sentryEventId: n
            })
        })
    }
    render() {
        const {
            hasError: t,
            sentryEventId: o
        } = this.state, {
            errorContentComponent: r
        } = this.props;
        return t ? r ? f.exports.cloneElement(r, {
            sentryEventId: o
        }) : a("span", {
            "data-sentry-id": o
        }) : this.props.children
    }
}
Et(yu, "defaultProps", {
    onComponentError: Gt,
    errorContentComponent: null
});
const xu = x.createContext(null);

function R4() {
    const e = f.exports.useContext(xu);
    if (e === null) throw new Error("Missing IComponentResolver implementation");
    return e
}

function Zt(e, t) {
    return Object.assign(x.memo(e), t)
}
const P4 = Zt(({
        children: e,
        elementId: t
    }) => y(x.Fragment, {
        children: [y("div", {
            children: ["Unknown element: ", t]
        }), e]
    }), {
        loadTranslation: !1
    }),
    F4 = Zt(e => y(x.Fragment, {
        children: [y("div", {
            children: ["Element not loaded: ", e.elementId]
        }), e.children]
    }), {
        loadTranslation: !1
    });

function I4(e, t) {
    return e.isKnown(t) ? e.getSync(t) ? ? F4 : Ln.resolveByType(t) ? ? P4
}

function $l(e) {
    const t = je(s => JS(s)),
        o = pu(),
        r = R4(),
        i = bu();
    x.useEffect(() => {
        e.sendStats && o.visitPage(e.page)
    }, [o, e.page, e.sendStats]);
    const n = f.exports.useMemo(() => ({
            content: e.page.content
        }), [e.page.content]),
        l = Rd.getPixelsFromPage(e.page);
    return y($4.Provider, {
        value: n,
        children: [a(B4, {
            page: e.page
        }), jb(t, i, e.page, e.customProps, n.content, r), l.map(s => a("img", {
            src: s,
            alt: "",
            style: {
                position: "absolute"
            }
        }, s))]
    })
}

function jb(e, t, o, r, i, n, l = Kr) {
    const s = i.elements.find(g => g.id === l);
    if ((s ? .properties).isHidden) return null;
    const u = i.relations.find(g => g.elementId === l) || {
            children: [],
            elementId: l
        },
        c = I4(n, s.type),
        h = e[s.id] ? ? {},
        m = !!s.properties.isHiddenOnMobile;
    return a(yu, {
        children: a(c, {
            elementId: s.id,
            elementType: s.type,
            ...s.properties,
            ...h,
            api: t,
            pageUuid: o.uuid,
            className: m ? Lb : void 0,
            ...r,
            children: u.children.map(g => jb(e, t, o, r, i, n, g))
        })
    }, s.id)
}
const vu = x.createContext(null);

function Cu() {
    return f.exports.useContext(vu)
}
class Ps extends Error {
    constructor(t) {
        super(`Missing system page "${t}"`)
    }
}
const k4 = () => {
    const e = je(l4);
    if (Cu().setIsPageProtected(!0), !e) throw new Ps("NotFoundPage");
    return a($l, {
        sendStats: !0,
        page: e
    })
};
class na {
    static loadPage(t, o, r) {
        return this.loadElements(this.getElements(o), t, r)
    }
    static mapElementToAsyncDataComponent(t, o) {
        if (o.hasResolved(t.type)) {
            const r = o.getSync(t.type);
            return Boolean(r) && "loadData" in r ? {
                element: t,
                component: r
            } : null
        }
        return o.resolveByType(t.type).then(r => Boolean(r) && "loadData" in r ? {
            element: t,
            component: r
        } : null)
    }
    static getComponentsWithAsyncData(t, o) {
        return Promise.all(o.map(r => this.mapElementToAsyncDataComponent(r, t))).then(r => r.filter(Boolean))
    }
    static loadComponentsWithAsyncData(t, o) {
        return Promise.all(t.map(r => this.loadComponentData(r, o))).then(r => r.filter(Boolean))
    }
    static async loadComponentData({
        component: t,
        element: o
    }, r) {
        const i = await t ? .loadData({ ...r,
            elementId: o.id,
            properties: o.properties
        });
        return Boolean(i) && typeof i == "object" ? {
            elementId: o.id,
            data: i
        } : null
    }
    static async loadElements(t, o, r) {
        const i = await this.getComponentsWithAsyncData(o, t);
        return this.loadComponentsWithAsyncData(i, r)
    }
    static hasAsyncComponent(t, o) {
        return this.getElements(o).some(r => t.getSync(r.type) ? .loadData)
    }
    static async getElementComponentsByCacheControl(t, o, r = En.Always) {
        const i = await this.getComponentsWithAsyncData(o, this.getElements(t));
        return r === En.Always ? i : i.filter(({
            component: n
        }) => "cache" in n ? n.cache === r : !1)
    }
    static getElements(t) {
        return t.content.elements
    }
}
var Zr = (e => (e.StartLoading = "wbe/asyncData/startLoading", e.StopLoading = "wbe/asyncData/stopLoading", e.SetMultipleData = "wbe/asyncData/setMultiple", e.SetData = "wbe/asyncData/set", e))(Zr || {});

function T4(e) {
    return {
        type: Zr.SetMultipleData,
        items: e
    }
}
const zb = x.createContext(null);

function E4() {
    return f.exports.useContext(zb)
}
class wu {
    static async load(t, {
        api: o
    }) {
        const r = await o.page.getContent(t);
        return r.ok ? (await r.json()).content : null
    }
}
var qo = (e => (e.SetSitemap = "wbe/sitemap/set", e.RemoveProtectedContent = "wbe/sitemap/removeProtectedContent", e.SetPageContent = "wbe/sitemap/setPageContent", e.SetMobileTheming = "wbe/sitemap/setMobileTheming", e))(qo || {});

function L4(...e) {
    return {
        type: qo.RemoveProtectedContent,
        uuidsWithAccess: e,
        timestamp: Date.now()
    }
}

function Bu(e, t) {
    return {
        type: qo.SetPageContent,
        uuid: e,
        content: t
    }
}

function M4(e) {
    return {
        type: qo.SetMobileTheming,
        theming: e
    }
}

function O4(e) {
    const {
        pageUuid: t
    } = e;
    E4();
    const o = bu(),
        r = Ms(),
        i = je(h => Db(h, t)),
        n = Cu();
    let l;
    l = i, l && n.setIsPageProtected(!1);
    const [s, u] = f.exports.useState(l);
    x.useEffect(() => {
        u(l)
    }, [t]);
    const c = f.exports.useMemo(() => ({
        protectedPageUuid: t,
        passwordViewController: {
            async navigateToPage() {
                const h = await wu.load(t, {
                    api: o
                });
                if (h === null) return console.error("There was an error while fetching protected page content");
                r(Bu(t, h)), u(!0)
            }
        }
    }), [t, u, o, r]);
    return s ? a(x.Fragment, {
        children: e.content
    }) : a($l, {
        sendStats: !0,
        page: e.passwordPage,
        customProps: c
    })
}

function A4(e) {
    const {
        pageUuid: t
    } = e, o = bu(), r = Ms();
    je(h => Ob(h));
    const i = je(h => Db(h, t)),
        n = Cu();
    let l;
    l = i, l && n.setIsPageProtected(!1);
    const [s, u] = f.exports.useState(l);
    x.useEffect(() => {
        u(l)
    }, [t]);
    const c = f.exports.useMemo(() => ({
        loginViewController: {
            async navigateToPage() {
                const h = await wu.load(t, {
                    api: o
                });
                if (h === null) return console.error("There was an error while fetching protected page content");
                r(Bu(t, h)), u(!0)
            }
        }
    }), [t, o, r]);
    return s ? a(x.Fragment, {
        children: e.content
    }) : a($l, {
        sendStats: !0,
        page: e.loginPage,
        customProps: c
    })
}

function _b(e, t = Date.now()) {
    if (e === null) return !1;
    const o = W4(e) ? e : e.scheduledOn;
    return new Date(o).getTime() > t
}

function W4(e) {
    return e === null || typeof e == "string"
}
const D4 = v.div.withConfig({
        componentId: "sc-f83f6k-0"
    })(["position:fixed;width:100%;height:2px;background:#ff0000;transform:scaleX(", ");transform-origin:left center;transition:transform .5s;z-index:1;pointer-events:none;display:", ";"], ({
        $scale: e
    }) => e, ({
        $visible: e
    }) => e ? "block" : "none"),
    Gb = x.createContext(void 0),
    N4 = e => {
        const {
            children: t
        } = e, [o, r] = x.useState(0), [i, n] = x.useState(!0);
        x.useEffect(() => {
            let s;
            return o === 100 && (s = window.setTimeout(() => {
                n(!1), r(0)
            }, 1e3)), i === !1 && (s = window.setTimeout(() => {
                n(!0)
            }, 10)), () => {
                window.clearTimeout(s)
            }
        }, [o, i]);
        const l = x.useMemo(() => ({
            start() {
                r(s => Math.max(20, s))
            },
            step(s) {
                r(u => Math.max(s, u))
            },
            stop() {
                r(s => s === 0 ? 0 : 100)
            }
        }), []);
        return y(Gb.Provider, {
            value: l,
            children: [a(D4, {
                $scale: Number((o / 100).toFixed(2)),
                $visible: i
            }), t]
        })
    },
    Fs = x.createContext(null);

function U4(e) {
    const t = Object.entries(e),
        o = () => {
            const r = {};
            for (const [i, n] of t) r[i] = f.exports.useContext(n);
            return r
        };
    return function(i) {
        return function(l) {
            const s = o();
            return a(i, { ...l,
                ...s
            })
        }
    }
}
const Zb = x.createContext(null);
class qb extends x.PureComponent {
    state = {
        urlLoaded: [{
            pathname: this.props.location.pathname,
            search: this.props.location.search
        }],
        urlLoading: [],
        contentLoadingUuids: [],
        contentLoadedUuids: [],
        lastResolverResult: null,
        elementsLoadingPageIds: []
    };
    constructor(t, o) {
        super(t, o), t.routingService.setPageId(t.resolverResult ? .page.uuid ? ? null)
    }
    async componentDidUpdate(t) {
        const o = this.context,
            {
                resolverResult: r,
                api: i,
                setContent: n,
                routingService: l,
                componentResolver: s
            } = this.props,
            {
                contentLoadingUuids: u,
                contentLoadedUuids: c,
                lastResolverResult: h,
                elementsLoadingPageIds: m
            } = this.state;
        if (l.setPageId(r ? .page.uuid ? ? null), r !== t.resolverResult && h !== t.resolverResult && this.setState({
                lastResolverResult: t.resolverResult
            }), !r) return;
        const {
            page: g
        } = r;
        if (!g.content && !u.includes(g.uuid) && !c.includes(g.uuid)) {
            o.start(), this.setState(b => ({
                contentLoadingUuids: [...b.contentLoadingUuids, g.uuid]
            })), o.step(20);
            const p = await wu.load(g.uuid, {
                api: i
            });
            p !== null && n(g.uuid, p), this.setState(b => ({
                contentLoadedUuids: [...b.contentLoadedUuids, g.uuid],
                contentLoadingUuids: b.contentLoadingUuids.filter(C => C !== g.uuid)
            }))
        }
        g.content && !m.includes(g.uuid) && !s.hasResolved(...this.currentPageElementTypes) && (o.step(40), this.setState(p => ({
            elementsLoadingPageIds: [...p.elementsLoadingPageIds, g.uuid]
        })), Promise.all(this.currentPageElementTypes.map(p => s.resolveByType(p))).then(() => {
            this.setState(p => ({
                elementsLoadingPageIds: p.elementsLoadingPageIds.filter(b => g.uuid !== b)
            }))
        })), this.hasResolvedAllElements && this.hasAsync && await this.loadPageElements(t), this.isLoading || o.stop()
    }
    async loadPageElements(t) {
        const o = this.context,
            {
                componentResolver: r,
                setAsyncData: i,
                showDeps: n,
                api: l,
                websiteId: s,
                resolverResult: u,
                pageUrlService: c
            } = this.props,
            {
                urlLoaded: h,
                urlLoading: m
            } = this.state,
            g = {
                pathname: this.props.location.pathname,
                search: this.props.location.search
            },
            p = h.some(w => w.pathname === g.pathname),
            b = m.find(w => w.pathname === g.pathname),
            C = t.location.pathname === g.pathname ? t.location.search !== g.search : !0;
        if (p && C && b ? .search !== g.search) {
            const w = await na.getElementComponentsByCacheControl(u.page, r, En.UntilLocationChanged);
            if (w.length) {
                o.start(), this.setState(B => ({
                    urlLoading: [...B.urlLoading.filter(S => S.pathname !== g.pathname), g],
                    urlLoaded: B.urlLoaded.filter(S => S.pathname !== g.pathname)
                })), o.step(60);
                try {
                    const B = await na.loadComponentsWithAsyncData(w, {
                        api: l,
                        entityId: s,
                        referenceResolver: n.referenceResolver,
                        pageUrl: c
                    });
                    o.step(80), this.state.urlLoading.some(S => S === g) && i(B)
                } catch (B) {
                    console.warn(B), this.props.history.goBack(), o.stop()
                }
                this.setState(B => ({
                    urlLoading: B.urlLoading.filter(S => S !== g),
                    urlLoaded: [...B.urlLoaded, g]
                }))
            }
        }
        if (!p && !b) {
            o.start(), this.setState(B => ({
                urlLoading: [...B.urlLoading, g]
            })), o.step(60);
            const w = await na.loadPage(r, u.page, {
                api: l,
                entityId: s,
                referenceResolver: n.referenceResolver,
                pageUrl: c
            });
            o.step(80), i(w), this.setState(B => ({
                urlLoading: B.urlLoading.filter(S => S.pathname !== g.pathname),
                urlLoaded: [...B.urlLoaded, g]
            }))
        }
    }
    get isLoading() {
        const t = this.hasAsync && !this.state.urlLoaded.some(r => r.pathname === this.props.location.pathname && r.search === this.props.location.search),
            o = this.state.contentLoadingUuids.includes(this.props.resolverResult ? .page.uuid);
        return t || o || !this.hasResolvedAllElements
    }
    get currentPageElementTypes() {
        return this.props.resolverResult ? .page.content ? .elements.map(t => t.type) ? ? []
    }
    get hasResolvedAllElements() {
        return !this.state.elementsLoadingPageIds.includes(this.props.resolverResult ? .page.uuid) && this.props.componentResolver.hasResolved(...this.currentPageElementTypes)
    }
    get hasAsync() {
        return this.props.resolverResult ? .page.content && na.hasAsyncComponent(this.props.componentResolver, this.props.resolverResult.page)
    }
    renderPageView(t) {
        return t.content ? a($l, {
            sendStats: !0,
            page: t
        }) : null
    }
    renderPage(t) {
        const {
            enterPasswordPage: o,
            loginPage: r,
            protectionService: i
        } = this.props, n = t ? .page;
        if (!n || this.isPageHidden(n)) return a(k4, {});
        if (n.access.type === Bo.Password) {
            if (!o) throw new Ps("EnterPasswordPage");
            return a(O4, {
                passwordPage: o,
                content: this.renderPageView(n),
                pageUuid: n.uuid,
                validPassword: n.access.password
            })
        } else if (n.access.type === Bo.Members) {
            if (!r) throw new Ps("LoginPage");
            return a(A4, {
                loginPage: r,
                content: this.renderPageView(n),
                pageUuid: n.uuid
            })
        }
        return i.setIsPageProtected(!1), this.renderPageView(n)
    }
    isPageHidden(t) {
        return this.props.isForcingDisabledPages ? !1 : t.status === kr.Inactive && typeof t.scheduledOn != "string" ? !0 : _b(t)
    }
    render() {
        return this.isLoading ? a(Fs.Provider, {
            value: this.state.lastResolverResult ? .page ? ? null,
            children: this.renderPage(this.state.lastResolverResult)
        }) : a(Fs.Provider, {
            value: this.props.resolverResult ? .page ? ? null,
            children: this.renderPage(this.props.resolverResult)
        })
    }
}
Et(qb, "contextType", Gb);
const V4 = tf((e, t) => ({
        resolverResult: Ab(e, t.location.pathname),
        enterPasswordPage: i4(e),
        loginPage: Wb(e),
        isForcingDisabledPages: C4(e),
        websiteId: w4(e)
    }), e => ({
        setAsyncData(t) {
            e(T4(t))
        },
        setContent(t, o) {
            e(Bu(t, o))
        }
    }))(U4({
        api: mu,
        protectionService: vu,
        routingService: Zb,
        componentResolver: xu,
        showDeps: eu,
        pageUrlService: wb
    })(qb)),
    H4 = "modulepreload",
    j4 = function(e) {
        return "https://us-wbe.gr-cdn.com/public/js/" + e
    },
    _c = {},
    z4 = function(t, o, r) {
        if (!o || o.length === 0) return t();
        const i = document.getElementsByTagName("link");
        return Promise.all(o.map(n => {
            if (n = j4(n), n in _c) return;
            _c[n] = !0;
            const l = n.endsWith(".css"),
                s = l ? '[rel="stylesheet"]' : "";
            if (!!r)
                for (let h = i.length - 1; h >= 0; h--) {
                    const m = i[h];
                    if (m.href === n && (!l || m.rel === "stylesheet")) return
                } else if (document.querySelector(`link[href="${n}"]${s}`)) return;
            const c = document.createElement("link");
            if (c.rel = l ? "stylesheet" : H4, l || (c.as = "script", c.crossOrigin = ""), c.href = n, document.head.appendChild(c), l) return new Promise((h, m) => {
                c.addEventListener("load", h), c.addEventListener("error", () => m(new Error(`Unable to preload CSS for ${n}`)))
            })
        })).then(() => t())
    };
var Pr = (e => (e[e.Small = 0] = "Small", e[e.Medium = 1] = "Medium", e[e.Large = 2] = "Large", e))(Pr || {});
const Gc = {
        [Pr.Large]: 32,
        [Pr.Medium]: 16,
        [Pr.Small]: 8
    },
    _4 = v.div.withConfig({
        componentId: "sc-zebns9-0"
    })(["animation:0.54s linear 0s infinite normal none running iconSpin;width:", "px;height:", "px;", " svg{fill:rgb(0,186,255);width:100%;height:100%;stroke:none;}@keyframes iconSpin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}"], e => Gc[e.$size], e => Gc[e.$size], e => e.$center ? "display: flex; justify-content: center; align-items: center; width: 100%;" : "");

function Jb(e) {
    return a(_4, {
        $size: e.size ? ? Pr.Large,
        $center: e.center ? ? !0,
        children: a("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 32 32",
            children: a("path", {
                d: "M16 30.3c-3.8.1-7.6-1.3-10.4-3.9C2.8 23.8 1.1 19.9 1 16 .8 12.1 2.3 8 5.1 5.1 7.9 2.2 11.9.4 16 .3c.8 0 1.4.6 1.5 1.4s-.6 1.4-1.4 1.5H16C12.6 3 9.2 4.3 6.6 6.6 4.1 9 2.5 12.4 2.4 16c-.1 3.6 1.2 7.2 3.7 9.9 2.5 2.6 6.1 4.3 9.9 4.4z"
            })
        })
    })
}
const G4 = {
    width: "100vw",
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
};

function Z4() {
    return a("div", {
        id: "loading-container",
        style: G4,
        children: a(Jb, {
            size: Pr.Large
        })
    })
}
const q4 = x.lazy(() => z4(() =>
    import ("./CoursePage.6a3fb026.js"), ["assets/CoursePage.6a3fb026.js", "assets/vendor.377da65b.js"]));

function J4(e) {
    const [t, o] = f.exports.useState(uB), r = a(Z4, {});
    return f.exports.useEffect(() => o(!1), []), t ? r : a(x.Suspense, {
        fallback: r,
        children: a(q4, {
            courseId: e.match.params.courseId
        })
    })
}
const Y4 = [{
    key: "course-page",
    path: "/-/courses/:courseId",
    component: J4
}, {
    key: "main-route",
    path: "*",
    component: V4
}];

function X4(e) {
    return e.startsWith("//") || e.includes("://")
}

function Is(e, t = e) {
    return a("link", {
        rel: "preconnect",
        href: X4(e) ? e : `//${e}`,
        crossOrigin: "anonymous"
    }, t)
}
const Zc = "fonts-link",
    K4 = 1e4,
    qc = "loaded",
    Q4 = e => {
        const t = je(d4),
            o = wo.getGoogleFontsUrl(t);
        return f.exports.useEffect(() => {
            if (o === null) return;
            const r = document.getElementById(Zc);

            function i() {
                r.rel = "stylesheet"
            }
            const n = window.setTimeout(() => {
                r.hasAttribute(qc) || (r.addEventListener("load", i), r.rel = "preload")
            }, K4);
            return () => {
                r.removeEventListener("load", i), clearTimeout(n)
            }
        }, [o]), y(x.Fragment, {
            children: [o === null ? null : y(so, {
                children: [Is(wo.host), Is("https://fonts.gstatic.com"), a("link", {
                    rel: "stylesheet",
                    as: "style",
                    href: o,
                    crossOrigin: "anonymous",
                    id: Zc,
                    type: "text/css",
                    onLoad: `this.setAttribute('${qc}', 'true')`
                }), a("noscript", {
                    children: `<link rel="stylesheet" href="${o}"/>`
                })]
            }), e.children]
        })
    };

function Yb(e) {
    return vl(e)[De.Typography]
}

function e5(e) {
    return Yb(e).custom
}

function t5(e) {
    return Yb(e).predefined
}

function Rl(e) {
    return e5(e) ? ? t5(e)
}

function o5() {
    return je(Cl)
}

function r5() {
    return je(Rl)
}

function n5() {
    return je(e => u4(e))
}

function Pl() {
    return je(gu, () => !0)
}

function i5() {
    const e = Pl(),
        t = ["us-wbe-img.gr-cdn.com", "m.gr-cdn-3.com"];
    if (e.analytics.analytics.isEnabled) {
        const {
            analytics: o
        } = e.analytics;
        o.isPlatformConfigured(Te.YandexMetrica) && t.push("mc.yandex.ru"), o.isPlatformConfigured(Te.FacebookPixel) && t.push("www.facebook.com"), (o.isPlatformConfigured(Te.GoogleAnalytics) || o.isPlatformConfigured(Te.GoogleTagManager)) && t.push("www.googletagmanager.com")
    }
    return e.analytics.chats.isConfigured && t.push("i.getresponse.chat"), a(so, {
        children: t.map(o => Is(o))
    })
}

function a5({
    settings: e
}) {
    return e.favicon.hasIcon ? a(so, {
        children: a("link", {
            rel: "shortcut icon",
            href: e.favicon.url
        })
    }) : null
}

function l5(e, t = !1) {
    return `(() => {const e={urlParams:'c=${encodeURIComponent(e)}',iuv:'${t?"v5":"v1"}',bottom:'45',right:'0',hidden:false};Array.isArray(window.__GrChatData__) ? window.__GrChatData__.push(e) : window.__GrChatData__=[e]})();`
}

function Jc(e) {
    return je(p4, () => !0)[e]
}

function s5({
    settings: e
}) {
    const t = Jc("isGrChatsBeta"),
        o = Jc("isGrChatsEnabled"),
        r = pb(),
        i = o && r && e.analytics.chats.isConfigured;
    return f.exports.useEffect(() => {
        if (i) {
            const n = t ? "https://iframegrchatbeta.web.app/embedded_chat.js" : "https://i.getresponse.chat/embedded_chat.js";
            return pB.injectHead(n)
        }
    }, [i, t]), i ? a(so, {
        children: a("script", {
            children: l5(e.analytics.chats.id, t)
        })
    }) : null
}

function d5(e) {
    return `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','${encodeURIComponent(e.id)}');`
}

function u5(e) {
    return y(x.Fragment, {
        children: [a(so, {
            children: a("script", {
                "data-script": "gtm",
                children: d5(e.config)
            })
        }), a("noscript", {
            children: a("iframe", {
                src: `https://www.googletagmanager.com/ns.html?id=${e.config.id}`,
                height: 0,
                width: 0,
                style: {
                    display: "none",
                    visibility: "hidden"
                },
                loading: "eager"
            })
        })]
    })
}

function c5(e) {
    return `function gtag(){dataLayer.push(arguments)}window.dataLayer=window.dataLayer||[],gtag("js",new Date),gtag("config","${encodeURIComponent(e.id)}");`
}

function h5(e) {
    return y(so, {
        children: [a("script", {
            "data-script": "ga",
            children: c5(e.config)
        }), a("script", {
            async: !0,
            src: `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(e.config.id)}`
        })]
    })
}

function m5(e) {
    return `(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)}; m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)}) (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym"); ym(${Number(e.id)}, "init", { clickmap:true, trackLinks:true, accurateTrackBounce:true });`
}

function b5(e) {
    return y(x.Fragment, {
        children: [a(so, {
            children: a("script", {
                "data-script": "ym",
                children: m5(e.config)
            })
        }), a("noscript", {
            children: a("div", {
                children: a("img", {
                    src: `https://mc.yandex.ru/watch/${Number(e.config.id)}`,
                    style: {
                        position: "absolute",
                        left: -9999
                    },
                    alt: "",
                    loading: "eager",
                    decoding: "async"
                })
            })
        })]
    })
}

function f5(e) {
    return `!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init', '${encodeURIComponent(e.id)}');fbq('track', 'PageView');`
}

function g5(e) {
    return y(x.Fragment, {
        children: [a(so, {
            children: a("script", {
                "data-script": "fbp",
                children: f5(e.config)
            })
        }), a("noscript", {
            children: a("img", {
                height: 1,
                width: 1,
                style: {
                    display: "none"
                },
                src: `https://www.facebook.com/tr?id=${e.config.id}&ev=PageView&noscript=1`,
                alt: "",
                loading: "eager",
                decoding: "async"
            })
        })]
    })
}
const Yc = {
    [Te.GoogleTagManager]: u5,
    [Te.GoogleAnalytics]: h5,
    [Te.YandexMetrica]: b5,
    [Te.FacebookPixel]: g5
};

function p5({
    settings: {
        analytics: {
            analytics: e
        }
    }
}) {
    if (!e.isEnabled) return null;
    const t = e.platforms.filter(o => o.type in Yc).filter(o => e.isPlatformConfigured(o.type));
    return t.length === 0 ? null : a(x.Fragment, {
        children: t.map(o => {
            const r = Yc[o.type];
            return a(r, {
                config: o
            }, o.type)
        })
    })
}

function y5(e, t, o) {
    return `(function(i,s,o,g,r,a,m){i.grpr='https://us-ms.gr-cdn.com/getresponse-${t}/push-notification/${e}-pr.js';i['__GetResponseAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)};a=s.createElement(o);m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m);})(window,document,'script','${o}','GrTracking');GrTracking('setDomain','auto');GrTracking('push');`
}

function x5({
    settings: e
}) {
    const t = je(f4),
        o = f.exports.useMemo(() => e.webPush.find(n => t.includes(n.domain)), [t, e.webPush]),
        r = !!o && o.isActive,
        i = f.exports.useMemo(() => y5(o ? .webPushIdPanelApiEncoded, o ? .grUserId, o ? .trackingUrl), [o]);
    return r ? a(so, {
        children: a("script", {
            type: "text/javascript",
            "data-ats-script": "web-push",
            children: i
        })
    }) : null
}

function v5() {
    const e = Pl();
    return y(x.Fragment, {
        children: [a(a5, {
            settings: e
        }), a(p5, {
            settings: e
        }), a(s5, {
            settings: e
        }), a(x5, {
            settings: e
        })]
    })
}
const C5 = v.div.withConfig({
    componentId: "sc-68g0kt-0"
})(["position:fixed;bottom:0;left:0;right:0;z-index:2000;"]);

function w5() {
    const {
        cookieBanner: e
    } = Pl(), t = pl(), o = f.exports.useCallback(() => t.acceptCookies(), [t]), r = f.exports.useCallback(() => t.rejectCookies(), [t]), i = ru(), n = je(g4), [l, s] = f.exports.useState(i === ut.Accepted);
    return f.exports.useEffect(() => t.subscribe(u => s(u !== ut.None)), [t]), l || !n || !e.isEnabled || i === ut.Accepted ? null : a(C5, {
        children: a(yw, {
            title: e.title,
            message: e.message,
            button: e.button,
            onConfirm: o,
            decline: e.decline,
            onReject: r
        })
    })
}
const B5 = x.memo(e => y(Q4, {
    children: [a(i5, {}), e.isCustomSystemPage ? null : a(jS, {}), a(v5, {}), a("div", {
        children: of (Y4)
    }), a(w5, {})]
}));
var ks = (e => (e.Element = "element", e.Frame = "frame", e.Navigation = "navigation", e.Resource = "resource", e.Mark = "mark", e.Measure = "measure", e.Paint = "paint", e.LongTask = "longtask", e))(ks || {}),
    Oo = (e => (e.Script = "script", e.Stylesheet = "css", e.Document = "document", e.Xhr = "xhr", e.Image = "img", e))(Oo || {});
let ds = null;

function S5() {
    return ds || (ds = "us-wbe-img.gr-cdn.com,multimedia.getresponse.com,m.gr-cdn-3.com,us-wbe.gr-cdn.com,https://wbe-stats-collector.local.gr-dev.me,iframegrchatbeta.web.app,i.getresponse.chat".split(",").concat(location.host))
}
const us = new Map;

function Xb(e) {
    if (us.has(e)) return us.get(e);
    const t = e in window;
    return us.set(e, t), t
}

function Xc(e) {
    return Xb("PerformanceNavigationTiming") && e instanceof PerformanceNavigationTiming
}

function $5(e) {
    return Xb("PerformanceResourceTiming") && e instanceof PerformanceResourceTiming
}
class ai {
    constructor(t, o, r) {
        this.type = t, this.transferSize = o, this.url = r;
        try {
            this.isApplicable = S5().includes(new URL(this.url).host)
        } catch {
            this.isApplicable = !1
        }
    }
    isApplicable;
    static fromPerformanceEntry(t) {
        if (Xc(t)) return new ai(Oo.Document, t.transferSize, t.name);
        if ($5(t)) {
            const o = ai.getBandwidthResourceTypeFromEntry(t);
            return o === null ? null : new ai(o, t.transferSize, t.name)
        }
        throw new Error("Unknown performance entry")
    }
    static getBandwidthResourceTypeFromEntry(t) {
        return Xc(t) ? Oo.Document : ["link", "css"].includes(t.initiatorType) ? Oo.Stylesheet : t.initiatorType === "script" ? Oo.Script : t.initiatorType === "img" ? Oo.Image : ["xmlhttprequest", "fetch", "beacon"].includes(t.initiatorType) ? Oo.Xhr : null
    }
}

function R5(e = document.getElementsByTagName("img")) {
    if (e.length === 0) return Promise.resolve();
    const t = [];
    for (const o of Array.from(e)) o.complete || t.push(P5(o));
    return Promise.all(t)
}

function P5(e) {
    return new Promise(t => {
        if (e.complete) {
            t();
            return
        }
        e.onload = e.onerror = () => t()
    })
}
const Fu = class {
    nextPerformanceIndex = 0;
    statisticsService = null;
    routingPubSub = null;
    constructor() {}
    measure() {
        requestAnimationFrame(async () => {
            await R5();
            const t = this.nextPerformanceIndex === 0,
                o = Fu.MeasuredTypes.flatMap(r => performance.getEntriesByType(r)).slice(this.nextPerformanceIndex).map(ai.fromPerformanceEntry).filter((r, i, n) => (i === 0 && (this.nextPerformanceIndex += n.length), r ? .isApplicable && (r.type !== Oo.Document || t))).reduce((r, i) => ({ ...r,
                    [i.type]: r[i.type] + i.transferSize
                }), Object.fromEntries(Object.values(Oo).map(r => [r, 0])));
            this.statisticsService.submitBandwidth(this.routingPubSub.getPageId(), o), window.__lastMeasuredBandwidth = Object.values(o).reduce((r, i) => r + i, 0)
        })
    }
    onRouteChange() {
        this.measure()
    }
    init(t, o) {
        this.statisticsService = t, this.routingPubSub = o;
        const r = setTimeout(() => this.measure(), 7500);
        document.readyState !== "complete" && window.addEventListener("load", () => {
            clearTimeout(r), this.measure()
        })
    }
};
let ua = Fu;
Et(ua, "MeasuredTypes", [ks.Resource, ks.Navigation]);
const Kb = new ua;
let Mn;
const F5 = (e, t = "/") => {
    Mn = e ? rf({
        initialEntries: [t]
    }) : nf(), Mn.listen(() => Kb.onRouteChange())
};

function I5(e) {
    return e < .5 ? 4 * e * e * e : 1 - Math.pow(-2 * e + 2, 3) / 2
}
const si = class {
    constructor(t = window) {
        this.container = t, this.dispose = this.dispose.bind(this), this.tick = this.tick.bind(this), si.CancelEvents.forEach(o => this.container.addEventListener(o, this.dispose))
    }
    element;
    cancel = !1;
    startTime = 0;
    startPosition = 0;
    targetPosition = 0;
    nextProgressSpyOffset = 0;
    duration = this.calculateDuration();
    tryScrollToId(t, o = 3) {
        if (this.cancel) return;
        const r = document.getElementById(t);
        r ? this.scrollTo(r) : o > 0 && requestAnimationFrame(() => this.tryScrollToId(t, o - 1))
    }
    scrollTo(t) {
        return this.startPosition = document.documentElement.scrollTop, this.element = t, this.targetPosition = t.offsetTop, this.startPosition === this.targetPosition ? this.dispose() : (this.duration = this.calculateDuration(), void requestAnimationFrame(this.tick))
    }
    tick(t) {
        if (this.cancel) return;
        this.startTime || (this.startTime = t);
        const o = t - this.startTime;
        this.nextProgressSpyOffset < o && (this.nextProgressSpyOffset = this.nextProgressSpyOffset + this.duration / 4, this.targetPosition = this.element.offsetTop);
        const r = Math.round(this.targetPosition - this.startPosition),
            i = o >= this.duration ? 1 : I5(o / this.duration),
            n = this.startPosition + Math.ceil(r * i);
        return window.scrollTo(0, n), i < 1 ? void requestAnimationFrame(this.tick) : this.dispose()
    }
    calculateDuration() {
        const [t, o] = si.DurationRange;
        return Math.min(o, Math.max(Math.abs(this.targetPosition - this.startPosition), t))
    }
    dispose() {
        this.cancel || (this.cancel = !0, si.CancelEvents.forEach(t => this.container.removeEventListener(t, this.dispose)))
    }
};
let ti = si;
Et(ti, "CancelEvents", ["mousedown", "wheel", "touchmove", "keydown"]), Et(ti, "DurationRange", [400, 1e3]);

function k5() {
    const {
        pathname: e,
        hash: t,
        key: o
    } = ah();
    return f.exports.useEffect(() => {
        if (t) {
            const r = new ti,
                i = t.replace("#", "");
            return r.tryScrollToId(i), r.dispose
        }
        return void window.scrollTo(0, 0)
    }, [e, t, o]), null
}
const Ts = ({
    children: e
}) => a(yu, {
    children: y(af, {
        history: Mn,
        children: [a(k5, {}), e]
    })
});
Ts.displayName = Ts.name;

function T5(e, t, o) {
    return t.includes(e.uuid) ? !1 : e.access.type !== Bo.Public ? !0 : !(e.status === kr.Active || e.scheduledOn !== null && !_b(e, o))
}
const E5 = {
    sitemap: null
};

function L5(e = E5, t) {
    switch (t ? .type) {
        case qo.SetSitemap:
            return { ...e,
                sitemap: t.sitemap
            };
        case qo.RemoveProtectedContent:
            return { ...e,
                sitemap: { ...e.sitemap,
                    pages: e.sitemap.pages.map(o => T5(o, t.uuidsWithAccess, t.timestamp) ? { ...o,
                        content: null,
                        access: o.access.type === Bo.Password ? {
                            type: Bo.Password
                        } : o.access
                    } : o)
                }
            };
        case qo.SetPageContent:
            return { ...e,
                sitemap: { ...e.sitemap,
                    pages: e.sitemap.pages.map(o => o.uuid === t.uuid ? { ...o,
                        content: typeof t.content == "string" ? JSON.parse(t.content) : t.content
                    } : o)
                }
            };
        case qo.SetMobileTheming:
            return { ...e,
                sitemap: { ...e.sitemap,
                    theming: { ...e.sitemap.theming,
                        [De.Mobile]: t.theming
                    }
                }
            }
    }
    return e
}
const M5 = {
    isLoading: !1,
    data: {}
};

function O5(e = M5, t) {
    switch (t ? .type) {
        case Zr.StartLoading:
            return { ...e,
                isLoading: !0
            };
        case Zr.StopLoading:
            return { ...e,
                isLoading: !1
            };
        case Zr.SetData:
            return { ...e,
                data: { ...e.data,
                    [t.elementId]: t.data
                }
            };
        case Zr.SetMultipleData:
            return { ...e,
                data: { ...e.data,
                    ...t.items.reduce((o, r) => ({ ...o,
                        [r.elementId]: r.data
                    }), {})
                }
            }
    }
    return e
}
var ka = (e => (e.SetIsLoggedIn = "wbe/member/setIsLoggedIn", e.ResetState = "wbe/member/resetState", e))(ka || {});
const Kc = {
    isLoggedIn: !1
};

function A5(e = Kc, t) {
    switch (t ? .type) {
        case ka.SetIsLoggedIn:
            return { ...e,
                isLoggedIn: t.isLoggedIn
            };
        case ka.ResetState:
            return Kc
    }
    return e
}
var Qb = (e => (e.SetData = "wbe/runtime/setData", e))(Qb || {});
const W5 = {
    endpoints: {
        statistics: "",
        apiBase: null
    },
    flags: {
        isStatisticsEnabled: !0,
        isExternalLinksEnabled: !0,
        navigationMode: fu.Browser,
        isCookieBannerEnabled: !0,
        isGrChatsBeta: !1,
        isGrChatsEnabled: !0,
        isForcingDisabledPages: !1,
        isDataElementIdEnabled: !1,
        isCustomCodeDisabled: !1
    },
    initialPagePath: "/",
    origin: "/",
    websiteId: null,
    account: {
        isFreemium: !0,
        isTrial: !0,
        hasBadge: !1,
        grBadgeUrl: null
    }
};

function D5(e = W5, t) {
    switch (t ? .type) {
        case Qb.SetData:
            return { ...e,
                endpoints: { ...e.endpoints,
                    statistics: t.context.endpoints.statistics,
                    apiBase: t.context.endpoints.apiBase
                },
                flags: { ...e.flags,
                    ...t.flags
                },
                initialPagePath: t.context.url,
                origin: t.context.origin,
                account: {
                    isFreemium: t.experiments.freemium && t.context.isFreemium,
                    isTrial: t.experiments.freemium && t.context.isTrial,
                    hasBadge: t.context.hasBadge,
                    grBadgeUrl: t.context.grBadgeUrl
                },
                websiteId: t.context.websiteId
            }
    }
    return e
}

function N5() {
    return lf({
        sitemap: L5,
        asyncData: O5,
        member: A5,
        runtime: D5
    })
}

function U5(e) {
    const t = [];
    t.push(cf);
    const o = [sf(...t)];
    return df(N5(), e, uf(...o))
}
var Ao;
(function(e) {
    e.Get = "get", e.Post = "post", e.Put = "put", e.Patch = "patch", e.Delete = "delete", e.Head = "head"
})(Ao || (Ao = {}));
var Ci;
(function(e) {
    e.Omit = "omit", e.SameOrigin = "same-origin", e.Include = "include"
})(Ci || (Ci = {}));

function V5() {
    if (typeof globalThis.fetch != "function") throw new Error("Failed to resolve `globalThis.fetch` automatically");
    return globalThis.fetch
}
class H5 extends Error {
    constructor(t, o, r) {
        super(`Fetch failed: ${t} ${o}`, {
            cause: r
        }), Object.defineProperty(this, "innerError", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.innerError = r
    }
}
class j5 extends Error {
    constructor(t, o, r) {
        super(`Unsuccessful status code. ${t} ${o} resulted in ${r}`)
    }
}

function z5(e, t) {
    const o = t;
    return o.ensureSuccess = function() {
        if (!t.ok) throw new j5(e, t.url, t.status)
    }, o
}
var Ta;
(function(e) {
    e[e.Continue = 100] = "Continue", e[e.SwitchingProtocols = 101] = "SwitchingProtocols", e[e.Processing = 102] = "Processing", e[e.EarlyHints = 103] = "EarlyHints", e[e.Ok = 200] = "Ok", e[e.Created = 201] = "Created", e[e.Accepted = 202] = "Accepted", e[e.NonAuthoritativeInformation = 203] = "NonAuthoritativeInformation", e[e.NoContent = 204] = "NoContent", e[e.ResetContent = 205] = "ResetContent", e[e.PartialContent = 206] = "PartialContent", e[e.MultiStatus = 207] = "MultiStatus", e[e.AlreadyReported = 208] = "AlreadyReported", e[e.IMUsed = 226] = "IMUsed", e[e.MultipleChoice = 300] = "MultipleChoice", e[e.MovedPermanently = 301] = "MovedPermanently", e[e.Found = 302] = "Found", e[e.SeeOther = 303] = "SeeOther", e[e.NotModified = 304] = "NotModified", e[e.UseProxy = 305] = "UseProxy", e[e.SwitchProxy = 306] = "SwitchProxy", e[e.TemporaryRedirect = 307] = "TemporaryRedirect", e[e.PermanentRedirect = 308] = "PermanentRedirect", e[e.BadRequest = 400] = "BadRequest", e[e.Unauthorized = 401] = "Unauthorized", e[e.PaymentRequired = 402] = "PaymentRequired", e[e.Forbidden = 403] = "Forbidden", e[e.NotFound = 404] = "NotFound", e[e.MethodNotAllowed = 405] = "MethodNotAllowed", e[e.NotAcceptable = 406] = "NotAcceptable", e[e.ProxyAuthenticationRequired = 407] = "ProxyAuthenticationRequired", e[e.RequestTimeout = 408] = "RequestTimeout", e[e.Conflict = 409] = "Conflict", e[e.Gone = 410] = "Gone", e[e.LengthRequired = 411] = "LengthRequired", e[e.PreconditionFailed = 412] = "PreconditionFailed", e[e.PayloadTooLarge = 413] = "PayloadTooLarge", e[e.URITooLong = 414] = "URITooLong", e[e.UnsupportedMediaType = 415] = "UnsupportedMediaType", e[e.RangeNotSatisfiable = 416] = "RangeNotSatisfiable", e[e.ExpectationFailed = 417] = "ExpectationFailed", e[e.ImATeapot = 418] = "ImATeapot", e[e.MisdirectedRequest = 421] = "MisdirectedRequest", e[e.UnprocessableEntity = 422] = "UnprocessableEntity", e[e.Locked = 423] = "Locked", e[e.FailedDependency = 424] = "FailedDependency", e[e.UpgradeRequired = 426] = "UpgradeRequired", e[e.PreconditionRequired = 428] = "PreconditionRequired", e[e.TooManyRequests = 429] = "TooManyRequests", e[e.RequestHeaderFieldsTooLarge = 431] = "RequestHeaderFieldsTooLarge", e[e.UnavailableForLegalReasons = 451] = "UnavailableForLegalReasons", e[e.InternalServerError = 500] = "InternalServerError", e[e.NotImplemented = 501] = "NotImplemented", e[e.BadGateway = 502] = "BadGateway", e[e.ServiceUnavailable = 503] = "ServiceUnavailable", e[e.GatewayTimeout = 504] = "GatewayTimeout", e[e.HTTPVersionNotSupported = 505] = "HTTPVersionNotSupported", e[e.VariantAlsoNegotiates = 506] = "VariantAlsoNegotiates", e[e.InsufficientStorage = 507] = "InsufficientStorage", e[e.LoopDetected = 508] = "LoopDetected", e[e.NotExtended = 510] = "NotExtended", e[e.NetworkAuthenticationRequired = 511] = "NetworkAuthenticationRequired"
})(Ta || (Ta = {}));
var Qc;
(function(e) {
    e[e.Information = 103] = "Information", e[e.Success = 255] = "Success", e[e.Redirection = 319] = "Redirection", e[e.ClientError = 511] = "ClientError", e[e.ServerError = 511] = "ServerError"
})(Qc || (Qc = {}));
var wi;
(function(e) {
    e.Brackets = "brackets", e.Comma = "Comma"
})(wi || (wi = {}));
async function _5({
    method: e,
    url: t,
    query: o,
    body: r,
    headers: i = {},
    credentials: n = Ci.Include,
    fetch: l = V5(),
    options: s
}) {
    const u = r !== void 0 && Es(r);
    try {
        return z5(e, await l(o ? `${t}?${e0(o,"",s)}` : t.toString(), {
            method: e.toUpperCase(),
            credentials: n,
            headers: Object.assign(u ? {
                "content-type": "application/json"
            } : {}, Object.fromEntries(Object.entries(i).filter(([, c]) => c !== void 0))),
            body: u ? JSON.stringify(r) : r
        }))
    } catch (c) {
        throw new H5(e, t, c)
    }
}

function G5(e, t, o) {
    switch (o) {
        case wi.Brackets:
            return e.map(i => `${t}[]=${encodeURIComponent(i)}`).join("&");
        case wi.Comma:
            return `${t}=${e.map(i=>encodeURIComponent(i)).join(",")}`;
        default:
            const r = o;
            throw new Error(`Unsupported array format: ${r}`)
    }
}

function e0(e, t = "", o = {
    queryArrayFormat: wi.Comma
}) {
    if (typeof e == "string" || !Es(e) || !e) return e;
    const r = [],
        i = Object.keys(e).filter(n => Object.hasOwn(e, n));
    for (const n of i) {
        const l = encodeURIComponent(n),
            s = t ? `${t}[${l}]` : l,
            u = e[n];
        Array.isArray(u) ? r.push(G5(u, s, o.queryArrayFormat)) : Es(u) ? r.push(e0(u, s)) : r.push(`${s}=${encodeURIComponent(u)}`)
    }
    return r.filter(Boolean).join("&")
}

function Es(e) {
    return Object.prototype.toString.call(e) === "[object Object]" || Array.isArray(e)
}

function Z5(e, t) {
    let o = 0,
        r = e;
    const i = (n = r) => (r = n, o === Math.max(t.length - 1, 0) ? _5(r) : t[++o].handle(i, r));
    return t.length === 0 ? i() : t[o].handle(i, r)
}
class t0 {
    constructor(t, o = {}) {
        var r, i, n, l;
        Object.defineProperty(this, "cookies", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "userAgent", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "ipAddress", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "baseUrl", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "csrfProvider", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "endpointPrefix", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, "middlewares", {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: void 0
        }), this.cookies = t.cookies, this.userAgent = t.userAgent, this.ipAddress = t.ipAddress, this.baseUrl = (r = t.baseUrl) !== null && r !== void 0 ? r : "", this.csrfProvider = (i = o.csrfProvider) !== null && i !== void 0 ? i : null, this.endpointPrefix = (n = t.endpointPrefix) !== null && n !== void 0 ? n : "/api", this.middlewares = (l = t.middlewares) !== null && l !== void 0 ? l : []
    }
    request(t) {
        const o = { ...t,
            url: this.resolveUrl(t),
            headers: Object.assign({}, t.headers, this.cookies ? {
                cookie: this.cookies
            } : {}, this.userAgent ? {
                "user-agent": this.userAgent
            } : {}, this.ipAddress ? {
                "x-real-ip": this.ipAddress
            } : {}, this.csrfProvider ? {
                "csrf-token": this.csrfProvider.getToken()
            } : {})
        };
        return Z5(o, this.middlewares)
    }
    post(t, o) {
        return this.request({
            method: Ao.Post,
            url: t,
            body: o
        })
    }
    get(t, o, r) {
        return this.request({
            method: Ao.Get,
            url: t,
            query: o,
            options: r
        })
    }
    delete(t) {
        return this.request({
            method: Ao.Delete,
            url: t
        })
    }
    head(t) {
        return this.request({
            method: Ao.Head,
            url: t
        })
    }
    put(t, o) {
        return this.request({
            method: Ao.Put,
            url: t,
            body: o
        })
    }
    patch(t, o) {
        return this.request({
            method: Ao.Patch,
            url: t,
            body: o
        })
    }
    resolveUrl(t) {
        return t.url instanceof URL ? t.url.toString() : encodeURI(t.overrideUrl ? t.url.toString() : `${this.baseUrl}${this.endpointPrefix}${t.url}`)
    }
}
class sr {
    constructor(t) {
        this.client = t
    }
}
class q5 extends sr {
    getList() {
        return this.client.get("/feed")
    }
}
class J5 extends sr {
    getPages() {
        return this.client.get("/sitemap")
    }
}
class Y5 extends sr {
    verifyPassword(t, o) {
        return this.client.post(`/page/${t}/access`, {
            password: o
        })
    }
    getContent(t) {
        return this.client.get(`/page/${t}`)
    }
}
class X5 extends sr {
    login(t, o, r) {
        return this.client.post("/member/login", {
            email: t,
            password: o,
            remember: r
        })
    }
    verifyToken() {
        return this.client.get("/member/verify-token")
    }
    getDetails() {
        return this.client.get("/member/me")
    }
    create(t) {
        return this.client.post("/member", t)
    }
    logout() {
        return this.client.get("/member/logout")
    }
}
class K5 extends sr {
    submitForm(t) {
        return this.client.post("/contacts", t)
    }
}
class Q5 extends sr {
    submitForm(t, o) {
        return this.client.post(`/webinars/${t}/register-attendee`, o)
    }
}
class e$ extends sr {
    getProducts(t, o) {
        return this.client.get(`/shops/${t}/product-variants?search[id]=${o.join(",")}`)
    }
}
class t$ {
    constructor(t) {
        this.authorization = t
    }
    handle(t, o) {
        return this.authorization && !o.headers ? .authorization ? t({ ...o,
            headers: { ...o.headers,
                authorization: this.authorization
            },
            credentials: Ci.SameOrigin
        }) : t(o)
    }
}
class o$ extends sr {
    getContent(t) {
        return this.client.get(`/courses/${t}`)
    }
}
class Su {
    feed;
    sitemap;
    page;
    member;
    webForm;
    webinar;
    productBox;
    courses;
    constructor(t) {
        const o = Su.createClient(t);
        this.feed = new q5(o), this.sitemap = new J5(o), this.page = new Y5(o), this.member = new X5(o), this.webForm = new K5(o), this.webinar = new Q5(o), this.productBox = new e$(o), this.courses = new o$(o)
    }
    static createClient({
        baseUrl: t,
        middlewares: o,
        authorization: r,
        ...i
    }) {
        return new t0({ ...i,
            baseUrl: t ? .endsWith("/") ? t.substring(0, t.length - 1) : t,
            middlewares: [...o ? ? [], new t$(r)]
        })
    }
    get promoCodes() {
        throw new Error("Promo codes are not implemented")
    }
}
class r$ extends Error {
    constructor() {
        super("Cookie decryption is not available in the browser")
    }
}
class Ls {
    cookies;
    encryptionService;
    constructor(t) {
        this.cookies = t
    }
    get(t) {
        const o = this.cookies.split(";").map(r => r.trim()).map(r => r.split("=")).find(([r]) => t === r) ? .[1];
        return o ? decodeURIComponent(o) : null
    }
    set(t, o) {
        document.cookie = `${t}=${encodeURIComponent(o)}; path=/; max-age=31536000`
    }
    has(t) {
        return this.get(t) !== null
    }
    getDecrypted(t) {
        throw new r$
    }
    delete(t) {
        document.cookie = `${t}=0; max-age=0`
    }
}
const Iu = class {
    cookiesService;
    constructor(t) {
        this.cookiesService = new Ls(t)
    }
    getPasswordStorageKey(t) {
        return `${Iu.storageKey}|${t}`
    }
    get(t) {
        return this.cookiesService.getDecrypted(this.getPasswordStorageKey(t))
    }
    has(t) {
        return !!this.get(t)
    }
    set(t, o) {
        this.cookiesService.set(this.getPasswordStorageKey(t), o)
    }
};
let ca = Iu;
Et(ca, "storageKey", "page_password");
class n$ {
    storageService;
    constructor(t) {
        this.storageService = new ca(t)
    }
    hasStoredPassword(t) {
        return this.storageService.has(t)
    }
    getStoredPassword(t) {
        return this.storageService.get(t)
    }
    savePassword(t, o) {
        this.storageService.set(t, o)
    }
}

function i$() {
    return y(so, {
        children: [a("meta", {
            charSet: "utf-8"
        }), a("meta", {
            httpEquiv: "X-UA-Compatible",
            content: "IE=edge"
        }), a("meta", {
            name: "viewport",
            content: "width=device-width initial-scale=1"
        })]
    })
}
class a$ {
    _isCurrentPageProtected = !0;
    setIsPageProtected(t) {
        this._isCurrentPageProtected = t
    }
    isCurrentPageProtected() {
        return this._isCurrentPageProtected
    }
    hasAccess() {
        return !this.isCurrentPageProtected()
    }
}
var $t = (e => (e[e.OpenPage = 1] = "OpenPage", e[e.HitMap = 2] = "HitMap", e[e.ClickMap = 3] = "ClickMap", e[e.ViewForm = 4] = "ViewForm", e[e.ClickForm = 5] = "ClickForm", e[e.FormLead = 6] = "FormLead", e[e.ViewContactForm = 7] = "ViewContactForm", e[e.ClickContactForm = 8] = "ClickContactForm", e[e.ContactFormLead = 9] = "ContactFormLead", e[e.ViewLightbox = 10] = "ViewLightbox", e[e.ClickLightbox = 11] = "ClickLightbox", e[e.LightboxLead = 12] = "LightboxLead", e[e.Bandwidth = 13] = "Bandwidth", e))($t || {});

function l$() {
    return Oe()
}
class s$ {
    constructor() {}
    get(t) {
        return localStorage.getItem(t)
    }
    has(t) {
        return this.get(t) !== null
    }
    set(t, o) {
        localStorage.setItem(t, o)
    }
    delete(t) {
        localStorage.removeItem(t)
    }
}
const oo = class {
    storage;
    cookieConsentService;
    isEnabled;
    constructor(t, o) {
        this.storage = new s$, this.cookieConsentService = t, this.isEnabled = o, this.cookieConsentService.subscribe(r => {
            r === ut.Rejected && this.clear()
        })
    }
    get canWrite() {
        return this.isEnabled && this.cookieConsentService.state !== ut.Rejected
    }
    isUniquePageVisit(t) {
        const o = this.getPageVisits(),
            r = Number(o[t]);
        return Number.isSafeInteger(r) ? Date.now() - r >= oo.SessionLength : !0
    }
    isUniqueWebsiteVisit() {
        const t = this.storage.get(oo.WebsiteVisitName);
        if (t === null) return !0;
        const o = Number(t);
        return Number.isSafeInteger(o) ? Date.now() - o >= oo.SessionLength : !0
    }
    storePageVisit(t) {
        !this.canWrite || (this.storage.set(oo.PageVisitsName, JSON.stringify({ ...this.getPageVisits(),
            [t]: Date.now()
        })), this.storeWebsiteVisit())
    }
    storeWebsiteVisit() {
        !this.canWrite || this.storage.set(oo.WebsiteVisitName, Date.now().toString())
    }
    getPageVisits() {
        const t = this.storage.get(oo.PageVisitsName);
        if (t === null) return {};
        try {
            return JSON.parse(t)
        } catch {
            this.storage.delete(oo.PageVisitsName)
        }
        return {}
    }
    clear() {
        this.storage.delete(oo.PageVisitsName), this.storage.delete(oo.WebsiteVisitName)
    }
};
let Vr = oo;
Et(Vr, "PageVisitsName", "__sspv"), Et(Vr, "WebsiteVisitName", "__sswv"), Et(Vr, "SessionLength", 30 * 60 * 1e3);

function d$(e) {
    let t = null;
    return () => t !== null ? t : t = localStorage.getItem(e) !== null
}
const u$ = d$("logStats");
var Sr, Xr, La, o0;
const ku = class {
    constructor(t) {
        qi(this, Sr, void 0);
        qi(this, Xr, void 0);
        Et(this, "textDecoder");
        Et(this, "textEncoder");
        Gl(this, Sr, Array.from(t).map(o => o.charCodeAt(0))), Gl(this, Xr, gr(this, Sr).length), this.textDecoder = new TextDecoder, this.textEncoder = new TextEncoder
    }
    obfuscate(t) {
        return this.textEncoder.encode(t).map((o, r) => o ^ gr(this, Sr)[r % gr(this, Xr)])
    }
    decode(t) {
        return this.textDecoder.decode(this.decodeToBytes(t))
    }
    decodeToBytes(t) {
        const o = Array.from(t).map((r, i) => r ^ gr(this, Sr)[i % gr(this, Xr)]);
        return new Uint8Array(o)
    }
    static get Default() {
        return this._default ? ? (this._default = new ku(gr(this, La, o0)))
    }
};
let oi = ku;
Sr = new WeakMap, Xr = new WeakMap, La = new WeakSet, o0 = function() {
    return typeof process < "u" ? process.env.FRONT_DATA_OBFUSCATION_KEY : "Th!sISup3rS3cr3-|-Str1nG"
}, qi(oi, La), Et(oi, "_default");
const c$ = 1e3,
    h$ = 1e4,
    m$ = 3;
class b$ {
    events = [];
    timeout;
    config;
    isReady = !1;
    cookieConsentService;
    storageService;
    isLoggingEnabled;
    _tmpIsObfuscationEnabled;
    textDecoder;
    payloadVersion;
    client = new t0({});
    constructor(t) {
        this.config = t, this.cookieConsentService = this.config.cookieConsentService, this.storageService = new Vr(this.cookieConsentService, this.config.isEnabled), this.cookieConsentService.subscribe(() => this.sendAsync()), this.isLoggingEnabled = u$(), this._tmpIsObfuscationEnabled = !0, this.textDecoder = new TextDecoder, this.payloadVersion = this._tmpIsObfuscationEnabled ? 2 : 1
    }
    ready() {
        this.isReady = !0, this.addEventListeners()
    }
    get isEnabled() {
        return this.config.isEnabled
    }
    visitPage(t) {
        this.addEvent(this.prepareEvent($t.OpenPage, t.uuid, {
            url: t.url,
            path: location.pathname,
            query: location.search,
            isUniquePage: this.storageService.isUniquePageVisit(t.uuid),
            isUnique: this.storageService.isUniqueWebsiteVisit()
        })), this.storageService.storePageVisit(t.uuid), this.sendAsync()
    }
    viewForm(t) {
        this.addEvent(this.prepareEvent(t.isContact ? $t.ViewContactForm : $t.ViewForm, t.pageId, {
            isUniquePage: this.storageService.isUniquePageVisit(t.pageId),
            elementId: t.elementId
        })), this.sendAsync()
    }
    clickForm(t) {
        this.addEvent(this.prepareEvent(t.isContact ? $t.ClickContactForm : $t.ClickForm, t.pageId, {
            elementId: t.elementId
        })), this.sendAsync()
    }
    formLead(t) {
        this.addEvent(this.prepareEvent(t.isContact ? $t.ContactFormLead : $t.FormLead, t.pageId, {
            elementId: t.elementId
        })), this.sendAsync()
    }
    viewLightbox(t, o) {
        this.addEvent(this.prepareEvent($t.ViewLightbox, t, {
            isUniquePage: this.storageService.isUniquePageVisit(t),
            elementId: o
        })), this.sendAsync()
    }
    clickLightbox(t, o) {
        this.addEvent(this.prepareEvent($t.ClickLightbox, t, {
            elementId: o
        })), this.sendAsync()
    }
    lightboxLead(t) {
        this.addEvent(this.prepareEvent($t.LightboxLead, t.pageId, {
            elementId: t.elementId
        })), this.sendAsync()
    }
    pageClick(t, o) {
        this.addEvent(this.prepareEvent($t.HitMap, t.pageUuid, {
            elementId: t.elementId,
            position: {
                x: o.pageX,
                y: o.pageY
            }
        })), this.sendAsync()
    }
    hyperlinkClick(t, o) {
        this.addEvent(this.prepareEvent($t.ClickMap, t, { ...o
        })), this.sendAsync()
    }
    submitBandwidth(t, o) {
        this.addEvent(this.prepareEvent($t.Bandwidth, t, o)), this.sendAsync()
    }
    addEventListeners() {
        window.addEventListener("beforeunload", () => {
            this.sendSync(!0)
        }, !1), window.addEventListener("pagehide", () => {
            this.sendSync()
        }, !1), window.addEventListener("online", () => {
            this.sendAsync()
        }, !1)
    }
    prepareEvent(t, o, r = {}) {
        return {
            id: l$(),
            websiteId: this.config.websiteId,
            pageId: o,
            pageVariantId: o,
            type: t,
            payload: JSON.stringify({
                date: Date.now(),
                ...r
            }),
            version: this.payloadVersion
        }
    }
    logEvent(t) {
        !this.isLoggingEnabled || (console.groupCollapsed(`%cstatistics event %c${$t[t.type]}`, "color: deepskyblue;", "color: white;"), console.log(t), console.groupEnd())
    }
    addEvent(t) {
        this.logEvent(t), this.events.push(t)
    }
    sendAsync(t = c$) {
        window.clearTimeout(this.timeout), this.events.length > m$ ? this.sendSync() : this.timeout = window.setTimeout(() => this.sendSync(), t)
    }
    sendSync(t = !1) {
        !this.isEnabled || this.cookieConsentService.state === ut.Rejected || (this.isSystemReady() || t ? (this.makeRequest([...this.events]), this.events.length = 0) : this.sendAsync(h$))
    }
    makeRequest(t) {
        if (t.length === 0) return;
        const o = JSON.stringify({
            stats: t.map(r => this._tmpIsObfuscationEnabled ? { ...r,
                payload: Array.from(oi.Default.obfuscate(r.payload))
            } : r)
        });
        navigator.sendBeacon ? .(this.config.url, o) || this.client.request({
            method: Ao.Post,
            body: o,
            url: this.config.url,
            overrideUrl: !0,
            credentials: Ci.Omit,
            headers: {
                "content-type": "text/plain"
            }
        })
    }
    isSystemReady() {
        return this.isReady && navigator.onLine
    }
}
var ha = (e => (e.ReadOnly = "readonly", e.Redirect = "redirect", e.RefreshMobileTheming = "refreshMobileTheming", e))(ha || {});
const f$ = e => {
    e ? document.body ? .classList.add("readonly") : document.body ? .classList.remove("readonly")
};

function g$(e) {
    Mn ? .push(e ? ? "/"), Er() ? .scrollTo(0, 0)
}

function p$(e, t) {
    t(M4(e))
}
class y$ {
    handler;
    messageMapper = new Map().set(ha.ReadOnly, t => f$(!!t)).set(ha.Redirect, t => g$(t));
    init() {
        return this.dispose(), this.handler = this.handleMessage.bind(this), window ? .addEventListener("message", this.handler), this
    }
    registerDispatchActions(t) {
        this.messageMapper.set(ha.RefreshMobileTheming, o => p$(o, t))
    }
    dispose() {
        this.handler && window ? .removeEventListener("message", this.handler)
    }
    handleMessage(t) {
        if (typeof t.data == "object") {
            const {
                type: o,
                payload: r
            } = t.data;
            this.messageMapper.get(o) ? .(r)
        }
    }
}
class x$ {
    constructor() {
        return new Proxy(this, this)
    }
    storage = new Map;
    get(t, o) {
        return o in this ? this[o] : this.getItem(o)
    }
    set(t, o, r) {
        return this.setItem(o, r ? .toString()), !0
    }
    get length() {
        return this.storage.size
    }
    clear() {
        this.storage.clear()
    }
    getItem(t) {
        return this.storage.get(t) ? ? null
    }
    key(t) {
        return Array.from(this.storage.keys())[t] ? ? null
    }
    removeItem(t) {
        this.storage.delete(t)
    }
    setItem(t, o) {
        this.storage.set(t, `${o}`)
    }
}

function v$() {
    try {
        document.cookie.toString()
    } catch {
        Object.defineProperty(document, "cookie", {
            get() {
                return ""
            },
            set() {}
        })
    }
    try {
        localStorage.getItem("exampleKey")
    } catch {
        const t = new x$;
        Object.defineProperty(window, "localStorage", {
            get() {
                return t
            }
        })
    }
}
const r0 = x.createContext(null);

function $u() {
    const e = f.exports.useContext(r0);
    if (e === null) throw new Error("Missing MemberProfileSyncContext");
    return e
}
class C$ extends mB {
    constructor(t) {
        super(), this.statisticsService = t, this.register(Pb, this.statisticsService.clickForm.bind(this.statisticsService)), this.register(Rb, this.statisticsService.viewForm.bind(this.statisticsService)), this.register(Ib, this.statisticsService.formLead.bind(this.statisticsService)), this.register(Fb, this.statisticsService.lightboxLead.bind(this.statisticsService))
    }
    useElementClick(t) {
        return Sl(t)
    }
}
const w$ = ({
        children: e,
        ...t
    }) => a(Y3, {
        content: je(lr),
        ...t,
        children: e
    }),
    B$ = ({
        children: e,
        hasClassesAndIds: t
    }) => a(vy, {
        content: gl(),
        hasClassesAndIds: t,
        children: e
    }),
    S$ = e => {
        const {
            children: t,
            store: o,
            passwordService: r,
            pageProtectionService: i,
            statistics: n,
            cookieConsentService: l,
            referenceResolver: s
        } = e, u = f.exports.useMemo(() => o.getState(), [o]), c = f.exports.useMemo(() => ({
            isTrial: y4(u),
            isFreemium: Vb(u),
            hasBadge: x4(u),
            grBadgeUrl: v4(u)
        }), [u]), h = f.exports.useMemo(() => new C$(n), [n]);
        return a(Mb.Provider, {
            value: e.ssrResultContext,
            children: a(dC, {
                value: e.translation,
                children: a(hf, {
                    store: o,
                    children: a(w$, {
                        flags: Hb(u),
                        owner: c,
                        handlers: h,
                        cookieConsent: l,
                        referenceResolver: s,
                        children: a(mu.Provider, {
                            value: e.api,
                            children: a(zb.Provider, {
                                value: r,
                                children: a(vu.Provider, {
                                    value: i,
                                    children: a(Bl.Provider, {
                                        value: n,
                                        children: a(N4, {
                                            children: a(am.Provider, {
                                                value: e.spaNavigationService ? ? null,
                                                children: a(r0.Provider, {
                                                    value: e.memberProfileSyncService,
                                                    children: a(B$, {
                                                        hasClassesAndIds: e.hasClassesAndIds,
                                                        children: a(Zb.Provider, {
                                                            value: e.routingPubSub,
                                                            children: a(xu.Provider, {
                                                                value: e.componentResolver,
                                                                children: t
                                                            })
                                                        })
                                                    })
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    },
    Ma = class {
        cookiesService;
        store;
        listeners;
        _state = null;
        constructor(t) {
            this.listeners = [], this.cookiesService = new Ls(t)
        }
        get state() {
            if (this._state !== null) return this._state;
            const t = this.cookiesService.get(Ma.CookieName);
            return t === null || !(t in ut) ? this._state = ut.None : this._state = Number(t)
        }
        setCookieState(t) {
            this._state = t, this.cookiesService.set(Ma.CookieName, t), this.cookiesService = new Ls(document.cookie);
            for (const o of this.listeners) o(t)
        }
        acceptCookies() {
            this.setCookieState(ut.Accepted)
        }
        rejectCookies() {
            this.setCookieState(ut.Rejected)
        }
        subscribe(t) {
            return this.listeners.push(t), () => this.listeners = this.listeners.filter(o => o !== t)
        }
    };
let ma = Ma;
Et(ma, "CookieName", "wbe_cc");
class $$ {
    constructor(t) {
        this.history = t;
        const o = t.location,
            r = this.history.listen(i => {
                i.pathname !== o.pathname && (this._isClientSideNav = !0, r())
            })
    }
    _isClientSideNav = !1;
    navigate(t) {
        this.history.push(t)
    }
    get isClientSideNavigation() {
        return this._isClientSideNav
    }
}

function R$(e) {
    if (!!e) try {
        mf({
            dsn: "https://996d045fe5fa483cb6feaeda46a1a443@sentry.int.getresponse.com/285",
            release: "c62cc00",
            environment: "Production",
            ignoreErrors: ["top.GLOBALS", "originalCreateNotification", "canvas.contentDocument", "MyApp_RemoveAllHighlights", "http://tt.epicplay.com", "Can't find variable: ZiteReader", "jigsaw is not defined", "ComboSearch is not defined", "http://loading.retry.widdit.com/", "atomicFindClose", "fb_xd_fragment", "bmi_SafeAddOnload", "EBCallBackMessageReceived", "conduitPage", 'Cannot find module "."', "wmrzz_time2 is not defined", "vid_mate_check is not defined", "VK is not defined", "'VK' is not defined", "Cannot read property '_avast_submit' of undefined", "window.readmode.onReadModeDataReady is not a function", "MetaMask detected another web3", "Cannot read property 'closingEls' of undefined"],
            denyUrls: [/graph\.facebook\.com/i, /connect\.facebook\.net/i, /eatdifferent\.com\.woopra-ns\.com/i, /static\.woopra\.com\/js\/woopra\.js/i, /extensions\//i, /^chrome:\/\//i, /^chrome-extension:\/\//i, /127\.0\.0\.1:4001\/isrunning/i, /webappstoolbarba\.texthelp\.com\//i, /metrics\.itunes\.apple\.com\.edgesuite\.net\//i, /s\.ytimg\.com/i, /dgnria2-at-nuance-dot-com/i, /script\.hotjar\.com/i, /kaspersky-labs\.com/, /wistia\.com/, /io\.clickguard\.com/, /www\.gstatic\.com/, /cdn\.livechatinc\.com/, /appmakedev\.xyz/, /workdevapp\.com/, /untsorce\.cool/, /www\.googletagmanager\.com/, /s0\.2mdn\.net/, /[a-z]*\.googleapis\.com/, /static\.adsafeprotected\.com/, /surveys-static\.survicate\.com/, /com\.lge\.browser/, /rgvqcsxqge\.com/, /countmake\.cool/]
        })
    } catch (t) {
        console.error(t)
    }
}
class Ru extends Error {
    response;
    constructor(t) {
        super(`Invalid fetch response. URL: ${t.url}. Status: ${t.status}.`), this.response = t
    }
    static createFromResponse(t) {
        return new Ru(t)
    }
}

function n0() {}
class P$ {
    listeners = [];
    hasStarted = !1;
    hasFinished = !1;
    successResult = null;
    errorResult = null;
    api;
    constructor(t) {
        this.api = t
    }
    subscribe(t, o, r) {
        return this.addTask(t, o, r), () => {
            this.listeners = this.listeners.filter(i => i[0] !== t && i[1] !== o)
        }
    }
    forceRefresh() {
        for (const [, , t] of this.listeners) t();
        return this.hasStarted = this.hasFinished = !1, this.successResult = this.errorResult = null, this.startRequest()
    }
    addTask(t, o, r = n0) {
        if (this.listeners.push([t, o, r]), this.hasFinished) return this.successResult !== null ? t(this.successResult) : o(this.errorResult);
        this.hasStarted || this.startRequest()
    }
    async startRequest() {
        if (!(this.hasStarted || this.hasFinished)) {
            this.hasStarted = !0;
            try {
                const t = await this.api.member.getDetails();
                if (!t.ok) {
                    this.errorResult = Ru.createFromResponse(t);
                    return
                }
                this.successResult = await t.json()
            } catch (t) {
                this.errorResult = t
            } finally {
                this.hasFinished = !0, this.submitResult()
            }
        }
    }
    submitResult() {
        for (const [t, o] of this.listeners) {
            if (this.successResult !== null) {
                t(this.successResult);
                continue
            }
            o(this.errorResult)
        }
    }
}

function eh(e) {
    return {
        type: ka.SetIsLoggedIn,
        isLoggedIn: e
    }
}
class F$ {
    pageId;
    pageIdListeners = [];
    constructor(t = null) {
        this.pageId = t
    }
    getPageId() {
        return this.pageId
    }
    setPageId(t) {
        if (this.pageId !== t) {
            this.pageId = t;
            for (const o of this.pageIdListeners) o(this.pageId)
        }
    }
    subscribePageId(t) {
        return this.pageIdListeners.push(t), () => {
            this.pageIdListeners = this.pageIdListeners.filter(o => o !== t)
        }
    }
}

function I$(e) {
    const t = Md(),
        o = S4(e.pageId, t);
    return x.useEffect(() => (document.addEventListener("click", o, !0), () => {
        document.removeEventListener("click", o, !0)
    }), [o]), null
}
const k$ = Zt(e => {
        const {
            children: t,
            ...o
        } = e, r = Sl(o);
        return y(xb, { ...e,
            onClick: r,
            children: [a(I$, {
                pageId: e.pageUuid
            }), e.children]
        })
    }, {
        loadTranslation: !1
    }),
    T$ = Zt(e => {
        const t = Ge(e),
            o = bf(),
            r = ah(),
            i = pu(),
            n = Uh(),
            l = Dv(),
            s = Wv(),
            u = hl(),
            c = f.exports.useCallback((m, g) => {
                if (i.pageClick(e, g), Co.isContentPage(m)) {
                    if (g.preventDefault(), r.pathname !== m.url || r.hash) {
                        const p = m.isHomepage ? "/" : m.url;
                        o.push(p)
                    }
                } else if (Co.isExternalPage(m) && m.hyperlink.target === Ce.Self && (j.isInternalHyperlink(m.hyperlink) || j.isAnchorHyperlink(m.hyperlink))) {
                    g.preventDefault();
                    const p = u.render(m.hyperlink);
                    p !== r.pathname && o.push(p)
                }
            }, [i, e, r.pathname, r.hash, o, u]),
            h = qe(t.elementId);
        return a(Lx, {
            dataAts: I.Navbar,
            pagesWithChildren: n5(),
            $boxBorderColorRight: t.boxBorderColorRight,
            $boxBorderColorLeft: t.boxBorderColorLeft,
            $boxBorderColorBottom: t.boxBorderColorBottom,
            $boxBackgroundColor: t.boxBackgroundColor,
            $boxBorderColorTop: t.boxBorderColorTop,
            $boxBorderRadiusBottomLeft: t.boxBorderRadiusBottomLeft,
            $boxBorderRadiusBottomRight: t.boxBorderRadiusBottomRight,
            $boxBorderRadiusTopLeft: t.boxBorderRadiusTopLeft,
            $boxBorderRadiusTopRight: t.boxBorderRadiusTopRight,
            $boxBorderStyleBottom: t.boxBorderStyleBottom,
            $boxBorderStyleLeft: t.boxBorderStyleLeft,
            $boxBorderStyleRight: t.boxBorderStyleRight,
            $boxBorderStyleTop: t.boxBorderStyleTop,
            $boxBorderWidthBottom: t.boxBorderWidthBottom,
            $boxBorderWidthLeft: t.boxBorderWidthLeft,
            $boxBorderWidthRight: t.boxBorderWidthRight,
            $boxBorderWidthTop: t.boxBorderWidthTop,
            $boxPaddingBottom: t.boxPaddingBottom,
            $boxPaddingLeft: t.boxPaddingLeft,
            $boxPaddingRight: t.boxPaddingRight,
            $boxPaddingTop: t.boxPaddingTop,
            $boxShadowBlurRadius: t.boxShadowBlurRadius,
            $boxShadowColor: t.boxShadowColor,
            $boxShadowOffsetX: t.boxShadowOffsetX,
            $boxShadowOffsetY: t.boxShadowOffsetY,
            $boxShadowOpacity: t.boxShadowOpacity,
            $boxShadowSpreadRadius: t.boxShadowSpreadRadius,
            $isBoxBorderEnabled: t.isBoxBorderEnabled,
            $isBoxShadowEnabled: t.isBoxShadowEnabled,
            $isBoxRadiusEnabled: t.isBoxRadiusEnabled,
            $isBoxPaddingEnabled: t.isBoxPaddingEnabled,
            $textColor: t.textColor,
            $fontFamily: t.fontFamily,
            $fontSize: t.fontSize,
            $isBold: t.isBold,
            $isItalic: t.isItalic,
            $isUnderline: t.isUnderline,
            $hoverTextColor: t.hoverTextColor,
            $isHoverBold: t.isHoverBold,
            $isHoverItalic: t.isHoverItalic,
            $isHoverUnderline: t.isHoverUnderline,
            onClick: c,
            $position: t.elementPosition,
            className: t.className,
            direction: t.direction,
            align: t.align,
            isMobileView: n,
            hasMobileView: l,
            paletteColors: o5(),
            parentBackgroundColor: s,
            dataAttrs: h
        })
    }, {
        loadTranslation: !1
    }),
    E$ = Zt(({
        items: e
    }) => y("div", {
        children: [a("div", {
            children: "feed"
        }), y("div", {
            children: ["items:", e.map(t => a("div", {
                children: t.title
            }, t.title))]
        })]
    }), {
        loadTranslation: !1,
        async loadData({
            properties: e
        }) {
            return console.info("[Feed] load data", e.id), await new Promise(t => setTimeout(t, 2e3)), {
                items: [{
                    title: "abc"
                }, {
                    title: "def"
                }]
            }
        }
    }),
    L$ = Zt(e => {
        const [t, o] = x.useState(null), r = x.useCallback(async (s, u) => {
            if (u.preventDefault(), s.trim().length < 2) {
                o("Incorrect password");
                return
            }(await e.api.page.verifyPassword(e.protectedPageUuid, s)).ok ? (o(null), e.passwordViewController.navigateToPage()) : o("Incorrect password")
        }, [e.api, e.passwordViewController, e.protectedPageUuid]), i = x.useCallback(() => {
            o(null)
        }, []), n = Ge(je(Nb)), l = qe(e.elementId);
        return x.useEffect(() => {
            o(null)
        }, [e.protectedPageUuid]), a(qy, {
            typography: r5(),
            button: n,
            error: t,
            labelContent: e.labelContent,
            buttonContent: e.buttonContent,
            isInteractionEnabled: !0,
            onClick: Sl(e),
            onSubmit: r,
            onPasswordFieldFocus: i,
            className: e.className,
            dataAttrs: l
        }, e.protectedPageUuid)
    }, {
        loadTranslation: !1
    });

function M$() {
    return Ge(je(Nb))
}

function i0() {
    const e = M$();
    return f.exports.useMemo(() => ({
        $backgroundColor: e.backgroundColor,
        $borderColorBottom: e.borderColorBottom,
        $borderColorLeft: e.borderColorLeft,
        $borderColorRight: e.borderColorRight,
        $borderColorTop: e.borderColorTop,
        $shadowColor: e.shadowColor,
        $textColor: e.textColor,
        $paddingRight: e.paddingRight,
        $paddingLeft: e.paddingLeft,
        $paddingBottom: e.paddingBottom,
        $paddingTop: e.paddingTop,
        $fontFamily: e.fontFamily,
        $borderRadiusBottomLeft: e.borderRadiusBottomLeft,
        $borderRadiusBottomRight: e.borderRadiusBottomRight,
        $borderRadiusTopLeft: e.borderRadiusTopLeft,
        $borderRadiusTopRight: e.borderRadiusTopRight,
        $isRadiusEnabled: e.isRadiusEnabled,
        $borderStyleBottom: e.borderStyleBottom,
        $borderStyleLeft: e.borderStyleLeft,
        $borderStyleRight: e.borderStyleRight,
        $borderStyleTop: e.borderStyleTop,
        $borderWidthBottom: e.borderWidthBottom,
        $borderWidthLeft: e.borderWidthLeft,
        $borderWidthRight: e.borderWidthRight,
        $borderWidthTop: e.borderWidthTop,
        $fontSize: e.fontSize,
        $isBold: e.isBold,
        $isBorderEnabled: e.isBorderEnabled,
        $isItalic: e.isItalic,
        $isShadowEnabled: e.isShadowEnabled,
        $isUnderline: e.isUnderline,
        $shadowBlurRadius: e.shadowBlurRadius,
        $shadowOffsetX: e.shadowOffsetX,
        $shadowOffsetY: e.shadowOffsetY,
        $shadowOpacity: e.shadowOpacity,
        $shadowSpreadRadius: e.shadowSpreadRadius,
        $backgroundColorHover: e.backgroundColorHover,
        $textColorHover: e.textColorHover,
        $cursor: "pointer"
    }), [e])
}
const li = {
    Error: {
        Required: {
            Email: "Enter an email address",
            Password: "Enter a password"
        },
        Incorrect: {
            Password: "Password is too short. Use at least 6 characters",
            Global: "Incorrect email address or password. Please check them and try again."
        }
    }
};

function Ea(e, t, o = !1) {
    const r = [];
    return e.trim().length === 0 && r.push({
        message: li.Error.Required.Email,
        type: _t.Email
    }), t.trim().length === 0 && r.push({
        message: li.Error.Required.Password,
        type: _t.Password
    }), o && t.trim().length < 6 && t.trim().length !== 0 && r.push({
        message: li.Error.Incorrect.Password,
        type: _t.Password
    }), r.length ? r : null
}
const O$ = Zt(e => {
    const t = Ge(e),
        o = qe(t.elementId),
        r = i0(),
        i = je(Rl)[Ve.Paragraph],
        n = je(Cl).find(b => b.name === D.Two),
        l = Dn(),
        s = $u(),
        [u, c] = f.exports.useState(!1),
        [h, m] = f.exports.useState(null),
        g = x.useCallback(async (b, C) => {
            if (C.preventDefault(), u) return;
            const {
                email: w,
                password: B,
                isRememberMeEnabled: S
            } = b;
            if (m(Ea(w, B)), !Ea(w, B)) try {
                c(!0), (await t.api.member.login(w, B, S)).ok ? (await s.forceRefresh(), t.loginViewController ? t.loginViewController.navigateToPage() : l.navigate("/")) : m([{
                    message: li.Error.Incorrect.Global,
                    type: _t.Global
                }])
            } catch {} finally {
                c(!1)
            }
        }, [u, t.api.member, t.loginViewController, s, l]),
        p = x.useCallback(() => {
            m(null)
        }, []);
    return a(Ho, {
        $boxBackgroundColor: t.boxBackgroundColor,
        $isBoxBorderEnabled: t.isBoxBorderEnabled,
        $boxBorderColorRight: t.boxBorderColorRight,
        $boxBorderColorLeft: t.boxBorderColorLeft,
        $boxBorderColorBottom: t.boxBorderColorBottom,
        $boxBorderColorTop: t.boxBorderColorTop,
        $boxBorderStyleBottom: t.boxBorderStyleBottom,
        $boxBorderStyleLeft: t.boxBorderStyleLeft,
        $boxBorderStyleRight: t.boxBorderStyleRight,
        $boxBorderStyleTop: t.boxBorderStyleTop,
        $boxBorderWidthBottom: t.boxBorderWidthBottom,
        $boxBorderWidthLeft: t.boxBorderWidthLeft,
        $boxBorderWidthRight: t.boxBorderWidthRight,
        $boxBorderWidthTop: t.boxBorderWidthTop,
        $boxBorderRadiusBottomLeft: t.boxBorderRadiusBottomLeft,
        $boxBorderRadiusBottomRight: t.boxBorderRadiusBottomRight,
        $boxBorderRadiusTopLeft: t.boxBorderRadiusTopLeft,
        $boxBorderRadiusTopRight: t.boxBorderRadiusTopRight,
        $boxPaddingBottom: t.boxPaddingBottom,
        $boxPaddingLeft: t.boxPaddingLeft,
        $boxPaddingRight: t.boxPaddingRight,
        $boxPaddingTop: t.boxPaddingTop,
        $isBoxShadowEnabled: t.isBoxShadowEnabled,
        $isBoxPaddingEnabled: t.isBoxPaddingEnabled,
        $isBoxRadiusEnabled: t.isBoxRadiusEnabled,
        $boxShadowBlurRadius: t.boxShadowBlurRadius,
        $boxShadowColor: t.boxShadowColor,
        $boxShadowOffsetX: t.boxShadowOffsetX,
        $boxShadowOffsetY: t.boxShadowOffsetY,
        $boxShadowOpacity: t.boxShadowOpacity,
        $boxShadowSpreadRadius: t.boxShadowSpreadRadius,
        ...o,
        children: a(tx, {
            isInteractionEnabled: !0,
            isRememberMeVisible: t.isRememberMeVisible,
            emailLabelContent: t.emailLabelContent,
            passwordLabelContent: t.passwordLabelContent,
            rememberMeLabelContent: t.rememberMeLabelContent,
            submitButtonContent: t.submitButtonContent,
            onSubmit: g,
            onClick: Sl(t),
            className: t.className,
            fontFamily: t.fontFamily ? ? i.fontFamily,
            fontSize: t.fontSize ? ? i.fontSize,
            isBold: t.isBold ? ? i.isBold,
            isUnderline: t.isUnderline ? ? i.isUnderline,
            isItalic: t.isItalic ? ? i.isItalic,
            color: t.color ? ? n.value,
            buttonProps: r,
            isSubmitting: u,
            error: h,
            onFocus: p
        })
    })
}, {
    loadTranslation: !1
});

function a0() {
    return f.exports.useContext(Fs)
}
const A$ = Zt(e => {
        const t = Ge(e),
            o = qe(t.elementId),
            r = $u(),
            [i, n] = f.exports.useState(!0),
            [l, s] = f.exports.useState(null),
            u = je(w => Wb(w).uuid),
            c = je(Rl)[Ve.Paragraph],
            h = je(Cl).find(w => w.name === D.Two),
            m = je(w => wl(w, we.Register) ? .uuid ? ? "missing page"),
            g = a0(),
            p = Dn(),
            b = Ms(),
            C = f.exports.useCallback(async () => {
                await t.api.member.logout(), await r.forceRefresh(), (!g || g.access.type === Bo.Members) && p.navigate("/"), b(L4())
            }, [b, r, p, g, t.api.member]);
        return f.exports.useEffect(() => r.subscribe(w => {
            s(w), n(!1)
        }, () => {
            n(!1)
        }, () => {
            n(!0), s(null)
        }), [r]), a(Ho, {
            $boxBackgroundColor: t.boxBackgroundColor,
            $isBoxBorderEnabled: t.isBoxBorderEnabled,
            $boxBorderColorRight: t.boxBorderColorRight,
            $boxBorderColorLeft: t.boxBorderColorLeft,
            $boxBorderColorBottom: t.boxBorderColorBottom,
            $boxBorderColorTop: t.boxBorderColorTop,
            $boxBorderStyleBottom: t.boxBorderStyleBottom,
            $boxBorderStyleLeft: t.boxBorderStyleLeft,
            $boxBorderStyleRight: t.boxBorderStyleRight,
            $boxBorderStyleTop: t.boxBorderStyleTop,
            $boxBorderWidthBottom: t.boxBorderWidthBottom,
            $boxBorderWidthLeft: t.boxBorderWidthLeft,
            $boxBorderWidthRight: t.boxBorderWidthRight,
            $boxBorderWidthTop: t.boxBorderWidthTop,
            $boxBorderRadiusBottomLeft: t.boxBorderRadiusBottomLeft,
            $boxBorderRadiusBottomRight: t.boxBorderRadiusBottomRight,
            $boxBorderRadiusTopLeft: t.boxBorderRadiusTopLeft,
            $boxBorderRadiusTopRight: t.boxBorderRadiusTopRight,
            $boxPaddingBottom: t.boxPaddingBottom,
            $boxPaddingLeft: t.boxPaddingLeft,
            $boxPaddingRight: t.boxPaddingRight,
            $boxPaddingTop: t.boxPaddingTop,
            $isBoxShadowEnabled: t.isBoxShadowEnabled,
            $isBoxPaddingEnabled: t.isBoxPaddingEnabled,
            $isBoxRadiusEnabled: t.isBoxRadiusEnabled,
            $boxShadowBlurRadius: t.boxShadowBlurRadius,
            $boxShadowColor: t.boxShadowColor,
            $boxShadowOffsetX: t.boxShadowOffsetX,
            $boxShadowOffsetY: t.boxShadowOffsetY,
            $boxShadowOpacity: t.boxShadowOpacity,
            $boxShadowSpreadRadius: t.boxShadowSpreadRadius,
            ...o,
            children: gt(i, a(Jb, {
                size: Pr.Medium
            }), a(Aw, {
                isMember: l !== null,
                fontFamily: t.fontFamily ? ? c.fontFamily,
                fontSize: t.fontSize ? ? c.fontSize,
                isBold: t.isBold ? ? c.isBold,
                isUnderline: t.isUnderline ? ? c.isUnderline,
                isItalic: t.isItalic ? ? c.isItalic,
                color: t.color ? ? h.value,
                hoverColor: t.hoverColor ? ? h.value,
                align: t.align,
                loginText: t.loginText,
                registerText: t.registerText,
                isEditMode: !1,
                loginPageId: u,
                registerPageId: m,
                email: l ? .email,
                avatar: a(Dw, {
                    email: l ? .email
                }),
                displayMode: t.mode,
                firstName: l ? .firstName,
                lastName: l ? .lastName,
                onLogoutClick: C
            }))
        })
    }, {
        loadTranslation: !1
    }),
    W$ = Zt(e => {
        const t = i0(),
            o = Ge(e),
            r = je(Rl)[Ve.Paragraph],
            i = je(Cl).find(b => b.name === D.Two),
            n = $u(),
            l = Dn(),
            [s, u] = f.exports.useState(!1),
            [c, h] = f.exports.useState(null),
            m = qe(o.elementId),
            g = f.exports.useCallback(async (b, C) => {
                if (C.preventDefault(), s) return;
                const {
                    email: w,
                    password: B
                } = b;
                if (h(Ea(w, B, !0)), !Ea(w, B, !0)) try {
                    u(!0), (await o.api.member.create({
                        email: w,
                        password: B
                    })).ok ? (await n.forceRefresh(), l.navigate("/")) : h([{
                        message: li.Error.Incorrect.Global,
                        type: _t.Global
                    }])
                } catch {} finally {
                    u(!1)
                }
            }, [s, n, l, o.api.member]),
            p = x.useCallback(() => {
                h(null)
            }, []);
        return a(Ho, {
            $boxBackgroundColor: o.boxBackgroundColor,
            $isBoxBorderEnabled: o.isBoxBorderEnabled,
            $boxBorderColorRight: o.boxBorderColorRight,
            $boxBorderColorLeft: o.boxBorderColorLeft,
            $boxBorderColorBottom: o.boxBorderColorBottom,
            $boxBorderColorTop: o.boxBorderColorTop,
            $boxBorderStyleBottom: o.boxBorderStyleBottom,
            $boxBorderStyleLeft: o.boxBorderStyleLeft,
            $boxBorderStyleRight: o.boxBorderStyleRight,
            $boxBorderStyleTop: o.boxBorderStyleTop,
            $boxBorderWidthBottom: o.boxBorderWidthBottom,
            $boxBorderWidthLeft: o.boxBorderWidthLeft,
            $boxBorderWidthRight: o.boxBorderWidthRight,
            $boxBorderWidthTop: o.boxBorderWidthTop,
            $boxBorderRadiusBottomLeft: o.boxBorderRadiusBottomLeft,
            $boxBorderRadiusBottomRight: o.boxBorderRadiusBottomRight,
            $boxBorderRadiusTopLeft: o.boxBorderRadiusTopLeft,
            $boxBorderRadiusTopRight: o.boxBorderRadiusTopRight,
            $boxPaddingBottom: o.boxPaddingBottom,
            $boxPaddingLeft: o.boxPaddingLeft,
            $boxPaddingRight: o.boxPaddingRight,
            $boxPaddingTop: o.boxPaddingTop,
            $isBoxShadowEnabled: o.isBoxShadowEnabled,
            $isBoxPaddingEnabled: o.isBoxPaddingEnabled,
            $isBoxRadiusEnabled: o.isBoxRadiusEnabled,
            $boxShadowBlurRadius: o.boxShadowBlurRadius,
            $boxShadowColor: o.boxShadowColor,
            $boxShadowOffsetX: o.boxShadowOffsetX,
            $boxShadowOffsetY: o.boxShadowOffsetY,
            $boxShadowOpacity: o.boxShadowOpacity,
            $boxShadowSpreadRadius: o.boxShadowSpreadRadius,
            ...m,
            children: a(Nw, {
                fontFamily: o.fontFamily ? ? r.fontFamily,
                fontSize: o.fontSize ? ? r.fontSize,
                isBold: o.isBold ? ? r.isBold,
                isUnderline: o.isUnderline ? ? r.isUnderline,
                isItalic: o.isItalic ? ? r.isItalic,
                color: o.color ? ? i.value,
                isInteractionEnabled: !0,
                emailLabelContent: o.emailLabelContent,
                passwordLabelContent: o.passwordLabelContent,
                submitButtonContent: o.submitButtonContent,
                onSubmit: g,
                buttonProps: t,
                isSubmitting: s,
                error: c,
                onFocus: p
            })
        })
    }, {
        loadTranslation: !1
    }),
    D$ = Zt(e => {
        const {
            children: t,
            position: o,
            trigger: r,
            minScrollPercentageWhenTriggers: i,
            size: n,
            customHeightPercentage: l,
            customWidthPercentage: s,
            name: u,
            overlayColor: c,
            boxBackgroundColor: h,
            isBoxBorderEnabled: m,
            boxBorderColorRight: g,
            boxBorderColorLeft: p,
            boxBorderColorBottom: b,
            boxBorderColorTop: C,
            boxBorderStyleBottom: w,
            boxBorderStyleLeft: B,
            boxBorderStyleRight: S,
            boxBorderStyleTop: $,
            boxBorderWidthBottom: L,
            boxBorderWidthLeft: M,
            boxBorderWidthRight: F,
            boxBorderWidthTop: A,
            boxBorderRadiusBottomLeft: z,
            boxBorderRadiusBottomRight: _,
            boxBorderRadiusTopLeft: Z,
            boxBorderRadiusTopRight: G,
            boxPaddingBottom: H,
            boxPaddingLeft: te,
            boxPaddingRight: oe,
            boxPaddingTop: re,
            isBoxShadowEnabled: Q,
            isBoxPaddingEnabled: J,
            isBoxRadiusEnabled: ee,
            boxShadowBlurRadius: le,
            boxShadowColor: ue,
            boxShadowOffsetX: me,
            boxShadowOffsetY: ie,
            boxShadowOpacity: Y,
            boxShadowSpreadRadius: ae,
            showAfterUnit: X,
            showAfterValue: ge,
            customFrequencyUnit: ce,
            customFrequencyValue: de,
            elementId: ne,
            frequency: Se,
            className: Fe,
            pageUuid: $e
        } = Ge(e), [Ie, xe] = x.useState(!1), ke = qe(e.elementId), Le = x.useRef(null), We = Le ? .current, {
            isDisabled: Ke
        } = uy({
            customFrequencyUnit: ce,
            customFrequencyValue: de,
            elementId: ne,
            frequency: Se
        }), at = pu();
        x.useEffect(() => {
            at.viewLightbox($e, ne)
        }, [ne, at, $e]);
        const wt = x.useCallback(() => {
                xe(tt => tt ? !0 : !Ke())
            }, [Ke]),
            ht = x.useCallback(() => {
                xe(!1)
            }, []);
        sy({
            minScrollPercentageWhenTriggers: i,
            onTrigger: wt,
            trigger: r,
            scrollableElementSelector: `#${yb}`,
            delay: vh([ge, X])
        }), x.useEffect(() => {
            const tt = mt => {
                mt.key === Tr.Escape && ht()
            };
            return Ie && document.addEventListener("keydown", tt), () => {
                document.removeEventListener("keydown", tt)
            }
        }, [ht, Ie]);
        const Bt = Jx({
            size: n,
            customHeightPercentage: l,
            customWidthPercentage: s
        });
        return x.useEffect(() => {
            if (!We) return;
            const tt = mt => {
                const yt = ["BUTTON", "A"],
                    xt = mt.target;
                yt.includes(xt.tagName) && at.clickLightbox($e, ne)
            };
            return We.addEventListener("click", tt), () => {
                We.removeEventListener("click", tt)
            }
        }, [ne, We, at, $e]), a("div", {
            ref: Le,
            children: a(Zx, {
                className: Fe,
                $overlayColor: c,
                $boxBackgroundColor: h,
                $isBoxBorderEnabled: m,
                $boxBorderColorRight: g,
                $boxBorderColorLeft: p,
                $boxBorderColorBottom: b,
                $boxBorderColorTop: C,
                $boxBorderStyleBottom: w,
                $boxBorderStyleLeft: B,
                $boxBorderStyleRight: S,
                $boxBorderStyleTop: $,
                $boxBorderWidthBottom: L,
                $boxBorderWidthLeft: M,
                $boxBorderWidthRight: F,
                $boxBorderWidthTop: A,
                $boxBorderRadiusBottomLeft: z,
                $boxBorderRadiusBottomRight: _,
                $boxBorderRadiusTopLeft: Z,
                $boxBorderRadiusTopRight: G,
                $boxPaddingBottom: H,
                $boxPaddingLeft: te,
                $boxPaddingRight: oe,
                $boxPaddingTop: re,
                $isBoxShadowEnabled: Q,
                $isBoxPaddingEnabled: J,
                $isBoxRadiusEnabled: ee,
                $boxShadowBlurRadius: le,
                $boxShadowColor: ue,
                $boxShadowOffsetX: me,
                $boxShadowOffsetY: ie,
                $boxShadowOpacity: Y,
                $boxShadowSpreadRadius: ae,
                "data-ats-canvas-view-element": I.Lightbox,
                position: o,
                isOpen: Ie,
                onClose: ht,
                size: Bt,
                title: u,
                ...ke,
                children: t
            })
        })
    }, {
        loadTranslation: !1
    });
class ia {
    static tryToCall(t, o, ...r) {
        return typeof o != "function" ? (console.warn("Failed to call lead tracking script:", t, "with args:", r), null) : o(...r)
    }
    static sendAdWords(t, o) {
        return new Promise((r, i) => {
            const n = new Image;
            n.onload = () => r(), n.onerror = i, n.src = `//www.googleadservices.com/pagead/conversion/${encodeURIComponent(t)}/?label=${encodeURIComponent(o)}&amp;guid=ON&amp;script=0`
        })
    }
    static sendFbPixel() {
        return this.tryToCall("fbq", window.fbq, "track", "Lead")
    }
    static sendGoogleAnalytics(t) {
        return this.tryToCall("ga", window.gtag, "event", "Lead", {
            pageName: t
        })
    }
    static sendGoogleTagManager() {
        this.tryToCall("gtm", window.dataLayer ? .push.bind(window.dataLayer), {
            event: "Lead"
        })
    }
}

function l0() {
    const e = Pl(),
        t = a0();
    return f.exports.useCallback(() => e.analytics.analytics.isEnabled ? Promise.all(e.analytics.analytics.platforms.map(o => o.type === Te.GoogleAds ? ia.sendAdWords(o.id, o.label) : o.type === Te.GoogleAnalytics ? ia.sendGoogleAnalytics(t.name) : o.type === Te.GoogleTagManager ? ia.sendGoogleTagManager() : o.type === Te.FacebookPixel ? ia.sendFbPixel() : Promise.resolve())).then(n0).catch(o => {}) : Promise.resolve(), [e, t])
}
const s0 = {
        1057: K.Elements.Form.Errors.NumberFormat,
        1058: K.Elements.Form.Errors.DateTimeFormatInvalid,
        1059: K.Elements.Form.Errors.FormatInvalid,
        1060: K.Elements.Form.Errors.IpInvalid,
        1061: K.Elements.Form.Errors.FormatInvalid,
        1062: K.Elements.Form.Errors.Required,
        1063: K.Elements.Form.Errors.ValueTooLong,
        1064: K.Elements.Form.Errors.CharactersNotAllowed,
        1065: K.Elements.Form.Errors.FormatInvalid,
        1066: K.Elements.Form.Errors.FormatInvalid,
        1067: K.Elements.Form.Errors.PhonePrefixInvalid,
        1068: K.Elements.Form.Errors.NumberFormat,
        1069: K.Elements.Form.Errors.UrlInvalid,
        1071: K.Elements.Form.Errors.FormatInvalid,
        1030: K.Elements.SubscriptionForm.Errors.AlreadySubscribed,
        1008: K.Elements.SubscriptionForm.Errors.AlreadySubscribed,
        1077: K.Elements.SubscriptionForm.Errors.WrongPhoneNumber,
        9003: K.Elements.Form.Errors.ValueTooLong
    },
    N$ = Zt(e => {
        const t = l0(),
            o = f.exports.useCallback(async r => {
                try {
                    const i = await e.api.webForm.submitForm(r);
                    if (i.ok) return await t(), new _S;
                    if (i.status === Ta.BadRequest) {
                        const n = await i.json();
                        return new zS(n, s0)
                    }
                    return new Hc
                } catch {
                    return new Hc
                }
            }, [e.api.webForm, t]);
        return a(Tb, { ...e,
            onSubmit: o
        })
    }, {
        loadTranslation: !0
    }),
    U$ = s0,
    V$ = Zt(e => {
        const t = l0(),
            o = f.exports.useCallback(async i => {
                try {
                    const n = await e.api.webinar.submitForm(e.webinarId, i);
                    if (n.ok) {
                        const l = await n.json();
                        return l.status === "redirect" && (window.location.href = l.url), await t(), new ZS
                    }
                    if (n.status === Ta.BadRequest) {
                        const l = await n.json();
                        return new GS(l, U$)
                    }
                    return new jc
                } catch {
                    return new jc
                }
            }, [e.api.webinar, e.webinarId, t]),
            r = x.useMemo(() => e.startsAtDate ? Intl.DateTimeFormat(Intl.DateTimeFormat().resolvedOptions().locale, {
                dateStyle: "long",
                timeStyle: "short"
            }).format(new Date(e.startsAtDate)) : null, [e.startsAtDate]);
        return a(Eb, { ...e,
            onSubmit: o,
            notAvailableInfo: a(zt, {
                id: K.Elements.WebinarForm.NotAvailableInfo
            }),
            webinarDate: r
        })
    }, {
        loadTranslation: !0
    }),
    H$ = Zt(() => null, {
        loadTranslation: !1
    });
class j$ {
    componentsMap = new Map([
        [Jo.Body, k$],
        [I.Navbar, T$],
        [I.EnterPasswordForm, L$],
        [I.LoginForm, O$],
        ["feed", E$],
        [I.Form, N$],
        [I.Webinar, V$],
        [I.Lightbox, D$],
        [I.MemberProfile, A$],
        [I.RegisterForm, W$]
    ]);
    constructor(t) {
        t ? .isCustomCodeDisabled && this.componentsMap.set(I.CustomHtml, H$)
    }
    resolveByType(t) {
        return Promise.resolve(this.getSync(t))
    }
    hasResolved() {
        return !0
    }
    getSync(t) {
        return this.componentsMap.get(t) ? ? Ln.resolveByType(t) ? ? null
    }
    isKnown(t) {
        return this.getSync(t) !== null
    }
}

function z$({
    locale: e,
    messages: t
}) {
    const o = new sC({
        locale: e
    });
    return o.setTranslations(t), o
}

function _$(e) {
    return e.startsWith("/-/courses")
}
v$();
const G$ = ih.hydrate,
    lo = window.__INITIAL_DATA__,
    Z$ = z$(window.__W_TRANSLATION__),
    q$ = window.__W_UUID__,
    d0 = new Su({
        baseUrl: lo.runtime.endpoints.apiBase ? .url,
        authorization: lo.runtime.endpoints.apiBase ? .authorization
    }),
    u0 = new ma(document.cookie),
    J$ = gu(lo),
    Pu = new b$({
        websiteId: q$,
        url: h4(lo),
        isEnabled: m4(lo),
        cookieConsentService: u0,
        isObfuscationEnabled: J$.experiments.statsObfuscation.isEnabled
    }),
    Bi = U5(lo);
Pu.ready();
new y$().init().registerDispatchActions(Bi.dispatch);
const c0 = new P$(d0);
c0.subscribe(() => Bi.dispatch(eh(!0)), () => Bi.dispatch(eh(!1)));
F5(b4(lo), Ub(lo));
R$({
    FRONT_DIRECT_STORAGE_HOST: "multimedia.getresponse.com",
    FRONT_GETRESPONSE_STORAGE_CDN: "m.gr-cdn-3.com",
    FRONT_WBE_STORAGE_CDN: "us-wbe-img.gr-cdn.com",
    FRONT_AUTH_ENABLED: "true",
    FRONT_BANDWIDTH_ORIGINS: "us-wbe-img.gr-cdn.com,multimedia.getresponse.com,m.gr-cdn-3.com,us-wbe.gr-cdn.com,https://wbe-stats-collector.local.gr-dev.me,iframegrchatbeta.web.app,i.getresponse.chat",
    FRONT_DATA_OBFUSCATION_KEY: "Th!sISup3rS3cr3-|-Str1nG",
    BASE_URL: "https://us-wbe.gr-cdn.com/public/js/",
    MODE: "production",
    DEV: !1,
    PROD: !0
}.FRONT_CLIENT_SENTRY === "true");
const Y$ = Ab(lo, Ub(lo)),
    h0 = new F$(Y$ ? .page.uuid),
    X$ = new j$({
        isCustomCodeDisabled: Hb(lo).isCustomCodeDisabled
    });
requestAnimationFrame(() => Kb.init(Pu, h0));
if (window.__grBootstrapReact !== !1) {
    const e = {};
    G$(y(S$, {
        store: Bi,
        pageProtectionService: new a$,
        passwordService: new n$(document.cookie),
        statistics: Pu,
        cookieConsentService: u0,
        spaNavigationService: new $$(Mn),
        memberProfileSyncService: c0,
        api: d0,
        routingPubSub: h0,
        componentResolver: X$,
        ssrResultContext: e,
        hasClassesAndIds: n4(Bi.getState()),
        translation: Z$,
        children: [a(i$, {}), a(Ts, {
            children: a(B5, {
                isCustomSystemPage: _$(Mn.location.pathname)
            })
        })]
    }), document.getElementById("app"))
}
export {
    Z4 as C, Ru as I, bu as u
};