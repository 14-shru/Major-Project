import {
    r as s,
    n as i,
    o as a
} from "./vendor.377da65b.js";
import {
    u as l,
    I as d,
    C as m
} from "./index.080c91a1.js";

function f() {
    s.exports.useEffect(() => {
        const e = document.createElement("script");
        return e.type = "module", e.src = "https://jss.getresponse.com/js/bootstrap.js?app=mobile-editor&env=szymon", document.head.appendChild(e), () => e.remove()
    }, [])
}
const c = "@getrevenue/display";

function h() {
    return typeof grImportApp < "u" ? grImportApp(c) : new Promise(e => {
        globalThis.onGrUniversalBootstrapLoad = o => o(c).then(r => e(r))
    })
}

function g(e, o) {
    const r = l(),
        [n, p] = s.exports.useState(null);
    f(), s.exports.useEffect(() => {
        (async () => {
            try {
                const t = await r.courses.getContent(e);
                if (!t.ok) throw d.createFromResponse(t);
                p(await t.json())
            } catch (t) {
                throw alert(`Failed to fetch course: ${String(t)}`), t
            }
        })()
    }, [r.courses, e]), s.exports.useEffect(() => {
        const t = h();
        if (n === null) return;
        let u;
        return (async () => u = (await t).mount(o.current, {
            content: JSON.parse(n.content),
            name: n.name
        }).unmount)(), () => u ? .()
    }, [o, n])
}

function j(e) {
    const o = s.exports.useRef(null);
    return g(e.courseId, o), i("div", {
        id: "course-content-root",
        children: [a(m, {}), a("div", {
            id: "course-app",
            ref: o
        })]
    })
}
export {
    j as
    default
};