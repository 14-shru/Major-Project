/**
 * Minified by jsDelivr using Terser v5.3.0.
 * Original file: /npm/pikaday@1.8.2/pikaday.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */